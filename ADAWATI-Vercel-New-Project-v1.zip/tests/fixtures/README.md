# Upload fixtures

These local, deterministic files unblock automated upload workflows. The
canonical paths are listed in `manifest.json`; test agents should resolve them
from the repository root and upload those exact paths.

- `test-image.png`: square 512×512 PNG for compression, QR logo, favicon,
  circular crop, and resize flows.
- `test-image-alt.png`: second square PNG for multi-image merge flows.
- `sample-a.pdf` and `sample-b.pdf`: two valid PDFs for merge tests.
- `sample-multipage.pdf`: four-page PDF for split and PDF-to-JPG tests.
- `sample-editable.pdf`: two-page PDF for edit-and-save tests.
- `sample-ocr.pdf`: high-contrast PDF with predictable English OCR text.

Run `node tests/fixtures/generate-fixtures.mjs` only when the deterministic
fixtures need to be regenerated.
