import { copyFile, mkdir, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

const fixtureDirectory = path.dirname(fileURLToPath(import.meta.url));
const projectDirectory = path.resolve(fixtureDirectory, "../..");
const fixedDate = new Date("2026-01-01T00:00:00.000Z");

await mkdir(fixtureDirectory, { recursive: true });
await copyFile(
  path.join(projectDirectory, "public/icon-512.png"),
  path.join(fixtureDirectory, "test-image.png"),
);
await copyFile(
  path.join(projectDirectory, "public/brand/adawati-app-icon.png"),
  path.join(fixtureDirectory, "test-image-alt.png"),
);

async function createPdf(fileName, pages) {
  const document = await PDFDocument.create();
  document.setTitle(`ADAWATI test fixture: ${fileName}`);
  document.setAuthor("ADAWATI automated tests");
  document.setSubject("Reusable local upload fixture");
  document.setCreator("ADAWATI fixture generator");
  document.setProducer("ADAWATI fixture generator");
  document.setCreationDate(fixedDate);
  document.setModificationDate(fixedDate);
  const regular = await document.embedFont(StandardFonts.Helvetica);
  const bold = await document.embedFont(StandardFonts.HelveticaBold);

  for (const [index, content] of pages.entries()) {
    const page = document.addPage([612, 792]);
    page.drawRectangle({
      x: 36,
      y: 36,
      width: 540,
      height: 720,
      borderColor: rgb(0.03, 0.33, 0.91),
      borderWidth: 2,
      color: rgb(0.97, 0.98, 1),
    });
    page.drawText("ADAWATI AUTOMATED TEST FIXTURE", {
      x: 64,
      y: 690,
      size: 24,
      font: bold,
      color: rgb(0.02, 0.1, 0.3),
    });
    page.drawText(content, {
      x: 64,
      y: 610,
      size: 28,
      font: bold,
      color: rgb(0, 0, 0),
    });
    page.drawText(`Page ${index + 1} of ${pages.length}`, {
      x: 64,
      y: 560,
      size: 18,
      font: regular,
      color: rgb(0.18, 0.22, 0.3),
    });
    page.drawText("Safe local file for upload, processing, and download checks.", {
      x: 64,
      y: 500,
      size: 16,
      font: regular,
      color: rgb(0.18, 0.22, 0.3),
    });
  }

  await writeFile(
    path.join(fixtureDirectory, fileName),
    await document.save({ useObjectStreams: false, addDefaultPage: false }),
  );
}

await createPdf("sample-a.pdf", ["MERGE SOURCE A", "SECOND PAGE A"]);
await createPdf("sample-b.pdf", ["MERGE SOURCE B"]);
await createPdf("sample-multipage.pdf", [
  "SPLIT PAGE ONE",
  "SPLIT PAGE TWO",
  "SPLIT PAGE THREE",
  "SPLIT PAGE FOUR",
]);
await createPdf("sample-editable.pdf", [
  "EDITABLE PDF SOURCE",
  "SAVE CHANGES CHECK",
]);
await createPdf("sample-ocr.pdf", [
  "ADAWATI OCR SAMPLE 2026",
  "CLEAR BLACK TEXT FOR RECOGNITION",
]);
