import ExcelJS from "exceljs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const fixtureDirectory = dirname(fileURLToPath(import.meta.url));

async function writeWorkbook(name, { cached, unsupported = false }) {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Calculations");
  sheet.addRow(["Item", "Quantity", "Unit price", "Calculated value"]);
  sheet.addRow(["First", 3, 12.5]);
  sheet.addRow(["Second", 4, 10]);
  sheet.getCell("D2").value = cached
    ? { formula: "B2*C2", result: 37.5 }
    : { formula: "B2*C2" };
  sheet.getCell("D3").value = cached
    ? { formula: "B3+C3", result: 14 }
    : { formula: "B3+C3" };
  sheet.getCell("C4").value = "SUM";
  sheet.getCell("D4").value = cached
    ? { formula: "SUM(D2:D3)", result: 51.5 }
    : { formula: "SUM(D2:D3)" };
  sheet.getCell("C5").value = "AVERAGE";
  sheet.getCell("D5").value = cached
    ? { formula: "AVERAGE(D2:D3)", result: 25.75 }
    : { formula: "AVERAGE(D2:D3)" };
  sheet.getCell("C6").value = "Addition";
  sheet.getCell("D6").value = cached
    ? { formula: "D2+D3", result: 51.5 }
    : { formula: "D2+D3" };
  if (unsupported) {
    sheet.getCell("C7").value = "Unsupported IF";
    sheet.getCell("D7").value = { formula: "IF(B2>0,B2,0)" };
  }
  sheet.columns = [
    { width: 18 },
    { width: 12 },
    { width: 14 },
    { width: 20 },
  ];
  await workbook.xlsx.writeFile(join(fixtureDirectory, name));
}

await writeWorkbook("excel-formulas-cached.xlsx", { cached: true });
await writeWorkbook("excel-formulas-uncached.xlsx", { cached: false });
await writeWorkbook("excel-formulas-unsupported.xlsx", {
  cached: false,
  unsupported: true,
});
