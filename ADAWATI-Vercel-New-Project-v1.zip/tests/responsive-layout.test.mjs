import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const css = await readFile(
  new URL("../app/globals.css", import.meta.url),
  "utf8",
);
const minCss = css.replace(/\s+/g, "");
const adminSource = await readFile(
  new URL("../app/components/AdminDashboard.tsx", import.meta.url),
  "utf8",
);
const selectSource = await readFile(
  new URL("../app/components/CustomSelect.tsx", import.meta.url),
  "utf8",
);

test("public pages include desktop, tablet, and compact-phone breakpoints", () => {
  for (const width of [1100, 820, 680, 520, 430, 370]) {
    assert.match(
      minCss,
      new RegExp(`@media\\(max-width:${width}px\\)`),
      `missing ${width}px breakpoint`,
    );
  }
  assert.match(
    minCss,
    /\.all-tools-grid\{[^}]*grid-template-columns:repeat\(2/,
  );
  assert.match(
    minCss,
    /@media\(max-width:430px\)[\s\S]*?\.metric-grid\{grid-template-columns:1fr/,
  );
  assert.match(
    minCss,
    /@media\(max-width:520px\)[\s\S]*?\.shopping-list>div\{[^}]*grid-template-columns:/,
  );
});

test("mobile navigation is fixed, opaque, and reserves safe bottom space", () => {
  assert.match(
    minCss,
    /@media\(max-width:760px\)[\s\S]*?body\{padding-bottom:calc\(82px\+env\(safe-area-inset-bottom,0px\)\)/,
  );
  assert.match(
    minCss,
    /@media\(max-width:760px\)[\s\S]*?\.bottom-nav\{[^}]*position:fixed[^}]*bottom:0[^}]*inset-inline:0[^}]*background:var\(--surface\)/,
  );
});

test("admin pages reflow while wide data tables remain internally scrollable", () => {
  assert.match(minCss, /\.admin-tools-table-scroll\{[^}]*overflow:auto/);
  assert.match(
    minCss,
    /@media\(max-width:1100px\)[\s\S]*?\.admin-settings-layout\{grid-template-columns:1fr/,
  );
  assert.match(
    minCss,
    /@media\(max-width:900px\)[\s\S]*?\.seo-center-grid\{grid-template-columns:1fr/,
  );
  assert.match(
    minCss,
    /@media\(max-width:720px\)[\s\S]*?\.admin-message-stats,\.admin-settings-summary\{grid-template-columns:1fr/,
  );
  assert.match(
    minCss,
    /\.admin-settings-fields\{[^}]*repeat\(auto-fit,minmax\(min\(100%,280px\),1fr\)\)/,
  );
  assert.match(
    minCss,
    /\.admin-pin-settings-grid\{[^}]*repeat\(auto-fit,minmax\(min\(100%,230px\),1fr\)\)/,
  );
});

test("weekly usage days are keyboard and touch selectable", () => {
  assert.match(adminSource, /aria-label="اختر يوماً لعرض استخداماته"/);
  assert.match(
    adminSource,
    /aria-pressed=\{selectedDay\?\.date === day\.date\}/,
  );
  assert.match(adminSource, /onClick=\{\(\) => setSelectedDate\(day\.date\)\}/);
  assert.match(css, /\.admin-chart-labels button\.active/);
  assert.match(adminSource, /آخر 6 أشهر/);
  assert.match(
    adminSource,
    /fetch\(`\/api\/admin\/searches\?range=\$\{days\}`/,
  );
  assert.match(adminSource, /<CustomSelect/);
  assert.match(selectSource, /aria-haspopup="listbox"/);
});
