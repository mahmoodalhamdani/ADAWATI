import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import ts from "typescript";

const registrySource = await readFile(
  new URL("../lib/registry.ts", import.meta.url),
  "utf8",
);
const workspaceSource = await readFile(
  new URL("../app/components/ToolWorkspace.tsx", import.meta.url),
  "utf8",
);
const additionalSource = await readFile(
  new URL("../app/components/AdditionalToolWorkspaces.tsx", import.meta.url),
  "utf8",
);
const prioritySource = await readFile(
  new URL("../app/components/PriorityToolWorkspaces.tsx", import.meta.url),
  "utf8",
);
const formulaSource = await readFile(
  new URL("../app/components/FormulaToolWorkspaces.tsx", import.meta.url),
  "utf8",
);
const pdfSource = await readFile(
  new URL("../app/components/PdfToolWorkspaces.tsx", import.meta.url),
  "utf8",
);
const printDesignSource = await readFile(
  new URL("../app/components/PrintDesignWorkspaces.tsx", import.meta.url),
  "utf8",
);
const registryFile = ts.createSourceFile(
  "registry.ts",
  registrySource,
  ts.ScriptTarget.Latest,
  true,
  ts.ScriptKind.TS,
);

function stringValue(node) {
  return ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)
    ? node.text
    : null;
}

function arrayStrings(node) {
  return ts.isArrayLiteralExpression(node)
    ? node.elements.map(stringValue).filter((value) => value !== null)
    : [];
}

function findArray(name) {
  let found = null;
  registryFile.forEachChild((node) => {
    if (!ts.isVariableStatement(node)) return;
    for (const declaration of node.declarationList.declarations) {
      if (
        ts.isIdentifier(declaration.name) &&
        declaration.name.text === name &&
        ts.isArrayLiteralExpression(declaration.initializer)
      )
        found = declaration.initializer;
    }
  });
  return found;
}

const categoryArray = findArray("categories");
const toolArray = findArray("tools");
const categories = categoryArray.elements.map((element) => {
  const property = element.properties.find(
    (item) => ts.isPropertyAssignment(item) && item.name.getText() === "slug",
  );
  return stringValue(property.initializer);
});
const tools = toolArray.elements.map((element) => ({
  slug: stringValue(element.arguments[0]),
  category: stringValue(element.arguments[4]),
  questions: arrayStrings(element.arguments[8]),
  related: arrayStrings(element.arguments[9]),
}));

test("registry contains 146 unique complete tools in valid categories", () => {
  const slugs = tools.map((tool) => tool.slug);
  assert.equal(tools.length, 146);
  assert.equal(new Set(slugs).size, tools.length);
  assert.ok(!slugs.includes("image-watermark-remover"));
  for (const tool of tools) {
    assert.ok(tool.slug);
    assert.ok(
      categories.includes(tool.category),
      `${tool.slug} has an invalid category`,
    );
    assert.ok(
      tool.questions.length >= 2,
      `${tool.slug} needs useful questions`,
    );
    for (const related of tool.related)
      assert.ok(
        slugs.includes(related),
        `${tool.slug} links to missing ${related}`,
      );
  }
});

test("public support email uses the ADAWATI identity", () => {
  assert.match(registrySource, /email:\s*"support@adawati\.site"/);
});

test("every registered tool is routed to an intentional workspace", () => {
  const explicit = new Set();
  for (const source of [
    workspaceSource,
    additionalSource,
    prioritySource,
    formulaSource,
    pdfSource,
    printDesignSource,
  ]) {
    for (const match of source.matchAll(/"([a-z0-9-]+)"/g)) {
      if (tools.some((tool) => tool.slug === match[1])) explicit.add(match[1]);
    }
  }
  const fallback = new Set([
    "random-picker",
    "random-number",
    "team-divider",
    "random-string",
  ]);
  const missing = tools
    .map((tool) => tool.slug)
    .filter((slug) => !explicit.has(slug) && !fallback.has(slug));
  assert.deepEqual(missing, []);
});

test("all additional workspace slugs have a matching switch case", () => {
  const listMatch = additionalSource.match(
    /additionalToolSlugs\s*=\s*\[([^\]]+)\]/,
  );
  assert.ok(listMatch);
  const listed = [...listMatch[1].matchAll(/"([a-z0-9-]+)"/g)].map(
    (match) => match[1],
  );
  const cases = [...additionalSource.matchAll(/case\s+"([a-z0-9-]+)"/g)].map(
    (match) => match[1],
  );
  assert.deepEqual(new Set(cases), new Set(listed));
});

test("image collage offers 36 distinct square, landscape, and portrait layouts", () => {
  const block = additionalSource.match(/const collageTemplates:[\s\S]+?\n\];/);
  assert.ok(block);
  const ids = [...block[0].matchAll(/\{\s*id:\s*"([^"]+)"/g)].map(
    (match) => match[1],
  );
  assert.equal(ids.length, 36);
  assert.equal(new Set(ids).size, 36);
  assert.match(block[0], /aspect:\s*\[1,\s*1\]/);
  assert.match(block[0], /aspect:\s*\[(?:16,\s*9|3,\s*2|21,\s*9)\]/);
  assert.match(block[0], /aspect:\s*\[(?:4,\s*5|9,\s*16|2,\s*3)\]/);
});
