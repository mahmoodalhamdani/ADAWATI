import test from "node:test";
import assert from "node:assert/strict";
import { cleanText } from "../lib/text-cleaner.ts";

test("text cleaner removes spacing without rewriting Arabic content", () => {
  const source = "ابدأ   بتحليل الصور المرجعية\n\n\tثم أنشئ نظام التصميم";
  assert.equal(
    cleanText(source),
    "ابدأ بتحليل الصور المرجعية\nثم أنشئ نظام التصميم",
  );
});

test("text cleaner never injects unrelated words", () => {
  const source = "رسالة صباحية جميلة";
  assert.equal(cleanText(source), source);
});
