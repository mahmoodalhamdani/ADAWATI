import assert from "node:assert/strict";
import test from "node:test";
import { PDFDocument } from "pdf-lib";
import { fillPdfForm, inspectPdfForm } from "../lib/pdf-forms.ts";

async function formFixture() {
  const document = await PDFDocument.create();
  const page = document.addPage([500, 700]);
  const form = document.getForm();
  const name = form.createTextField("full_name");
  name.addToPage(page, { x: 40, y: 600, width: 250, height: 28 });
  const approved = form.createCheckBox("approved");
  approved.addToPage(page, { x: 40, y: 550, width: 20, height: 20 });
  const choice = form.createDropdown("department");
  choice.addOptions(["Design", "Engineering"]);
  choice.addToPage(page, { x: 40, y: 500, width: 180, height: 28 });
  return document.save({ useObjectStreams: false });
}

test("PDF Forms discovers actual interactive fields and their choices", async () => {
  const fields = await inspectPdfForm(await formFixture());
  assert.deepEqual(
    fields.map(({ name, type, options }) => ({ name, type, options })),
    [
      { name: "full_name", type: "text", options: [] },
      { name: "approved", type: "checkbox", options: [] },
      {
        name: "department",
        type: "choice",
        options: ["Design", "Engineering"],
      },
    ],
  );
});

test("PDF Forms writes submitted values into a readable PDF result", async () => {
  const output = await fillPdfForm(await formFixture(), {
    full_name: "Alice Example",
    approved: "true",
    department: "Engineering",
  });
  const document = await PDFDocument.load(output);
  const form = document.getForm();
  assert.equal(form.getTextField("full_name").getText(), "Alice Example");
  assert.equal(form.getCheckBox("approved").isChecked(), true);
  assert.deepEqual(form.getDropdown("department").getSelected(), [
    "Engineering",
  ]);
  assert.equal(document.getPageCount(), 1);
});

test("PDF Forms can flatten values into permanent page content", async () => {
  const output = await fillPdfForm(
    await formFixture(),
    { full_name: "Final", approved: "false", department: "Design" },
    true,
  );
  const document = await PDFDocument.load(output);
  assert.equal(document.getPageCount(), 1);
  assert.equal(document.getForm().getFields().length, 0);
});
