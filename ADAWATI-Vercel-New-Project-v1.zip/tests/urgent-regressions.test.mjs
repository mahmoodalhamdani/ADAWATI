import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { jsonErrorDetails } from "../lib/json-tools.ts";
import { categoryForSearch } from "../lib/registry.ts";

const read = (path) => readFile(new URL(`../${path}`, import.meta.url), "utf8");

test("date and time controls commit their visible values to React state", async () => {
  const [picker, priority, additional, formula] = await Promise.all([
    read("app/components/ModernDatePicker.tsx"),
    read("app/components/PriorityToolWorkspaces.tsx"),
    read("app/components/AdditionalToolWorkspaces.tsx"),
    read("app/components/FormulaToolWorkspaces.tsx"),
  ]);
  assert.match(picker, /type="date"/);
  assert.match(picker, /value=\{value\}/);
  assert.match(picker, /onInput=.*commit/s);
  assert.match(priority, /timesheet-\$\{row\.id\}-date/);
  assert.match(priority, /maintenance-last-date/);
  assert.match(additional, /id="work-hours-start"/);
  assert.match(additional, /id="work-hours-end"/);
  assert.match(additional, /id="timezone-source-time"/);
  assert.match(formula, /formula-\$\{slug\}-\$\{field\.key\}/);
});

test("file conversion flows preserve structure instead of flattening to text", async () => {
  const [workspace, printHelper, excelHelper] = await Promise.all([
    read("app/components/PdfToolWorkspaces.tsx"),
    read("lib/browser-print.ts"),
    read("lib/office-print.ts"),
  ]);
  assert.match(workspace, /@aiden0z\/pptx-renderer/);
  assert.match(workspace, /\[data-slide-index\].*break-after:page/s);
  assert.match(workspace, /wordToPrintMarkup/);
  assert.match(workspace, /renderExcelForPrint/);
  assert.match(workspace, /parsePrintableHtml/);
  assert.match(printHelper, /printWindow\.print\(\)/);
  assert.match(excelHelper, /new ExcelJS\.Workbook\(\)/);
  assert.match(excelHelper, /cell\.border/);
  assert.match(excelHelper, /cell\.alignment/);
  assert.match(excelHelper, /value\.result/);
});

test("OCR creates a searchable PDF and refuses an empty recognition result", async () => {
  const workspace = await read("app/components/PdfToolWorkspaces.tsx");
  assert.match(workspace, /\{ pdf: true, blocks: true \}/);
  assert.match(workspace, /ocr-no-recognizable-text/);
  assert.match(workspace, /adawati-ocr-searchable\.pdf/);
  assert.match(workspace, /searchablePdf\.copyPages/);
});

test("repair and compression validate output before claiming success", async () => {
  const workspace = await read("app/components/PdfToolWorkspaces.tsx");
  const repairStart = workspace.indexOf('slug === "pdf-repair"');
  const validation = workspace.indexOf("validateRepairedPdf(repaired)", repairStart);
  const publish = workspace.indexOf('publishPdf(repaired, "adawati-repaired.pdf")', repairStart);
  assert.ok(repairStart >= 0 && validation > repairStart && publish > validation);
  assert.match(workspace, /output\.byteLength < file\.size/);
  assert.match(workspace, /تم الاحتفاظ بالأصل بدون ادعاء نجاح الضغط/);
});

test("PDF comparison reports real small-file units and page dimensions", async () => {
  const workspace = await read("app/components/PdfToolWorkspaces.tsx");
  assert.match(workspace, /if \(bytes < 1024\)/);
  assert.match(workspace, /Page dimensions/);
  assert.match(workspace, /widthMm/);
});

test("JSON errors expose line, column, and reason", () => {
  const source = '{\n  "valid": true,\n  "broken":,\n  "after": 2\n}';
  let caught;
  try {
    JSON.parse(source);
  } catch (error) {
    caught = error;
  }
  const details = jsonErrorDetails(source, caught);
  assert.equal(details.line, 3);
  assert.ok(details.column >= 3);
  assert.ok(details.reason.length > 3);
});

test("accessibility helpers link labels and move focus through the skip link", async () => {
  const [fields, skip, chrome] = await Promise.all([
    read("app/components/AccessibleFieldBehavior.tsx"),
    read("app/components/SkipLink.tsx"),
    read("app/components/SiteChrome.tsx"),
  ]);
  assert.match(fields, /label\.htmlFor = control\.id/);
  assert.match(fields, /aria-label/);
  assert.match(fields, /aria-describedby/);
  assert.match(skip, /main\.focus\(/);
  assert.match(skip, /scrollIntoView/);
  assert.match(chrome, /id="main-content" tabIndex=\{-1\}/);
});

test("bill deadlines and task reminders are complete persistent flows", async () => {
  const [core, planner] = await Promise.all([
    read("app/components/ToolWorkspace.tsx"),
    read("app/components/TaskPlannerWorkspace.tsx"),
  ]);
  assert.match(core, /Bill payment deadline reminder/);
  assert.match(core, /Bill name/);
  assert.match(core, /Reminder frequency/);
  assert.match(core, /Save bill reminder/);
  assert.match(core, /minjaz-bill-reminders/);
  assert.match(planner, /Reminder time/);
  assert.match(planner, /Task priority/);
  assert.match(planner, /Task completion plan/);
  assert.match(planner, /reminderTime/);
  assert.match(planner, /priority/);
});

test("text hashing, category filtering, currencies, and percentage adjustments are explicit", async () => {
  const [core, priority, explorer] = await Promise.all([
    read("app/components/ToolWorkspace.tsx"),
    read("app/components/PriorityToolWorkspaces.tsx"),
    read("app/components/ToolsExplorer.tsx"),
  ]);
  assert.match(priority, /Text to hash/);
  assert.match(priority, /new TextEncoder\(\)\.encode\(textInput\)/);
  assert.match(priority, /Direct text/);
  assert.match(explorer, /effectiveCategory/);
  assert.match(explorer, /item\.category === effectiveCategory/);
  assert.match(explorer, /onChange=\{\(event\) => setQuery\(event\.target\.value\)\}/);
  assert.equal(categoryForSearch("الأدوات السريعة"), "quick");
  assert.equal(categoryForSearch("Quick Tools"), "quick");
  assert.match(core, /Each person pays: \$\{share\.toFixed\(2\)\} \$\{currency\}/);
  assert.match(core, /Apply a discount/);
  assert.match(core, /Total after discount/);
  assert.match(core, /Apply an increase/);
});
