import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { formulaDefinitions } from "../app/components/FormulaToolWorkspaces.tsx";
import { searchTools, toolMap, tools } from "../lib/registry.ts";

const printWorkspace = await readFile(
  new URL("../app/components/PrintDesignWorkspaces.tsx", import.meta.url),
  "utf8",
);
const additionalWorkspace = await readFile(
  new URL("../app/components/AdditionalToolWorkspaces.tsx", import.meta.url),
  "utf8",
);
const coreWorkspace = await readFile(
  new URL("../app/components/ToolWorkspace.tsx", import.meta.url),
  "utf8",
);
const formulaWorkspace = await readFile(
  new URL("../app/components/FormulaToolWorkspaces.tsx", import.meta.url),
  "utf8",
);
const pdfWorkspace = await readFile(
  new URL("../app/components/PdfToolWorkspaces.tsx", import.meta.url),
  "utf8",
);
const routing = await readFile(
  new URL("../lib/workspace-routing.ts", import.meta.url),
  "utf8",
);
const homeSearch = await readFile(
  new URL("../app/components/HomeSearch.tsx", import.meta.url),
  "utf8",
);
const toolsExplorer = await readFile(
  new URL("../app/components/ToolsExplorer.tsx", import.meta.url),
  "utf8",
);
const toolsPage = await readFile(
  new URL("../app/tools/page.tsx", import.meta.url),
  "utf8",
);
const taskPlanner = await readFile(
  new URL("../app/components/TaskPlannerWorkspace.tsx", import.meta.url),
  "utf8",
);
const priorityWorkspace = await readFile(
  new URL("../app/components/PriorityToolWorkspaces.tsx", import.meta.url),
  "utf8",
);

test("page setup, QR print, flyer, and poster flows are routed and searchable", () => {
  for (const slug of [
    "page-setup",
    "qr-print-designer",
    "flyer-maker",
    "poster-maker",
  ]) {
    assert.ok(toolMap[slug], slug);
    assert.match(routing, new RegExp(`"${slug}"`));
  }
  assert.equal(searchTools("فلاير")[0].slug, "flyer-maker");
  assert.equal(searchTools("بوستر")[0].slug, "poster-maker");
  assert.equal(searchTools("إعداد الصفحة")[0].slug, "page-setup");
  assert.match(printWorkspace, /Paper size/);
  assert.match(printWorkspace, /Page orientation/);
  assert.match(printWorkspace, /Download layout PDF/);
  assert.match(printWorkspace, /Add QR content to design/);
  assert.match(printWorkspace, /Download print PNG/);
});

test("trip planning and work-hour reset controls are visible and state-backed", () => {
  assert.match(additionalWorkspace, /Starting point/);
  assert.match(additionalWorkspace, /Destination/);
  assert.match(additionalWorkspace, /Suggested fuel stops/);
  assert.match(additionalWorkspace, /fuelStopPlan/);
  assert.match(additionalWorkspace, /Clear and reset/);
  assert.match(additionalWorkspace, /setCalculationMode\(""\)/);
  assert.match(additionalWorkspace, /setDistance\(""\)/);
  assert.match(additionalWorkspace, /setHasResult\(false\)/);
  assert.match(additionalWorkspace, /setStart\(""\)/);
  assert.match(additionalWorkspace, /setEnd\(""\)/);
  assert.match(additionalWorkspace, /setResult\(null\)/);
});

test("fuel economy conversion and both discount modes are explicit", () => {
  assert.match(additionalWorkspace, /Fuel economy/);
  assert.match(additionalWorkspace, /L\/100 km/);
  assert.match(additionalWorkspace, /km\/L/);
  assert.match(additionalWorkspace, /mpg \(US\)/);
  assert.match(coreWorkspace, /Calculate price after discount/);
  assert.match(coreWorkspace, /I have the price after discount/);
  assert.match(coreWorkspace, /Price after discount/);
  assert.match(coreWorkspace, /aria-pressed/);
});

test("reported planner, budget, fuel, age, statistics, and favicon flows expose real controls", () => {
  assert.equal(searchTools("حاسبة العمر")[0].slug, "age-calculator");
  assert.equal(searchTools("مخطط مهام")[0].slug, "task-planner");
  assert.equal(searchTools("مقارنة قيمتين")[0].slug, "value-comparison");
  assert.match(taskPlanner, /Task title/);
  assert.match(taskPlanner, /Due date/);
  assert.match(taskPlanner, /Save and create task/);
  assert.match(taskPlanner, /type="checkbox"/);
  assert.match(taskPlanner, /localStorage\.setItem/);
  assert.match(additionalWorkspace, /Daily spending target/);
  assert.match(additionalWorkspace, /Save budget and target/);
  assert.match(additionalWorkspace, /Actual fuel used in liters/);
  assert.match(additionalWorkspace, /Trip cost \(\$\{currency\}\)/);
  assert.match(coreWorkspace, /Total hours/);
  assert.match(coreWorkspace, /Total minutes/);
  assert.match(coreWorkspace, /Total seconds/);
  assert.match(coreWorkspace, /Count/);
  assert.match(coreWorkspace, /Clear and reset/);
  assert.match(priorityWorkspace, /Website URL/);
  assert.match(priorityWorkspace, /Load website icon/);
});

test("percentage change and add-workdays modes expose explicit controls", () => {
  assert.match(coreWorkspace, /Percentage change/);
  assert.match(coreWorkspace, /Starting value/);
  assert.match(coreWorkspace, /Ending value/);
  assert.match(coreWorkspace, /Add workdays/);
  assert.match(coreWorkspace, /Workdays to add/);
  assert.match(coreWorkspace, /Due date/);
});

test("target margin and tile material cost produce currency-aware results", () => {
  const margin = formulaDefinitions["profit-margin-calculator"];
  assert.ok(margin.fields.some((field) => field.key === "targetMargin"));
  const marginDefaults = Object.fromEntries(
    margin.fields.map((field) => [field.key, field.value]),
  );
  const marginResult = margin.calculate(marginDefaults);
  assert.ok(
    marginResult.results.some(
      (item) => item.en.includes("Recommended price") && item.kind === "money",
    ),
  );

  const tile = formulaDefinitions["tile-calculator"];
  assert.ok(tile.fields.some((field) => field.key === "tilePrice"));
  const tileDefaults = Object.fromEntries(
    tile.fields.map((field) => [field.key, field.value]),
  );
  const tileResult = tile.calculate(tileDefaults);
  assert.ok(
    tileResult.results.some(
      (item) => item.en === "Total tile material cost" && item.kind === "money",
    ),
  );
  assert.match(formulaWorkspace, /Saudi riyal \(SAR\)/);
});

test("exact Arabic short-name search does not leak unrelated cards", () => {
  const result = searchTools("إضافة PDF");
  assert.deepEqual(
    result.map((item) => item.slug),
    ["pdf-edit"],
  );
  assert.equal(new Set(tools.map((item) => item.slug)).size, 146);
});

test("search has a true empty state and routes Enter to a counted results view", () => {
  assert.deepEqual(searchTools("no-match-term-xyz-487216"), []);
  const pdfResults = searchTools("PDF");
  assert.ok(pdfResults.length > 1);
  assert.ok(pdfResults.some((item) => item.slug === "pdf-merge"));
  assert.ok(searchTools("الصور").some((item) => item.category === "images"));
  assert.match(homeSearch, /action="\/tools"/);
  assert.match(homeSearch, /name="search"/);
  assert.match(homeSearch, /نتيجة مطابقة/);
  assert.match(homeSearch, /عرض كل النتائج/);
  assert.match(homeSearch, /لم نجد أداة مطابقة/);
  assert.match(toolsExplorer, /initialQuery/);
  assert.match(toolsExplorer, /نتيجة مطابقة/);
  assert.match(toolsPage, /searchParams/);
  assert.match(toolsPage, /نتائج البحث/);
});

test("Word to PDF prints real document pages with a searchable text layer", () => {
  assert.match(pdfWorkspace, /renderAsync\(file, renderHost/);
  assert.match(pdfWorkspace, /section\.docx/);
  assert.match(pdfWorkspace, /printHtmlDocument/);
  assert.match(pdfWorkspace, /بطبقة نص قابلة للبحث/);
  assert.doesNotMatch(pdfWorkspace, /html2canvas\(renderedPage/);
  assert.doesNotMatch(pdfWorkspace, /mammoth\.extractRawText/);
  assert.match(pdfWorkspace, /renderHeaders: true/);
  assert.match(pdfWorkspace, /renderFooters: true/);
});
