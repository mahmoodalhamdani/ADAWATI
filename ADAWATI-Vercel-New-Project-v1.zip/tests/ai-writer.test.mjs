import assert from "node:assert/strict";
import test from "node:test";
import {
  buildLocalDraft,
  extractSubject,
} from "../lib/local-writer.ts";

test("Arabic writer executes a message request instead of defining it", () => {
  const output = buildLocalDraft("اكتب لي رسالة صباحية حب", 100, "ar");
  assert.match(output, /صباح/);
  assert.match(output, /قلب|حب|يوم/);
  assert.doesNotMatch(output, /تعني كلمة|تعريف|المقصود/);
  assert.ok(output.trim().split(/\s+/).length <= 100);
});

test("Arabic writer extracts the requested article subject", () => {
  assert.equal(extractSubject("اكتب لي مقال عن الصداقة", "ar"), "الصداقة");
  const output = buildLocalDraft("اكتب لي مقال عن الصداقة", 70, "ar");
  assert.match(output, /^الصداقة/);
  assert.ok(output.trim().split(/\s+/).length <= 70);
});

test("English writer executes the requested artifact and word limit", () => {
  assert.equal(
    extractSubject("Write me an article about friendship", "en"),
    "friendship",
  );
  const output = buildLocalDraft(
    "Write me an article about friendship",
    45,
    "en",
  );
  assert.match(output, /^friendship/i);
  assert.ok(output.trim().split(/\s+/).length <= 45);
});
