import assert from "node:assert/strict";
import test from "node:test";
import { rankPopularToolSlugs } from "../lib/popular-tools.ts";

const valid = ["merge", "split", "crop", "compress", "forms", "scan"];
const fallback = ["merge", "split", "crop", "compress"];

function views(slug, count) {
  return Array.from({ length: count }, () => ({ selected_tool: slug }));
}

test("most-used tools are ranked by real usage and capped at four", () => {
  const rows = [
    ...views("forms", 8),
    ...views("scan", 6),
    ...views("merge", 4),
    ...views("crop", 2),
    ...views("not-a-tool", 100),
  ];
  assert.deepEqual(rankPopularToolSlugs(rows, valid, fallback, 4), [
    "forms",
    "scan",
    "merge",
    "crop",
  ]);
});

test("most-used tools change when the rolling usage ranking changes", () => {
  const earlier = rankPopularToolSlugs(
    [...views("merge", 9), ...views("split", 8)],
    valid,
    fallback,
  );
  const later = rankPopularToolSlugs(
    [...views("forms", 12), ...views("scan", 11)],
    valid,
    fallback,
  );
  assert.deepEqual(earlier.slice(0, 2), ["merge", "split"]);
  assert.deepEqual(later.slice(0, 2), ["forms", "scan"]);
  assert.notDeepEqual(later, earlier);
  assert.equal(later.length, 4);
});

test("most-used tools keep four safe fallbacks when analytics is empty", () => {
  assert.deepEqual(rankPopularToolSlugs([], valid, fallback), fallback);
});
