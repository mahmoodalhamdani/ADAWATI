import assert from "node:assert/strict";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import test from "node:test";

const projectRoot = path.resolve(new URL("..", import.meta.url).pathname);

async function collectSources(directory) {
  const result = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const target = path.join(directory, entry.name);
    if (entry.isDirectory()) result.push(...(await collectSources(target)));
    else if (/\.(tsx?|css)$/.test(entry.name)) result.push(target);
  }
  return result;
}

const appSources = await collectSources(path.join(projectRoot, "app"));
const componentSource = (
  await Promise.all(
    appSources
      .filter((file) => /\.(tsx?|ts)$/.test(file))
      .map((file) => readFile(file, "utf8")),
  )
).join("\n");
const css = await readFile(path.join(projectRoot, "app/globals.css"), "utf8");
const upload = await readFile(
  path.join(projectRoot, "app/components/FileUploadZone.tsx"),
  "utf8",
);
const customSelect = await readFile(
  path.join(projectRoot, "app/components/CustomSelect.tsx"),
  "utf8",
);

test("site choices use the ADAWATI listbox instead of native select popups", () => {
  assert.doesNotMatch(componentSource, /<(?:select|option)\b/i);
  assert.doesNotMatch(componentSource, /window\.(?:alert|confirm|prompt)\s*\(/);
  assert.match(customSelect, /role="listbox"/);
  assert.match(customSelect, /event\.key === "Escape"/);
  assert.match(customSelect, /event\.key === "ArrowDown"/);
  assert.match(customSelect, /document\.addEventListener\("pointerdown"/);
});

test("every shared file uploader exposes blue progress and temporary success or error feedback", () => {
  assert.match(upload, /"loading" \| "complete" \| "error"/);
  assert.match(upload, /setProgress\(100\)/);
  assert.match(upload, /setMessageVisible\(false\)/);
  assert.match(upload, /role=\{state === "error" \? "alert" : "status"\}/);
  assert.match(css, /\.smart-upload\.is-error/);
  assert.match(css, /\.smart-upload\.is-complete \.upload-status/);
  assert.match(
    css,
    /background:\s*linear-gradient\(90deg, #0754e8, #2f76f4, #67a0ff\)/,
  );
});

test("tool and category cards share one exact responsive height system", () => {
  assert.match(css, /--catalog-card-height:\s*184px/);
  assert.match(
    css,
    /\.tool-card,\s*\.category-card\s*\{[^}]*height:\s*var\(--catalog-card-height\)[^}]*min-height:\s*var\(--catalog-card-height\)/s,
  );
  assert.match(css, /max-width:\s*760px[\s\S]*--catalog-card-height:\s*160px/);
});
