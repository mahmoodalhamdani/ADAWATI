import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { PDFDocument } from "pdf-lib";
import { mergePdfDocuments, splitPdfDocument } from "../lib/pdf-tools.ts";

const fixture = (name) => new URL(`./fixtures/${name}`, import.meta.url);

test("shared image upload fixtures are valid square PNG files", async () => {
  for (const name of ["test-image.png", "test-image-alt.png"]) {
    const bytes = await readFile(fixture(name));
    assert.deepEqual([...bytes.subarray(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10]);
    assert.ok(bytes.length > 1_000);
    const width = bytes.readUInt32BE(16);
    const height = bytes.readUInt32BE(20);
    assert.ok(width >= 512);
    assert.equal(width, height);
  }
});

test("PDF upload fixtures load with the page counts required by each flow", async () => {
  const expectedPages = {
    "sample-a.pdf": 2,
    "sample-b.pdf": 1,
    "sample-multipage.pdf": 4,
    "sample-editable.pdf": 2,
    "sample-ocr.pdf": 2,
  };
  for (const [name, pageCount] of Object.entries(expectedPages)) {
    const bytes = await readFile(fixture(name));
    assert.equal(bytes.subarray(0, 5).toString(), "%PDF-");
    assert.equal((await PDFDocument.load(bytes)).getPageCount(), pageCount);
  }
});

test("fixture PDFs complete real merge and split operations", async () => {
  const sourceA = await readFile(fixture("sample-a.pdf"));
  const sourceB = await readFile(fixture("sample-b.pdf"));
  const mergedBytes = await mergePdfDocuments([sourceA, sourceB]);
  assert.equal((await PDFDocument.load(mergedBytes)).getPageCount(), 3);

  const multipage = await readFile(fixture("sample-multipage.pdf"));
  const parts = await splitPdfDocument(multipage, 2);
  assert.equal(parts.length, 2);
  assert.deepEqual(
    await Promise.all(parts.map(async (part) => (await PDFDocument.load(part)).getPageCount())),
    [2, 2],
  );
});
