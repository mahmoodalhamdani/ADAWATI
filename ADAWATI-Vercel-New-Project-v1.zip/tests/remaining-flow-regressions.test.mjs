import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const read = (path) => readFile(new URL(`../${path}`, import.meta.url), "utf8");

test("device age inputs copy currentTarget value before updating state", async () => {
  const source = await read("app/components/FormulaToolWorkspaces.tsx");
  assert.match(
    source,
    /function handleFieldChange[\s\S]*const value = event\.currentTarget\.value;[\s\S]*updateFieldValue\(fieldKey, value\)/,
  );
  assert.doesNotMatch(
    source,
    /setValues\(\([^)]*\)\s*=>\s*\(\{[^}]*event\.(?:currentTarget|target)\.value/,
  );
  assert.match(source, /waitsForClientDate/);
  assert.match(source, /setCalculationNow\(new Date\(\)\)/);
  assert.match(source, /new Intl\.NumberFormat\("en-US"/);
});

test("favorite and icon-only home labels react to the active locale", async () => {
  const [favorite, logo] = await Promise.all([
    read("app/components/FavoriteButton.tsx"),
    read("app/components/Logo.tsx"),
  ]);
  assert.match(favorite, /useLocale\(\)/);
  assert.match(favorite, /t\("إضافة إلى المفضلة", "Add to favorites"\)/);
  assert.match(favorite, /t\("إزالة من المفضلة", "Remove from favorites"\)/);
  assert.match(logo, /t\("أدواتي - الرئيسية", "ADAWATI - Home"\)/);
  assert.match(logo, /alt=\{t\("شعار أدواتي", "ADAWATI logo"\)\}/);
});

test("Excel conversion recalculates common formulas and blocks unsupported ones", async () => {
  const [helper, workspace] = await Promise.all([
    read("lib/office-print.ts"),
    read("app/components/PdfToolWorkspaces.tsx"),
  ]);
  assert.match(helper, /"SUM", "AVERAGE", "MIN", "MAX"/);
  assert.match(helper, /recalculatedFormulaCount/);
  assert.match(helper, /excel-formula-result-missing/);
  assert.match(workspace, /No PDF was produced to avoid misleading output/);
});
