import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";
import { categories, siteConfig, tools } from "../lib/registry.ts";
import { GET as toolsSitemap } from "../app/sitemaps/tools.xml/route.ts";
import { GET as categorySitemap } from "../app/sitemaps/categories.xml/route.ts";
import { summarizePdfText } from "../app/components/PdfToolWorkspaces.tsx";

const toolWorkspace = await readFile(new URL("../app/components/ToolWorkspace.tsx", import.meta.url), "utf8");
const additionalWorkspace = await readFile(new URL("../app/components/AdditionalToolWorkspaces.tsx", import.meta.url), "utf8");
const pdfWorkspace = await readFile(new URL("../app/components/PdfToolWorkspaces.tsx", import.meta.url), "utf8");
const priorityWorkspace = await readFile(new URL("../app/components/PriorityToolWorkspaces.tsx", import.meta.url), "utf8");
const formulaWorkspace = await readFile(new URL("../app/components/FormulaToolWorkspaces.tsx", import.meta.url), "utf8");
const qrWorkspace = await readFile(new URL("../app/components/QrStudio.tsx", import.meta.url), "utf8");
const homeSource = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");

test("every tool and category has one indexed canonical URL", async () => {
  const toolXml = await (await toolsSitemap()).text();
  const categoryXml = await (await categorySitemap()).text();
  const toolLocs = [...toolXml.matchAll(/<loc>([^<]+)<\/loc>/g)].map((match) => match[1]);
  const categoryLocs = [...categoryXml.matchAll(/<loc>([^<]+)<\/loc>/g)].map((match) => match[1]);
  assert.equal(toolLocs.length, tools.length);
  assert.equal(categoryLocs.length, categories.length);
  assert.equal(new Set(toolLocs).size, tools.length);
  assert.equal(new Set(categoryLocs).size, categories.length);
  for (const tool of tools) assert.ok(toolLocs.includes(`${siteConfig.baseUrl}/tools/${tool.slug}`), tool.slug);
  for (const category of categories) assert.ok(categoryLocs.includes(`${siteConfig.baseUrl}/tools/${category.slug}`), category.slug);
});

test("public tool workspaces do not send tool inputs to remote APIs", async () => {
  const publicSources = [toolWorkspace, additionalWorkspace, pdfWorkspace, priorityWorkspace, formulaWorkspace, qrWorkspace].join("\n");
  assert.doesNotMatch(publicSources, /fetch\(\s*[`'"]https?:\/\//);
  assert.doesNotMatch(publicSources, /\/api\/(?:generate-text|pdf-intelligence)/);
  assert.doesNotMatch(publicSources, /frankfurter|cloudflare:workers|from\s+["']ai["']/);
  await assert.rejects(access(new URL("../app/api/generate-text/route.ts", import.meta.url)));
  await assert.rejects(access(new URL("../app/api/pdf-intelligence/route.ts", import.meta.url)));
});

test("local PDF summary is deterministic and preserves source sentences", () => {
  const text = "Budget planning helps families control spending. A clear budget records income and spending every month. Saving money creates a useful emergency reserve. Weather changes quickly during winter. Reviewing the budget each week keeps the plan accurate.";
  const first = summarizePdfText(text, 3);
  const second = summarizePdfText(text, 3);
  assert.equal(first, second);
  assert.equal(first.split(/(?<=[.!?])\s+/).length, 3);
  for (const sentence of first.split(/(?<=[.!?])\s+/)) assert.ok(text.includes(sentence));
});

test("home catalog starts with three horizontal rows and expands inline", () => {
  assert.match(homeSource, /showAllTools\s*\?\s*tools\s*:\s*tools\.slice\(0,\s*18\)/);
  assert.match(homeSource, /aria-expanded=\{showAllTools\}/);
  assert.match(homeSource, /setShowAllTools\(\(current\)\s*=>\s*!current\)/);
  assert.match(homeSource, /عرض أقل/);
});
