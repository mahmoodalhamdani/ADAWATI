import assert from "node:assert/strict";
import test from "node:test";
import { PDFDocument } from "pdf-lib";
import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";
import { addPdfPageNumbers, cropPdfMargins } from "../lib/pdf-decorations.ts";

async function fixture() {
  const document = await PDFDocument.create();
  document.addPage([200, 300]);
  document.addPage([400, 500]);
  document.addPage([600, 700]);
  return document.save({ useObjectStreams: false });
}

test("page numbering writes the correct visible number on every PDF page", async () => {
  const output = await addPdfPageNumbers(await fixture(), "bottom-center");
  const pdf = await getDocument({ data: output }).promise;
  assert.equal(pdf.numPages, 3);
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber);
    const content = await page.getTextContent();
    assert.deepEqual(content.items.map((item) => item.str).filter(Boolean), [
      String(pageNumber),
    ]);
  }
});

test("PDF crop changes only the requested page boxes by the exact percentage", async () => {
  const output = await cropPdfMargins(await fixture(), "1,3", 10);
  const document = await PDFDocument.load(output);
  assert.deepEqual(
    document.getPages().map((page) => page.getCropBox()),
    [
      { x: 20, y: 30, width: 160, height: 240 },
      { x: 0, y: 0, width: 400, height: 500 },
      { x: 60, y: 70, width: 480, height: 560 },
    ],
  );
});
