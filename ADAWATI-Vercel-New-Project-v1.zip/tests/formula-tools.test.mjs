import assert from "node:assert/strict";
import test from "node:test";
import { formulaDefinitions } from "../app/components/FormulaToolWorkspaces.tsx";

test("every formula produces stable results for two valid calculations", () => {
  assert.equal(Object.keys(formulaDefinitions).length, 41);
  for (const [slug, formula] of Object.entries(formulaDefinitions)) {
    const defaults = Object.fromEntries(formula.fields.map((field) => [field.key, field.value]));
    const first = formula.calculate(defaults);
    assert.equal(first.error, undefined, `${slug}: defaults should be valid`);
    assert.ok(first.results.length >= 3, `${slug}: expected useful result metrics`);
    for (const item of first.results) {
      assert.doesNotMatch(item.value, /NaN|Infinity/, `${slug}: invalid numeric output`);
    }

    const changed = { ...defaults };
    const numericField = formula.fields.find((field) => (field.type || "number") === "number");
    changed[numericField.key] = String(Number(changed[numericField.key]) + 1);
    const second = formula.calculate(changed);
    assert.equal(second.error, undefined, `${slug}: changed valid input should work`);
    assert.ok(second.results.length >= 3, `${slug}: second calculation needs results`);
  }
});

test("every formula rejects a malformed numeric input without leaking NaN", () => {
  for (const [slug, formula] of Object.entries(formulaDefinitions)) {
    const values = Object.fromEntries(formula.fields.map((field) => [field.key, field.value]));
    const numericField = formula.fields.find((field) => (field.type || "number") === "number");
    values[numericField.key] = "not-a-number";
    const output = formula.calculate(values);
    assert.equal(output.error, "invalid", `${slug}: malformed number must be rejected`);
    assert.deepEqual(output.results, [], `${slug}: malformed input must not show stale results`);
  }
});

test("device age and daily cost stays accurate across repeated field changes", () => {
  const calculator = formulaDefinitions["device-age-cost-calculator"];
  const now = new Date(2026, 7, 21, 19, 45);
  const priceThenDate = calculator.calculate(
    { price: "1200", date: "2025-08-21" },
    now,
  );
  const dateThenPrice = calculator.calculate(
    { date: "2025-08-21", price: "1200" },
    now,
  );
  const changedAgain = calculator.calculate(
    { price: "730", date: "2024-08-21" },
    now,
  );
  assert.deepEqual(priceThenDate, dateThenPrice);
  assert.equal(priceThenDate.error, undefined);
  assert.equal(
    priceThenDate.results.find((item) => item.en === "Device age days")?.value,
    "365",
  );
  assert.equal(
    priceThenDate.results.find((item) => item.en === "Cost per day")?.value,
    "3.29",
  );
  assert.equal(
    changedAgain.results.find((item) => item.en === "Device age days")?.value,
    "730",
  );
  assert.equal(
    changedAgain.results.find((item) => item.en === "Cost per day")?.value,
    "1",
  );
});
