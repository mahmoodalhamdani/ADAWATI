import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { convertFuelEconomy } from "../lib/tool-calculations.ts";

const source = await readFile(
  new URL("../app/components/AdditionalToolWorkspaces.tsx", import.meta.url),
  "utf8",
);
const fuelTripSource = source.slice(
  source.indexOf("function FuelTrip()"),
  source.indexOf("function WorkHours()"),
);

test("Fuel and Trip reloads into a forced blank controlled state", () => {
  for (const stateName of [
    "calculationMode",
    "origin",
    "destination",
    "distance",
    "consumption",
    "fuelUsed",
    "price",
    "currency",
    "tankCapacity",
    "startingFuel",
    "reserveFuel",
  ]) {
    assert.match(fuelTripSource, new RegExp(`\\[${stateName}, set`));
  }
  assert.match(fuelTripSource, /window\.addEventListener\("pageshow", restoreBlankState\)/);
  assert.match(fuelTripSource, /queueMicrotask\(restoreBlankState\)/);
  assert.match(fuelTripSource, /key=\{workspaceGeneration\}/);
  assert.match(fuelTripSource, /setTankCapacity\(""\)/);
  assert.match(fuelTripSource, /setStartingFuel\(""\)/);
  assert.doesNotMatch(fuelTripSource, /(?:local|session)Storage/);
});

test("Fuel and Trip clears completed and stale results", () => {
  assert.match(fuelTripSource, /function reset\(\) \{\s*clearWorkspace\(\);\s*\}/);
  assert.match(fuelTripSource, /function updateText[\s\S]*invalidateResult\(\)/);
  assert.match(fuelTripSource, /setHasResult\(false\)/);
  assert.match(fuelTripSource, /Clear and reset/);
});

test("fuel economy conversions still support the related planning flow", () => {
  const litersPer100Km = convertFuelEconomy(8, "L/100 km", "km/L");
  const usMpg = convertFuelEconomy(8, "L/100 km", "mpg (US)");
  assert.equal(litersPer100Km, 12.5);
  assert.ok(usMpg && Math.abs(usMpg - 29.401822875) < 0.000001);
});
