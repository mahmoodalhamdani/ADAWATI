import assert from "node:assert/strict";
import test from "node:test";
import { strFromU8, unzipSync } from "fflate";
import * as XLSX from "xlsx";
import { pagesToDocx, pagesToXlsx } from "../lib/document-exports.ts";
import {
  canvasPointFromClient,
  circularCropPlacement,
  smartFillMaskedPixels,
} from "../lib/image-tools.ts";

test("PDF-to-Word creates a real DOCX package with editable page text", async () => {
  const blob = await pagesToDocx(["مرحبا بالعالم", "Second page"], "الصفحة");
  const bytes = new Uint8Array(await blob.arrayBuffer());
  assert.equal(String.fromCharCode(bytes[0], bytes[1]), "PK");
  const archive = unzipSync(bytes);
  assert.ok(archive["word/document.xml"]);
  const xml = strFromU8(archive["word/document.xml"]);
  assert.match(xml, /مرحبا بالعالم/);
  assert.match(xml, /Second page/);
});

test("PDF-to-Excel creates a real XLSX workbook with page rows", async () => {
  const bytes = await pagesToXlsx(["First line\nSecond line", "Third line"]);
  const workbook = XLSX.read(bytes, { type: "array" });
  const rows = XLSX.utils.sheet_to_json(
    workbook.Sheets[workbook.SheetNames[0]],
    { header: 1 },
  );
  assert.deepEqual(rows.slice(0, 4), [
    ["Page", "Content"],
    [1, "First line"],
    [1, "Second line"],
    [2, "Third line"],
  ]);
});

test("circular crop geometry always covers the transparent output circle", () => {
  for (const [width, height] of [
    [1600, 900],
    [900, 1600],
    [800, 800],
  ]) {
    const result = circularCropPlacement(
      width,
      height,
      1.4,
      9_999,
      -9_999,
      1024,
    );
    assert.ok(result.x <= 0 && result.y <= 0);
    assert.ok(result.x + result.width >= 1024);
    assert.ok(result.y + result.height >= 1024);
  }
});

test("watermark pointer coordinates match the displayed canvas at every edge", () => {
  const rect = { left: 180, top: 75, width: 600, height: 800 };
  assert.deepEqual(canvasPointFromClient(180, 75, rect, 1200, 1600), {
    x: 0,
    y: 0,
  });
  assert.deepEqual(canvasPointFromClient(780, 875, rect, 1200, 1600), {
    x: 1200,
    y: 1600,
  });
  assert.deepEqual(canvasPointFromClient(480, 475, rect, 1200, 1600), {
    x: 600,
    y: 800,
  });
});

test("smart watermark fill replaces a bounded marked pixel from surrounding content", () => {
  const width = 5,
    height = 5;
  const source = new Uint8ClampedArray(width * height * 4);
  const mask = new Uint8ClampedArray(width * height * 4);
  for (let index = 0; index < width * height; index += 1)
    source.set([20, 80, 180, 255], index * 4);
  const center = (2 * width + 2) * 4;
  source.set([250, 20, 20, 255], center);
  mask[center + 3] = 255;
  const result = smartFillMaskedPixels(source, mask, width, height);
  assert.deepEqual([...result.slice(center, center + 4)], [20, 80, 180, 255]);
  assert.throws(() =>
    smartFillMaskedPixels(
      source,
      new Uint8ClampedArray(mask.length),
      width,
      height,
    ),
  );
});
