import assert from "node:assert/strict";
import { File } from "node:buffer";
import { readFile } from "node:fs/promises";
import test from "node:test";
import {
  EXCEL_FORMULA_RESULT_MISSING,
  renderExcelForPrint,
} from "../lib/office-print.ts";

async function fixtureFile(name) {
  const bytes = await readFile(new URL(`fixtures/${name}`, import.meta.url));
  return new File([bytes], name, {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}

test("Excel print uses cached formula results when they are present", async () => {
  const output = await renderExcelForPrint(
    await fixtureFile("excel-formulas-cached.xlsx"),
  );
  assert.equal(output.recalculatedFormulaCount, 0);
  assert.match(output.bodyHtml, />37\.5<\/td>/);
  assert.match(output.bodyHtml, />51\.5<\/td>/);
  assert.match(output.bodyHtml, />25\.75<\/td>/);
  assert.doesNotMatch(output.bodyHtml, /=B2\*C2/);
});

test("Excel print recalculates common formulas without cached results", async () => {
  const output = await renderExcelForPrint(
    await fixtureFile("excel-formulas-uncached.xlsx"),
  );
  assert.equal(output.recalculatedFormulaCount, 5);
  assert.match(output.bodyHtml, />37\.5<\/td>/);
  assert.match(output.bodyHtml, />14<\/td>/);
  assert.match(output.bodyHtml, />51\.5<\/td>/);
  assert.match(output.bodyHtml, />25\.75<\/td>/);
  assert.doesNotMatch(output.bodyHtml, /=(?:B2\*C2|SUM|AVERAGE)/);
});

test("Excel print blocks unsupported formulas without cached results", async () => {
  await assert.rejects(
    renderExcelForPrint(await fixtureFile("excel-formulas-unsupported.xlsx")),
    (error) => error instanceof Error && error.message.startsWith(`${EXCEL_FORMULA_RESULT_MISSING}:`),
  );
});
