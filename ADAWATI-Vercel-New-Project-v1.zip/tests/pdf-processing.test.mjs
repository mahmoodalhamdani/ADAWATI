import assert from "node:assert/strict";
import test from "node:test";
import { PDFDocument } from "pdf-lib";
import {
  imagesToPdfDocuments,
  mergePdfDocuments,
  parsePdfPageSelection,
  signPdfDocument,
} from "../lib/pdf-tools.ts";

const onePixelPng = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9WlVfGQAAAAASUVORK5CYII=",
  "base64",
);

test("PDF page ranges are strict, ordered, and bounded", () => {
  assert.deepEqual(parsePdfPageSelection("1-3,5", 5), [0, 1, 2, 4]);
  assert.deepEqual(parsePdfPageSelection("3-1", 3), [2, 1, 0]);
  assert.deepEqual(parsePdfPageSelection("all", 2), [0, 1]);
  assert.throws(() => parsePdfPageSelection("1,x", 4));
  assert.throws(() => parsePdfPageSelection("5", 4));
});

test("PDF merge copies every source page in order", async () => {
  const first = await PDFDocument.create();
  first.addPage([200, 300]);
  const second = await PDFDocument.create();
  second.addPage([300, 400]);
  second.addPage([400, 500]);
  const merged = await PDFDocument.load(
    await mergePdfDocuments([await first.save(), await second.save()]),
  );
  assert.equal(merged.getPageCount(), 3);
  assert.deepEqual(
    merged.getPages().map((page) => page.getWidth()),
    [200, 300, 400],
  );
});

test("image-to-PDF creates a visible image page", async () => {
  const bytes = await imagesToPdfDocuments([
    { bytes: onePixelPng, type: "image/png" },
  ]);
  const loaded = await PDFDocument.load(bytes);
  assert.equal(loaded.getPageCount(), 1);
  assert.ok(bytes.length > 700);
});

test("document signing preserves pages and embeds the signature image", async () => {
  const source = await PDFDocument.create();
  source.addPage([600, 800]);
  const original = await source.save({ useObjectStreams: false });
  const signed = await signPdfDocument(original, onePixelPng, {
    target: "first",
    position: "bottom-right",
    sizePercent: 20,
    signatureType: "image/png",
  });
  assert.equal(signed.pageCount, 1);
  assert.equal(signed.signedPages, 1);
  assert.equal((await PDFDocument.load(signed.bytes)).getPageCount(), 1);
  assert.ok(signed.bytes.length > original.length);
});
