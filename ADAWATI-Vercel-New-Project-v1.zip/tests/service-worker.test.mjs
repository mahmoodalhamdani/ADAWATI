import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const worker = await readFile(
  new URL("../public/sw.js", import.meta.url),
  "utf8",
);

test("service worker never serves stale HTML navigation before the network", () => {
  assert.match(worker, /request\.mode==="navigate"/);
  assert.match(worker, /fetch\(request,\{cache:"no-store"\}\)/);
  assert.doesNotMatch(
    worker,
    /cached\|\|network\.catch\(\(\)=>event\.request\.mode==="navigate"/,
  );
});

test("service worker clears previous caches and refreshes controlled pages after update", () => {
  assert.match(worker, /adawati-v45-static/);
  assert.match(worker, /caches\.delete\(key\)/);
  assert.match(worker, /client\.navigate\(client\.url\)/);
});
