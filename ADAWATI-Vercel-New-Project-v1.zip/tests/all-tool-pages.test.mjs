import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { categories, pdfSections, tools } from "../lib/registry.ts";

const toolPage = await readFile(
  new URL("../app/tools/[slug]/page.tsx", import.meta.url),
  "utf8",
);
const toolSitemap = await readFile(
  new URL("../app/sitemaps/tools.xml/route.ts", import.meta.url),
  "utf8",
);
const htmlSitemap = await readFile(
  new URL("../app/sitemap/page.tsx", import.meta.url),
  "utf8",
);

test("every tool receives its own generated page and sitemap URL", () => {
  assert.match(
    toolPage,
    /tools\.map\(\(item\)\s*=>\s*\(\{\s*slug:\s*item\.slug\s*\}\)\)/,
  );
  assert.match(toolPage, /toolMap\[slug\]/);
  assert.match(
    toolSitemap,
    /tools\.map\(item\s*=>\s*`<url><loc>\$\{siteConfig\.baseUrl\}\/tools\/\$\{item\.slug\}<\/loc><\/url>`\)/,
  );
  assert.match(
    htmlSitemap,
    /tools\.map\(\(item\)\s*=>\s*<Link key=\{item\.slug\} href=\{`\/tools\/\$\{item\.slug\}`\}/,
  );
  assert.equal(
    new Set(tools.map((item) => `/tools/${item.slug}`)).size,
    tools.length,
  );
});

test("all 146 tool pages have complete unique indexing metadata", () => {
  const titles = new Set();
  const descriptions = new Set();
  for (const tool of tools) {
    assert.ok(tool.name.length >= 3, `${tool.slug}: Arabic name`);
    assert.ok(tool.nameEn.length >= 3, `${tool.slug}: English name`);
    assert.ok(tool.description.length >= 25, `${tool.slug}: description`);
    assert.ok(tool.seoTitle.includes(tool.name), `${tool.slug}: SEO title`);
    assert.ok(
      tool.seoDescription.includes(tool.name),
      `${tool.slug}: SEO description`,
    );
    assert.equal(
      titles.has(tool.seoTitle),
      false,
      `${tool.slug}: duplicate title`,
    );
    assert.equal(
      descriptions.has(tool.seoDescription),
      false,
      `${tool.slug}: duplicate description`,
    );
    titles.add(tool.seoTitle);
    descriptions.add(tool.seoDescription);
  }
});

test("every PDF tool belongs to one professional PDF section", () => {
  const sectionSlugs = new Set(pdfSections.map((section) => section.slug));
  const pdfTools = tools.filter((tool) => tool.category === "pdf-files");
  assert.equal(pdfTools.length, 35);
  for (const tool of pdfTools)
    assert.ok(
      sectionSlugs.has(tool.pdfSection),
      `${tool.slug}: missing PDF section`,
    );
  assert.equal(
    new Set(categories.map((category) => category.slug)).has("pdf-files"),
    true,
  );
});
