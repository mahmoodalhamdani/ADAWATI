import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const dashboard = await readFile(
  new URL("../app/components/AdminDashboard.tsx", import.meta.url),
  "utf8",
);
const analyticsRoute = await readFile(
  new URL("../app/api/admin/searches/route.ts", import.meta.url),
  "utf8",
);
const messagesRoute = await readFile(
  new URL("../app/api/admin/messages/route.ts", import.meta.url),
  "utf8",
);
const settingsRoute = await readFile(
  new URL("../app/api/admin/settings/route.ts", import.meta.url),
  "utf8",
);
const authRoute = await readFile(
  new URL("../app/api/admin/auth/route.ts", import.meta.url),
  "utf8",
);

test("admin navigation and overview cards open real sections", () => {
  assert.match(dashboard, /\["overview", "نظرة عامة", "grid"\]/);
  assert.match(dashboard, /\["tools", "الأدوات", "sparkles"\]/);
  assert.match(dashboard, /\["messages", "الرسائل", "message"\]/);
  assert.match(dashboard, /\["seo", "SEO والفهرسة", "search"\]/);
  assert.match(dashboard, /\["settings", "الإعدادات", "shield"\]/);
  assert.match(dashboard, /onClick=\{\(\) => setTab\(id\)\}/);
  assert.match(dashboard, /فتح إعدادات حساب الإدارة/);
  assert.match(dashboard, /className=\{onClick \? "is-actionable"/);
});

test("analytics period selector is backed by authenticated real-data ranges", () => {
  for (const days of [7, 30, 180]) {
    assert.match(analyticsRoute, new RegExp(`\\[7, 30, 180\\]`));
    assert.match(dashboard, new RegExp(`days: ${days}`));
  }
  assert.match(analyticsRoute, /created_at=gte\./);
  assert.match(analyticsRoute, /periodTotal/);
  assert.match(dashboard, /api\/admin\/searches\?range=/);
});

test("tools controls include filtering, selection, copy, details, and pagination", () => {
  for (const marker of [
    "setQuery",
    "setCategory",
    "setSeoFilter",
    "toggleSelected",
    "copyToolLink",
    "setExpanded",
    "bulkAction",
    "setPageSize",
  ]) {
    assert.match(dashboard, new RegExp(marker));
  }
});

test("messages and settings use complete authenticated CRUD routes", () => {
  assert.match(messagesRoute, /export async function GET/);
  assert.match(messagesRoute, /export async function PATCH/);
  assert.match(messagesRoute, /export async function DELETE/);
  assert.match(settingsRoute, /export async function GET/);
  assert.match(settingsRoute, /export async function PUT/);
  assert.match(authRoute, /body\.action === "change"/);
  assert.match(dashboard, /markRead/);
  assert.match(dashboard, /removeConfirmed/);
  assert.match(dashboard, /changePin/);
});

test("SEO controls perform scan, report, preview, and sitemap actions", () => {
  for (const marker of [
    "runScan",
    "downloadReport",
    "setStatusTab",
    "setPreviewDevice",
    "copySitemap",
  ]) {
    assert.match(dashboard, new RegExp(marker));
  }
});
