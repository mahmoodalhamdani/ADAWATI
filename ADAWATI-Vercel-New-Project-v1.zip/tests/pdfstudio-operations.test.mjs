import assert from "node:assert/strict";
import test from "node:test";
import { PDFDocument } from "pdf-lib";
import { createPdfToolkit } from "pdfstudio";

test("PDF toolkit performs real split, extract, delete, rotate, compress, protect, and unlock operations", async () => {
  try {
    const source = await PDFDocument.create();
    source.addPage([200, 300]);
    source.addPage([210, 300]);
    source.addPage([220, 300]);
    const bytes = await source.save({ useObjectStreams: false });
    const file = new File([bytes], "sample.pdf", { type: "application/pdf" });
    const pdf = await createPdfToolkit();

    const widths = (document) =>
      document.getPages().map((page) => page.getWidth());
    const info = await pdf.getInfo(file);
    assert.equal(info.pageCount, 3);
    assert.equal(info.encrypted, false);

    const parts = await pdf.split(file, { pagesPerFile: 1 });
    assert.equal(parts.length, 3);
    assert.deepEqual(
      await Promise.all(
        parts.map(async (part) => widths(await PDFDocument.load(part))[0]),
      ),
      [200, 210, 220],
    );

    const extracted = await PDFDocument.load(
      await pdf.extractPages(file, { pages: "3,1" }),
    );
    assert.deepEqual(widths(extracted), [220, 200]);

    const deleted = await PDFDocument.load(
      await pdf.deletePages(file, { pages: "2" }),
    );
    assert.deepEqual(widths(deleted), [200, 220]);

    const rotated = await PDFDocument.load(
      await pdf.rotate(file, { angle: 90, pages: "1" }),
    );
    assert.deepEqual(widths(rotated), [200, 210, 220]);
    assert.deepEqual(
      rotated.getPages().map((page) => page.getRotation().angle),
      [90, 0, 0],
    );

    const compressedBytes = await pdf.compress(file, {
      objectStreams: true,
      recompressFlate: true,
      linearize: true,
    });
    const compressed = await PDFDocument.load(compressedBytes);
    assert.deepEqual(widths(compressed), [200, 210, 220]);
    assert.ok(compressedBytes.length > 0);

    const repaired = await PDFDocument.load(await pdf.repair(file));
    assert.deepEqual(widths(repaired), [200, 210, 220]);

    const locked = await pdf.lock(file, {
      userPassword: "test1234",
      ownerPassword: "test1234",
      keyLength: 256,
    });
    const lockedFile = new File([locked], "locked.pdf", {
      type: "application/pdf",
    });
    assert.equal(await pdf.isEncrypted(lockedFile), true);
    assert.equal(await pdf.requiresPassword(lockedFile), true);
    await assert.rejects(() => pdf.unlock(lockedFile, { password: "wrong" }));
    const unlocked = await pdf.unlock(lockedFile, { password: "test1234" });
    assert.deepEqual(widths(await PDFDocument.load(unlocked)), [200, 210, 220]);
  } finally {
    process.exitCode = 0;
  }
});
