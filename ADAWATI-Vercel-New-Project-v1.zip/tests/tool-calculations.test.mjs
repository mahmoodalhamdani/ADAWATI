import assert from "node:assert/strict";
import test from "node:test";
import {
  addWorkDays,
  average,
  billShare,
  calendarDaysBetween,
  cleanList,
  compareUnitPrices,
  convertDigitShapes,
  convertFuelEconomy,
  countdownToStartOfDay,
  dateDifference,
  discountFromFinalPrice,
  discountTotal,
  deviceAgeCost,
  electricityUsage,
  expensePlan,
  fuelTripCost,
  fuelStopPlan,
  installmentPayment,
  internetUsage,
  maintenanceScheduleProjection,
  percentageOf,
  percentageChange,
  preciseAge,
  randomIntegerInclusive,
  requiredFinalGrade,
  savingsPlan,
  shiftDate,
  studyPlan,
  taskDivision,
  targetSalePriceFromMargin,
  wageBreakdown,
  weightedAverage,
  workDaysInclusive,
  workMinutes,
  zonedDateTimeToUtc,
} from "../lib/tool-calculations.ts";

test("date calculations use calendar days and stay stable across DST boundaries", () => {
  assert.equal(calendarDaysBetween("2026-03-07", "2026-03-09"), 2);
  assert.equal(calendarDaysBetween("2026-10-31", "2026-11-02"), 2);
  assert.deepEqual(dateDifference("2024-01-31", "2024-02-29"), {
    years: 0,
    months: 1,
    days: 0,
    totalDays: 29,
  });
  assert.equal(shiftDate("2024-02-28", 1), "2024-02-29");
  assert.equal(shiftDate("2024-03-01", -1), "2024-02-29");
});

test("appointment countdown targets the beginning of the selected day", () => {
  const result = countdownToStartOfDay(
    "2026-08-20",
    new Date(2026, 7, 19, 18, 30),
  );
  assert.deepEqual(result, { days: 0, hours: 5, minutes: 30, reached: false });
  assert.deepEqual(
    countdownToStartOfDay("2026-08-19", new Date(2026, 7, 19, 0, 1)),
    { days: 0, hours: 0, minutes: 0, reached: true },
  );
});

test("precise age does not calculate before a valid birth date and handles leap years", () => {
  assert.equal(preciseAge("", "2026-08-19"), null);
  assert.equal(preciseAge("2030-01-01", "2026-08-19"), null);
  assert.deepEqual(preciseAge("1997-08-06", "2026-08-19"), {
    years: 29,
    months: 0,
    days: 13,
    totalDays: 10_605,
    daysToBirthday: 352,
  });
  assert.deepEqual(preciseAge("2000-02-29", "2025-02-28"), {
    years: 25,
    months: 0,
    days: 0,
    totalDays: 9_131,
    daysToBirthday: 0,
  });
});

test("workday calculator counts inclusively and respects custom weekend days", () => {
  assert.deepEqual(workDaysInclusive("2026-08-16", "2026-08-22", [5, 6]), {
    workDays: 5,
    calendarDays: 7,
  });
  assert.deepEqual(workDaysInclusive("2026-08-16", "2026-08-22", [0]), {
    workDays: 6,
    calendarDays: 7,
  });
  assert.equal(addWorkDays("2026-08-20", 3, [5, 6]), "2026-08-25");
  assert.equal(addWorkDays("2026-08-20", 0, [5, 6]), "2026-08-20");
  assert.equal(addWorkDays("2026-08-20", 3, [0, 1, 2, 3, 4, 5, 6]), null);
});

test("number lists reject empty or malformed input instead of returning a fake zero", () => {
  assert.equal(average(""), null);
  assert.equal(average("10, nope, 20"), null);
  assert.equal(average("10, 15, 20"), 15);
  assert.equal(weightedAverage("80,90", "2,3"), 86);
  assert.equal(weightedAverage("80,90", "2"), null);
  assert.equal(weightedAverage("80,90", "2,0"), null);
});

test("daily financial calculators return the expected real arithmetic", () => {
  assert.equal(percentageOf(400, 15), 60);
  assert.equal(percentageChange(80, 100), 25);
  assert.equal(percentageChange(0, 100), null);
  assert.equal(targetSalePriceFromMargin(70, 30), 100);
  assert.equal(targetSalePriceFromMargin(70, 100), null);
  assert.deepEqual(discountTotal(100, 20, 10), {
    afterDiscount: 80,
    taxAmount: 8,
    final: 88,
  });
  assert.deepEqual(discountFromFinalPrice(100, 75), {
    saved: 25,
    discountRate: 25,
  });
  assert.equal(discountFromFinalPrice(100, 125), null);
  assert.equal(billShare(120, 4, 10), 33);
  assert.equal(billShare(120, 2.5, 10), null);
  assert.equal(billShare(-20, 2, 0), null);
  assert.deepEqual(savingsPlan(5_000, 8, 1_000), {
    remaining: 4_000,
    monthly: 500,
    weekly: 4_000 / (8 * 4.345),
  });
  assert.deepEqual(installmentPayment(1_200, 0, 12, 0), {
    payment: 100,
    total: 1_200,
    financingCost: 0,
  });
  const financed = installmentPayment(5_000, 500, 12, 12);
  assert.ok(financed && financed.payment > 399 && financed.payment < 400);
  assert.equal(installmentPayment(1_000, 1_200, 12, 0), null);
  assert.equal(requiredFinalGrade(75, 60, 80), 87.5);
  assert.equal(requiredFinalGrade(75, 100, 80), null);
});

test("study and work-time tools validate their boundaries", () => {
  assert.deepEqual(studyPlan(400, 10, 1, 1), {
    activeDays: 8,
    pagesPerDay: 50,
  });
  assert.equal(studyPlan(400, 10, 5, 5), null);
  assert.equal(studyPlan(400, 10.5, 1, 1), null);
  assert.equal(workMinutes("08:00", "17:00", 60), 480);
  assert.equal(workMinutes("22:00", "06:00", 30), 450);
  assert.equal(workMinutes("08:00", "08:00", 0), 0);
  assert.equal(workMinutes("09:17", "18:02", 45), 480);
});

test("date and time tools calculate from non-default controlled values", () => {
  assert.equal(
    zonedDateTimeToUtc("2026-01-15", "11:45", "Asia/Baghdad")?.toISOString(),
    "2026-01-15T08:45:00.000Z",
  );
  assert.deepEqual(
    deviceAgeCost(1_000, "2026-08-10", new Date(2026, 7, 20, 19, 30)),
    { days: 10, months: 10 / 30.4375, costPerDay: 100 },
  );
  const maintenance = maintenanceScheduleProjection({
    lastDate: "2026-02-10",
    currentKm: 36_000,
    lastKm: 35_000,
    months: 6,
    kilometers: 10_000,
    dailyKm: 100,
    now: new Date(2026, 2, 1),
  });
  assert.equal(maintenance?.nextDate.getFullYear(), 2026);
  assert.equal(maintenance?.nextDate.getMonth(), 7);
  assert.equal(maintenance?.nextDate.getDate(), 10);
  assert.equal(maintenance?.nextKm, 45_000);
  assert.equal(maintenance?.kmRemaining, 9_000);
  assert.equal(maintenance?.effectiveDate.getMonth(), 4);
  assert.equal(maintenance?.effectiveDate.getDate(), 30);
});

test("random integer calculator preserves zero and normalizes reversed limits", () => {
  assert.equal(
    randomIntegerInclusive(0, 0, () => 0.5),
    0,
  );
  assert.equal(
    randomIntegerInclusive(10, 0, () => 0),
    0,
  );
  assert.equal(
    randomIntegerInclusive(10, 0, () => 0.999999),
    10,
  );
  assert.equal(
    randomIntegerInclusive(0, 10, () => 1),
    10,
  );
  assert.equal(randomIntegerInclusive(Number.NaN, 10), null);
});

test("daily utility tools calculate exact results and reject invalid boundaries", () => {
  assert.deepEqual(expensePlan(1_500, 650, 350, 30), {
    remaining: 500,
    daily: 500 / 30,
    expenseRatio: (1_000 / 1_500) * 100,
  });
  assert.equal(expensePlan(-1, 0, 0, 30), null);
  assert.deepEqual(fuelTripCost(180, 8, 0.75, true), {
    kilometers: 360,
    liters: 28.8,
    cost: 21.6,
  });
  assert.deepEqual(fuelStopPlan(900, 10, 50, 50, 5, false), {
    kilometers: 900,
    firstLeg: 450,
    fullLeg: 450,
    stops: 1,
    stopKilometers: [450],
  });
  assert.equal(fuelStopPlan(900, 10, 50, 60, 5, false), null);
  assert.deepEqual(wageBreakdown("hourly", 10, 22, 8), {
    monthly: 1_760,
    daily: 80,
    hourly: 10,
  });
  assert.deepEqual(electricityUsage(1_000, 5, 30, 0.1), {
    kwh: 150,
    cost: 15,
  });
  assert.deepEqual(internetUsage(1.5, 2, 30), {
    gigabytes: 90,
    suggestedPlan: 103.49999999999999,
  });
});

test("fuel economy conversion supports metric, US mpg, and UK mpg", () => {
  assert.equal(convertFuelEconomy(8, "L/100 km", "km/L"), 12.5);
  assert.ok(
    Math.abs(convertFuelEconomy(8, "L/100 km", "mpg (US)") - 29.401822875) <
      1e-9,
  );
  assert.ok(
    Math.abs(convertFuelEconomy(30, "mpg (US)", "L/100 km") - 7.8404861) < 1e-9,
  );
  assert.ok(
    Math.abs(
      convertFuelEconomy(35, "mpg (UK)", "L/100 km") - 8.070883885714286,
    ) < 1e-9,
  );
  assert.equal(convertFuelEconomy(0, "km/L", "mpg (US)"), null);
});

test("comparison and cleanup tools produce deterministic usable output", () => {
  assert.deepEqual(compareUnitPrices(12, 20, 18, 27), {
    first: 20 / 12,
    second: 1.5,
    better: "second",
  });
  assert.equal(compareUnitPrices(0, 20, 18, 27), null);
  assert.deepEqual(taskDivision(181, 30, 0), {
    activeDays: 30,
    tasksPerDay: 7,
    spareCapacity: 29,
  });
  assert.equal(taskDivision(180.5, 30, 0), null);
  assert.equal(convertDigitShapes("123 و٤٥٦", "ar"), "١٢٣ و٤٥٦");
  assert.equal(convertDigitShapes("١٢٣ and 456", "en"), "123 and 456");
  assert.deepEqual(cleanList("Apple\napple\nBanana", false), {
    items: ["Apple", "apple", "Banana"],
    unique: ["apple", "Banana"],
    duplicateCount: 1,
  });
});
