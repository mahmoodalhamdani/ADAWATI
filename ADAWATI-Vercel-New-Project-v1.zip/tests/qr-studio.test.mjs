import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import {
  buildPlatformPayload,
  buildQrPayload,
  colorContrast,
  emptyQrFields,
  getQrCardLayout,
  normalizeWebUrl,
  qrCardFormats,
  qrCardTemplates,
  qrColorFamilies,
  qrGradientPresets,
  qrPlatformCategories,
  qrPlatforms,
  qrPresetIcons,
  qrPurposes,
  qrShapes,
} from "../lib/qr-studio.ts";
import { hasAuthenticBrandIcon } from "../lib/brand-icons.ts";

const qrWorkspace = await readFile(
  new URL("../app/components/QrStudio.tsx", import.meta.url),
  "utf8",
);
const globalStyles = await readFile(
  new URL("../app/globals.css", import.meta.url),
  "utf8",
);

test("QR platform catalog is broad, categorized, duplicate-free, and uses genuine vector marks", () => {
  assert.ok(qrPlatforms.length >= 210);
  assert.equal(new Set(qrPlatforms.map((item) => item.id)).size, qrPlatforms.length);
  assert.equal(new Set(qrPlatformCategories.map((item) => item.id)).size, qrPlatformCategories.length);
  for (const category of qrPlatformCategories) {
    assert.ok(qrPlatforms.some((item) => item.category === category.id), category.id);
  }
  for (const item of qrPlatforms) {
    assert.ok(item.name.trim());
    assert.ok(item.icon.trim());
    assert.match(item.color, /^#[0-9a-f]{6}$/i);
    if (item.id !== "custom") assert.equal(hasAuthenticBrandIcon(item.id), true, item.id);
  }
  assert.ok(qrPlatforms.some((item) => item.id === "custom" && item.input === "url"));
});

test("every QR export format keeps its visual regions inside the card without overlap", () => {
  for (const format of qrCardFormats) {
    for (const variant of ["clean", "ticket"]) {
      const layout = getQrCardLayout(format.id, format.width, format.height, variant);
      assert.ok(layout.qrX - 25 >= layout.margin, `${format.id} left`);
      assert.ok(layout.qrY - 25 >= layout.margin, `${format.id} top`);
      assert.ok(layout.qrX + layout.qrSize + 25 <= format.width - layout.margin, `${format.id} right`);
      assert.ok(layout.qrY + layout.qrSize + 25 <= format.height - layout.margin, `${format.id} bottom`);
      assert.ok(layout.badgeY + layout.badgeRadius < layout.titleY, `${format.id} badge/title`);
      assert.ok(layout.titleY < layout.subtitleY, `${format.id} title/subtitle`);
      assert.ok(layout.footerY + 26 <= format.height - layout.margin, `${format.id} footer`);
      if (format.id === "compact") {
        assert.ok(layout.headerX + layout.textMaxWidth / 2 < layout.qrX - 25, "compact columns");
      } else {
        assert.ok(layout.subtitleY + layout.subtitleSize / 2 + 10 < layout.qrY - 25, `${format.id} header/QR`);
        assert.ok(layout.qrY + layout.qrSize + 25 < layout.footerY - 26, `${format.id} QR/footer`);
      }
    }
  }
});

test("platform payloads support handles, phones, places, full URLs, and the open fallback", () => {
  const instagram = qrPlatforms.find((item) => item.id === "instagram");
  const whatsapp = qrPlatforms.find((item) => item.id === "whatsapp");
  const maps = qrPlatforms.find((item) => item.id === "google-maps");
  const custom = qrPlatforms.find((item) => item.id === "custom");
  assert.equal(buildPlatformPayload(instagram, "@minjaz"), "https://instagram.com/minjaz");
  assert.equal(
    buildPlatformPayload(whatsapp, "+964 770 123 4567", "هلا بيك"),
    "https://wa.me/9647701234567?text=%D9%87%D9%84%D8%A7%20%D8%A8%D9%8A%D9%83",
  );
  assert.equal(
    buildPlatformPayload(maps, "شارع المتنبي بغداد"),
    `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent("شارع المتنبي بغداد")}`,
  );
  assert.equal(buildPlatformPayload(custom, "example.com/new-service"), "https://example.com/new-service");
  assert.equal(buildPlatformPayload(instagram, "https://example.com/profile"), "https://example.com/profile");
});

test("core QR payloads are deterministic and date events begin at 00:00", () => {
  const event = buildQrPayload("event", {
    ...emptyQrFields,
    eventTitle: "موعد",
    eventDate: "2026-08-20",
    eventEndDate: "2026-08-21",
    eventLocation: "بغداد",
  });
  assert.match(event, /DTSTART:20260820T000000/);
  assert.match(event, /DTEND:20260821T000000/);
  assert.equal(
    buildQrPayload("event", {
      ...emptyQrFields,
      eventTitle: "Invalid",
      eventDate: "2026-08-21",
      eventEndDate: "2026-08-20",
    }),
    "",
  );
  assert.equal(
    buildQrPayload("wifi", {
      ...emptyQrFields,
      ssid: "Home;5G",
      password: "a:b",
      encryption: "WPA",
      hidden: true,
    }),
    "WIFI:T:WPA;S:Home\\;5G;P:a\\:b;H:true;;",
  );
  assert.equal(
    buildQrPayload("location", { ...emptyQrFields, latitude: "91", longitude: "44" }),
    "",
  );
  assert.equal(normalizeWebUrl("example.com"), "https://example.com");
});

test("QR visual system has separate card, QR-shape, and image choices", () => {
  assert.equal(qrCardTemplates.length, 20);
  assert.equal(new Set(qrCardTemplates.map((item) => item.id)).size, 20);
  assert.ok(qrShapes.length >= 14);
  assert.equal(new Set(qrShapes.map((item) => item.id)).size, qrShapes.length);
  assert.equal(qrCardFormats.length, 4);
  assert.equal(qrPresetIcons.length, 20);
  assert.equal(new Set(qrPurposes.map((item) => item.id)).size, qrPurposes.length);
  assert.equal(qrColorFamilies.length, 24);
  assert.ok(qrColorFamilies.every((family) => Object.keys(family.shades).length === 11));
  assert.equal(qrGradientPresets.length, 36);
  assert.match(qrWorkspace, /brandIconDataUrl/);
  assert.match(qrWorkspace, /fitCanvasText/);
  assert.doesNotMatch(qrWorkspace, /strokeStyle = meta\.color/);
  assert.match(qrWorkspace, /fillStyle = logoImage \? activeColors\.light : meta\.color/);
  assert.match(qrWorkspace, /context\.textAlign = "center";[\s\S]*context\.fillText\("ADAWATI QR STUDIO", headerX, footerY\)/);
  assert.doesNotMatch(qrWorkspace, /\{fallback\}<\/span>/);
  assert.match(qrWorkspace, /Saved QR shape/);
  assert.ok(colorContrast("#07184f", "#ffffff") >= 7);
  assert.ok(colorContrast("#ffffff", "#ffffff") < 4.5);
  assert.match(qrWorkspace, /StudioPanel = "content" \| "style" \| "color" \| "image"/);
  assert.match(qrWorkspace, /role="radiogroup"/);
  assert.match(qrWorkspace, /role="radio"/);
  assert.match(qrWorkspace, /data-qr-purpose/);
  assert.match(qrWorkspace, /"ArrowRight"/);
  assert.match(qrWorkspace, /nextPurpose\.id/);
  assert.match(qrWorkspace, /FileUploadZone/);
  assert.match(qrWorkspace, /minjaz-download-feedback/);
  assert.doesNotMatch(qrWorkspace, /window\.(?:alert|confirm|prompt)\s*\(/);
  assert.doesNotMatch(qrWorkspace, /fetch\s*\(/);
  assert.doesNotMatch(qrWorkspace, /type="date"|<select\b/);
  assert.match(globalStyles, /@media \(max-width: 520px\)[\s\S]*\.qr-platform-grid/);
  assert.match(globalStyles, /\.qr-studio-tabs\s*\{[\s\S]*grid-template-columns:\s*repeat\(4/);
});
