const CACHE="adawati-v45-static";
const CORE=["/favicon.png","/icon-192.png","/icon-512.png","/brand/adawati-logo.webp"];

self.addEventListener("install",event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(CORE)).then(()=>self.skipWaiting()));
});

self.addEventListener("activate",event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)));
    await self.clients.claim();
    const clients=await self.clients.matchAll({type:"window"});
    await Promise.all(clients.map(client=>client.navigate(client.url)));
  })());
});

self.addEventListener("fetch",event=>{
  const request=event.request;
  const url=new URL(request.url);
  if(request.method!=="GET"||url.origin!==location.origin||url.pathname.startsWith("/api/")||request.headers.get("RSC"))return;

  if(request.mode==="navigate"){
    event.respondWith(fetch(request,{cache:"no-store"}).catch(()=>caches.match("/").then(response=>response||Response.error())));
    return;
  }

  event.respondWith((async()=>{
    const cached=await caches.match(request);
    const network=fetch(request).then(response=>{
      if(response.ok&&["style","script","image","font"].includes(request.destination)){
        caches.open(CACHE).then(cache=>cache.put(request,response.clone()));
      }
      return response;
    });
    return cached||network.catch(()=>Response.error());
  })());
});
