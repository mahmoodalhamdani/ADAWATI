import { normalizeSearch, toolMap } from "@/lib/registry";
import { tools } from "@/lib/registry";
import { rankPopularToolSlugs } from "@/lib/popular-tools";
import { supabaseAll, supabaseRequest } from "@/lib/supabase-rest";

type ToolViewRow = { selected_tool: string };

function fallbackPopular() {
  return tools
    .filter((tool) => tool.popular)
    .slice(0, 4)
    .map((tool) => tool.slug);
}

export async function GET() {
  const fallback = fallbackPopular();
  try {
    const cutoff = new Date();
    cutoff.setUTCDate(cutoff.getUTCDate() - 30);
    const rows = await supabaseAll<ToolViewRow>(
      `minjaz_search_events?select=selected_tool&event_type=eq.tool_view&created_at=gte.${encodeURIComponent(cutoff.toISOString())}`,
    );
    const slugs = rankPopularToolSlugs(
      rows,
      tools.map((tool) => tool.slug),
      fallback,
      4,
    );
    return Response.json(
      { slugs, windowDays: 30 },
      {
        headers: {
          "Cache-Control": "public, s-maxage=300, stale-while-revalidate=600",
        },
      },
    );
  } catch {
    return Response.json(
      { slugs: fallback, windowDays: 30 },
      { headers: { "Cache-Control": "public, max-age=60" } },
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      query?: string;
      resultCount?: number;
      selectedTool?: string;
    };
    const query = String(body.query || "")
      .trim()
      .slice(0, 120);
    if (
      query.length < 2 ||
      /[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/.test(query) ||
      /\d{7,}/.test(query)
    )
      return Response.json({ ok: true }, { status: 202 });
    const selectedTool = toolMap[String(body.selectedTool || "")]?.slug || "";
    const eventType = query === "__tool_view__" ? "tool_view" : "search";
    await supabaseRequest("minjaz_search_events", {
      method: "POST",
      headers: { Prefer: "return=minimal" },
      body: JSON.stringify({
        event_type: eventType,
        query: eventType === "tool_view" ? "" : query,
        normalized_query:
          eventType === "tool_view" ? "" : normalizeSearch(query),
        result_count: Math.max(0, Math.min(500, Number(body.resultCount) || 0)),
        selected_tool: selectedTool,
      }),
    });
    return Response.json({ ok: true }, { status: 201 });
  } catch {
    return Response.json({ ok: false }, { status: 503 });
  }
}
