import { hashSecret } from "@/lib/admin-auth";
import { exactCount, supabaseRequest } from "@/lib/supabase-rest";

const clean = (value: unknown, max: number) =>
  String(value || "")
    .trim()
    .slice(0, max);
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    if (body.website) return Response.json({ ok: true }, { status: 202 });
    const kind = body.kind === "suggest" ? "suggest" : "contact";
    const name = clean(body.name, 80);
    const email = clean(body.email, 160);
    const subject = clean(body.subject || body.tool, 140);
    const type = clean(body.type, 80);
    const message = clean(body.message || body.description, 3000);
    const category = clean(body.category, 100);
    if (
      name.length < 2 ||
      message.length < 10 ||
      (kind === "contact" && !/^\S+@\S+\.\S+$/.test(email))
    )
      return Response.json(
        { error: "البيانات غير مكتملة أو غير صحيحة." },
        { status: 400 },
      );
    const ip =
      request.headers.get("cf-connecting-ip") ||
      request.headers.get("x-forwarded-for") ||
      "unknown";
    const ipHash = await hashSecret(ip);
    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const recent = await supabaseRequest(
      `minjaz_messages?select=id&ip_hash=eq.${encodeURIComponent(ipHash)}&created_at=gt.${encodeURIComponent(since)}`,
      { method: "HEAD", headers: { Prefer: "count=exact" } },
    );
    if (exactCount(recent) >= 5)
      return Response.json(
        { error: "تم تجاوز عدد الرسائل المسموح به مؤقتاً. حاول لاحقاً." },
        { status: 429 },
      );
    await supabaseRequest("minjaz_messages", {
      method: "POST",
      headers: { Prefer: "return=minimal" },
      body: JSON.stringify({ kind, name, email, subject, type, message, category, ip_hash: ipHash }),
    });
    return Response.json({ ok: true }, { status: 201 });
  } catch {
    return Response.json(
      { error: "تعذر حفظ الرسالة حالياً." },
      { status: 500 },
    );
  }
}
