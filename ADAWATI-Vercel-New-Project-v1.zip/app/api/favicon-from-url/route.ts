const MAX_ICON_BYTES = 2 * 1024 * 1024;

export async function GET(request: Request) {
  const raw = new URL(request.url).searchParams.get("url")?.trim() || "";
  if (!raw) return Response.json({ error: "missing_url" }, { status: 400 });

  let site: URL;
  try {
    site = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
  } catch {
    return Response.json({ error: "invalid_url" }, { status: 400 });
  }
  if (!["http:", "https:"].includes(site.protocol) || !site.hostname || site.username || site.password) {
    return Response.json({ error: "invalid_url" }, { status: 400 });
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8_000);
  try {
    const providerUrl = `https://www.google.com/s2/favicons?domain_url=${encodeURIComponent(site.origin)}&sz=256`;
    const response = await fetch(providerUrl, {
      signal: controller.signal,
      headers: { Accept: "image/png,image/*;q=0.8" },
    });
    if (!response.ok) throw new Error("upstream");
    const contentType = response.headers.get("content-type") || "";
    if (!contentType.startsWith("image/")) throw new Error("not_image");
    const bytes = await response.arrayBuffer();
    if (!bytes.byteLength || bytes.byteLength > MAX_ICON_BYTES) throw new Error("invalid_size");
    return new Response(bytes, {
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "public, max-age=3600, s-maxage=86400",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch {
    return Response.json({ error: "favicon_unavailable" }, { status: 502 });
  } finally {
    clearTimeout(timeout);
  }
}
