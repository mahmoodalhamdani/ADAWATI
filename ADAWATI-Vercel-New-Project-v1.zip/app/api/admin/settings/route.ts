import { isAdmin } from "@/lib/admin-auth";
import { supabaseJson, supabaseRequest } from "@/lib/supabase-rest";

const allowed = ["name", "nameEn", "domain", "owner", "email", "privacy", "tagline"];

export async function GET(request: Request) {
  if (!(await isAdmin(request))) return Response.json({ error: "غير مصرح" }, { status: 401 });
  const rows = await supabaseJson<Array<{ key: string; value: string }>>("minjaz_site_settings?select=key,value");
  return Response.json({ settings: Object.fromEntries(rows.map((row) => [row.key, row.value])) });
}

export async function PUT(request: Request) {
  if (!(await isAdmin(request))) return Response.json({ error: "غير مصرح" }, { status: 401 });
  const payload = (await request.json()) as Record<string, unknown>;
  const rows = allowed.filter((key) => key in payload).map((key) => ({
    key,
    value: String(payload[key] || "").slice(0, 300),
    updated_at: new Date().toISOString(),
  }));
  if (rows.length) {
    await supabaseRequest("minjaz_site_settings?on_conflict=key", {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify(rows),
    });
  }
  return Response.json({ ok: true });
}
