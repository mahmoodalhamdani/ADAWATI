import { isAdmin } from "@/lib/admin-auth";
import { exactCount, supabaseJson, supabaseRequest } from "@/lib/supabase-rest";

type MessageRow = {
  id: string;
  kind: string;
  name: string;
  email: string;
  subject: string;
  type: string;
  message: string;
  category: string;
  status: string;
  created_at: string;
};

export async function GET(request: Request) {
  if (!(await isAdmin(request))) return Response.json({ error: "غير مصرح" }, { status: 401 });
  const [rows, totalResponse, newResponse] = await Promise.all([
    supabaseJson<MessageRow[]>("minjaz_messages?select=id,kind,name,email,subject,type,message,category,status,created_at&order=created_at.desc&limit=200"),
    supabaseRequest("minjaz_messages?select=id", { method: "HEAD", headers: { Prefer: "count=exact" } }),
    supabaseRequest("minjaz_messages?select=id&status=eq.new", { method: "HEAD", headers: { Prefer: "count=exact" } }),
  ]);
  return Response.json({
    messages: rows.map((row) => ({ ...row, createdAt: row.created_at })),
    total: exactCount(totalResponse),
    newTotal: exactCount(newResponse),
  });
}

export async function DELETE(request: Request) {
  if (!(await isAdmin(request))) return Response.json({ error: "غير مصرح" }, { status: 401 });
  const id = new URL(request.url).searchParams.get("id") || "";
  let ids = id ? [id] : [];
  if (!ids.length) {
    try { const body = (await request.json()) as { ids?: string[] }; ids = Array.isArray(body.ids) ? body.ids.slice(0, 200) : []; } catch { ids = []; }
  }
  ids = ids.filter((value) => /^[a-zA-Z0-9_-]{1,80}$/.test(value));
  if (!ids.length) return Response.json({ error: "المعرف مطلوب" }, { status: 400 });
  const filter = ids.length === 1 ? `id=eq.${encodeURIComponent(ids[0])}` : `id=in.(${ids.map(encodeURIComponent).join(",")})`;
  await supabaseRequest(`minjaz_messages?${filter}`, { method: "DELETE", headers: { Prefer: "return=minimal" } });
  return Response.json({ ok: true });
}

export async function PATCH(request: Request) {
  if (!(await isAdmin(request))) return Response.json({ error: "غير مصرح" }, { status: 401 });
  const body = (await request.json()) as { ids?: string[]; status?: string };
  const ids = (Array.isArray(body.ids) ? body.ids : []).slice(0, 200).filter((value) => /^[a-zA-Z0-9_-]{1,80}$/.test(value));
  if (!ids.length || body.status !== "read") return Response.json({ error: "الطلب غير صالح" }, { status: 400 });
  const filter = ids.length === 1 ? `id=eq.${encodeURIComponent(ids[0])}` : `id=in.(${ids.map(encodeURIComponent).join(",")})`;
  await supabaseRequest(`minjaz_messages?${filter}`, { method: "PATCH", headers: { Prefer: "return=minimal" }, body: JSON.stringify({ status: "read" }) });
  return Response.json({ ok: true });
}
