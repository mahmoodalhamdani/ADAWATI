import { isAdmin } from "@/lib/admin-auth";
import { supabaseAll } from "@/lib/supabase-rest";

type SearchRow = {
  id: string;
  event_type: "search" | "tool_view";
  query: string;
  normalized_query: string;
  result_count: number;
  selected_tool: string;
  created_at: string;
};

export async function GET(request: Request) {
  if (!(await isAdmin(request))) return Response.json({ error: "غير مصرح" }, { status: 401 });
  const requestedRange = Number(new URL(request.url).searchParams.get("range") || 7);
  const rangeDays = [7, 30, 180].includes(requestedRange) ? requestedRange : 7;
  const now = new Date();
  const cutoff = new Date(now);
  if (rangeDays === 180) {
    cutoff.setUTCDate(1);
    cutoff.setUTCMonth(cutoff.getUTCMonth() - 5);
  } else {
    cutoff.setUTCDate(now.getUTCDate() - (rangeDays - 1));
  }
  cutoff.setUTCHours(0, 0, 0, 0);
  const rows = await supabaseAll<SearchRow>(`minjaz_search_events?select=id,event_type,query,normalized_query,result_count,selected_tool,created_at&created_at=gte.${encodeURIComponent(cutoff.toISOString())}&order=created_at.desc`);
  const searches = new Map<string, { query: string; count: number; noResults: number; selected: number }>();
  const popular = new Map<string, number>();
  const days = rangeDays === 180
    ? Array.from({ length: 6 }, (_, index) => {
        const date = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - (5 - index), 1));
        return { date: date.toISOString().slice(0, 7), label: new Intl.DateTimeFormat("ar-IQ", { month: "short", year: "numeric", timeZone: "UTC" }).format(date), count: 0 };
      })
    : Array.from({ length: rangeDays }, (_, index) => {
        const date = new Date(now);
        date.setUTCDate(now.getUTCDate() - (rangeDays - 1 - index));
        return {
          date: date.toISOString().slice(0, 10),
          label: new Intl.DateTimeFormat("ar-IQ", rangeDays === 7 ? { weekday: "short", timeZone: "UTC" } : { day: "numeric", month: "short", timeZone: "UTC" }).format(date),
          count: 0,
        };
      });
  const daily = new Map(days.map((day) => [day.date, day]));
  for (const row of rows) {
    if (row.event_type === "tool_view") {
      if (row.selected_tool) popular.set(row.selected_tool, (popular.get(row.selected_tool) || 0) + 1);
      const day = daily.get(row.created_at.slice(0, rangeDays === 180 ? 7 : 10));
      if (day) day.count++;
      continue;
    }
    const key = row.normalized_query;
    const current = searches.get(key) || { query: row.query, count: 0, noResults: 0, selected: 0 };
    current.count++;
    if (row.result_count === 0) current.noResults++;
    if (row.selected_tool) current.selected++;
    searches.set(key, current);
  }
  const values = [...searches.values()].sort((a, b) => b.count - a.count);
  return Response.json({
    top: values.slice(0, 10),
    gaps: values.filter((value) => value.noResults > 0).sort((a, b) => b.noResults - a.noResults).slice(0, 10),
    popularTools: [...popular.entries()].map(([slug, count]) => ({ slug, count })).sort((a, b) => b.count - a.count).slice(0, 8),
    daily: days,
    weekTotal: days.reduce((sum, day) => sum + day.count, 0),
    periodTotal: days.reduce((sum, day) => sum + day.count, 0),
    rangeDays,
    events: rows.slice(0, 30).map((row) => ({ id: row.id, type: row.event_type === "tool_view" ? "tool" : "search", slug: row.selected_tool, query: row.query, createdAt: row.created_at })),
  });
}
