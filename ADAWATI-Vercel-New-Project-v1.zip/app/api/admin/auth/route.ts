import { supabaseRequest } from "@/lib/supabase-rest";
import {
  adminCookie,
  getAdminAuth,
  hashSecret,
  isAdmin,
} from "@/lib/admin-auth";

export async function GET(request: Request) {
  try {
    const auth = await getAdminAuth();
    return Response.json({
      configured: Boolean(auth),
      authenticated: await isAdmin(request),
    });
  } catch {
    return Response.json(
      { configured: false, authenticated: false },
      { status: 503 },
    );
  }
}
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { action?: string; pin?: string; newPin?: string; confirmPin?: string };
    const pin = String(body.pin || "");
    if (!/^\d{6}$/.test(pin))
      return Response.json(
        { error: "يجب أن يتكون رمز PIN من 6 أرقام بالضبط." },
        { status: 400 },
      );
    const existing = await getAdminAuth();
    const pinHash = await hashSecret(pin);
    if (body.action === "change") {
      const newPin = String(body.newPin || "");
      const confirmPin = String(body.confirmPin || "");
      if (!(await isAdmin(request))) return Response.json({ error: "انتهت الجلسة الإدارية. سجّل الدخول مجدداً." }, { status: 401 });
      if (!existing || existing.pinHash !== pinHash) return Response.json({ error: "رمز الدخول الحالي غير صحيح." }, { status: 401 });
      if (!/^\d{6}$/.test(newPin)) return Response.json({ error: "يجب أن يتكون الرمز الجديد من 6 أرقام بالضبط." }, { status: 400 });
      if (newPin !== confirmPin) return Response.json({ error: "الرمز الجديد وتأكيده غير متطابقين." }, { status: 400 });
      if (newPin === pin) return Response.json({ error: "اختر رمزاً جديداً مختلفاً عن الرمز الحالي." }, { status: 400 });
      const newPinHash = await hashSecret(newPin);
      await supabaseRequest("minjaz_admin_auth?id=eq.1", {
        method: "PATCH",
        headers: { Prefer: "return=minimal" },
        body: JSON.stringify({ pin_hash: newPinHash }),
      });
      return Response.json({ ok: true }, { headers: { "set-cookie": adminCookie(newPinHash) } });
    }
    if (body.action === "setup") {
      if (existing)
        return Response.json(
          { error: "تم إعداد لوحة الإدارة مسبقاً." },
          { status: 409 },
        );
      await supabaseRequest("minjaz_admin_auth", {
        method: "POST",
        headers: { Prefer: "return=minimal" },
        body: JSON.stringify({ id: 1, pin_hash: pinHash }),
      });
      return Response.json(
        { ok: true },
        { status: 201, headers: { "set-cookie": adminCookie(pinHash) } },
      );
    }
    if (!existing || existing.pinHash !== pinHash)
      return Response.json({ error: "رمز الدخول غير صحيح." }, { status: 401 });
    return Response.json(
      { ok: true },
      { headers: { "set-cookie": adminCookie(pinHash) } },
    );
  } catch {
    return Response.json(
      { error: "تعذر التحقق من لوحة الإدارة." },
      { status: 500 },
    );
  }
}
export async function DELETE() {
  return Response.json(
    { ok: true },
    {
      headers: {
        "set-cookie":
          "minjaz_admin=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0",
      },
    },
  );
}
