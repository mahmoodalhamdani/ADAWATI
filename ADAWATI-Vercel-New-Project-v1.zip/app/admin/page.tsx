import type {Metadata} from "next";import {AdminDashboard} from "../components/AdminDashboard";
export const metadata:Metadata={title:"لوحة الإدارة",robots:{index:false,follow:false},alternates:{canonical:"/admin"}};
export default function AdminPage(){return <div className="admin-page"><AdminDashboard/></div>}
