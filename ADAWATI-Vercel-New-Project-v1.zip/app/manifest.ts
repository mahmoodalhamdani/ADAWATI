import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "أدواتي | ADAWATI",
    short_name: "أدواتي",
    description: "أدواتي لتجعل حياتك أسهل",
    start_url: "/",
    display: "standalone",
    background_color: "#fcfdff",
    theme_color: "#07184f",
    dir: "rtl",
    lang: "ar",
    orientation: "any",
    icons: [
      { src: "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
