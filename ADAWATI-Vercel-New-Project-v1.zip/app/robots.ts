import type { MetadataRoute } from "next";
import { siteConfig } from "@/lib/registry";

export default function robots(): MetadataRoute.Robots {
  return { rules: [{ userAgent: "*", allow: "/", disallow: ["/admin", "/api/", "/favorites", "/suggest-tool", "/search", "/*?sort=", "/*?category="] }], sitemap: `${siteConfig.baseUrl}/sitemap.xml`, host: siteConfig.baseUrl };
}
