import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { categories, categoryMap, getCategoryDescription, getToolDescription, siteConfig, toolMap, tools } from "@/lib/registry";
import { Icon } from "@/app/components/Icon";
import { FavoriteButton } from "@/app/components/FavoriteButton";
import { ToolCard } from "@/app/components/Cards";
import { ToolWorkspace } from "@/app/components/ToolWorkspace";
import { ToolsExplorer } from "@/app/components/ToolsExplorer";
import { Localized } from "@/app/components/Localized";

type Props = { params: Promise<{ slug: string }> };

export function generateStaticParams() { return [...categories.map((item) => ({ slug: item.slug })), ...tools.map((item) => ({ slug: item.slug }))]; }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  if (slug === "data-extractor") return { title: "مولّد النص الذكي", robots: { index: false, follow: true } };
  const item = toolMap[slug]; const category = categoryMap[slug];
  if (item) return { title: item.seoTitle.replace(" | أدواتي", ""), description: item.seoDescription, alternates: { canonical: `/tools/${slug}` }, openGraph: { title: item.seoTitle, description: item.seoDescription, url: `/tools/${slug}`, type: "website", images: [{ url: "/og.png", width: 1200, height: 630, alt: `أدواتي - ${item.name}` }] }, twitter: { card: "summary_large_image", title: item.seoTitle, description: item.seoDescription, images: ["/og.png"] } };
  if (category) return { title: `${category.name} المجانية`, description: `${category.description} اكتشف أفضل ${category.name} المجانية على أدواتي.`, alternates: { canonical: `/tools/${slug}` } };
  return { title: "الصفحة غير موجودة", robots: { index: false, follow: false } };
}

export default async function ToolOrCategoryPage({ params }: Props) {
  const { slug } = await params;
  if (slug === "data-extractor") redirect("/tools/local-text-generator");
  const category = categoryMap[slug]; const item = toolMap[slug];

  if (category) {
    const count = tools.filter((tool) => tool.category === category.slug).length;
    return <div className="inner-page"><div className="page-width">
      <nav className="breadcrumb"><Link href="/"><Localized ar="الرئيسية" en="Home" /></Link><span>/</span><Link href="/tools"><Localized ar="الأدوات" en="Tools" /></Link><span>/</span><span><Localized ar={category.name} en={category.nameEn} /></span></nav>
      <header className="category-hero"><span className={`icon-tile color-${category.color}`}><Icon name={category.icon} size={30}/></span><div><h1><Localized ar={`أدوات ${category.name}`} en={`${category.nameEn} tools`} /></h1><p><Localized ar={`${category.description} يتوفر حالياً ${count} أدوات عملية في هذا التصنيف.`} en={`${getCategoryDescription(category, "en")} ${count} practical tools are available in this category.`} /></p></div></header>
      <ToolsExplorer initialCategory={category.slug}/>
      <section className="seo-copy panel"><h2><Localized ar={`ما الذي يمكنك إنجازه بأدوات ${category.name}؟`} en={`What can you do with ${category.nameEn} tools?`} /></h2><p><Localized ar="صُممت هذه المجموعة لتمنحك نتيجة واضحة وسريعة من الهاتف أو الحاسوب. اختر الأداة المناسبة، أدخل بياناتك، وستظهر النتيجة مباشرة دون خطوات معقدة." en="This collection is designed for clear, fast results on phones and computers. Choose a tool, enter the required details, and get an instant result." /></p><h2><Localized ar="هل استخدام الأدوات آمن؟" en="Are these tools safe?" /></h2><p><Localized ar="نطبّق مبدأ المعالجة المحلية كلما سمحت التقنية بذلك، لذلك تبقى ملفاتك ومدخلاتك داخل جهازك في الأدوات التي تدعم هذا الأسلوب." en="Whenever possible, processing happens locally so your files and inputs stay on your device." /></p></section>
    </div></div>;
  }

  if (!item) notFound();
  const group = categoryMap[item.category];
  const related = item.related.map((relatedSlug) => toolMap[relatedSlug]).filter(Boolean);
  const breadcrumbSchema = { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: "الرئيسية", item: siteConfig.baseUrl }, { "@type": "ListItem", position: 2, name: group.name, item: `${siteConfig.baseUrl}/tools/${group.slug}` }, { "@type": "ListItem", position: 3, name: item.name, item: `${siteConfig.baseUrl}/tools/${item.slug}` }] };
  const appSchema = { "@context": "https://schema.org", "@type": "WebApplication", name: item.name, alternateName: item.nameEn, description: item.description, applicationCategory: "UtilitiesApplication", operatingSystem: "Any", isAccessibleForFree: true, url: `${siteConfig.baseUrl}/tools/${item.slug}`, offers: { "@type": "Offer", price: "0", priceCurrency: "USD" } };
  const englishQuestions = [`How do I use ${item.nameEn}?`, `Is ${item.nameEn} private?`, `Can I use it for free?`];

  return <article className="inner-page tool-detail">
    <script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(breadcrumbSchema)}}/><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(appSchema)}}/>
    <div className="page-width">
      <nav className="breadcrumb"><Link href="/"><Localized ar="الرئيسية" en="Home" /></Link><span>/</span><Link href={`/tools/${group.slug}`}><Localized ar={group.name} en={group.nameEn} /></Link><span>/</span><span><Localized ar={item.name} en={item.nameEn} /></span></nav>
      <header className="tool-heading"><span className={`icon-tile color-${item.color}`}><Icon name={item.icon} size={34}/></span><div><p>{item.nameEn}</p><h1><Localized ar={item.name} en={item.nameEn} /></h1><span><Localized ar={item.description} en={getToolDescription(item, "en")} /></span></div><FavoriteButton slug={item.slug}/></header>
      <section className="tool-workspace panel" aria-label={item.nameEn}><ToolWorkspace slug={item.slug}/></section>
      <div className="tool-content-grid"><div className="tool-article panel">
        <section><h2><Localized ar={`كيفية استخدام ${item.name}`} en={`How to use ${item.nameEn}`} /></h2><ol><li><Localized ar="أدخل البيانات أو اختر الملفات المطلوبة في مساحة الأداة أعلاه." en="Enter the requested details or choose the required files above." /></li><li><Localized ar="راجع الخيارات المتاحة واضبطها بما يناسب مهمتك." en="Review the available settings and adjust them for your task." /></li><li><Localized ar="اضغط زر التنفيذ لتحصل على النتيجة فوراً." en="Run the tool to get your result instantly." /></li></ol></section>
        <section><h2><Localized ar={`ما هي ${item.name}؟`} en={`What is ${item.nameEn}?`} /></h2><p><Localized ar={`${item.description} صممناها لتعمل ببساطة على الهاتف والحاسوب ومن دون إنشاء حساب.`} en={`${getToolDescription(item, "en")} It works on phones and computers without requiring an account.`} /></p></section>
        <section><h2><Localized ar="الخصوصية أولاً" en="Privacy first" /></h2><p><Localized ar="تعالج أدواتي مدخلات هذه الأداة داخل متصفحك كلما كان ذلك ممكناً، ولا تستخدم الملفات أو البيانات الشخصية لأغراض تسويقية." en="ADAWATI processes inputs in your browser whenever possible and never uses your files or personal data for marketing." /></p></section>
        <section><h2><Localized ar="أسئلة شائعة" en="Frequently asked questions" /></h2><div className="faq-list">{item.questions.map((question, index)=><details key={question} open={index===0}><summary><Localized ar={question} en={englishQuestions[index] || englishQuestions[0]} /></summary><p><Localized ar={index===1 ? "تعمل الأداة محلياً قدر الإمكان، ولا نحتفظ بمدخلاتك الشخصية." : `يمكنك استخدام ${item.name} مباشرة وبشكل مجاني. اتبع الخطوات الموجودة أعلى الصفحة وستظهر النتيجة خلال ثوانٍ.`} en={index===1 ? "Processing stays on your device whenever possible, and personal inputs are not stored." : `You can use ${item.nameEn} immediately and for free. Follow the steps above to get a result in seconds.`} /></p></details>)}</div></section>
      </div><aside className="tool-aside"><div className="panel privacy-card"><Icon name="shield" size={26}/><h2><Localized ar="بياناتك تحت سيطرتك" en="Your data stays under your control" /></h2><p><Localized ar="لا تحتاج إلى تسجيل، ولا نستخدم مدخلات الأداة في التتبع أو الإعلانات." en="No account is required, and tool inputs are not used for tracking or ads." /></p></div><Link href={`/contact?tool=${item.slug}`} className="report-link"><Localized ar="وجدت مشكلة؟ أخبرنا عنها" en="Found a problem? Tell us" /></Link></aside></div>
      {related.length>0&&<section className="related-section"><div className="section-heading"><h2><Localized ar="أدوات مشابهة" en="Related tools" /></h2></div><div className="related-grid">{related.map((tool)=><ToolCard key={tool.slug} tool={tool}/>)}</div></section>}
    </div>
  </article>;
}
