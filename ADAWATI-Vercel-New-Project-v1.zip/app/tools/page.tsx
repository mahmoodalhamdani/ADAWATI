import type { Metadata } from "next";
import Link from "next/link";
import { ToolsExplorer } from "../components/ToolsExplorer";
import { Localized } from "../components/Localized";

export const metadata: Metadata = {
  title: "كل الأدوات الرقمية المجانية",
  description: "اكتشف أدوات أدواتي للصور وPDF والنصوص والحسابات والدراسة والإنترنت واختر ما تحتاجه لإنجاز مهمتك بسرعة.",
  alternates: { canonical: "/tools" },
};

export default async function ToolsPage({ searchParams }: { searchParams?: Promise<{ search?: string | string[] }> }) {
  const params = await searchParams;
  const rawSearch = params?.search;
  const initialQuery = (Array.isArray(rawSearch) ? rawSearch[0] : rawSearch || "").trim();
  return <div className="inner-page"><div className="page-width"><nav className="breadcrumb"><Link href="/"><Localized ar="الرئيسية" en="Home" /></Link><span>/</span><span><Localized ar={initialQuery ? "نتائج البحث" : "كل الأدوات"} en={initialQuery ? "Search results" : "All tools"} /></span></nav><header className="page-heading"><h1><Localized ar={initialQuery ? "نتائج البحث" : "كل الأدوات"} en={initialQuery ? "Search results" : "All tools"} /></h1><p>{initialQuery ? <Localized ar={`كل الأدوات المطابقة لعبارة «${initialQuery}» في قائمة واحدة؛ اختر الأداة التي تريد فتحها.`} en={`All tools matching “${initialQuery}” in one list. Select the tool you want to open.`} /> : <Localized ar="اكتشف أدوات أدواتي واختر ما تحتاجه لإنجاز مهمتك بسرعة. جميع الأدوات تعمل دون تسجيل، ومعالجة البيانات تتم داخل جهازك كلما أمكن." en="Explore every ADAWATI tool and choose what you need to finish your task quickly. No account is required, and data is processed locally whenever possible." />}</p></header><ToolsExplorer initialQuery={initialQuery} /></div></div>;
}
