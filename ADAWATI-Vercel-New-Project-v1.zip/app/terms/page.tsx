import type { Metadata } from "next";
import Link from "next/link";
import { Localized } from "../components/Localized";
import { siteConfig } from "@/lib/registry";

export const metadata: Metadata = {
  title: "الشروط والأحكام | Terms",
  description: "شروط استخدام منصة أدواتي وأدواتها الرقمية.",
  alternates: { canonical: "/terms" },
};

const sections = [
  ["قبول الشروط وطبيعة الخدمة", "Accepting the terms", "استخدام أدواتي يعني الموافقة على هذه الشروط. توفر المنصة أدوات رقمية عامة لمساعدة المستخدم في مهام يومية.", "Using ADAWATI means accepting these terms. The platform provides general digital tools for everyday tasks."],
  ["الاستخدام المشروع", "Lawful use", "يمنع استخدام الأدوات لأغراض مخالفة للقانون، أو الإضرار بالآخرين، أو محاولة اختراق المنصة أو تعطيلها أو تجاوز حدود الاستخدام.", "You may not use the tools unlawfully, harm others, attempt to compromise the platform, disrupt it, or bypass usage limits."],
  ["دقة النتائج", "Result accuracy", "نبذل جهداً لتوفير نتائج صحيحة، لكن بعض النتائج تعتمد على مدخلات المستخدم وعوامل تقنية خارجية. راجع النتائج المهمة قبل الاعتماد عليها.", "We work to provide accurate results, but some depend on user input and external technical factors. Verify important results before relying on them."],
  ["الأدوات المالية", "Financial tools", "الحاسبات المالية لأغراض حسابية وتعليمية عامة ولا تمثل استشارة مالية أو قانونية.", "Financial calculators are for general calculation and education and do not constitute financial or legal advice."],
  ["الملكية الفكرية", "Intellectual property", "حقوق تصميم أدواتي والعلامة والهوية والمحتوى الأصلي محفوظة لمالك المنصة.", "The ADAWATI design, brand, identity, and original content remain the property of the platform owner."],
  ["الخدمات والتحديثات", "Services and updates", "يمكن تحديث الأدوات أو إضافتها أو إزالتها عند الحاجة، وقد تعتمد بعض الأدوات مستقبلاً على خدمات خارجية تخضع لسياساتها الخاصة.", "Tools may be updated, added, or removed when needed. Some future tools may depend on external services governed by their own policies."],
  ["التواصل", "Contact", `للاستفسارات القانونية تواصل عبر ${siteConfig.legalEmail}. ويحدد الاختصاص القانوني النهائي من إعدادات المنصة عند الإطلاق العام.`, `For legal questions, contact ${siteConfig.legalEmail}. Final jurisdiction will be defined in the platform settings before public launch.`],
] as const;

export default function TermsPage() {
  return <div className="inner-page"><div className="page-width legal-page">
    <nav className="breadcrumb"><Link href="/"><Localized ar="الرئيسية" en="Home" /></Link><span>/</span><span><Localized ar="الشروط والأحكام" en="Terms" /></span></nav>
    <header className="page-heading"><h1><Localized ar="الشروط والأحكام" en="Terms and conditions" /></h1><p><Localized ar="تنظم هذه الشروط استخدام منصة أدواتي والأدوات المتاحة فيها." en="These terms govern your use of ADAWATI and its available tools." /></p></header>
    <div className="panel legal-copy">{sections.map(([arTitle,enTitle,arText,enText]) => <section key={arTitle}><h2><Localized ar={arTitle} en={enTitle} /></h2><p><Localized ar={arText} en={enText} /></p></section>)}</div>
  </div></div>;
}
