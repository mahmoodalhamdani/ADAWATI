import type { Metadata } from "next";
import Link from "next/link";
import { Localized } from "../components/Localized";
import { siteConfig } from "@/lib/registry";

export const metadata: Metadata = {
  title: "سياسة الخصوصية | Privacy Policy",
  description: "سياسة الخصوصية في منصة أدواتي الرقمية.",
  alternates: { canonical: "/privacy" },
};

const sections = [
  ["مقدمة", "Introduction", "تحترم أدواتي خصوصيتك، ونبني أدواتنا وفق مبدأ تقليل جمع البيانات والمعالجة المحلية كلما أمكن.", "ADAWATI respects your privacy. We design our tools to minimize data collection and process information locally whenever possible."],
  ["البيانات التي نجمعها", "Data we collect", "قد نجمع بيانات تقنية عامة ومحدودة مثل نوع الجهاز والمتصفح والصفحات المستخدمة وبيانات إحصائية مجهولة بهدف تحسين الأداء.", "We may collect limited general technical data, such as device and browser type, pages used, and anonymous statistics to improve performance."],
  ["بيانات الأدوات والملفات", "Tool data and files", "لا نستخدم المدخلات أو الملفات لأغراض تسويقية. الأدوات التي يمكن تشغيلها داخل المتصفح تعالج البيانات على جهازك. وإذا تطلبت أداة مستقبلية معالجة خادمية، تكون الملفات مؤقتة وتحذف وفق النظام المعلن للأداة.", "We do not use your inputs or files for marketing. Browser-based tools process data on your device. If a future tool requires server processing, files will be temporary and deleted according to the policy shown for that tool."],
  ["كلمات المرور", "Passwords", "مولد كلمات المرور وفاحص القوة يعملان داخل جهازك، ولا نخزن كلمات المرور أو نرسلها إلى الخادم.", "The password generator and strength checker run on your device. Passwords are neither stored nor sent to the server."],
  ["ملفات الارتباط والتحليلات", "Cookies and analytics", "قد نستخدم تخزين المتصفح لحفظ الثيم والمفضلة، وتحليلات محدودة لتحسين الموقع. لا نسجل محتوى النصوص أو الصور أو PDF أو كلمات المرور أو المدخلات المالية الشخصية.", "We may use browser storage for theme and favorites, plus limited analytics to improve the site. We do not log the contents of text, images, PDFs, passwords, or personal financial inputs."],
  ["حقوقك", "Your rights", `يمكنك طلب الوصول إلى بياناتك إن وجدت، أو تصحيحها أو حذفها، عبر ${siteConfig.privacyEmail}.`, `You may request access to, correction of, or deletion of any data we hold by contacting ${siteConfig.privacyEmail}.`],
  ["تحديث السياسة", "Policy updates", "قد نحدّث هذه السياسة عند تغير الأدوات أو طريقة المعالجة، وسنوضح تاريخ التحديث الحقيقي عند حدوثه.", "We may update this policy when tools or processing methods change, and we will display the actual revision date when that happens."],
] as const;

export default function PrivacyPage() {
  return <div className="inner-page"><div className="page-width legal-page">
    <nav className="breadcrumb"><Link href="/"><Localized ar="الرئيسية" en="Home" /></Link><span>/</span><span><Localized ar="سياسة الخصوصية" en="Privacy policy" /></span></nav>
    <header className="page-heading"><h1><Localized ar="سياسة الخصوصية" en="Privacy policy" /></h1><p><Localized ar="آخر تحديث: يعرض عند إجراء تعديل جوهري على هذه السياسة." en="Last updated: shown whenever this policy changes materially." /></p></header>
    <div className="panel legal-copy">{sections.map(([arTitle,enTitle,arText,enText]) => <section key={arTitle}><h2><Localized ar={arTitle} en={enTitle} /></h2><p><Localized ar={arText} en={enText} /></p></section>)}</div>
  </div></div>;
}
