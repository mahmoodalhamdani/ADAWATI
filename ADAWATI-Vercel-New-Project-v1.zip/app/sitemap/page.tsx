import type { Metadata } from "next";
import Link from "next/link";
import { Localized } from "../components/Localized";
import { categories, tools } from "@/lib/registry";

export const metadata: Metadata = {
  title: "خريطة الموقع | Sitemap",
  description: "دليل منظم لصفحات وأدوات وتصنيفات أدواتي.",
  alternates: { canonical: "/sitemap" },
};

const pages = [
  ["/", "الرئيسية", "Home"],
  ["/tools", "كل الأدوات", "All tools"],
  ["/about", "من نحن", "About"],
  ["/contact", "اتصل بنا", "Contact"],
  ["/faq", "الأسئلة الشائعة", "FAQ"],
  ["/privacy", "سياسة الخصوصية", "Privacy policy"],
  ["/terms", "الشروط والأحكام", "Terms"],
] as const;

export default function SitemapPage(){return <div className="inner-page"><div className="page-width">
  <header className="page-heading"><h1><Localized ar="خريطة الموقع" en="Sitemap" /></h1><p><Localized ar="وصول سريع ومنظم إلى جميع الصفحات والتصنيفات والأدوات المنشورة." en="Quick, organized access to every published page, category, and tool." /></p></header>
  <div className="sitemap-grid">
    <section className="panel"><h2><Localized ar="الصفحات" en="Pages" /></h2>{pages.map(([href,ar,en])=><Link key={href} href={href}><Localized ar={ar} en={en} /></Link>)}</section>
    <section className="panel"><h2><Localized ar="التصنيفات" en="Categories" /></h2>{categories.map((item)=><Link key={item.slug} href={`/tools/${item.slug}`}><Localized ar={item.name} en={item.nameEn} /></Link>)}</section>
    <section className="panel sitemap-tools"><h2><Localized ar="الأدوات" en="Tools" /></h2>{tools.map((item)=><Link key={item.slug} href={`/tools/${item.slug}`}><Localized ar={item.name} en={item.nameEn} /></Link>)}</section>
  </div>
</div></div>}
