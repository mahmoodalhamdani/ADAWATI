import type { Metadata } from "next";
import Link from "next/link";
import { FavoritesGrid } from "../components/FavoritesGrid";
import { Localized } from "../components/Localized";

export const metadata:Metadata={title:"المفضلة",description:"أدوات أدواتي التي حفظتها على هذا الجهاز.",robots:{index:false,follow:true},alternates:{canonical:"/favorites"}};
export default function FavoritesPage(){return <div className="inner-page"><div className="page-width"><nav className="breadcrumb"><Link href="/"><Localized ar="الرئيسية" en="Home" /></Link><span>/</span><span><Localized ar="المفضلة" en="Favorites" /></span></nav><header className="page-heading"><h1><Localized ar="المفضلة" en="Favorites" /></h1><p><Localized ar="أدواتك المحفوظة على هذا الجهاز، لتصل إليها بسرعة في أي وقت." en="Tools saved on this device so you can reach them quickly at any time." /></p></header><FavoritesGrid/></div></div>}
