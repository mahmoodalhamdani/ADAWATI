import type { Metadata } from "next";
import "./globals.css";
import { SiteChrome } from "./components/SiteChrome";
import { siteConfig } from "@/lib/registry";
import { PwaRegister } from "./components/PwaRegister";
import { LocaleProvider } from "./components/LocaleProvider";
import { CopyFeedback } from "./components/CopyFeedback";
import { NumericInputBehavior } from "./components/NumericInputBehavior";
import { AccessibleFieldBehavior } from "./components/AccessibleFieldBehavior";
import { SkipLink } from "./components/SkipLink";

export const viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#fcfdff" },
    { media: "(prefers-color-scheme: dark)", color: "#07101f" },
  ],
};

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.baseUrl),
  title: { default: "أدواتي | أدوات رقمية سريعة ومجانية", template: "%s | أدواتي" },
  description: "أدواتي منصة عربية تجمع أدوات مجانية للصور وPDF والنصوص والحسابات والدراسة والخصوصية، وتعمل بسرعة من مكان واحد.",
  applicationName: "أدواتي | ADAWATI",
  keywords: ["أدوات مجانية", "أدوات اون لاين", "ضغط الصور", "دمج PDF", "حاسبة العمر", "أدواتي", "ADAWATI"],
  alternates: { canonical: "/" },
  openGraph: { type: "website", locale: "ar_AR", url: "/", siteName: "أدواتي | ADAWATI", title: "أدواتي | لتجعل حياتك أسهل", description: "منصة عربية ذكية تجمع أدوات رقمية سريعة ومفيدة في مكان واحد", images: [{ url: "/og.png", width: 1200, height: 630, alt: "شعار أدواتي الذهبي مع عبارة أدواتي لتجعل حياتك أسهل" }] },
  twitter: { card: "summary_large_image", title: "أدواتي | ADAWATI", description: "أدواتي لتجعل حياتك أسهل", images: ["/og.png"] },
  other: {
    "codex-preview": "development",
    "apple-mobile-web-app-capable": "yes",
    "apple-mobile-web-app-status-bar-style": "default",
  },
  icons: {
    icon: [{ url: "/favicon.png", sizes: "64x64", type: "image/png" }, { url: "/favicon-32.png", sizes: "32x32", type: "image/png" }, { url: "/favicon-16.png", sizes: "16x16", type: "image/png" }], shortcut: "/favicon.png", apple: "/apple-touch-icon.png",
  },
  manifest: "/manifest.webmanifest",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify({"@context":"https://schema.org","@type":"Organization",name:"أدواتي",alternateName:"ADAWATI",url:siteConfig.baseUrl,logo:`${siteConfig.baseUrl}/brand/adawati-logo.webp`})}}/><PwaRegister/><NumericInputBehavior/><AccessibleFieldBehavior/><LocaleProvider><CopyFeedback/><SkipLink/><SiteChrome>{children}</SiteChrome></LocaleProvider></body>
    </html>
  );
}
