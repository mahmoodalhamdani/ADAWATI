import type { Metadata } from "next";
import Link from "next/link";
import { Localized } from "../components/Localized";

export const metadata: Metadata = { title: "الأسئلة الشائعة", description: "إجابات عن الأسئلة الشائعة حول أدوات أدواتي والخصوصية والملفات.", alternates: { canonical: "/faq" } };
const faqs = [
  { arQ: "هل أدوات أدواتي مجانية؟", arA: "نعم، الأدوات المتاحة حالياً مجانية ولا تحتاج إلى إنشاء حساب.", enQ: "Are ADAWATI tools free?", enA: "Yes. The tools currently available are free and require no account." },
  { arQ: "هل أحتاج إلى إنشاء حساب؟", arA: "لا. يمكنك استخدام الأدوات وحفظ المفضلة على جهازك دون حساب.", enQ: "Do I need an account?", enA: "No. You can use tools and save favorites on your device without an account." },
  { arQ: "هل يتم حفظ ملفاتي؟", arA: "تعالج الأدوات الملفات داخل المتصفح كلما أمكن، ولا تُستخدم ملفاتك لأغراض تسويقية.", enQ: "Are my files stored?", enA: "Files are processed in your browser whenever possible and are never used for marketing." },
  { arQ: "هل تعمل الأدوات على الهاتف؟", arA: "نعم، صُممت أدواتي لتعمل على الهواتف والأجهزة اللوحية والحواسيب.", enQ: "Do the tools work on phones?", enA: "Yes. ADAWATI is designed for phones, tablets, and computers." },
  { arQ: "هل يمكن اقتراح أداة؟", arA: "نعم، استخدم صفحة «اقترح أداة» وأرسل وصفاً مختصراً للفكرة.", enQ: "Can I suggest a tool?", enA: "Yes. Use the Suggest a tool page and send a short description of your idea." },
  { arQ: "هل أدواتي متاح باللغة الإنجليزية؟", arA: "نعم. استخدم قائمة اللغة في أعلى الموقع للتبديل فوراً بين العربية والإنجليزية.", enQ: "Is ADAWATI available in English?", enA: "Yes. Use the language menu at the top of the site to switch between Arabic and English." },
];

export default function FaqPage() {
  const schema = { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: faqs.map((item) => ({ "@type": "Question", name: item.arQ, acceptedAnswer: { "@type": "Answer", text: item.arA } })) };
  return <div className="inner-page"><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(schema)}}/><div className="page-width narrow-page"><nav className="breadcrumb"><Link href="/"><Localized ar="الرئيسية" en="Home" /></Link><span>/</span><span><Localized ar="الأسئلة الشائعة" en="FAQ" /></span></nav><header className="page-heading"><h1><Localized ar="الأسئلة الشائعة" en="Frequently asked questions" /></h1><p><Localized ar="إجابات سريعة عن استخدام أدواتي، الخصوصية، الملفات والمفضلة." en="Quick answers about using ADAWATI, privacy, files, and favorites." /></p></header><div className="faq-list panel">{faqs.map((item,index)=><details key={item.arQ} open={index===0}><summary><Localized ar={item.arQ} en={item.enQ} /></summary><p><Localized ar={item.arA} en={item.enA} /></p></details>)}</div></div></div>;
}
