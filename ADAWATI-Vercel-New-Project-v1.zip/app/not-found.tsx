import Link from "next/link";
import { Icon } from "./components/Icon";
import { HomeSearch } from "./components/HomeSearch";
import { Localized } from "./components/Localized";

export default function NotFound(){return <div className="inner-page"><div className="page-width not-found panel"><span className="not-found-code">404</span><h1><Localized ar="لم نجد هذه الصفحة" en="Page not found" /></h1><p><Localized ar="ربما انتقلت الصفحة أو أن الرابط غير صحيح. يمكنك البحث عن الأداة التي تحتاجها." en="The page may have moved or the link may be incorrect. Search for the tool you need." /></p><HomeSearch/><Link className="primary-button" href="/"><Icon name="home" size={18}/> <Localized ar="العودة للرئيسية" en="Back to home" /></Link></div></div>}
