"use client";

import { useEffect, useState } from "react";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";

const key = "minjaz-favorites";
export function getFavorites() {
  if (typeof window === "undefined") return [] as string[];
  try { const parsed: unknown = JSON.parse(localStorage.getItem(key) || "[]"); return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : []; } catch { return []; }
}
export function FavoriteButton({ slug, compact = false }: { slug: string; compact?: boolean }) {
  const { t } = useLocale();
  const [active, setActive] = useState(false);
  useEffect(() => {
    queueMicrotask(() => setActive(getFavorites().includes(slug)));
  }, [slug]);
  function toggle(event: React.MouseEvent) {
    event.preventDefault(); event.stopPropagation();
    const values = getFavorites();
    const next = values.includes(slug) ? values.filter((item) => item !== slug) : [...values, slug];
    localStorage.setItem(key, JSON.stringify(next)); setActive(next.includes(slug));
    window.dispatchEvent(new Event("minjaz-favorites"));
  }
  return <button className={`favorite-button ${active ? "is-active" : ""}`} onClick={toggle} aria-label={active ? t("إزالة من المفضلة", "Remove from favorites") : t("إضافة إلى المفضلة", "Add to favorites")}><Icon name="star" size={compact ? 18 : 20} /></button>;
}
