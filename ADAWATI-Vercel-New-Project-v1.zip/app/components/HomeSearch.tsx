"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { searchTools } from "@/lib/registry";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";

export function HomeSearch({ large = false }: { large?: boolean }) {
  const { locale, t } = useLocale();
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLFormElement>(null);
  const allResults = useMemo(
    () => (query.trim() ? searchTools(query) : []),
    [query],
  );
  const results = allResults.slice(0, 6);
  const resultsHref = `/tools?search=${encodeURIComponent(query.trim())}`;
  useEffect(() => {
    function dismiss(event: PointerEvent) {
      if (!root.current?.contains(event.target as Node)) setOpen(false);
    }
    document.addEventListener("pointerdown", dismiss);
    return () => document.removeEventListener("pointerdown", dismiss);
  }, []);
  return (
    <form
      className={`smart-search ${large ? "smart-search--large" : ""}`}
      role="search"
      ref={root}
      action="/tools"
      method="get"
      onSubmit={(event) => {
        if (!query.trim()) event.preventDefault();
        else setOpen(false);
      }}
    >
      <div className="smart-search__field">
        <Icon name="search" size={23} />
        <input
          value={query}
          onFocus={() => query && setOpen(true)}
          onChange={(event) => {
            setQuery(event.target.value);
            setOpen(Boolean(event.target.value));
          }}
          onKeyDown={(event) => {
            if (event.key === "Escape") setOpen(false);
          }}
          placeholder={t(
            "ابحث عن أداة... مثال: ضغط صور، دمج PDF، حاسبة العمر",
            "Search tools... e.g. compress image, merge PDF, age calculator",
          )}
          aria-label={t("البحث عن أداة", "Search tools")}
          role="combobox"
          aria-autocomplete="list"
          aria-expanded={open && Boolean(query)}
          aria-controls="home-search-results"
          autoComplete="off"
          name="search"
        />
        {query && (
          <button
            type="button"
            onClick={() => {
              setQuery("");
              setOpen(false);
            }}
            aria-label={t("مسح البحث", "Clear search")}
          >
            <Icon name="x" size={18} />
          </button>
        )}
      </div>
      {query && open && (
        <div id="home-search-results" className="search-popover" role="listbox">
          {results.length ? (
            <>
              <div className="search-results-count" role="status" aria-live="polite">
                <strong>{allResults.length}</strong> {t("نتيجة مطابقة", "matching results")}
              </div>
              {results.map((item) => (
                <Link
                  key={item.slug}
                  href={`/tools/${item.slug}`}
                  className="search-result"
                  onClick={() => {
                    setOpen(false);
                  }}
                >
                  <span
                    className={`icon-tile icon-tile--mini color-${item.color}`}
                  >
                    <Icon name={item.icon} size={20} />
                  </span>
                  <span>
                    <strong>{locale === "en" ? item.nameEn : item.name}</strong>
                    <small>{locale === "en" ? item.name : item.nameEn}</small>
                  </span>
                  <Icon name="back" size={17} />
                </Link>
              ))}
              <Link className="search-all-results" href={resultsHref} onClick={() => setOpen(false)}>
                {t("عرض كل النتائج", "View all results")}
                <Icon name="back" size={17} />
              </Link>
            </>
          ) : (
            <div className="search-empty">
              <Icon name="search" size={26} />
              <strong>
                {t("لم نجد أداة مطابقة", "No matching tool found")}
              </strong>
              <span>
                {t(
                  "جرّب وصف المشكلة بكلمات أخرى.",
                  "Try describing what you want in different words.",
                )}
              </span>
            </div>
          )}
        </div>
      )}
    </form>
  );
}
