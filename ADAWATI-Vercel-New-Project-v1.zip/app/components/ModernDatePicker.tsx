"use client";

import { useId } from "react";
import { useLocale } from "./LocaleProvider";

/**
 * A real controlled date input. The previous visual picker kept its own date
 * snapshot, which allowed automation and external state to diverge from the
 * value used by the calculator.
 */
export function ModernDatePicker({
  label,
  value,
  onChange,
  allowFuture = true,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  allowFuture?: boolean;
}) {
  const { t } = useLocale();
  const generatedId = useId();
  const inputId = `minjaz-date-${generatedId.replaceAll(":", "")}`;
  const descriptionId = `${inputId}-description`;
  const now = new Date();
  const localToday = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  const commit = (next: string) => onChange(next);

  return (
    <div className="field modern-date-field">
      <label htmlFor={inputId}>{label}</label>
      <input
        id={inputId}
        type="date"
        min="1900-01-01"
        max={allowFuture ? undefined : localToday}
        value={value}
        aria-describedby={descriptionId}
        onInput={(event) => commit(event.currentTarget.value)}
        onChange={(event) => commit(event.currentTarget.value)}
      />
      <small id={descriptionId}>
        {t(
          "غيّر اليوم أو الشهر أو السنة؛ تُستخدم القيمة الظاهرة نفسها في الحساب.",
          "Change the day, month, or year; the visible value is the value used in the calculation.",
        )}
      </small>
    </div>
  );
}
