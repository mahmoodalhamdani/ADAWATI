/* eslint-disable @next/next/no-img-element */
"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { FileUploadZone } from "./FileUploadZone";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";
import { CustomSelect } from "./CustomSelect";
import { copyWithFeedback } from "@/lib/copy-feedback";
import { maintenanceScheduleProjection } from "@/lib/tool-calculations";

type Metric = { value: string; ar: string; en: string };

function number(value: string | number) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function fixed(value: number, digits = 2) {
  return new Intl.NumberFormat(undefined, {
    maximumFractionDigits: digits,
  }).format(value);
}

function download(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  window.dispatchEvent(new CustomEvent("minjaz-download-feedback"));
  window.setTimeout(() => URL.revokeObjectURL(url), 1_500);
}

function dateValue(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function todayValue() {
  const now = new Date();
  return dateValue(new Date(now.getFullYear(), now.getMonth(), now.getDate()));
}

function Metrics({ items }: { items: Metric[] }) {
  const { t } = useLocale();
  return (
    <div className="metric-grid">
      {items.map((item) => (
        <div key={item.ar}>
          <strong>{item.value}</strong>
          <span>{t(item.ar, item.en)}</span>
        </div>
      ))}
    </div>
  );
}

function Tip({ ar, en }: { ar: string; en: string }) {
  const { t } = useLocale();
  return (
    <p className="workspace-tip">
      <Icon name="shield" size={18} />
      <span>{t(ar, en)}</span>
    </p>
  );
}

function durationMinutes(start: string, end: string, breakMinutes: number) {
  const pattern = /^(\d{2}):(\d{2})$/;
  const first = pattern.exec(start);
  const last = pattern.exec(end);
  if (!first || !last || breakMinutes < 0) return 0;
  const startMinutes = Number(first[1]) * 60 + Number(first[2]);
  const endMinutes = Number(last[1]) * 60 + Number(last[2]);
  if (startMinutes >= 1_440 || endMinutes >= 1_440) return 0;
  let result = endMinutes - startMinutes;
  if (result < 0) result += 1_440;
  return Math.max(0, result - breakMinutes);
}

function localId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function")
    return crypto.randomUUID();
  const values = new Uint32Array(2);
  if (typeof crypto !== "undefined" && crypto.getRandomValues)
    crypto.getRandomValues(values);
  else {
    values[0] = Math.floor(Math.random() * 0xffffffff);
    values[1] = Date.now() >>> 0;
  }
  return `${Date.now().toString(36)}-${values[0].toString(36)}${values[1].toString(36)}`;
}

type Shift = {
  id: string;
  date: string;
  start: string;
  end: string;
  breakMinutes: number;
};

function newShift(): Shift {
  return {
    id: localId(),
    date: todayValue(),
    start: "08:00",
    end: "17:00",
    breakMinutes: 60,
  };
}

function Timesheet() {
  const { t } = useLocale();
  const [rows, setRows] = useState<Shift[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let saved: Shift[] = [];
    try {
      const value = JSON.parse(localStorage.getItem("minjaz-timesheet") || "[]");
      if (Array.isArray(value)) {
        saved = value.filter(
          (item): item is Shift =>
            item &&
            typeof item.id === "string" &&
            typeof item.date === "string" &&
            typeof item.start === "string" &&
            typeof item.end === "string" &&
            Number.isFinite(item.breakMinutes),
        );
      }
    } catch {
      localStorage.removeItem("minjaz-timesheet");
    }
    queueMicrotask(() => {
      if (cancelled) return;
      setRows(saved.length ? saved : [newShift()]);
      setReady(true);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem("minjaz-timesheet", JSON.stringify(rows));
  }, [ready, rows]);

  const minutes = rows.reduce(
    (sum, row) => sum + durationMinutes(row.start, row.end, row.breakMinutes),
    0,
  );

  function update(id: string, patch: Partial<Shift>) {
    setRows((current) =>
      current.map((row) => (row.id === id ? { ...row, ...patch } : row)),
    );
  }

  function exportCsv() {
    const lines = [
      ["date", "start", "end", "break_minutes", "worked_hours"],
      ...rows.map((row) => [
        row.date,
        row.start,
        row.end,
        String(row.breakMinutes),
        (durationMinutes(row.start, row.end, row.breakMinutes) / 60).toFixed(2),
      ]),
    ];
    const csv = lines.map((line) => line.join(",")).join("\n");
    download(new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" }), "adawati-timesheet.csv");
  }

  if (!ready) return <div className="notice">{t("جاري تجهيز سجل الدوام...", "Preparing timesheet...")}</div>;

  return (
    <div className="workspace-stack">
      <div className="timesheet-list">
        {rows.map((row, index) => {
          const worked = durationMinutes(row.start, row.end, row.breakMinutes);
          return (
            <section key={row.id} className="timesheet-row">
              <header>
                <strong>{t(`اليوم ${index + 1}`, `Day ${index + 1}`)}</strong>
                <button
                  type="button"
                  onClick={() => setRows((current) => current.filter((item) => item.id !== row.id))}
                  aria-label={t("حذف اليوم", "Delete day")}
                  disabled={rows.length === 1}
                >
                  <Icon name="trash" size={17} />
                </button>
              </header>
              <div className="timesheet-fields">
                <label htmlFor={`timesheet-${row.id}-date`}>
                  <span>{t("التاريخ", "Date")}</span>
                  <input id={`timesheet-${row.id}-date`} type="date" value={row.date} aria-label={t("تاريخ يوم الدوام", "Timesheet work date")} onInput={(event) => update(row.id, { date: event.currentTarget.value })} onChange={(event) => update(row.id, { date: event.target.value })} />
                </label>
                <label htmlFor={`timesheet-${row.id}-start`}>
                  <span>{t("الحضور", "Check-in")}</span>
                  <input id={`timesheet-${row.id}-start`} type="time" value={row.start} aria-label={t("وقت حضور يوم الدوام", "Timesheet check-in time")} onInput={(event) => update(row.id, { start: event.currentTarget.value })} onChange={(event) => update(row.id, { start: event.target.value })} />
                </label>
                <label htmlFor={`timesheet-${row.id}-end`}>
                  <span>{t("الانصراف", "Check-out")}</span>
                  <input id={`timesheet-${row.id}-end`} type="time" value={row.end} aria-label={t("وقت انصراف يوم الدوام", "Timesheet check-out time")} onInput={(event) => update(row.id, { end: event.currentTarget.value })} onChange={(event) => update(row.id, { end: event.target.value })} />
                </label>
                <label htmlFor={`timesheet-${row.id}-break`}>
                  <span>{t("الاستراحة بالدقائق", "Break minutes")}</span>
                  <input id={`timesheet-${row.id}-break`} type="number" min="0" value={row.breakMinutes} onChange={(event) => update(row.id, { breakMinutes: Math.max(0, number(event.target.value)) })} />
                </label>
              </div>
              <b>{Math.floor(worked / 60)}:{String(worked % 60).padStart(2, "0")}</b>
            </section>
          );
        })}
      </div>
      <div className="button-row">
        <button type="button" className="primary-button" onClick={() => setRows((current) => [...current, newShift()])}>
          <Icon name="plus" size={18} /> {t("إضافة يوم", "Add day")}
        </button>
        <button type="button" className="secondary-button" onClick={exportCsv}>
          <Icon name="download" size={18} /> {t("تنزيل CSV", "Download CSV")}
        </button>
      </div>
      <Metrics
        items={[
          { value: String(rows.length), ar: "الأيام المسجلة", en: "Recorded days" },
          { value: `${Math.floor(minutes / 60)}:${String(minutes % 60).padStart(2, "0")}`, ar: "إجمالي الساعات والدقائق", en: "Total hours and minutes" },
          { value: fixed(minutes / 60), ar: "إجمالي الساعات العشرية", en: "Total decimal hours" },
        ]}
      />
      <Tip ar="يُحفظ السجل داخل هذا الجهاز فقط، وتُحسب الورديات التي تتجاوز منتصف الليل بصورة صحيحة" en="The sheet stays on this device only and overnight shifts are calculated correctly" />
    </div>
  );
}

function formatDuration(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return "—";
  if (seconds < 60) return `${Math.ceil(seconds)}s`;
  const hours = Math.floor(seconds / 3_600);
  const minutes = Math.floor((seconds % 3_600) / 60);
  const remaining = Math.ceil(seconds % 60);
  return [hours ? `${hours}h` : "", minutes ? `${minutes}m` : "", remaining ? `${remaining}s` : ""]
    .filter(Boolean)
    .join(" ");
}

function TransferTime() {
  const { t } = useLocale();
  const [size, setSize] = useState(2);
  const [sizeUnit, setSizeUnit] = useState("GB");
  const [speed, setSpeed] = useState(50);
  const [speedUnit, setSpeedUnit] = useState("Mbps");
  const [overhead, setOverhead] = useState(10);
  const bytes = size * (sizeUnit === "GB" ? 1024 ** 3 : sizeUnit === "MB" ? 1024 ** 2 : 1024);
  const bytesPerSecond = speedUnit === "Mbps" ? (speed * 1_000_000) / 8 : speed * 1_000_000;
  const seconds = bytesPerSecond > 0 ? (bytes / bytesPerSecond) * (1 + overhead / 100) : Number.NaN;
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field"><label>{t("حجم الملف", "File size")}</label><input type="number" min="0" step="any" value={size} onChange={(event) => setSize(Math.max(0, number(event.target.value)))} /></div>
        <div className="field"><label>{t("وحدة الحجم", "Size unit")}</label><CustomSelect value={sizeUnit} onChange={setSizeUnit} label={t("وحدة الحجم", "Size unit")} options={["KB", "MB", "GB"].map((value) => ({ value, label: value }))} /></div>
        <div className="field"><label>{t("سرعة الاتصال", "Connection speed")}</label><input type="number" min="0" step="any" value={speed} onChange={(event) => setSpeed(Math.max(0, number(event.target.value)))} /></div>
        <div className="field"><label>{t("وحدة السرعة", "Speed unit")}</label><CustomSelect value={speedUnit} onChange={setSpeedUnit} label={t("وحدة السرعة", "Speed unit")} options={[{ value: "Mbps", label: "Mbps" }, { value: "MBps", label: "MB/s" }]} /></div>
        <div className="field"><label>{t("هامش الحمل الإضافي %", "Protocol overhead %")}</label><input type="number" min="0" max="100" value={overhead} onChange={(event) => setOverhead(Math.min(100, Math.max(0, number(event.target.value))))} /></div>
      </div>
      {speed > 0 ? <Metrics items={[
        { value: formatDuration(seconds), ar: "الوقت التقريبي", en: "Estimated time" },
        { value: fixed(bytes / 1024 ** 2), ar: "الحجم بالميجابايت", en: "Size in MB" },
        { value: fixed(bytesPerSecond / 1_000_000), ar: "السرعة الفعلية MB/s", en: "Effective MB/s" },
      ]} /> : <div className="error-notice">{t("يجب أن تكون سرعة الاتصال أكبر من صفر", "Connection speed must be greater than zero")}</div>}
      <Tip ar="الحساب محلي وتقريبي؛ السرعة الحقيقية قد تتغير حسب الشبكة والخادم" en="The local estimate is mathematical; real speed can vary by network and server" />
    </div>
  );
}

const typingSamples = {
  ar: "يمنحنا التنظيم فرصة أفضل لإنجاز أعمالنا بهدوء ودقة. عندما نقسم المهمة إلى خطوات واضحة يصبح التقدم أسهل، ونستطيع قياس الوقت وتحسين السرعة من دون التضحية بجودة العمل.",
  en: "Clear planning makes daily work easier and more accurate. When a large task is divided into simple steps, progress becomes visible and speed improves without reducing quality.",
};

function TypingSpeed() {
  const { t, locale } = useLocale();
  const sample = locale === "en" ? typingSamples.en : typingSamples.ar;
  const [target, setTarget] = useState(sample);
  const [typed, setTyped] = useState("");
  const [duration, setDuration] = useState(60);
  const [remaining, setRemaining] = useState(60);
  const [running, setRunning] = useState(false);
  const deadline = useRef(0);

  useEffect(() => {
    if (!running) return;
    const timer = window.setInterval(() => {
      const next = Math.max(0, Math.ceil((deadline.current - Date.now()) / 1_000));
      setRemaining(next);
      if (next === 0) setRunning(false);
    }, 200);
    return () => window.clearInterval(timer);
  }, [running]);

  useEffect(() => {
    if (!typed && !running)
      queueMicrotask(() =>
        setTarget(locale === "en" ? typingSamples.en : typingSamples.ar),
      );
  }, [locale, running, typed]);

  const elapsed = Math.max(1, duration - remaining);
  const correct = [...typed].filter((character, index) => character === [...target][index]).length;
  const accuracy = typed.length ? (correct / typed.length) * 100 : 100;
  const wpm = (correct / 5) / (elapsed / 60);

  function reset() {
    setTyped("");
    setRemaining(duration);
    setRunning(false);
  }

  function type(value: string) {
    if (remaining === 0) return;
    if (!running && !typed) {
      deadline.current = Date.now() + remaining * 1_000;
      setRunning(true);
    }
    setTyped(value.slice(0, target.length));
    if (value.length >= target.length) setRunning(false);
  }

  return (
    <div className="workspace-stack typing-workspace">
      <div className="form-grid">
        <div className="field"><label>{t("مدة الاختبار", "Test duration")}</label><CustomSelect value={String(duration)} onChange={(value) => { if (running || typed) return; const next = number(value); setDuration(next); setRemaining(next); }} label={t("مدة الاختبار", "Test duration")} options={[30, 60, 120].map((value) => ({ value: String(value), label: `${value} ${t("ثانية", "seconds")}` }))} /></div>
        <button className="secondary-button" type="button" onClick={reset}><Icon name="reset" size={18} /> {t("إعادة الاختبار", "Reset test")}</button>
      </div>
      <div className="typing-target" aria-label={t("النص المطلوب", "Target text")}>{[...target].map((character, index) => <span key={`${character}-${index}`} className={index < typed.length ? typed[index] === character ? "correct" : "wrong" : ""}>{character}</span>)}</div>
      <div className="field"><label>{t("ابدأ الكتابة هنا؛ يبدأ المؤقت مع أول حرف", "Start typing here; the timer starts on the first character")}</label><textarea value={typed} onChange={(event) => type(event.target.value)} disabled={remaining === 0} autoCapitalize="off" spellCheck={false} /></div>
      <Metrics items={[
        { value: String(remaining), ar: "ثانية متبقية", en: "Seconds left" },
        { value: fixed(wpm, 0), ar: "كلمة في الدقيقة WPM", en: "Words per minute" },
        { value: `${fixed(accuracy, 1)}%`, ar: "الدقة", en: "Accuracy" },
        { value: String(correct), ar: "أحرف صحيحة", en: "Correct characters" },
      ]} />
      <Tip ar="كل الحسابات تتم فورياً داخل المتصفح ولا يُرسل النص أو الأداء إلى أي جهة" en="All calculations run instantly in the browser and no typing data is sent anywhere" />
    </div>
  );
}

function GooglePreview() {
  const { t } = useLocale();
  const [title, setTitle] = useState("أدواتي | أدوات رقمية سريعة ومجانية");
  const [description, setDescription] = useState("مجموعة أدوات عربية تعمل بسرعة وخصوصية داخل جهازك لإنجاز المهام اليومية.");
  const [url, setUrl] = useState("https://sawi-adawati.mahmoodalhamdani.chatgpt.site/tools/example");
  let host = "sawi-adawati.mahmoodalhamdani.chatgpt.site";
  try { host = new URL(url.startsWith("http") ? url : `https://${url}`).hostname; } catch { /* Keep a safe preview host. */ }
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field full"><label>{t("عنوان SEO", "SEO title")} <small>{title.length}/60</small></label><input value={title} maxLength={90} onChange={(event) => setTitle(event.target.value)} /></div>
        <div className="field full"><label>{t("الوصف", "Description")} <small>{description.length}/160</small></label><textarea value={description} maxLength={240} onChange={(event) => setDescription(event.target.value)} /></div>
        <div className="field full"><label>{t("الرابط", "URL")}</label><input dir="ltr" value={url} onChange={(event) => setUrl(event.target.value)} /></div>
      </div>
      <section className="google-result-preview" dir="ltr">
        <div className="google-preview-site"><span>{host.slice(0, 1).toUpperCase()}</span><div><strong>{host}</strong><small>{url}</small></div></div>
        <h3>{title || t("عنوان الصفحة", "Page title")}</h3>
        <p>{description || t("سيظهر وصف الصفحة هنا بصورة تقريبية.", "The page description will appear here approximately.")}</p>
      </section>
      {(title.length > 60 || description.length > 160) && <div className="error-notice">{t("قد يختصر Google العنوان أو الوصف الطويل في النتيجة الفعلية", "Google may truncate a long title or description in the real result")}</div>}
      <Tip ar="هذه معاينة محلية تقريبية؛ شكل Google الفعلي قد يختلف حسب الجهاز وعبارة البحث" en="This is a local approximation; the real Google result may vary by device and query" />
    </div>
  );
}

async function canvasPng(bitmap: ImageBitmap, size: number) {
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("canvas");
  context.clearRect(0, 0, size, size);
  const scale = Math.min(size / bitmap.width, size / bitmap.height);
  const width = bitmap.width * scale;
  const height = bitmap.height * scale;
  context.drawImage(bitmap, (size - width) / 2, (size - height) / 2, width, height);
  return await new Promise<Blob>((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("png")), "image/png"));
}

function FaviconGenerator() {
  const { t } = useLocale();
  const [files, setFiles] = useState<File[]>([]);
  const [siteUrl, setSiteUrl] = useState("");
  const [urlBusy, setUrlBusy] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const preview = useMemo(
    () => (files[0] ? URL.createObjectURL(files[0]) : ""),
    [files],
  );
  useEffect(
    () => () => {
      if (preview) URL.revokeObjectURL(preview);
    },
    [preview],
  );

  async function loadFromSite() {
    const value = siteUrl.trim();
    setError("");
    setNotice("");
    if (!value) {
      setError(t("اكتب رابط الموقع أولاً.", "Enter the website URL first."));
      return;
    }
    setUrlBusy(true);
    try {
      const response = await fetch(`/api/favicon-from-url?url=${encodeURIComponent(value)}`);
      if (!response.ok) throw new Error("favicon");
      const blob = await response.blob();
      if (!blob.type.startsWith("image/")) throw new Error("image");
      const extension = blob.type.includes("png") ? "png" : blob.type.includes("svg") ? "svg" : "ico";
      setFiles([new File([blob], `website-favicon.${extension}`, { type: blob.type })]);
      setNotice(t("تم جلب أيقونة الموقع وأصبحت جاهزة لإنشاء المقاسات.", "Website icon loaded and ready for size generation."));
    } catch {
      setError(t("تعذر جلب أيقونة هذا الموقع. يمكنك رفع صورة بدلاً منها.", "The icon could not be loaded from this site. You can upload an image instead."));
    } finally {
      setUrlBusy(false);
    }
  }

  async function generate() {
    const file = files[0];
    if (!file) return;
    setBusy(true); setError(""); setNotice("");
    try {
      const bitmap = await createImageBitmap(file);
      const sizes = [16, 32, 48, 64, 180, 192, 512];
      const entries: Record<string, Uint8Array> = {};
      for (const size of sizes) {
        const blob = await canvasPng(bitmap, size);
        entries[size === 180 ? "apple-touch-icon.png" : `favicon-${size}x${size}.png`] = new Uint8Array(await blob.arrayBuffer());
      }
      bitmap.close();
      const manifest = JSON.stringify({ icons: sizes.filter((size) => size >= 192).map((size) => ({ src: `/favicon-${size}x${size}.png`, sizes: `${size}x${size}`, type: "image/png" })) }, null, 2);
      entries["icons-manifest-example.json"] = new TextEncoder().encode(manifest);
      const { zipSync } = await import("fflate");
      download(new Blob([zipSync(entries) as BlobPart], { type: "application/zip" }), "adawati-favicons.zip");
      setNotice(t("تم إنشاء الأحجام وتنزيلها داخل ملف ZIP", "Icon sizes were generated and downloaded as a ZIP"));
    } catch {
      setError(t("تعذر قراءة الصورة. استخدم PNG أو JPG صالحاً.", "The image could not be read. Use a valid PNG or JPG."));
    } finally { setBusy(false); }
  }
  return (
    <div className="workspace-stack">
      <section className="favicon-url-flow">
        <header>
          <Icon name="globe" size={22} />
          <div><h3>{t("إنشاء الأيقونة من رابط موقع", "Create from a website URL")}</h3><p>{t("ألصق رابط الموقع لجلب أيقونته الحالية ثم إنشاء الحزمة القياسية.", "Paste a website URL to load its current icon and create the standard pack.")}</p></div>
        </header>
        <div className="favicon-url-controls">
          <div className="field">
            <label htmlFor="favicon-site-url">{t("رابط الموقع", "Website URL")}</label>
            <input id="favicon-site-url" dir="ltr" inputMode="url" value={siteUrl} onChange={(event) => { setSiteUrl(event.target.value); setError(""); setNotice(""); }} placeholder="https://example.com" />
          </div>
          <button className="secondary-button" type="button" onClick={loadFromSite} disabled={urlBusy}>
            <Icon name="globe" size={18} />
            {urlBusy ? t("جاري جلب الأيقونة...", "Loading icon...") : t("جلب أيقونة الموقع", "Load website icon")}
          </button>
        </div>
      </section>
      <div className="workspace-divider"><span>{t("أو ارفع صورة", "or upload an image")}</span></div>
      <FileUploadZone files={files} onFiles={(next) => { setFiles(next.slice(0, 1)); setError(""); setNotice(""); }} accept="image/png,image/jpeg,image/webp,image/x-icon" icon="image" title={t("اختر صورة مربعة عالية الجودة", "Choose a high-quality square image")} helper={t("تتم معالجة الصورة المختارة بالكامل داخل جهازك", "The selected image is processed entirely on your device")} />
      {preview && <div className="favicon-preview"><img src={preview} alt={t("معاينة الأيقونة", "Icon preview")} /><div>{[16, 32, 48, 64, 180, 192, 512].map((size) => <span key={size}>{size}×{size}</span>)}</div></div>}
      <button className="primary-button" type="button" disabled={!files.length || busy} onClick={generate}><Icon name="download" size={18} /> {busy ? t("جاري إنشاء الأحجام...", "Generating sizes...") : t("إنشاء وتنزيل حزمة Favicon", "Generate and download favicon pack")}</button>
      {notice && <div className="notice">{notice}</div>}{error && <div className="error-notice">{error}</div>}
      <Tip ar="الصور المرفوعة تُعالج محلياً؛ عند استخدام الرابط يجري طلب أيقونة النطاق فقط، ثم تُنشأ المقاسات داخل جهازك" en="Uploaded images are processed locally. URL mode requests only the domain icon, then generates sizes on your device" />
    </div>
  );
}

function FileHash() {
  const { t } = useLocale();
  const [files, setFiles] = useState<File[]>([]);
  const [sourceType, setSourceType] = useState<"text" | "file">("text");
  const [textInput, setTextInput] = useState("");
  const [algorithm, setAlgorithm] = useState("SHA-256");
  const [hash, setHash] = useState("");
  const [expected, setExpected] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function calculate() {
    setBusy(true); setError(""); setHash("");
    try {
      const payload = sourceType === "text"
        ? new TextEncoder().encode(textInput)
        : await files[0]?.arrayBuffer();
      if (!payload || (sourceType === "text" && !textInput.length)) {
        setError(t("أدخل نصاً أو اختر ملفاً أولاً.", "Enter text or choose a file first."));
        return;
      }
      const result = await crypto.subtle.digest(algorithm, payload);
      setHash([...new Uint8Array(result)].map((byte) => byte.toString(16).padStart(2, "0")).join(""));
    } catch { setError(t("تعذر حساب البصمة للمدخل المحدد", "The selected input could not be hashed")); }
    finally { setBusy(false); }
  }
  const normalizedExpected = expected.trim().toLowerCase().replace(/\s+/g, "");
  const validLength = algorithm === "SHA-256" ? 64 : algorithm === "SHA-384" ? 96 : 128;
  const compared = Boolean(hash && normalizedExpected);
  const matches = compared && hash === normalizedExpected;
  return (
    <div className="workspace-stack">
      <div className="field">
        <label>{t("نوع المدخل", "Input type")}</label>
        <CustomSelect
          value={sourceType}
          onChange={(value) => { setSourceType(value as "text" | "file"); setHash(""); setError(""); }}
          label={t("اختر نصاً أو ملفاً", "Choose text or file")}
          options={[
            { value: "text", label: t("نص مباشر", "Direct text") },
            { value: "file", label: t("ملف محلي", "Local file") },
          ]}
        />
      </div>
      {sourceType === "text" ? (
        <div className="field">
          <label htmlFor="hash-text-input">{t("النص المراد تجزئته", "Text to hash")}</label>
          <textarea
            id="hash-text-input"
            rows={7}
            value={textInput}
            onChange={(event) => { setTextInput(event.target.value); setHash(""); setError(""); }}
            placeholder={t("اكتب أو ألصق أي نص هنا...", "Type or paste any text here...")}
          />
        </div>
      ) : (
        <FileUploadZone files={files} onFiles={(next) => { setFiles(next.slice(0, 1)); setHash(""); setError(""); }} icon="hash" title={t("اختر الملف محلياً", "Choose a local file")} helper={t("الملف لا يغادر جهازك", "The file never leaves your device")} />
      )}
      <div className="form-grid"><div className="field"><label>{t("الخوارزمية", "Algorithm")}</label><CustomSelect value={algorithm} onChange={(value) => { setAlgorithm(value); setHash(""); }} label={t("الخوارزمية", "Algorithm")} options={["SHA-256", "SHA-384", "SHA-512"].map((value) => ({ value, label: value }))} /></div><div className="field"><label>{t("البصمة المتوقعة للمقارنة", "Expected hash to compare")}</label><input dir="ltr" value={expected} onChange={(event) => setExpected(event.target.value)} placeholder={t("اختياري", "Optional")} /></div></div>
      <button className="primary-button" type="button" disabled={(sourceType === "text" ? !textInput.length : !files.length) || busy} onClick={calculate}>{busy ? t("جاري الحساب...", "Calculating...") : t("حساب البصمة", "Calculate hash")}</button>
      {hash && <div className="hash-result"><span>{algorithm}</span><code>{hash}</code><button className="secondary-button" type="button" onClick={(event) => copyWithFeedback(hash, event.currentTarget)}><Icon name="copy" size={17} /> {t("نسخ", "Copy")}</button></div>}
      {expected && normalizedExpected.length !== validLength && <div className="error-notice">{t(`البصمة المتوقعة يجب أن تتكون من ${validLength} خانة`, `Expected hash must contain ${validLength} characters`)}</div>}
      {compared && normalizedExpected.length === validLength && <div className={matches ? "notice" : "error-notice"}>{matches ? t("الملف مطابق للبصمة المتوقعة", "The file matches the expected hash") : t("الملف غير مطابق للبصمة المتوقعة", "The file does not match the expected hash")}</div>}
      {error && <div className="error-notice">{error}</div>}
      <Tip ar="تُحسب بصمة النص أو الملف بواسطة Web Crypto داخل المتصفح ولا تُرفع المدخلات" en="Text and file hashes are calculated with Web Crypto in the browser; inputs are never uploaded" />
    </div>
  );
}

function AttendanceCalculator() {
  const { t } = useLocale();
  const [total, setTotal] = useState(30);
  const [attended, setAttended] = useState(27);
  const [minimum, setMinimum] = useState(75);
  const safeAttended = Math.min(total, attended);
  const absences = Math.max(0, total - safeAttended);
  const current = total > 0 ? (safeAttended / total) * 100 : 0;
  const requiredAttended = Math.ceil((minimum / 100) * total);
  const allowedAbsences = Math.max(0, total - requiredAttended);
  const remainingAbsences = Math.max(0, allowedAbsences - absences);
  const ratio = minimum / 100;
  const recovery = current >= minimum ? 0 : ratio >= 1 ? Number.POSITIVE_INFINITY : Math.ceil((ratio * total - safeAttended) / (1 - ratio));
  const invalid = total <= 0 || attended < 0 || attended > total || minimum <= 0 || minimum > 100;
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field"><label>{t("إجمالي المحاضرات حتى الآن", "Classes held so far")}</label><input type="number" min="1" step="1" value={total} onChange={(event) => setTotal(Math.floor(number(event.target.value)))} /></div>
        <div className="field"><label>{t("عدد مرات الحضور", "Classes attended")}</label><input type="number" min="0" step="1" value={attended} onChange={(event) => setAttended(Math.floor(number(event.target.value)))} /></div>
        <div className="field"><label>{t("الحد الأدنى المطلوب %", "Minimum required %")}</label><input type="number" min="1" max="100" step="any" value={minimum} onChange={(event) => setMinimum(number(event.target.value))} /></div>
      </div>
      {invalid ? <div className="error-notice">{t("تحقق من أن الحضور لا يتجاوز الإجمالي وأن النسبة بين 1 و100", "Attendance cannot exceed the total and the percentage must be between 1 and 100")}</div> : <Metrics items={[
        { value: `${fixed(current, 1)}%`, ar: "نسبة الحضور الحالية", en: "Current attendance" },
        { value: String(absences), ar: "الغيابات الحالية", en: "Current absences" },
        { value: String(remainingAbsences), ar: "غيابات إضافية مسموحة", en: "More absences allowed" },
        { value: Number.isFinite(recovery) ? String(recovery) : "—", ar: "حضور متتالٍ لاستعادة الحد", en: "Consecutive attendance to recover" },
      ]} />}
      <Tip ar="النتيجة حسابية حسب الحد الذي تدخله؛ راجع نظام جامعتك لأن بعض المؤسسات تطبق قواعد إضافية" en="The result follows your entered threshold; check your institution for additional rules" />
    </div>
  );
}

function MaintenanceSchedule() {
  const { t } = useLocale();
  const [lastDate, setLastDate] = useState(todayValue());
  const [currentKm, setCurrentKm] = useState(40_000);
  const [lastKm, setLastKm] = useState(35_000);
  const [months, setMonths] = useState(6);
  const [kilometers, setKilometers] = useState(10_000);
  const [dailyKm, setDailyKm] = useState(35);
  const projection = maintenanceScheduleProjection({
    lastDate,
    currentKm,
    lastKm,
    months,
    kilometers,
    dailyKm,
  });
  const nextDate = projection?.nextDate || null;
  const nextKm = projection?.nextKm || 0;
  const kmRemaining = projection?.kmRemaining || 0;
  const effectiveDate = projection?.effectiveDate || null;
  const daysByDate = projection?.daysByDate || 0;
  const invalid = !projection;
  const lastDateLabel = t("تاريخ آخر صيانة — يبدأ 00:00", "Last service date — starts at 00:00");
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field"><label htmlFor="maintenance-last-date">{lastDateLabel}</label><input id="maintenance-last-date" type="date" value={lastDate} aria-label={lastDateLabel} onInput={(event) => setLastDate(event.currentTarget.value)} onChange={(event) => setLastDate(event.target.value)} /></div>
        <div className="field"><label>{t("عداد السيارة عند آخر صيانة", "Odometer at last service")}</label><input type="number" min="0" value={lastKm} onChange={(event) => setLastKm(number(event.target.value))} /></div>
        <div className="field"><label>{t("عداد السيارة الآن", "Current odometer")}</label><input type="number" min="0" value={currentKm} onChange={(event) => setCurrentKm(number(event.target.value))} /></div>
        <div className="field"><label>{t("الفاصل الزمني بالأشهر", "Service interval months")}</label><input type="number" min="0" step="1" value={months} onChange={(event) => setMonths(number(event.target.value))} /></div>
        <div className="field"><label>{t("الفاصل بالكيلومترات", "Service interval km")}</label><input type="number" min="1" value={kilometers} onChange={(event) => setKilometers(number(event.target.value))} /></div>
        <div className="field"><label>{t("متوسط القيادة اليومي كم", "Average daily driving km")}</label><input type="number" min="0" step="any" value={dailyKm} onChange={(event) => setDailyKm(number(event.target.value))} /></div>
      </div>
      {invalid ? <div className="error-notice">{t("تحقق من التاريخ والعدادات والفواصل المدخلة", "Check the entered date, odometer values, and intervals")}</div> : <Metrics items={[
        { value: nextDate ? dateValue(nextDate) : "—", ar: "موعد الصيانة حسب التاريخ", en: "Service date by time" },
        { value: fixed(nextKm, 0), ar: "عداد الصيانة القادمة", en: "Next service odometer" },
        { value: fixed(kmRemaining, 0), ar: "كيلومترات متبقية", en: "Kilometers remaining" },
        { value: effectiveDate ? dateValue(effectiveDate) : "—", ar: "الموعد الأقرب المتوقع", en: "Expected earlier due date" },
      ]} />}
      {!invalid && daysByDate < 0 && <div className="error-notice">{t("موعد الصيانة الزمني متجاوز", "The time-based service date has passed")}</div>}
      <Tip ar="يُحسب التاريخ دائماً من بداية اليوم 00:00، والموعد الأقرب بين الزمن والكيلومترات هو الأهم" en="Dates always start at 00:00, and the earlier of the time or mileage interval is highlighted" />
    </div>
  );
}

export const priorityToolSlugs = [
  "timesheet",
  "file-transfer-time",
  "typing-speed-test",
  "google-result-preview",
  "favicon-generator",
  "file-hash-verifier",
  "attendance-calculator",
  "maintenance-schedule",
];

export function PriorityToolWorkspace({ slug }: { slug: string }) {
  switch (slug) {
    case "timesheet": return <Timesheet />;
    case "file-transfer-time": return <TransferTime />;
    case "typing-speed-test": return <TypingSpeed />;
    case "google-result-preview": return <GooglePreview />;
    case "favicon-generator": return <FaviconGenerator />;
    case "file-hash-verifier": return <FileHash />;
    case "attendance-calculator": return <AttendanceCalculator />;
    case "maintenance-schedule": return <MaintenanceSchedule />;
    default: return null;
  }
}
