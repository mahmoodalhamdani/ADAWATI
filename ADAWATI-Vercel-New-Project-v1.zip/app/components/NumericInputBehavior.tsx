"use client";

import { useEffect } from "react";

const easternDigits: Record<string, string> = {
  "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4",
  "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
  "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4",
  "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
};

function normalizeNumericKey(value: string) {
  return value.replace(/[٠-٩۰-۹]/g, (digit) => easternDigits[digit] ?? digit).replace("٫", ".");
}

function isNumericInput(target: EventTarget | null): target is HTMLInputElement {
  return target instanceof HTMLInputElement && target.type === "number";
}

function replaceInputValue(input: HTMLInputElement, value: string) {
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
  setter?.call(input, value);
  input.dispatchEvent(new Event("input", { bubbles: true }));
}

/**
 * Makes pre-filled calculator fields behave like modern mobile inputs: after a
 * tap/click, the first typed digit replaces the example value immediately.
 */
export function NumericInputBehavior() {
  useEffect(() => {
    const arm = (event: Event) => {
      if (isNumericInput(event.target)) event.target.dataset.replaceOnType = "true";
    };

    const onKeyDown = (event: KeyboardEvent) => {
      if (!isNumericInput(event.target) || event.target.dataset.replaceOnType !== "true") return;
      const normalized = normalizeNumericKey(event.key);
      if (!/^[0-9.,-]$/.test(normalized)) return;
      event.preventDefault();
      delete event.target.dataset.replaceOnType;
      replaceInputValue(event.target, normalized === "," ? "." : normalized);
    };

    const onBeforeInput = (event: InputEvent) => {
      if (!isNumericInput(event.target) || event.target.dataset.replaceOnType !== "true" || !event.data) return;
      const normalized = normalizeNumericKey(event.data);
      if (!/^-?[0-9]+(?:[.,][0-9]*)?$/.test(normalized)) return;
      event.preventDefault();
      delete event.target.dataset.replaceOnType;
      replaceInputValue(event.target, normalized.replace(",", "."));
    };

    const disarm = (event: Event) => {
      if (isNumericInput(event.target) && event.isTrusted) delete event.target.dataset.replaceOnType;
    };

    document.addEventListener("pointerdown", arm, true);
    document.addEventListener("focusin", arm, true);
    document.addEventListener("keydown", onKeyDown, true);
    document.addEventListener("beforeinput", onBeforeInput, true);
    document.addEventListener("input", disarm, true);
    return () => {
      document.removeEventListener("pointerdown", arm, true);
      document.removeEventListener("focusin", arm, true);
      document.removeEventListener("keydown", onKeyDown, true);
      document.removeEventListener("beforeinput", onBeforeInput, true);
      document.removeEventListener("input", disarm, true);
    };
  }, []);

  return null;
}
