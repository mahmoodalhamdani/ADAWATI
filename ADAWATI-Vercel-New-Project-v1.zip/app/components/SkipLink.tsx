"use client";

export function SkipLink() {
  function focusMain(event: React.MouseEvent<HTMLAnchorElement>) {
    const main = document.getElementById("main-content");
    if (!main) return;
    event.preventDefault();
    window.history.pushState(null, "", "#main-content");
    main.focus({ preventScroll: true });
    main.scrollIntoView({ block: "start" });
  }

  return (
    <a className="skip-link" href="#main-content" onClick={focusMain}>
      تخطَّ إلى المحتوى / Skip to content
    </a>
  );
}
