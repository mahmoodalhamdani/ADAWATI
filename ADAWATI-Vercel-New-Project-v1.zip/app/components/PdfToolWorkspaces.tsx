"use client";

import { useState } from "react";
import { Icon } from "./Icon";
import { CustomSelect } from "./CustomSelect";
import { FileUploadZone } from "./FileUploadZone";
import { useLocale } from "./LocaleProvider";

type PdfToolkit = Awaited<
  ReturnType<(typeof import("pdfstudio"))["createPdfToolkit"]>
>;
let toolkitPromise: Promise<PdfToolkit> | null = null;

function toolkit() {
  toolkitPromise ||= import("pdfstudio").then(({ createPdfToolkit }) =>
    createPdfToolkit(),
  );
  return toolkitPromise;
}

function download(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  window.dispatchEvent(new CustomEvent("minjaz-download-feedback"));
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

type ReadyFile = { blob: Blob; name: string };

function ReadyDownload({ file }: { file: ReadyFile | null }) {
  const { t } = useLocale();
  if (!file) return null;
  return (
    <div className="ready-download" role="status">
      <span>
        <Icon name="check" size={18} />
        {t("الملف جاهز للتحميل", "Your file is ready to download")}
      </span>
      <button
        type="button"
        className="primary-button"
        onClick={() => download(file.blob, file.name)}
      >
        <Icon name="download" size={18} />
        {t("تحميل الملف", "Download file")}
      </button>
    </div>
  );
}

function errorText(locale: "ar" | "en") {
  return locale === "ar"
    ? "تعذّر تنفيذ العملية. تأكد من سلامة الملف وكلمة المرور ونطاق الصفحات ثم حاول مرة أخرى."
    : "The operation could not be completed. Check the file, password, and page range, then try again.";
}

function PdfUpload({
  file,
  setFile,
  label,
}: {
  file: File | null;
  setFile: (file: File | null) => void;
  label?: string;
}) {
  const { t } = useLocale();
  return (
    <FileUploadZone
      files={file ? [file] : []}
      onFiles={(files) => setFile(files[0] || null)}
      accept="application/pdf,.pdf"
      icon="file"
      title={label || t("اختر ملف PDF", "Choose a PDF file")}
      helper={t(
        "تتم المعالجة داخل متصفحك ولا يُرفع الملف إلى الخادم",
        "Processing happens in your browser and the file is not uploaded",
      )}
    />
  );
}

function ResultNotice({
  text,
  error = false,
  neutral = false,
}: {
  text: string;
  error?: boolean;
  neutral?: boolean;
}) {
  if (!text) return null;
  return (
    <div
      className={
        error
          ? "error-notice"
          : neutral
            ? "notice"
            : "notice success-notice"
      }
    >
      <Icon name={error || neutral ? "alert" : "check"} size={18} />
      {text}
    </div>
  );
}

function formatFileSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(bytes < 10 * 1024 ? 1 : 0)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(2)} MB`;
}

const basicSlugs = [
  "pdf-split",
  "pdf-delete-pages",
  "pdf-extract-pages",
  "pdf-organize",
  "pdf-compress",
  "pdf-repair",
  "pdf-rotate",
  "pdf-protect",
  "pdf-unlock",
];
const decorateSlugs = [
  "pdf-page-numbers",
  "pdf-watermark",
  "pdf-crop",
  "pdf-edit",
  "pdf-redact",
  "pdf-to-pdfa",
];
const officeToPdfSlugs = [
  "word-to-pdf",
  "powerpoint-to-pdf",
  "excel-to-pdf",
  "html-to-pdf",
];
const extractSlugs = [
  "pdf-to-jpg",
  "pdf-to-word",
  "pdf-to-powerpoint",
  "pdf-to-excel",
  "pdf-ocr",
  "pdf-summary",
  "pdf-to-markdown",
];

export const pdfToolSlugs = [
  ...basicSlugs,
  ...decorateSlugs,
  ...officeToPdfSlugs,
  ...extractSlugs,
  "pdf-forms",
  "pdf-compare",
];

function BasicPdfWorkspace({ slug }: { slug: string }) {
  const { locale, t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [pages, setPages] = useState("1");
  const [password, setPassword] = useState("");
  const [angle, setAngle] = useState("90");
  const [pagesPerFile, setPagesPerFile] = useState("1");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [neutralNotice, setNeutralNotice] = useState(false);
  const [error, setError] = useState("");
  const [readyFile, setReadyFile] = useState<ReadyFile | null>(null);
  const needsPages = [
    "pdf-delete-pages",
    "pdf-extract-pages",
    "pdf-organize",
    "pdf-rotate",
  ].includes(slug);

  async function run() {
    if (!file) return;
    setBusy(true);
    setError("");
    setNotice("");
    setNeutralNotice(false);
    setReadyFile(null);
    const publish = (blob: Blob, name: string) => {
      setReadyFile({ blob, name });
      download(blob, name);
    };
    const publishPdf = (bytes: Uint8Array, name: string) =>
      publish(new Blob([bytes as BlobPart], { type: "application/pdf" }), name);
    try {
      if (slug === "pdf-split") {
        const { splitPdfDocument } = await import("@/lib/pdf-tools");
        const parts = await splitPdfDocument(
          await file.arrayBuffer(),
          Number(pagesPerFile),
        );
        if (parts.length === 1) publishPdf(parts[0], "adawati-split-1.pdf");
        else {
          const { zipSync } = await import("fflate");
          const entries = Object.fromEntries(
            parts.map((part, index) => [`adawati-part-${index + 1}.pdf`, part]),
          );
          publish(
            new Blob([zipSync(entries) as BlobPart], {
              type: "application/zip",
            }),
            "adawati-split-pdf.zip",
          );
        }
        setNotice(
          t(
            `تم تقسيم الملف إلى ${parts.length} أجزاء وتنزيله`,
            `The PDF was split into ${parts.length} parts and downloaded`,
          ),
        );
        return;
      }
      const pdf = await toolkit();
      if (needsPages) {
        const { parsePdfPageSelection } = await import("@/lib/pdf-tools");
        const info = await pdf.getInfo(file);
        const selected = parsePdfPageSelection(pages, info.pageCount, false);
        if (
          slug === "pdf-delete-pages" &&
          new Set(selected).size >= info.pageCount
        )
          throw new Error("all-pages");
      }
      if (slug === "pdf-delete-pages") {
        publishPdf(
          await pdf.deletePages(file, { pages }),
          "adawati-pages-deleted.pdf",
        );
        setNotice(
          t(
            "تم حذف الصفحات المحددة وتنزيل النسخة الجديدة",
            "Selected pages were deleted and the new copy was downloaded",
          ),
        );
      } else if (slug === "pdf-extract-pages" || slug === "pdf-organize") {
        publishPdf(
          await pdf.extractPages(file, { pages }),
          slug === "pdf-organize"
            ? "adawati-organized.pdf"
            : "adawati-extracted.pdf",
        );
        setNotice(
          t(
            "تم إنشاء ملف بالصفحات والترتيب المحدد",
            "A PDF with the selected pages and order was created",
          ),
        );
      } else if (slug === "pdf-compress") {
        const output = await pdf.compress(file, {
          objectStreams: true,
          compressionLevel: 9,
          linearize: true,
        });
        if (output.byteLength < file.size) {
          publishPdf(output, "adawati-compressed.pdf");
          const saving = Math.round((1 - output.byteLength / file.size) * 100);
          setNotice(
            t(
              `تم تقليل الملف من ${formatFileSize(file.size)} إلى ${formatFileSize(output.byteLength)} (${saving}%) وتنزيل النسخة الأصغر.`,
              `The PDF was reduced from ${formatFileSize(file.size)} to ${formatFileSize(output.byteLength)} (${saving}%) and the smaller copy was downloaded.`,
            ),
          );
        } else {
          setNeutralNotice(true);
          setReadyFile({ blob: file, name: file.name });
          setNotice(
            t(
              `لا يمكن تقليل الملف أكثر؛ الناتج المقترح (${formatFileSize(output.byteLength)}) ليس أصغر من الأصل (${formatFileSize(file.size)}). تم الاحتفاظ بالأصل بدون ادعاء نجاح الضغط.`,
              `The PDF cannot be reduced further: the proposed output (${formatFileSize(output.byteLength)}) is not smaller than the original (${formatFileSize(file.size)}). The original was kept without claiming compression succeeded.`,
            ),
          );
        }
      } else if (slug === "pdf-repair") {
        const repaired = await pdf.repair(file);
        const validation = await validateRepairedPdf(repaired);
        publishPdf(repaired, "adawati-repaired.pdf");
        setNotice(
          t(
            `تم التحقق من ${validation.meaningfulPages} صفحات ذات محتوى فعلي${validation.textCharacters ? ` و${validation.textCharacters} حرفاً قابلاً للاستخراج` : ""} قبل تنزيل النسخة المُصلحة.`,
            `Verified ${validation.meaningfulPages} pages with real content${validation.textCharacters ? ` and ${validation.textCharacters} extractable text characters` : ""} before downloading the repaired copy.`,
          ),
        );
      } else if (slug === "pdf-rotate") {
        publishPdf(
          await pdf.rotate(file, {
            angle: Number(angle) as 90 | 180 | 270,
            pages: pages.trim() || undefined,
          }),
          "adawati-rotated.pdf",
        );
        setNotice(
          t(
            "تم تدوير الصفحات المحددة وتنزيل الملف",
            "Selected pages were rotated and downloaded",
          ),
        );
      } else if (slug === "pdf-protect") {
        if (password.length < 4) throw new Error("password");
        publishPdf(
          await pdf.lock(file, {
            userPassword: password,
            ownerPassword: password,
            keyLength: 256,
            permissions: { print: "full", modify: "none", extract: false },
          }),
          "adawati-protected.pdf",
        );
        setNotice(
          t(
            "تم تطبيق حماية AES-256 وتنزيل الملف المحمي",
            "AES-256 protection was applied and the protected PDF was downloaded",
          ),
        );
      } else if (slug === "pdf-unlock") {
        publishPdf(await pdf.unlock(file, { password }), "adawati-unlocked.pdf");
        setNotice(
          t(
            "تم فتح الملف وتنزيل نسخة بلا كلمة مرور",
            "The PDF was unlocked and downloaded without a password",
          ),
        );
      }
    } catch {
      setError(
        slug === "pdf-repair"
          ? t(
              "لم يُعرض نجاح لأن النسخة المُصلحة لم تحتوِ صفحات أو نصوصاً فعلية قابلة للتحقق. جرّب نسخة أخرى من الملف.",
              "No success was reported because the repaired copy did not contain verifiable pages or text. Try another copy of the file.",
            )
          : errorText(locale),
      );
    } finally {
      setBusy(false);
    }
  }

  const action =
    slug === "pdf-split"
      ? t("تقسيم وتنزيل", "Split and download")
      : slug === "pdf-delete-pages"
        ? t("حذف الصفحات", "Delete pages")
        : slug === "pdf-extract-pages"
          ? t("استخراج الصفحات", "Extract pages")
          : slug === "pdf-organize"
            ? t("تنظيم وتنزيل", "Organize and download")
            : slug === "pdf-compress"
              ? t("ضغط PDF", "Compress PDF")
              : slug === "pdf-repair"
                ? t("إصلاح PDF", "Repair PDF")
                : slug === "pdf-rotate"
                  ? t("تدوير وتنزيل", "Rotate and download")
                  : slug === "pdf-protect"
                    ? t("حماية وتنزيل", "Protect and download")
                    : t("فتح وتنزيل", "Unlock and download");
  return (
    <div className="workspace-stack">
      <PdfUpload
        file={file}
        setFile={(next) => {
          setFile(next);
          setNotice("");
          setNeutralNotice(false);
          setError("");
          setReadyFile(null);
        }}
      />
      {slug === "pdf-split" && (
        <div className="field">
          <label>{t("عدد الصفحات في كل جزء", "Pages per part")}</label>
          <input
            type="number"
            min="1"
            max="100"
            value={pagesPerFile}
            onChange={(event) => setPagesPerFile(event.target.value)}
          />
        </div>
      )}
      {needsPages && (
        <div className="field">
          <label>
            {slug === "pdf-organize"
              ? t("ترتيب الصفحات المطلوب", "Desired page order")
              : t("الصفحات أو النطاقات", "Pages or ranges")}
          </label>
          <input
            value={pages}
            onChange={(event) => setPages(event.target.value)}
            placeholder="1-3,5,8"
          />
          <small>
            {t(
              "مثال: 1-3,5,8 ويمكن تغيير ترتيب الأرقام في أداة التنظيم",
              "Example: 1-3,5,8; reorder the numbers in the organizer",
            )}
          </small>
        </div>
      )}
      {slug === "pdf-rotate" && (
        <div className="field">
          <label>{t("زاوية التدوير", "Rotation angle")}</label>
          <CustomSelect
            value={angle}
            onChange={setAngle}
            label={t("زاوية التدوير", "Rotation angle")}
            options={[
              { value: "90", label: "90°" },
              { value: "180", label: "180°" },
              { value: "270", label: "270°" },
            ]}
          />
        </div>
      )}
      {["pdf-protect", "pdf-unlock"].includes(slug) && (
        <div className="field">
          <label>{t("كلمة المرور", "Password")}</label>
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder={t("أدخل كلمة المرور", "Enter password")}
          />
        </div>
      )}
      <button className="primary-button" disabled={!file || busy} onClick={run}>
        {busy ? t("جاري تنفيذ العملية…", "Processing…") : action}
      </button>
      <ResultNotice text={notice} neutral={neutralNotice} />
      <ReadyDownload file={readyFile} />
      <ResultNotice text={error} error />
    </div>
  );
}

async function transparentTextPng(
  text: string,
  fontSize = 54,
  color = "#15326f",
) {
  const canvas = document.createElement("canvas");
  canvas.width = 1200;
  canvas.height = 190;
  const context = canvas.getContext("2d")!;
  context.clearRect(0, 0, canvas.width, canvas.height);
  context.fillStyle = color;
  context.font = `800 ${fontSize}px Tahoma, Arial`;
  context.textAlign = "center";
  context.textBaseline = "middle";
  context.direction = /[\u0600-\u06ff]/.test(text) ? "rtl" : "ltr";
  context.fillText(
    text,
    canvas.width / 2,
    canvas.height / 2,
    canvas.width - 30,
  );
  return canvas.toDataURL("image/png");
}

async function dataUrlBytes(url: string) {
  return fetch(url).then((response) => response.arrayBuffer());
}

function DecoratePdfWorkspace({ slug }: { slug: string }) {
  const { locale, t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [text, setText] = useState(slug === "pdf-watermark" ? "ADAWATI" : "");
  const [pages, setPages] = useState(slug === "pdf-edit" ? "1" : "all");
  const [position, setPosition] = useState("bottom-center");
  const [margin, setMargin] = useState("5");
  const [x, setX] = useState("10");
  const [y, setY] = useState("10");
  const [width, setWidth] = useState("35");
  const [height, setHeight] = useState("12");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [readyFile, setReadyFile] = useState<ReadyFile | null>(null);

  async function run() {
    if (!file) return;
    setBusy(true);
    setNotice("");
    setError("");
    setReadyFile(null);
    try {
      const source = await file.arrayBuffer();
      if (slug === "pdf-page-numbers" || slug === "pdf-crop") {
        const { addPdfPageNumbers, cropPdfMargins } =
          await import("@/lib/pdf-decorations");
        const output =
          slug === "pdf-page-numbers"
            ? await addPdfPageNumbers(
                source,
                position as import("@/lib/pdf-decorations").PageNumberPosition,
              )
            : await cropPdfMargins(source, pages, Number(margin) || 0);
        const name =
          slug === "pdf-page-numbers"
            ? "adawati-page-numbers.pdf"
            : "adawati-cropped.pdf";
        const blob = new Blob([output as BlobPart], {
          type: "application/pdf",
        });
        setReadyFile({ blob, name });
        download(blob, name);
        setNotice(
          t(
            slug === "pdf-page-numbers"
              ? "تم ترقيم جميع الصفحات بالتسلسل وتنزيل PDF الجديد"
              : "تم قص هوامش الصفحات المحددة وتنزيل PDF الجديد",
            slug === "pdf-page-numbers"
              ? "Every page was numbered sequentially and the new PDF was downloaded"
              : "Selected page margins were cropped and the new PDF was downloaded",
          ),
        );
        return;
      }
      const { PDFDocument, degrees } = await import("pdf-lib");
      const document = await PDFDocument.load(source);
      const allPages = document.getPages();
      const { parsePdfPageSelection } = await import("@/lib/pdf-tools");
      const targets = [
        ...new Set(parsePdfPageSelection(pages, allPages.length)),
      ];
      if (slug === "pdf-redact") {
        const output = await flattenPdf(file, new Set(targets), {
          x: Number(x),
          y: Number(y),
          width: Number(width),
          height: Number(height),
        });
        const name = "adawati-permanently-redacted.pdf";
        const blob = new Blob([output as BlobPart], {
          type: "application/pdf",
        });
        setReadyFile({ blob, name });
        download(blob, name);
        setNotice(
          t(
            "تم الحجب نهائياً عبر تسطيح الصفحات، ولا يمكن استرجاع النص المغطى من الملف الناتج",
            "Redaction was permanently flattened, so covered text cannot be recovered from the output",
          ),
        );
        return;
      }
      if (slug === "pdf-to-pdfa") {
        const output = await flattenPdf(file);
        const name = "adawati-archival-copy.pdf";
        const blob = new Blob([output as BlobPart], {
          type: "application/pdf",
        });
        setReadyFile({ blob, name });
        download(blob, name);
        setNotice(
          t(
            "تم إنشاء نسخة أرشيفية مسطّحة ثابتة المظهر. لا تُعد هذه شهادة مطابقة معيارية من جهة تدقيق PDF/A",
            "A stable flattened archival copy was created. This is not a standards-body PDF/A compliance certificate",
          ),
        );
        return;
      }
      if (slug === "pdf-watermark") {
        if (!text.trim()) throw new Error("text");
        const image = await document.embedPng(
          await dataUrlBytes(await transparentTextPng(text, 62, "#174a9c")),
        );
        targets.forEach((index) => {
          const page = allPages[index],
            imageWidth = Math.min(page.getWidth() * 0.62, 470),
            imageHeight = (imageWidth * image.height) / image.width;
          page.drawImage(image, {
            x: (page.getWidth() - imageWidth) / 2,
            y: (page.getHeight() - imageHeight) / 2,
            width: imageWidth,
            height: imageHeight,
            rotate: degrees(-32),
            opacity: 0.24,
          });
        });
      } else if (slug === "pdf-edit") {
        if (!text.trim()) throw new Error("text");
        const image = await document.embedPng(
          await dataUrlBytes(await transparentTextPng(text, 50, "#0d2c63")),
        );
        const index = Math.max(
            0,
            Math.min(allPages.length - 1, Number(pages || 1) - 1),
          ),
          page = allPages[index],
          imageWidth = Math.min(330, page.getWidth() * 0.55),
          imageHeight = (imageWidth * image.height) / image.width;
        page.drawImage(image, {
          x:
            (page.getWidth() * Math.max(0, Math.min(90, Number(x) || 10))) /
            100,
          y:
            page.getHeight() *
              (1 - Math.max(0, Math.min(95, Number(y) || 10)) / 100) -
            imageHeight,
          width: imageWidth,
          height: imageHeight,
        });
      }
      const output = await document.save({ useObjectStreams: true });
      const name = `adawati-${slug.replace("pdf-", "")}.pdf`;
      const blob = new Blob([output as BlobPart], { type: "application/pdf" });
      setReadyFile({ blob, name });
      download(blob, name);
      setNotice(
        t(
          "تم تنفيذ التعديل وتنزيل نسخة PDF الجديدة",
          "The update was applied and a new PDF was downloaded",
        ),
      );
    } catch {
      setError(errorText(locale));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="workspace-stack">
      <PdfUpload
        file={file}
        setFile={(next) => {
          setFile(next);
          setNotice("");
          setError("");
          setReadyFile(null);
        }}
      />
      {["pdf-watermark", "pdf-edit"].includes(slug) && (
        <div className="field">
          <label>
            {slug === "pdf-watermark"
              ? t("نص العلامة المائية", "Watermark text")
              : t("النص الجديد", "New text")}
          </label>
          <input
            value={text}
            onChange={(event) => setText(event.target.value)}
            placeholder={t("اكتب النص", "Enter text")}
          />
        </div>
      )}
      {slug !== "pdf-page-numbers" && slug !== "pdf-to-pdfa" && (
        <div className="field">
          <label>
            {slug === "pdf-edit"
              ? t("رقم الصفحة", "Page number")
              : t("الصفحات", "Pages")}
          </label>
          <input
            value={pages}
            onChange={(event) => setPages(event.target.value)}
            placeholder={
              slug === "pdf-edit" ? "1" : t("all أو 1-3,5", "all or 1-3,5")
            }
          />
        </div>
      )}
      {slug === "pdf-page-numbers" && (
        <div className="field">
          <label>{t("موضع الرقم", "Number position")}</label>
          <CustomSelect
            value={position}
            onChange={setPosition}
            label={t("موضع الرقم", "Number position")}
            options={[
              {
                value: "bottom-center",
                label: t("أسفل الوسط", "Bottom center"),
              },
              {
                value: "bottom-right",
                label: t("أسفل اليمين", "Bottom right"),
              },
              { value: "bottom-left", label: t("أسفل اليسار", "Bottom left") },
              { value: "top-center", label: t("أعلى الوسط", "Top center") },
            ]}
          />
        </div>
      )}
      {slug === "pdf-crop" && (
        <label className="range-field">
          <span>
            {t("نسبة قص الهوامش", "Margin crop")}: {margin}%
          </span>
          <input
            type="range"
            min="0"
            max="25"
            value={margin}
            onChange={(event) => setMargin(event.target.value)}
          />
        </label>
      )}
      {["pdf-edit", "pdf-redact"].includes(slug) && (
        <div className="form-grid">
          <div className="field">
            <label>X %</label>
            <input
              type="number"
              value={x}
              onChange={(event) => setX(event.target.value)}
            />
          </div>
          <div className="field">
            <label>Y %</label>
            <input
              type="number"
              value={y}
              onChange={(event) => setY(event.target.value)}
            />
          </div>
          {slug === "pdf-redact" && (
            <>
              <div className="field">
                <label>{t("العرض %", "Width %")}</label>
                <input
                  type="number"
                  value={width}
                  onChange={(event) => setWidth(event.target.value)}
                />
              </div>
              <div className="field">
                <label>{t("الارتفاع %", "Height %")}</label>
                <input
                  type="number"
                  value={height}
                  onChange={(event) => setHeight(event.target.value)}
                />
              </div>
            </>
          )}
        </div>
      )}
      <button className="primary-button" disabled={!file || busy} onClick={run}>
        {busy
          ? t("جاري تجهيز الملف…", "Preparing PDF…")
          : t("تنفيذ وتنزيل PDF", "Apply and download PDF")}
      </button>
      <ResultNotice text={notice} />
      <ReadyDownload file={readyFile} />
      <ResultNotice text={error} error />
    </div>
  );
}

async function wordToPrintMarkup(file: File) {
  const { renderAsync } = await import("docx-preview");
  const renderHost = document.createElement("div");
  renderHost.className = "word-pdf-render-host";
  renderHost.setAttribute("aria-hidden", "true");
  document.body.appendChild(renderHost);

  try {
    await renderAsync(file, renderHost, renderHost, {
      breakPages: true,
      ignoreWidth: false,
      ignoreHeight: false,
      ignoreFonts: false,
      renderHeaders: true,
      renderFooters: true,
      renderFootnotes: true,
      renderEndnotes: true,
      useBase64URL: true,
      experimental: true,
    });
    await document.fonts.ready;
    await Promise.all(
      [...renderHost.querySelectorAll("img")].map((image) =>
        image.complete ? Promise.resolve() : image.decode().catch(() => {}),
      ),
    );

    const renderedPages = [
      ...renderHost.querySelectorAll<HTMLElement>("section.docx"),
    ];
    if (!renderedPages.length) throw new Error("docx-pages-missing");
    return {
      bodyHtml: renderHost.innerHTML,
      pageCount: renderedPages.length,
      styles: `
        @page{size:auto;margin:0}
        body{font-family:Arial,Tahoma,sans-serif}
        section.docx{break-after:page!important;box-shadow:none!important;margin:0 auto!important}
        section.docx:last-of-type{break-after:auto!important}
      `,
    };
  } finally {
    renderHost.remove();
  }
}

async function powerpointToPrintMarkup(file: File) {
  const [{ PptxViewer }, { replaceCanvasesWithImages }] = await Promise.all([
    import("@aiden0z/pptx-renderer"),
    import("@/lib/browser-print"),
  ]);
  const renderHost = document.createElement("div");
  renderHost.className = "powerpoint-pdf-render-host";
  renderHost.setAttribute("aria-hidden", "true");
  Object.assign(renderHost.style, {
    position: "fixed",
    insetInlineStart: "-100000px",
    top: "0",
    width: "1200px",
    background: "#fff",
  });
  document.body.appendChild(renderHost);
  const viewer = await PptxViewer.open(await file.arrayBuffer(), renderHost, {
    fitMode: "none",
    renderMode: "list",
    listOptions: { windowed: false, batchSize: 4 },
    pdfjs: false,
  });
  try {
    if (!viewer.slideCount) throw new Error("pptx-slides-missing");
    replaceCanvasesWithImages(renderHost);
    const width = viewer.slideWidth;
    const height = viewer.slideHeight;
    return {
      bodyHtml: renderHost.innerHTML,
      pageCount: viewer.slideCount,
      styles: `
        @page{size:${width}px ${height}px;margin:0}
        body{overflow:visible}
        [data-slide-index]{width:${width}px!important;height:${height}px!important;margin:0!important;break-after:page;overflow:hidden}
        [data-slide-index]>div{width:${width}px!important;height:${height}px!important;margin:0!important;overflow:hidden}
        [data-slide-index]:last-child{break-after:auto}
      `,
    };
  } finally {
    window.setTimeout(() => {
      viewer.destroy();
      renderHost.remove();
    }, 60_000);
  }
}

function OfficeToPdfWorkspace({ slug }: { slug: string }) {
  const { locale, t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [html, setHtml] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [readyFile, setReadyFile] = useState<ReadyFile | null>(null);
  const accept =
    slug === "word-to-pdf"
      ? ".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      : slug === "powerpoint-to-pdf"
        ? ".pptx,application/vnd.openxmlformats-officedocument.presentationml.presentation"
        : slug === "excel-to-pdf"
          ? ".xlsx,.xls,.csv"
          : ".html,.htm,text/html";
  async function run() {
    if (!file && !html.trim()) return;
    setBusy(true);
    setNotice("");
    setError("");
    setReadyFile(null);
    try {
      const title = file?.name || "HTML";
      const { parsePrintableHtml, printHtmlDocument } = await import(
        "@/lib/browser-print"
      );
      if (file && slug === "word-to-pdf") {
        const output = await wordToPrintMarkup(file);
        await printHtmlDocument({
          title,
          bodyHtml: output.bodyHtml,
          styles: output.styles,
          direction: "auto",
        });
        setNotice(
          t(
            `فُتحت طباعة المتصفح لـ${output.pageCount} صفحة بطبقة نص قابلة للبحث. اختر «حفظ بصيغة PDF».`,
            `Browser print opened for ${output.pageCount} pages with a searchable text layer. Choose “Save as PDF”.`,
          ),
        );
        return;
      }
      if (file && slug === "excel-to-pdf") {
        const { renderExcelForPrint } = await import("@/lib/office-print");
        const output = await renderExcelForPrint(file);
        await printHtmlDocument({
          title,
          bodyHtml: output.bodyHtml,
          styles: output.styles,
          direction: output.direction,
        });
        setNotice(
          t(
            `فُتحت طباعة المتصفح لـ${output.sheetCount} أوراق مع الخلايا والحدود والألوان والعروض والقيم المحسوبة${output.recalculatedFormulaCount ? `، وأُعيد حساب ${output.recalculatedFormulaCount} معادلات محلياً` : ""}. اختر «حفظ بصيغة PDF».`,
            `Browser print opened for ${output.sheetCount} sheets with cells, borders, colors, widths, and calculated values${output.recalculatedFormulaCount ? `; ${output.recalculatedFormulaCount} formulas were recalculated locally` : ""}. Choose “Save as PDF”.`,
          ),
        );
        return;
      }
      if (file && slug === "powerpoint-to-pdf") {
        const output = await powerpointToPrintMarkup(file);
        await printHtmlDocument({
          title,
          bodyHtml: output.bodyHtml,
          styles: output.styles,
          direction: "auto",
        });
        setNotice(
          t(
            `فُتحت طباعة ${output.pageCount} شرائح؛ كل شريحة صفحة مستقلة مع الصور والألوان والتخطيط. اختر «حفظ بصيغة PDF».`,
            `Print opened for ${output.pageCount} slides; every slide is a separate page with images, colors, and layout. Choose “Save as PDF”.`,
          ),
        );
        return;
      }
      if (slug !== "html-to-pdf") throw new Error("unsupported-office-file");
      const source = file ? await file.text() : html.trim();
      if (!source) throw new Error("empty");
      const printable = parsePrintableHtml(source);
      await printHtmlDocument({
        title,
        ...printable,
        styles:
          "@page{size:auto;margin:12mm}table{border-collapse:collapse}thead{display:table-header-group}tr,img{break-inside:avoid}html,body{unicode-bidi:plaintext}",
      });
      setNotice(
        t(
          "فُتحت طباعة المتصفح مع CSS والجداول والخطوط والصور واتجاه RTL. اختر «حفظ بصيغة PDF».",
          "Browser print opened with CSS, tables, fonts, images, and RTL support. Choose “Save as PDF”.",
        ),
      );
    } catch (caught) {
      const isMissingFormulaResult =
        slug === "excel-to-pdf" &&
        caught instanceof Error &&
        caught.message.startsWith("excel-formula-result-missing:");
      setError(
        isMissingFormulaResult
          ? t(
              "يحتوي ملف Excel على معادلة بلا نتيجة محفوظة ولا يدعمها محرك الحساب المحلي. افتح الملف في Excel أو Google Sheets لإعادة الحساب والحفظ، ثم ارفعه مجدداً. لم يتم إنشاء PDF لتجنب عرض نتيجة مضللة.",
              "This Excel file contains a formula without a cached result that the local formula engine cannot calculate. Open it in Excel or Google Sheets, recalculate and save it, then upload it again. No PDF was produced to avoid misleading output.",
            )
          : errorText(locale),
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="workspace-stack">
      <FileUploadZone
        files={file ? [file] : []}
        onFiles={(files) => {
          setFile(files[0] || null);
          setNotice("");
          setError("");
          setReadyFile(null);
        }}
        accept={accept}
        icon={
          slug === "excel-to-pdf"
            ? "sheet"
            : slug === "powerpoint-to-pdf"
              ? "presentation"
              : "file"
        }
        title={t("اختر الملف المراد تحويله", "Choose the file to convert")}
        helper={t(
          slug === "word-to-pdf"
            ? "يطبع المستند بطبقة نص حقيقية قابلة للبحث مع دعم RTL وLTR"
            : slug === "powerpoint-to-pdf"
              ? "يرسم العرض كاملاً، وكل شريحة تصبح صفحة مستقلة"
              : slug === "excel-to-pdf"
                ? "يحافظ على الخلايا والحدود والألوان والمحاذاة والعروض والقيم المحسوبة"
                : "يستخدم محرك طباعة المتصفح الفعلي مع CSS والخطوط والصور وRTL",
          slug === "word-to-pdf"
            ? "Prints a real searchable text layer with correct RTL and LTR support"
            : slug === "powerpoint-to-pdf"
              ? "Renders the complete deck with each slide on its own page"
              : slug === "excel-to-pdf"
                ? "Preserves cells, borders, colors, alignment, widths, and calculated values"
                : "Uses the real browser print engine with CSS, fonts, images, and RTL",
        )}
      />
      {slug === "html-to-pdf" && (
        <div className="field">
          <label>{t("أو الصق HTML هنا", "Or paste HTML here")}</label>
          <textarea
            value={html}
            onChange={(event) => setHtml(event.target.value)}
            placeholder="<h1>ADAWATI</h1>"
          />
        </div>
      )}
      <button
        className="primary-button"
        disabled={(!file && !html.trim()) || busy}
        onClick={run}
      >
        {busy
          ? t("جاري التحويل…", "Converting…")
          : t("فتح الطباعة وحفظ PDF", "Open print and save PDF")}
      </button>
      <ResultNotice text={notice} />
      <ReadyDownload file={readyFile} />
      <ResultNotice text={error} error />
    </div>
  );
}

async function loadPdfJs() {
  const pdfjs = await import("pdfjs-dist");
  pdfjs.GlobalWorkerOptions.workerSrc = new URL(
    "pdfjs-dist/build/pdf.worker.min.mjs",
    import.meta.url,
  ).toString();
  return pdfjs;
}

async function pdfDocument(file: File) {
  const pdfjs = await loadPdfJs();
  return pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) })
    .promise;
}

async function extractPdfText(file: File) {
  const pdf = await pdfDocument(file);
  const pages: string[] = [];
  for (let index = 1; index <= pdf.numPages; index += 1) {
    const page = await pdf.getPage(index);
    const content = await page.getTextContent();
    pages.push(
      content.items
        .map((item) => ("str" in item ? item.str : ""))
        .join(" ")
        .replace(/\s+/g, " ")
        .trim(),
    );
  }
  return pages;
}

async function extractPdfTableRows(file: File) {
  const pdf = await pdfDocument(file);
  const pages: string[][][] = [];
  for (let index = 1; index <= pdf.numPages; index += 1) {
    const page = await pdf.getPage(index);
    const content = await page.getTextContent();
    const positioned = content.items.flatMap((item) => {
      if (!("str" in item) || !("transform" in item) || !item.str.trim())
        return [];
      const transform = item.transform as number[];
      return [
        {
          text: item.str.trim(),
          x: Number(transform[4] || 0),
          y: Number(transform[5] || 0),
          width: "width" in item ? Number(item.width || 0) : 0,
          height: "height" in item ? Number(item.height || 10) : 10,
          rtl: "dir" in item && item.dir === "rtl",
        },
      ];
    });
    positioned.sort((first, second) => second.y - first.y);
    const rows: Array<{ y: number; items: typeof positioned }> = [];
    for (const item of positioned) {
      const tolerance = Math.max(2.5, item.height * 0.45);
      const row = rows.find((candidate) => Math.abs(candidate.y - item.y) <= tolerance);
      if (row) {
        row.items.push(item);
        row.y = (row.y * (row.items.length - 1) + item.y) / row.items.length;
      } else rows.push({ y: item.y, items: [item] });
    }
    rows.sort((first, second) => second.y - first.y);
    pages.push(
      rows.map((row) => {
        const rtl = row.items.filter((item) => item.rtl).length > row.items.length / 2;
        row.items.sort((first, second) =>
          rtl ? second.x - first.x : first.x - second.x,
        );
        const cells: Array<{ text: string; x: number; width: number; height: number }> = [];
        for (const item of row.items) {
          const previous = cells.at(-1);
          if (!previous) {
            cells.push({ ...item });
            continue;
          }
          const gap = rtl
            ? previous.x - (item.x + item.width)
            : item.x - (previous.x + previous.width);
          const cellGap = Math.max(14, Math.max(previous.height, item.height) * 1.35);
          if (gap <= cellGap) {
            previous.text = `${previous.text} ${item.text}`.replace(/\s+/g, " ");
            if (!rtl) previous.width = item.x + item.width - previous.x;
            else {
              previous.width = previous.x + previous.width - item.x;
              previous.x = item.x;
            }
          } else cells.push({ ...item });
        }
        return cells.map((cell) => cell.text);
      }),
    );
  }
  return pages;
}

async function renderPdf(file: File, scale = 1.7) {
  const pdf = await pdfDocument(file);
  const images: Blob[] = [];
  for (let index = 1; index <= pdf.numPages; index += 1) {
    const page = await pdf.getPage(index),
      viewport = page.getViewport({ scale }),
      canvas = document.createElement("canvas");
    canvas.width = Math.ceil(viewport.width);
    canvas.height = Math.ceil(viewport.height);
    const context = canvas.getContext("2d")!;
    await page.render({ canvas, canvasContext: context, viewport }).promise;
    images.push(
      await new Promise<Blob>((resolve, reject) =>
        canvas.toBlob(
          (blob) => (blob ? resolve(blob) : reject(new Error("image"))),
          "image/jpeg",
          0.9,
        ),
      ),
    );
  }
  return images;
}

async function validateRepairedPdf(bytes: Uint8Array) {
  const pdfjs = await loadPdfJs();
  const pdf = await pdfjs.getDocument({ data: bytes.slice() }).promise;
  if (!pdf.numPages) throw new Error("repaired-pdf-has-no-pages");
  let meaningfulPages = 0;
  let textCharacters = 0;
  for (let index = 1; index <= pdf.numPages; index += 1) {
    const page = await pdf.getPage(index);
    const content = await page.getTextContent();
    const text = content.items
      .map((item) => ("str" in item ? item.str : ""))
      .join("")
      .trim();
    textCharacters += text.length;
    if (text.length) {
      meaningfulPages += 1;
      continue;
    }

    const viewport = page.getViewport({ scale: 0.4 });
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.ceil(viewport.width));
    canvas.height = Math.max(1, Math.ceil(viewport.height));
    const context = canvas.getContext("2d", { willReadFrequently: true })!;
    context.fillStyle = "#fff";
    context.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvas, canvasContext: context, viewport }).promise;
    const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
    let nonWhite = 0;
    for (let offset = 0; offset < pixels.length; offset += 16) {
      if (
        pixels[offset] < 245 ||
        pixels[offset + 1] < 245 ||
        pixels[offset + 2] < 245
      ) {
        nonWhite += 1;
        if (nonWhite >= 12) break;
      }
    }
    if (nonWhite >= 12) meaningfulPages += 1;
  }
  if (!meaningfulPages) throw new Error("repaired-pdf-is-blank");
  return { pageCount: pdf.numPages, meaningfulPages, textCharacters };
}

async function flattenPdf(
  file: File,
  redactedPages = new Set<number>(),
  rectangle?: { x: number; y: number; width: number; height: number },
) {
  const source = await pdfDocument(file);
  const { PDFDocument } = await import("pdf-lib");
  const output = await PDFDocument.create();
  for (let index = 1; index <= source.numPages; index += 1) {
    const page = await source.getPage(index);
    const display = page.getViewport({ scale: 1 });
    const viewport = page.getViewport({ scale: 2 });
    const canvas = document.createElement("canvas");
    canvas.width = Math.ceil(viewport.width);
    canvas.height = Math.ceil(viewport.height);
    const context = canvas.getContext("2d")!;
    await page.render({ canvas, canvasContext: context, viewport }).promise;
    if (rectangle && redactedPages.has(index - 1)) {
      const left = Math.max(0, Math.min(99, rectangle.x || 0));
      const top = Math.max(0, Math.min(99, rectangle.y || 0));
      const rectWidth = Math.max(1, Math.min(100 - left, rectangle.width || 1));
      const rectHeight = Math.max(
        1,
        Math.min(100 - top, rectangle.height || 1),
      );
      context.fillStyle = "#000";
      context.fillRect(
        (canvas.width * left) / 100,
        (canvas.height * top) / 100,
        (canvas.width * rectWidth) / 100,
        (canvas.height * rectHeight) / 100,
      );
    }
    const blob = await new Promise<Blob>((resolve, reject) =>
      canvas.toBlob(
        (value) => (value ? resolve(value) : reject(new Error("flatten"))),
        "image/jpeg",
        0.94,
      ),
    );
    const image = await output.embedJpg(await blob.arrayBuffer());
    const target = output.addPage([display.width, display.height]);
    target.drawImage(image, {
      x: 0,
      y: 0,
      width: display.width,
      height: display.height,
    });
  }
  output.setProducer("ADAWATI Archival Renderer");
  output.setCreator("ADAWATI");
  output.setSubject(
    redactedPages.size
      ? "Permanently flattened redaction"
      : "Stable flattened archival copy",
  );
  return output.save({ useObjectStreams: false });
}

function blobDataUrl(blob: Blob) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

export function summarizePdfText(text: string, sentenceLimit = 8) {
  const sentences = text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?؟])\s+/)
    .map((sentence) => sentence.trim())
    .filter((sentence) => sentence.length > 25);
  if (sentences.length <= sentenceLimit) return sentences.join(" ");
  const stopWords = new Set(["هذا", "هذه", "ذلك", "التي", "الذي", "على", "إلى", "الى", "من", "في", "عن", "مع", "كان", "هي", "هو", "the", "and", "for", "that", "this", "with", "from", "are", "was"]);
  const frequencies = new Map<string, number>();
  for (const word of text.toLowerCase().match(/[\p{L}\p{N}]+/gu) || []) {
    if (word.length < 3 || stopWords.has(word)) continue;
    frequencies.set(word, (frequencies.get(word) || 0) + 1);
  }
  return sentences
    .map((sentence, index) => {
      const words = sentence.toLowerCase().match(/[\p{L}\p{N}]+/gu) || [];
      const score = words.reduce((sum, word) => sum + (frequencies.get(word) || 0), 0) / Math.sqrt(Math.max(1, words.length));
      return { sentence, index, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, sentenceLimit)
    .sort((a, b) => a.index - b.index)
    .map((item) => item.sentence)
    .join(" ");
}

function PdfExtractWorkspace({ slug }: { slug: string }) {
  const { locale, t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");
  const [result, setResult] = useState("");
  const [error, setError] = useState("");
  const [readyFile, setReadyFile] = useState<ReadyFile | null>(null);
  async function run() {
    if (!file) return;
    setBusy(true);
    setError("");
    setResult("");
    setReadyFile(null);
    setProgress(t("جاري قراءة الصفحات…", "Reading pages…"));
    const publish = (blob: Blob, name: string) => {
      setReadyFile({ blob, name });
      download(blob, name);
    };
    try {
      if (slug === "pdf-to-jpg") {
        const images = await renderPdf(file);
        const { zipSync } = await import("fflate");
        const entries: Record<string, Uint8Array> = {};
        for (let index = 0; index < images.length; index += 1)
          entries[`page-${index + 1}.jpg`] = new Uint8Array(
            await images[index].arrayBuffer(),
          );
        publish(
          new Blob([zipSync(entries) as BlobPart], { type: "application/zip" }),
          "adawati-pdf-images.zip",
        );
        setResult(
          t(
            `تم تحويل ${images.length} صفحات إلى JPG`,
            `${images.length} pages were converted to JPG`,
          ),
        );
      } else if (slug === "pdf-to-powerpoint") {
        const images = await renderPdf(file, 1.45);
        const PptxGenJS = (await import("pptxgenjs")).default;
        const presentation = new PptxGenJS();
        presentation.layout = "LAYOUT_WIDE";
        for (const image of images)
          presentation.addSlide().addImage({
            data: await blobDataUrl(image),
            x: 0,
            y: 0,
            w: 13.333,
            h: 7.5,
          });
        const output = await presentation.write({ outputType: "blob" });
        const presentationBlob =
          output instanceof Blob
            ? output
            : new Blob([output as BlobPart], {
                type: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              });
        publish(presentationBlob, "adawati-pdf.pptx");
        setResult(
          t(
            `تم إنشاء عرض من ${images.length} شرائح`,
            `A ${images.length}-slide presentation was created`,
          ),
        );
      } else if (slug === "pdf-ocr") {
        const sourceBytes = new Uint8Array(await file.arrayBuffer());
        const nativeText = await extractPdfText(file);
        const needsRecognition = nativeText.map(
          (page) => page.replace(/\s+/g, "").length < 8,
        );
        const recognizedPdfPages: Array<number[] | null> = Array.from(
          { length: nativeText.length },
          () => null,
        );
        const output = [...nativeText];
        let worker: Awaited<ReturnType<(typeof import("tesseract.js"))["createWorker"]>> | null = null;
        try {
          if (needsRecognition.some(Boolean)) {
            const images = await renderPdf(file, 2.5);
            const { createWorker } = await import("tesseract.js");
            worker = await createWorker(["ara", "eng"], undefined, {
              logger: (message) => {
                if (message.status !== "recognizing text") return;
                setProgress(
                  t(
                    `جاري التعرّف على النص… ${Math.round(message.progress * 100)}%`,
                    `Recognizing text… ${Math.round(message.progress * 100)}%`,
                  ),
                );
              },
            });
            await worker.setParameters({
              preserve_interword_spaces: "1",
              user_defined_dpi: "240",
            });
            for (let index = 0; index < images.length; index += 1) {
              if (!needsRecognition[index]) continue;
              setProgress(
                t(
                  `جاري قراءة الصفحة ${index + 1} من ${images.length}…`,
                  `Recognizing page ${index + 1} of ${images.length}…`,
                ),
              );
              const recognition = await worker.recognize(
                images[index],
                { pdfTitle: `${file.name} — page ${index + 1}` },
                { pdf: true, blocks: true },
              );
              const pageText = recognition.data.text.trim();
              if (pageText.replace(/\s+/g, "").length >= 2) {
                output[index] = pageText;
                recognizedPdfPages[index] = recognition.data.pdf;
              }
            }
          }
        } finally {
          await worker?.terminate();
        }
        if (!output.some((page) => page.replace(/\s+/g, "").length >= 2))
          throw new Error("ocr-no-recognizable-text");

        const { PDFDocument } = await import("pdf-lib");
        const sourcePdf = await PDFDocument.load(sourceBytes.slice());
        const searchablePdf = await PDFDocument.create();
        for (let index = 0; index < sourcePdf.getPageCount(); index += 1) {
          const recognizedPage = recognizedPdfPages[index];
          if (recognizedPage?.length) {
            const ocrPdf = await PDFDocument.load(new Uint8Array(recognizedPage));
            const [page] = await searchablePdf.copyPages(ocrPdf, [0]);
            searchablePdf.addPage(page);
          } else {
            const [page] = await searchablePdf.copyPages(sourcePdf, [index]);
            searchablePdf.addPage(page);
          }
        }
        searchablePdf.setCreator("ADAWATI PDF OCR");
        searchablePdf.setProducer("ADAWATI + Tesseract.js");
        const text = output
          .map(
            (page, index) =>
              `## ${t("الصفحة", "Page")} ${index + 1}\n\n${page}`,
          )
          .join("\n\n");
        publish(
          new Blob(
            [await searchablePdf.save({ useObjectStreams: true }) as BlobPart],
            { type: "application/pdf" },
          ),
          "adawati-ocr-searchable.pdf",
        );
        setResult(text);
      } else {
        if (slug === "pdf-to-excel") {
          const tablePages = await extractPdfTableRows(file);
          if (!tablePages.some((page) => page.some((row) => row.some(Boolean))))
            throw new Error("no-table-text");
          const { tableRowsToXlsx } = await import("@/lib/document-exports");
          const bytes = await tableRowsToXlsx(
            tablePages,
            t("صفحة", "Page"),
          );
          publish(
            new Blob([bytes], {
              type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            }),
            "adawati-pdf-tables.xlsx",
          );
          setResult(
            t(
              `تم اكتشاف الصفوف والأعمدة حسب مواضع النص وإنشاء ${tablePages.length} أوراق؛ راجع الجداول المعقدة أو الممسوحة ضوئياً قبل الاعتماد عليها.`,
              `Rows and columns were detected from text positions across ${tablePages.length} sheets. Review complex or scanned tables before relying on them.`,
            ),
          );
          return;
        }
        const pages = await extractPdfText(file);
        const text = pages.filter(Boolean).join("\n\n");
        if (!text.trim()) throw new Error("no-text");
        if (slug === "pdf-to-word") {
          const { pagesToDocx } = await import("@/lib/document-exports");
          publish(
            await pagesToDocx(pages, t("الصفحة", "Page")),
            "adawati-pdf-word.docx",
          );
        }
        if (slug === "pdf-to-markdown") {
          const markdown = pages
            .map(
              (page, index) =>
                `## ${t("الصفحة", "Page")} ${index + 1}\n\n${page}`,
            )
            .join("\n\n");
          publish(
            new Blob([markdown], { type: "text/markdown;charset=utf-8" }),
            "adawati-pdf.md",
          );
          setResult(markdown);
        }
        if (slug === "pdf-summary") {
          const summary = summarizePdfText(text.slice(0, 100_000));
          if (!summary) throw new Error("no-summary");
          setResult(summary);
          publish(new Blob([summary], { type: "text/plain;charset=utf-8" }), "adawati-pdf-summary.txt");
        }
        if (slug === "pdf-to-word")
          setResult(
            t(
              "تم استخراج المحتوى وتنزيل الملف الجديد",
              "Content was extracted and the new file was downloaded",
            ),
          );
      }
    } catch {
      setError(
        slug === "pdf-ocr"
          ? t(
              "تعذر التعرف على النص. تحقق من وضوح الصفحات واتصال الإنترنت لتحميل لغة OCR أول مرة.",
              "OCR failed. Check page clarity and the internet connection needed for the first language download.",
            )
          : errorText(locale),
      );
    } finally {
      setBusy(false);
      setProgress("");
    }
  }
  return (
    <div className="workspace-stack">
      <PdfUpload
        file={file}
        setFile={(next) => {
          setFile(next);
          setResult("");
          setError("");
          setReadyFile(null);
        }}
      />
      <button className="primary-button" disabled={!file || busy} onClick={run}>
        {busy
          ? progress || t("جاري التنفيذ…", "Processing…")
          : t("بدء المعالجة", "Start processing")}
      </button>
      {result && (
        <div className="pdf-text-result">
          <div className="button-row">
            <strong>{t("النتيجة", "Result")}</strong>
            <button
              className="secondary-button"
              onClick={() => navigator.clipboard.writeText(result)}
            >
              <Icon name="copy" size={17} />
              {t("نسخ", "Copy")}
            </button>
          </div>
          <pre>{result}</pre>
        </div>
      )}
      <ReadyDownload file={readyFile} />
      <ResultNotice text={error} error />
    </div>
  );
}

function PdfCompareWorkspace() {
  const { locale, t } = useLocale();
  const [first, setFirst] = useState<File | null>(null);
  const [second, setSecond] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState("");
  const [error, setError] = useState("");
  const [readyFile, setReadyFile] = useState<ReadyFile | null>(null);
  async function run() {
    if (!first || !second) return;
    setBusy(true);
    setError("");
    setResult("");
    setReadyFile(null);
    try {
      const pdf = await toolkit();
      const pageDimensions = async (documentFile: File) => {
        const document = await pdfDocument(documentFile);
        const sizes = new Set<string>();
        for (let index = 1; index <= document.numPages; index += 1) {
          const viewport = (await document.getPage(index)).getViewport({ scale: 1 });
          const widthMm = (viewport.width * 25.4) / 72;
          const heightMm = (viewport.height * 25.4) / 72;
          sizes.add(
            `${viewport.width.toFixed(1)}×${viewport.height.toFixed(1)} pt (${widthMm.toFixed(1)}×${heightMm.toFixed(1)} mm)`,
          );
        }
        const values = [...sizes];
        return values.length <= 3
          ? values.join("، ")
          : `${values.slice(0, 3).join("، ")} +${values.length - 3}`;
      };
      const [one, two, oneText, twoText, oneDimensions, twoDimensions] = await Promise.all([
        pdf.getInfo(first),
        pdf.getInfo(second),
        extractPdfText(first),
        extractPdfText(second),
        pageDimensions(first),
        pageDimensions(second),
      ]);
      const a = oneText.join(" "),
        b = twoText.join(" "),
        max = Math.max(a.length, b.length, 1);
      let same = 0;
      for (let index = 0; index < Math.min(a.length, b.length); index += 1)
        if (a[index] === b[index]) same += 1;
      const report = t(
        `الملف الأول: ${one.pageCount} صفحة، ${formatFileSize(first.size)}\nأبعاد الصفحات: ${oneDimensions}\nالملف الثاني: ${two.pageCount} صفحة، ${formatFileSize(second.size)}\nأبعاد الصفحات: ${twoDimensions}\nتشابه النص التقريبي: ${Math.round((same / max) * 100)}%`,
        `First PDF: ${one.pageCount} pages, ${formatFileSize(first.size)}\nPage dimensions: ${oneDimensions}\nSecond PDF: ${two.pageCount} pages, ${formatFileSize(second.size)}\nPage dimensions: ${twoDimensions}\nApproximate text similarity: ${Math.round((same / max) * 100)}%`,
      );
      setResult(report);
      setReadyFile({
        blob: new Blob([report], { type: "text/plain;charset=utf-8" }),
        name: "adawati-pdf-comparison.txt",
      });
    } catch {
      setError(errorText(locale));
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <PdfUpload
          file={first}
          setFile={setFirst}
          label={t("اختر ملف PDF الأول", "Choose first PDF")}
        />
        <PdfUpload
          file={second}
          setFile={setSecond}
          label={t("اختر ملف PDF الثاني", "Choose second PDF")}
        />
      </div>
      <button
        className="primary-button"
        disabled={!first || !second || busy}
        onClick={run}
      >
        {busy
          ? t("جاري المقارنة…", "Comparing…")
          : t("مقارنة الملفين", "Compare PDFs")}
      </button>
      {result && (
        <div className="pdf-text-result">
          <pre>{result}</pre>
        </div>
      )}
      <ReadyDownload file={readyFile} />
      <ResultNotice text={error} error />
    </div>
  );
}

function PdfFormsWorkspace() {
  const { locale, t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [fields, setFields] = useState<
    import("@/lib/pdf-forms").PdfFormField[]
  >([]);
  const [values, setValues] = useState<Record<string, string>>({});
  const [flatten, setFlatten] = useState(false);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [readyFile, setReadyFile] = useState<ReadyFile | null>(null);

  async function inspect(next: File | null) {
    setFile(next);
    setFields([]);
    setValues({});
    setNotice("");
    setError("");
    setReadyFile(null);
    if (!next) return;
    setLoading(true);
    try {
      const { inspectPdfForm } = await import("@/lib/pdf-forms");
      const discovered = await inspectPdfForm(await next.arrayBuffer());
      if (!discovered.length)
        throw new Error("The PDF does not contain interactive form fields");
      setFields(discovered);
      setValues(
        Object.fromEntries(
          discovered.map((field) => [field.name, field.value]),
        ),
      );
      setNotice(
        t(
          `تم العثور على ${discovered.length} حقول قابلة للتعبئة`,
          `${discovered.length} fillable fields were found`,
        ),
      );
    } catch (caught) {
      setError(
        caught instanceof Error && caught.message.includes("interactive")
          ? t(
              "لا يحتوي الملف على حقول نماذج تفاعلية قابلة للتعبئة.",
              "This PDF does not contain interactive fillable form fields.",
            )
          : errorText(locale),
      );
    } finally {
      setLoading(false);
    }
  }

  async function save() {
    if (!file || !fields.length) return;
    setBusy(true);
    setError("");
    setNotice("");
    setReadyFile(null);
    try {
      const { fillPdfForm } = await import("@/lib/pdf-forms");
      const bytes = await fillPdfForm(
        await file.arrayBuffer(),
        values,
        flatten,
      );
      const name = flatten
        ? "adawati-filled-form-flattened.pdf"
        : "adawati-filled-form.pdf";
      const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
      setReadyFile({ blob, name });
      download(blob, name);
      setNotice(
        t(
          flatten
            ? "تمت تعبئة النموذج وتثبيت الحقول وتنزيل PDF النهائي"
            : "تمت تعبئة النموذج وتنزيل PDF مع بقاء الحقول قابلة للتعديل",
          flatten
            ? "The form was filled, flattened, and downloaded"
            : "The form was filled and downloaded with editable fields",
        ),
      );
    } catch {
      setError(errorText(locale));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="workspace-stack">
      <PdfUpload file={file} setFile={inspect} />
      {loading && (
        <div className="notice" role="status">
          <Icon name="loader" size={18} />
          {t("جاري قراءة حقول النموذج…", "Reading form fields…")}
        </div>
      )}
      {!!fields.length && (
        <div className="pdf-form-fields">
          {fields.map((field) => (
            <div className="field" key={field.name}>
              <label>{field.name}</label>
              {field.type === "text" && (
                <input
                  value={values[field.name] || ""}
                  onChange={(event) =>
                    setValues((current) => ({
                      ...current,
                      [field.name]: event.target.value,
                    }))
                  }
                />
              )}
              {field.type === "checkbox" && (
                <label className="modern-check pdf-form-check">
                  <input
                    type="checkbox"
                    checked={values[field.name] === "true"}
                    onChange={(event) =>
                      setValues((current) => ({
                        ...current,
                        [field.name]: String(event.target.checked),
                      }))
                    }
                  />
                  {t("محدد", "Checked")}
                </label>
              )}
              {field.type === "choice" && (
                <CustomSelect
                  value={values[field.name] || ""}
                  onChange={(value) =>
                    setValues((current) => ({
                      ...current,
                      [field.name]: value,
                    }))
                  }
                  label={field.name}
                  options={[
                    { value: "", label: t("بدون اختيار", "No selection") },
                    ...field.options.map((option) => ({
                      value: option,
                      label: option,
                    })),
                  ]}
                />
              )}
              {field.type === "unsupported" && (
                <small className="error-notice">
                  {t(
                    "نوع هذا الحقل غير مدعوم حالياً وسيبقى كما هو.",
                    "This field type is not currently supported and will be preserved.",
                  )}
                </small>
              )}
            </div>
          ))}
        </div>
      )}
      {!!fields.length && (
        <label className="modern-check">
          <input
            type="checkbox"
            checked={flatten}
            onChange={(event) => setFlatten(event.target.checked)}
          />
          <span>
            {t("تثبيت الحقول بعد التعبئة", "Flatten fields after filling")}
            <small>
              {t(
                "يحوّل القيم إلى محتوى ثابت لمنع تعديلها لاحقاً.",
                "Turns the values into fixed page content to prevent later editing.",
              )}
            </small>
          </span>
        </label>
      )}
      <button
        type="button"
        className="primary-button"
        disabled={!file || !fields.length || loading || busy}
        onClick={save}
      >
        {busy
          ? t("جاري تجهيز النموذج…", "Preparing form…")
          : t("تعبئة وتنزيل PDF", "Fill and download PDF")}
      </button>
      <ResultNotice text={notice} />
      <ReadyDownload file={readyFile} />
      <ResultNotice text={error} error />
    </div>
  );
}

export function PdfToolWorkspace({ slug }: { slug: string }) {
  if (basicSlugs.includes(slug)) return <BasicPdfWorkspace slug={slug} />;
  if (decorateSlugs.includes(slug)) return <DecoratePdfWorkspace slug={slug} />;
  if (officeToPdfSlugs.includes(slug))
    return <OfficeToPdfWorkspace slug={slug} />;
  if (extractSlugs.includes(slug)) return <PdfExtractWorkspace slug={slug} />;
  if (slug === "pdf-forms") return <PdfFormsWorkspace />;
  if (slug === "pdf-compare") return <PdfCompareWorkspace />;
  return null;
}
