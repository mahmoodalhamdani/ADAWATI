"use client";

import { useEffect, useMemo, useState, type ChangeEvent } from "react";
import { CustomSelect } from "./CustomSelect";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";
import { copyWithFeedback } from "@/lib/copy-feedback";
import { deviceAgeCost, targetSalePriceFromMargin } from "@/lib/tool-calculations";

type Field = {
  key: string;
  ar: string;
  en: string;
  value: string;
  type?: "number" | "date" | "select";
  min?: number;
  step?: string;
  options?: { value: string; ar: string; en: string }[];
};
type Result = { value: string; ar: string; en: string; kind?: "money" };
type Formula = {
  fields: Field[];
  calculate: (values: Record<string, string>, now?: Date) => { results: Result[]; error?: string };
  noteAr: string;
  noteEn: string;
};

const n = (values: Record<string, string>, key: string) => Number(values[key]);
const ok = (...values: number[]) => values.every(Number.isFinite);
const fmt = (value: number, digits = 2) =>
  Number.isFinite(value)
    ? new Intl.NumberFormat("en-US", { maximumFractionDigits: digits }).format(value)
    : "—";
const metric = (value: number | string, ar: string, en: string, suffix = "", kind?: "money"): Result => ({
  value: typeof value === "number" ? `${fmt(value)}${suffix}` : `${value}${suffix}`,
  ar,
  en,
  kind,
});
const numeric = (key: string, ar: string, en: string, value: number, min = 0, step = "any"): Field => ({ key, ar, en, value: String(value), type: "number", min, step });
const dateText = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
const today = () => {
  const date = new Date();
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0);
};

export const formulaDefinitions: Record<string, Formula> = {
  "overtime-calculator": {
    fields: [numeric("hours", "الساعات الإضافية", "Overtime hours", 8), numeric("rate", "الأجر الأساسي بالساعة", "Base hourly rate", 15), numeric("multiplier", "معامل الإضافي", "Overtime multiplier", 1.5, 0, "0.1")],
    calculate: (v) => {
      const hours = n(v, "hours"), rate = n(v, "rate"), multiplier = n(v, "multiplier");
      return !ok(hours, rate, multiplier) || hours < 0 || rate < 0 || multiplier < 0 ? { results: [], error: "invalid" } : { results: [metric(rate * multiplier, "أجر الساعة الإضافية", "Overtime hourly rate"), metric(hours * rate * multiplier, "إجمالي العمل الإضافي", "Total overtime pay"), metric(hours * rate, "القيمة بالسعر الأساسي", "Base-rate value")] };
    },
    noteAr: "المعامل يحدده المستخدم وفق عقده أو نظام جهة العمل، ولا تفترض الأداة نسبة قانونية ثابتة.", noteEn: "Enter the multiplier defined by your contract or employer; the tool does not assume a legal rate.",
  },
  "monthly-annual-comparison": {
    fields: [numeric("monthly", "سعر الاشتراك الشهري", "Monthly subscription", 12), numeric("annual", "سعر الاشتراك السنوي", "Annual subscription", 110), numeric("months", "عدد أشهر الاستخدام بالسنة", "Months used per year", 12, 1, "1")],
    calculate: (v) => { const monthly = n(v, "monthly"), annual = n(v, "annual"), months = n(v, "months"); if (!ok(monthly, annual, months) || monthly < 0 || annual < 0 || months <= 0) return { results: [], error: "invalid" }; const monthlyTotal = monthly * months; return { results: [metric(monthlyTotal, "إجمالي الخطة الشهرية", "Monthly-plan total"), metric(annual, "إجمالي الخطة السنوية", "Annual-plan total"), metric(Math.abs(monthlyTotal - annual), "فرق السعر", "Price difference"), metric(monthlyTotal === annual ? "متساويان" : monthlyTotal < annual ? "الشهري" : "السنوي", "الأقل كلفة", "Lower cost")] }; },
    noteAr: "المقارنة رقمية فقط ولا تشمل مزايا أو شروطاً غير مدخلة.", noteEn: "This is a numeric comparison and does not include unentered benefits or terms.",
  },
  "cost-per-use": {
    fields: [numeric("price", "السعر الكلي", "Total price", 120), numeric("uses", "عدد مرات الاستخدام", "Number of uses", 30, 1, "1")],
    calculate: (v) => { const price = n(v, "price"), uses = n(v, "uses"); return !ok(price, uses) || price < 0 || uses <= 0 ? { results: [], error: "invalid" } : { results: [metric(price / uses, "تكلفة كل استخدام", "Cost per use"), metric(price, "التكلفة الكلية", "Total cost"), metric(uses, "عدد الاستخدامات", "Uses")] }; },
    noteAr: "يمكن استخدامها للاشتراك أو الجهاز أو الملابس أو أي شراء متكرر الاستخدام.", noteEn: "Use it for subscriptions, devices, clothing, or any repeatedly used purchase.",
  },
  "break-even-calculator": {
    fields: [numeric("fixed", "التكاليف الثابتة", "Fixed costs", 5000), numeric("variable", "تكلفة الوحدة", "Variable cost per unit", 8), numeric("price", "سعر بيع الوحدة", "Sale price per unit", 15)],
    calculate: (v) => { const fixed = n(v, "fixed"), variable = n(v, "variable"), price = n(v, "price"), contribution = price - variable; if (!ok(fixed, variable, price) || fixed < 0 || variable < 0 || contribution <= 0) return { results: [], error: "invalid" }; const units = Math.ceil(fixed / contribution); return { results: [metric(contribution, "هامش المساهمة للوحدة", "Contribution per unit"), metric(units, "وحدات نقطة التعادل", "Break-even units"), metric(units * price, "مبيعات نقطة التعادل", "Break-even revenue")] }; },
    noteAr: "يجب أن يكون سعر البيع أكبر من تكلفة الوحدة حتى توجد نقطة تعادل.", noteEn: "Sale price must exceed unit cost for a break-even point to exist.",
  },
  "profit-margin-calculator": {
    fields: [numeric("cost", "سعر الشراء أو التكلفة", "Cost price", 60), numeric("sale", "سعر البيع الحالي", "Current sale price", 100), numeric("targetMargin", "هامش الربح المستهدف %", "Target profit margin %", 30, 0, "0.1")],
    calculate: (v) => { const cost = n(v, "cost"), sale = n(v, "sale"), targetMargin = n(v, "targetMargin"), targetPrice = targetSalePriceFromMargin(cost, targetMargin); if (!ok(cost, sale, targetMargin) || cost < 0 || sale <= 0 || targetPrice === null) return { results: [], error: "invalid" }; const profit = sale - cost; return { results: [metric(profit, "الربح الحالي", "Current profit", "", "money"), metric((profit / sale) * 100, "هامش الربح الحالي", "Current profit margin", "%"), metric(cost > 0 ? (profit / cost) * 100 : 0, "Markup", "Markup", "%"), metric(targetPrice, "سعر البيع المقترح للهامش المستهدف", "Recommended price for target margin", "", "money")] }; },
    noteAr: "هامش الربح يقسم الربح على سعر البيع؛ أدخل الهامش المستهدف لتحصل على سعر بيع مقترح بالعملة المختارة.", noteEn: "Margin divides profit by sale price; enter a target margin to get a recommended price in the selected currency.",
  },
  "home-area-calculator": {
    fields: [numeric("length", "الطول بالمتر", "Length in meters", 5), numeric("width", "العرض بالمتر", "Width in meters", 4)],
    calculate: (v) => { const length = n(v, "length"), width = n(v, "width"); return !ok(length, width) || length <= 0 || width <= 0 ? { results: [], error: "invalid" } : { results: [metric(length * width, "المساحة", "Area", " m²"), metric(2 * (length + width), "المحيط", "Perimeter", " m"), metric(Math.hypot(length, width), "القطر", "Diagonal", " m")] }; },
    noteAr: "الحساب لغرفة أو مساحة مستطيلة؛ قسّم المخطط المعقد إلى مستطيلات واجمع النتائج.", noteEn: "For a rectangular area; split complex layouts into rectangles and add the results.",
  },
  "tile-calculator": {
    fields: [numeric("area", "مساحة المكان m²", "Area m²", 24), numeric("tileLength", "طول البلاطة cm", "Tile length cm", 60), numeric("tileWidth", "عرض البلاطة cm", "Tile width cm", 60), numeric("waste", "نسبة الهدر %", "Waste %", 10), numeric("tilePrice", "سعر البلاطة الواحدة", "Price per tile", 2.5)],
    calculate: (v) => { const area = n(v, "area"), length = n(v, "tileLength"), width = n(v, "tileWidth"), waste = n(v, "waste"), tilePrice = n(v, "tilePrice"); if (!ok(area, length, width, waste, tilePrice) || area <= 0 || length <= 0 || width <= 0 || waste < 0 || tilePrice < 0) return { results: [], error: "invalid" }; const required = area * (1 + waste / 100), tileArea = (length / 100) * (width / 100), tileCount = Math.ceil(required / tileArea); return { results: [metric(tileArea, "مساحة البلاطة", "Tile area", " m²"), metric(required, "المساحة مع الهدر", "Area with waste", " m²"), metric(tileCount, "عدد البلاطات المطلوبة", "Tiles required"), metric(tileCount * tilePrice, "إجمالي تكلفة مواد البلاط", "Total tile material cost", "", "money")] }; },
    noteAr: "يُقرب عدد البلاطات إلى الأعلى وتُحسب تكلفة المواد من سعر البلاطة؛ لا تشمل النتيجة التركيب أو النقل.", noteEn: "Tile count is rounded up and material cost uses the entered per-tile price; labor and delivery are excluded.",
  },
  "paint-calculator": {
    fields: [numeric("area", "مساحة الجدران m²", "Wall area m²", 80), numeric("coats", "عدد الطبقات", "Coats", 2, 1, "1"), numeric("coverage", "تغطية اللتر m²", "Coverage per liter m²", 10), numeric("can", "حجم العبوة باللتر", "Can size liters", 4)],
    calculate: (v) => { const area = n(v, "area"), coats = n(v, "coats"), coverage = n(v, "coverage"), canSize = n(v, "can"); if (!ok(area, coats, coverage, canSize) || area <= 0 || coats <= 0 || coverage <= 0 || canSize <= 0) return { results: [], error: "invalid" }; const liters = (area * coats) / coverage; return { results: [metric(liters, "الدهان المطلوب", "Paint required", " L"), metric(Math.ceil(liters / canSize), "عدد العبوات", "Cans required"), metric(Math.ceil(liters / canSize) * canSize - liters, "الكمية الزائدة", "Extra paint", " L")] }; },
    noteAr: "استخدم رقم التغطية المكتوب على العبوة؛ السطح الخشن قد يستهلك أكثر.", noteEn: "Use the coverage printed on the can; rough surfaces may require more.",
  },
  "tank-volume-calculator": {
    fields: [{ key: "shape", ar: "شكل الخزان", en: "Tank shape", value: "rect", type: "select", options: [{ value: "rect", ar: "مستطيل", en: "Rectangular" }, { value: "cylinder", ar: "أسطواني", en: "Cylindrical" }] }, numeric("length", "الطول أو الارتفاع cm", "Length or height cm", 150), numeric("width", "العرض cm", "Width cm", 80), numeric("depth", "العمق أو القطر cm", "Depth or diameter cm", 60)],
    calculate: (v) => { const length = n(v, "length"), width = n(v, "width"), depth = n(v, "depth"); if (!ok(length, width, depth) || length <= 0 || depth <= 0 || (v.shape === "rect" && width <= 0)) return { results: [], error: "invalid" }; const cm3 = v.shape === "cylinder" ? Math.PI * (depth / 2) ** 2 * length : length * width * depth; return { results: [metric(cm3 / 1000, "السعة", "Capacity", " L"), metric(cm3 / 1_000_000, "الحجم", "Volume", " m³"), metric((cm3 / 1000) * 0.264172, "السعة بالجالون الأمريكي", "US gallons")] }; },
    noteAr: "في الخزان الأسطواني أدخل الارتفاع في الحقل الأول والقطر في الحقل الثالث.", noteEn: "For a cylinder, enter height in the first field and diameter in the third.",
  },
  "water-consumption-calculator": {
    fields: [numeric("people", "عدد الأشخاص", "People", 4, 1, "1"), numeric("perPerson", "استهلاك الشخص يومياً L", "Liters per person daily", 120), numeric("extra", "استخدامات إضافية يومية L", "Extra daily use liters", 80)],
    calculate: (v) => { const people = n(v, "people"), per = n(v, "perPerson"), extra = n(v, "extra"); if (!ok(people, per, extra) || people <= 0 || per < 0 || extra < 0) return { results: [], error: "invalid" }; const daily = people * per + extra; return { results: [metric(daily, "الاستهلاك اليومي", "Daily use", " L"), metric(daily * 30, "الاستهلاك الشهري", "Monthly use", " L"), metric((daily * 30) / 1000, "شهرياً بالمتر المكعب", "Monthly cubic meters", " m³")] }; },
    noteAr: "النتيجة تقديرية وتعتمد بالكامل على معدل الاستخدام الذي يدخله المستخدم.", noteEn: "The estimate depends entirely on the usage rate entered by the user.",
  },
  "reading-time-calculator": {
    fields: [numeric("words", "عدد الكلمات", "Word count", 1200, 1, "1"), numeric("speed", "سرعة القراءة كلمة/دقيقة", "Reading speed WPM", 220, 1, "1")],
    calculate: (v) => { const words = n(v, "words"), speed = n(v, "speed"); if (!ok(words, speed) || words < 0 || speed <= 0) return { results: [], error: "invalid" }; const minutes = words / speed; return { results: [metric(minutes, "الدقائق", "Minutes"), metric(minutes * 60, "الثواني", "Seconds"), metric(Math.ceil(minutes), "المدة المقربة", "Rounded duration", " min")] }; },
    noteAr: "للنصوص العربية والإنجليزية؛ يمكن معرفة عدد الكلمات من أداة محلل النص.", noteEn: "Works for Arabic and English; use the text analyzer to get a word count.",
  },
  "speech-time-calculator": {
    fields: [numeric("words", "عدد كلمات الخطاب", "Speech word count", 900, 1, "1"), numeric("speed", "سرعة الكلام كلمة/دقيقة", "Speaking speed WPM", 130, 1, "1"), numeric("pause", "وقت الوقفات %", "Pause allowance %", 10)],
    calculate: (v) => { const words = n(v, "words"), speed = n(v, "speed"), pause = n(v, "pause"); if (!ok(words, speed, pause) || words < 0 || speed <= 0 || pause < 0) return { results: [], error: "invalid" }; const minutes = (words / speed) * (1 + pause / 100); return { results: [metric(minutes, "مدة الإلقاء", "Speech duration", " min"), metric(minutes * 60, "المدة بالثواني", "Duration seconds"), metric(words / Math.max(minutes, 0.001), "السرعة الفعلية بعد الوقفات", "Effective WPM")] }; },
    noteAr: "زد نسبة الوقفات للعروض التي تحتوي شرحاً أو تفاعلاً مع الجمهور.", noteEn: "Increase the pause allowance for presentations with explanations or audience interaction.",
  },
  "car-cost-per-km": {
    fields: [numeric("fuel", "تكلفة الوقود", "Fuel cost", 900), numeric("maintenance", "الصيانة والإطارات", "Maintenance and tires", 450), numeric("other", "التأمين والمصاريف الأخرى", "Insurance and other costs", 650), numeric("distance", "المسافة المقطوعة km", "Distance driven km", 12000, 1)],
    calculate: (v) => { const fuel = n(v, "fuel"), maintenance = n(v, "maintenance"), other = n(v, "other"), distance = n(v, "distance"); if (!ok(fuel, maintenance, other, distance) || fuel < 0 || maintenance < 0 || other < 0 || distance <= 0) return { results: [], error: "invalid" }; const total = fuel + maintenance + other; return { results: [metric(total, "إجمالي التكاليف", "Total costs"), metric(total / distance, "التكلفة لكل كيلومتر", "Cost per kilometer"), metric((total / distance) * 100, "التكلفة لكل 100 كم", "Cost per 100 km")] }; },
    noteAr: "استخدم تكاليف ومسافة من الفترة الزمنية نفسها للحصول على نتيجة صحيحة.", noteEn: "Use costs and distance from the same period for a valid result.",
  },
  "installment-comparison": {
    fields: [numeric("aDown", "دفعة العرض الأول", "Offer A down payment", 500), numeric("aPayment", "قسط العرض الأول", "Offer A payment", 200), numeric("aMonths", "أشهر العرض الأول", "Offer A months", 24, 1, "1"), numeric("aFees", "رسوم العرض الأول", "Offer A fees", 50), numeric("bDown", "دفعة العرض الثاني", "Offer B down payment", 250), numeric("bPayment", "قسط العرض الثاني", "Offer B payment", 215), numeric("bMonths", "أشهر العرض الثاني", "Offer B months", 24, 1, "1"), numeric("bFees", "رسوم العرض الثاني", "Offer B fees", 25)],
    calculate: (v) => { const a = n(v, "aDown") + n(v, "aPayment") * n(v, "aMonths") + n(v, "aFees"), b = n(v, "bDown") + n(v, "bPayment") * n(v, "bMonths") + n(v, "bFees"); if (!["aDown", "aPayment", "aMonths", "aFees", "bDown", "bPayment", "bMonths", "bFees"].every((key) => Number.isFinite(n(v, key)) && n(v, key) >= 0) || n(v, "aMonths") <= 0 || n(v, "bMonths") <= 0) return { results: [], error: "invalid" }; return { results: [metric(a, "إجمالي العرض الأول", "Offer A total"), metric(b, "إجمالي العرض الثاني", "Offer B total"), metric(Math.abs(a - b), "فرق التكلفة", "Cost difference"), metric(a === b ? "متساويان" : a < b ? "الأول" : "الثاني", "الأقل إجمالاً", "Lower total")] }; },
    noteAr: "النتيجة تقارن الإجمالي فقط ولا تقدم توصية تمويلية.", noteEn: "The result compares totals only and is not financial advice.",
  },
  "storage-estimator": {
    fields: [numeric("photos", "عدد الصور", "Photos", 15000, 0, "1"), numeric("photoSize", "متوسط حجم الصورة MB", "Average photo MB", 4), numeric("videos", "عدد الفيديوهات", "Videos", 500, 0, "1"), numeric("videoSize", "متوسط حجم الفيديو MB", "Average video MB", 250)],
    calculate: (v) => { const photos = n(v, "photos"), photoSize = n(v, "photoSize"), videos = n(v, "videos"), videoSize = n(v, "videoSize"); if (!ok(photos, photoSize, videos, videoSize) || [photos, photoSize, videos, videoSize].some((x) => x < 0)) return { results: [], error: "invalid" }; const mb = photos * photoSize + videos * videoSize; return { results: [metric(mb, "المساحة بالميجابايت", "Storage MB", " MB"), metric(mb / 1024, "المساحة بالجيجابايت", "Storage GB", " GB"), metric(mb / 1024 / 1024, "المساحة بالتيرابايت", "Storage TB", " TB")] }; },
    noteAr: "النتيجة تقديرية؛ الأحجام الفعلية تختلف حسب الدقة والضغط والصيغة.", noteEn: "This is an estimate; actual sizes vary by resolution, compression, and format.",
  },
  "parking-cost-calculator": {
    fields: [numeric("minutes", "مدة الوقوف بالدقائق", "Parking duration minutes", 150, 0, "1"), numeric("free", "الفترة المجانية بالدقائق", "Free minutes", 15, 0, "1"), numeric("hourly", "سعر الساعة", "Hourly rate", 3), numeric("entry", "رسم دخول ثابت", "Fixed entry fee", 0)],
    calculate: (v) => { const minutes = n(v, "minutes"), free = n(v, "free"), hourly = n(v, "hourly"), entry = n(v, "entry"); if (!ok(minutes, free, hourly, entry) || [minutes, free, hourly, entry].some((x) => x < 0)) return { results: [], error: "invalid" }; const billable = Math.max(0, minutes - free), hours = Math.ceil(billable / 60); return { results: [metric(billable, "الدقائق المدفوعة", "Billable minutes"), metric(hours, "الساعات المحتسبة", "Charged hours"), metric(entry + hours * hourly, "تكلفة الوقوف", "Parking cost")] }; },
    noteAr: "تُقرّب كل ساعة مدفوعة إلى الأعلى؛ غيّر المدخلات إذا كانت التسعيرة تجزئ الساعة.", noteEn: "Each billed hour is rounded up; adjust inputs if the lot prorates partial hours.",
  },
  "battery-runtime-calculator": {
    fields: [numeric("capacity", "طاقة البطارية Wh", "Battery energy Wh", 74), numeric("power", "استهلاك الجهاز W", "Device draw W", 15), numeric("efficiency", "الكفاءة %", "Efficiency %", 85, 1, "any")],
    calculate: (v) => { const capacity = n(v, "capacity"), power = n(v, "power"), efficiency = n(v, "efficiency"); if (!ok(capacity, power, efficiency) || capacity < 0 || power <= 0 || efficiency <= 0 || efficiency > 100) return { results: [], error: "invalid" }; const hours = (capacity * efficiency / 100) / power; return { results: [metric(hours, "مدة التشغيل بالساعات", "Runtime hours"), metric(hours * 60, "مدة التشغيل بالدقائق", "Runtime minutes"), metric(capacity * efficiency / 100, "الطاقة القابلة للاستخدام", "Usable energy", " Wh")] }; },
    noteAr: "استخدم Wh عندما تكون متاحة؛ النتيجة تقريبية لأن الاستهلاك قد يتغير أثناء التشغيل.", noteEn: "Use Wh when available; runtime is approximate because device draw can change.",
  },
  "power-bank-calculator": {
    fields: [numeric("bank", "سعة Power Bank mAh", "Power bank mAh", 20000), numeric("phone", "سعة بطارية الهاتف mAh", "Phone battery mAh", 5000), numeric("efficiency", "الكفاءة %", "Efficiency %", 75, 1)],
    calculate: (v) => { const bank = n(v, "bank"), phone = n(v, "phone"), efficiency = n(v, "efficiency"); if (!ok(bank, phone, efficiency) || bank < 0 || phone <= 0 || efficiency <= 0 || efficiency > 100) return { results: [], error: "invalid" }; const usable = bank * efficiency / 100; return { results: [metric(usable, "السعة الفعلية التقريبية", "Approximate usable capacity", " mAh"), metric(usable / phone, "عدد الشحنات التقريبي", "Approximate charges"), metric((usable % phone) / phone * 100, "المتبقي بعد الشحنات الكاملة", "Remainder after full charges", "%")] }; },
    noteAr: "اختلاف الجهد والحرارة والكابل يؤثر في العدد الفعلي للشحنات.", noteEn: "Voltage conversion, temperature, and cable quality affect actual charges.",
  },
  "aspect-ratio-calculator": {
    fields: [numeric("width", "العرض الأصلي", "Original width", 1920, 1), numeric("height", "الارتفاع الأصلي", "Original height", 1080, 1), numeric("newWidth", "العرض الجديد", "New width", 1280, 1)],
    calculate: (v) => { const width = n(v, "width"), height = n(v, "height"), next = n(v, "newWidth"); if (!ok(width, height, next) || width <= 0 || height <= 0 || next <= 0) return { results: [], error: "invalid" }; const gcd = (a: number, b: number): number => b ? gcd(b, a % b) : a; const divisor = gcd(Math.round(width), Math.round(height)); return { results: [metric(`${Math.round(width / divisor)}:${Math.round(height / divisor)}`, "نسبة الأبعاد", "Aspect ratio"), metric((next * height) / width, "الارتفاع المقابل", "Matching height"), metric((width * height) / 1_000_000, "الدقة الأصلية", "Original megapixels", " MP")] }; },
    noteAr: "غيّر العرض الجديد لتحصل على الارتفاع الذي يحافظ على النسبة الأصلية.", noteEn: "Change the new width to get the height that preserves the original ratio.",
  },
  "delivery-cost-calculator": {
    fields: [numeric("base", "السعر الأساسي", "Base price", 5), numeric("distance", "المسافة km", "Distance km", 12), numeric("perKm", "السعر لكل km", "Price per km", 1.25), numeric("extras", "إضافات", "Extras", 2)],
    calculate: (v) => { const base = n(v, "base"), distance = n(v, "distance"), perKm = n(v, "perKm"), extras = n(v, "extras"); if (!ok(base, distance, perKm, extras) || [base, distance, perKm, extras].some((x) => x < 0)) return { results: [], error: "invalid" }; return { results: [metric(distance * perKm, "تكلفة المسافة", "Distance cost"), metric(base + distance * perKm + extras, "التكلفة الكلية", "Total delivery cost"), metric(base + extras, "الرسوم غير المرتبطة بالمسافة", "Non-distance fees")] }; },
    noteAr: "أدخل أي رسوم انتظار أو طلب سريع ضمن الإضافات.", noteEn: "Put waiting or express-delivery charges under extras.",
  },
  "depreciation-calculator": {
    fields: [numeric("cost", "سعر الأصل", "Asset cost", 12000), numeric("residual", "القيمة المتبقية", "Residual value", 2000), numeric("years", "العمر الافتراضي بالسنوات", "Useful life years", 5, 1, "1"), numeric("elapsed", "سنوات الاستخدام", "Years elapsed", 2, 0, "any")],
    calculate: (v) => { const cost = n(v, "cost"), residual = n(v, "residual"), years = n(v, "years"), elapsed = n(v, "elapsed"); if (!ok(cost, residual, years, elapsed) || cost < 0 || residual < 0 || residual > cost || years <= 0 || elapsed < 0) return { results: [], error: "invalid" }; const annual = (cost - residual) / years, used = Math.min(years, elapsed); return { results: [metric(annual, "الإهلاك السنوي", "Annual depreciation"), metric(annual / 12, "الإهلاك الشهري", "Monthly depreciation"), metric(Math.max(residual, cost - annual * used), "القيمة الدفترية الحالية", "Current book value")] }; },
    noteAr: "تستخدم الأداة طريقة الإهلاك الخطي فقط.", noteEn: "This tool uses straight-line depreciation only.",
  },
  "reorder-point-calculator": {
    fields: [numeric("daily", "متوسط الاستهلاك اليومي", "Average daily demand", 15), numeric("lead", "مدة التوريد بالأيام", "Lead time days", 8, 0, "1"), numeric("safety", "مخزون الأمان", "Safety stock", 40)],
    calculate: (v) => { const daily = n(v, "daily"), lead = n(v, "lead"), safety = n(v, "safety"); if (!ok(daily, lead, safety) || [daily, lead, safety].some((x) => x < 0)) return { results: [], error: "invalid" }; return { results: [metric(daily * lead, "استهلاك فترة التوريد", "Lead-time demand"), metric(daily * lead + safety, "نقطة إعادة الطلب", "Reorder point"), metric(safety / Math.max(daily, 0.0001), "أيام يغطيها مخزون الأمان", "Safety-stock days")] }; },
    noteAr: "اطلب عند وصول الرصيد إلى نقطة إعادة الطلب أو قبلها حسب تقلب الطلب.", noteEn: "Reorder when stock reaches this point, adjusting for demand variability.",
  },
  "inventory-balance-calculator": {
    fields: [numeric("opening", "مخزون البداية", "Opening stock", 500), numeric("inbound", "الداخل", "Inbound", 120), numeric("outbound", "الخارج", "Outbound", 260)],
    calculate: (v) => { const opening = n(v, "opening"), inbound = n(v, "inbound"), outbound = n(v, "outbound"); if (!ok(opening, inbound, outbound) || [opening, inbound, outbound].some((x) => x < 0)) return { results: [], error: "invalid" }; const available = opening + inbound; return { results: [metric(available, "المتاح قبل الصرف", "Available before issue"), metric(available - outbound, "الرصيد النهائي", "Closing stock"), metric(outbound, "إجمالي الخارج", "Total outbound")] }; },
    noteAr: "حساب جلسة واحدة داخل المتصفح ولا يغيّر أي نظام مخزون خارجي.", noteEn: "A one-session local calculation that does not change any external inventory system.",
  },
  "shipping-volume-calculator": {
    fields: [numeric("length", "الطول cm", "Length cm", 60), numeric("width", "العرض cm", "Width cm", 40), numeric("height", "الارتفاع cm", "Height cm", 35), numeric("actual", "الوزن الفعلي kg", "Actual weight kg", 12), numeric("divisor", "معامل الوزن الحجمي", "Volumetric divisor", 5000, 1)],
    calculate: (v) => { const length = n(v, "length"), width = n(v, "width"), height = n(v, "height"), actual = n(v, "actual"), divisor = n(v, "divisor"); if (!ok(length, width, height, actual, divisor) || length <= 0 || width <= 0 || height <= 0 || actual < 0 || divisor <= 0) return { results: [], error: "invalid" }; const volume = length * width * height, volumetric = volume / divisor; return { results: [metric(volume / 1_000_000, "حجم الصندوق", "Box volume", " m³"), metric(volumetric, "الوزن الحجمي", "Volumetric weight", " kg"), metric(Math.max(actual, volumetric), "الوزن القابل للفوترة", "Billable weight", " kg")] }; },
    noteAr: "استخدم معامل شركة الشحن لأن المعامل يختلف بين الشركات والخدمات.", noteEn: "Use the carrier's divisor because it differs by carrier and service.",
  },
  "box-count-calculator": {
    fields: [numeric("items", "عدد العناصر", "Items", 125, 0, "1"), numeric("capacity", "سعة الصندوق", "Items per box", 24, 1, "1")],
    calculate: (v) => { const items = n(v, "items"), capacity = n(v, "capacity"); if (!ok(items, capacity) || items < 0 || capacity <= 0) return { results: [], error: "invalid" }; const boxes = Math.ceil(items / capacity); return { results: [metric(boxes, "الصناديق المطلوبة", "Boxes required"), metric(Math.floor(items / capacity), "الصناديق الممتلئة", "Full boxes"), metric(boxes * capacity - items, "السعة الفارغة", "Unused capacity")] }; },
    noteAr: "يُقرب عدد الصناديق إلى الأعلى حتى تتسع لجميع العناصر.", noteEn: "Box count is rounded up so every item fits.",
  },
  "mixing-ratio-calculator": {
    fields: [numeric("a", "الجزء الأول", "First ratio part", 1, 0), numeric("b", "الجزء الثاني", "Second ratio part", 3, 0), numeric("total", "الحجم النهائي", "Final amount", 1000, 0)],
    calculate: (v) => { const a = n(v, "a"), b = n(v, "b"), total = n(v, "total"), sum = a + b; if (!ok(a, b, total) || a < 0 || b < 0 || total < 0 || sum <= 0) return { results: [], error: "invalid" }; return { results: [metric(total * a / sum, "كمية المكوّن الأول", "First component"), metric(total * b / sum, "كمية المكوّن الثاني", "Second component"), metric(`${fmt(a)}:${fmt(b)}`, "النسبة", "Ratio")] }; },
    noteAr: "أداة رياضيات عامة للنسب وليست لتحديد جرعات طبية.", noteEn: "A general ratio calculator, not for medical dosing.",
  },
  "commission-calculator": {
    fields: [numeric("sales", "قيمة المبيعات", "Sales value", 10000), numeric("rate", "نسبة العمولة %", "Commission %", 5), numeric("fixed", "مكافأة ثابتة", "Fixed bonus", 0)],
    calculate: (v) => { const sales = n(v, "sales"), rate = n(v, "rate"), fixed = n(v, "fixed"); if (!ok(sales, rate, fixed) || sales < 0 || rate < 0 || fixed < 0) return { results: [], error: "invalid" }; const variable = sales * rate / 100; return { results: [metric(variable, "العمولة النسبية", "Percentage commission"), metric(fixed, "المكافأة الثابتة", "Fixed bonus"), metric(variable + fixed, "إجمالي المستحق", "Total commission")] }; },
    noteAr: "أدخل النسبة والمكافأة كما هي محددة في اتفاقك.", noteEn: "Enter the rate and bonus exactly as defined in your agreement.",
  },
  "platform-fee-calculator": {
    fields: [numeric("sale", "سعر البيع", "Sale price", 100), numeric("rate", "نسبة العمولة %", "Fee %", 5), numeric("fixed", "رسم ثابت", "Fixed fee", 1)],
    calculate: (v) => { const sale = n(v, "sale"), rate = n(v, "rate"), fixed = n(v, "fixed"); if (!ok(sale, rate, fixed) || sale < 0 || rate < 0 || fixed < 0) return { results: [], error: "invalid" }; const fees = sale * rate / 100 + fixed; return { results: [metric(sale * rate / 100, "الرسوم النسبية", "Percentage fee"), metric(fees, "إجمالي الرسوم", "Total fees"), metric(sale - fees, "الصافي", "Net amount")] }; },
    noteAr: "حاسبة عامة؛ تحقق من الضرائب والرسوم الأخرى التي قد تطبقها المنصة.", noteEn: "A general calculator; check any taxes or other platform charges.",
  },
  "target-sale-price-calculator": {
    fields: [numeric("net", "الصافي المطلوب", "Target net amount", 50), numeric("rate", "نسبة الرسوم %", "Fee %", 5), numeric("fixed", "رسم ثابت", "Fixed fee", 1)],
    calculate: (v) => { const net = n(v, "net"), rate = n(v, "rate"), fixed = n(v, "fixed"); if (!ok(net, rate, fixed) || net < 0 || rate < 0 || rate >= 100 || fixed < 0) return { results: [], error: "invalid" }; const price = (net + fixed) / (1 - rate / 100), fees = price - net; return { results: [metric(price, "سعر البيع المطلوب", "Required sale price", "", "money"), metric(fees, "الرسوم المتوقعة", "Expected fees", "", "money"), metric(net, "الصافي المستهدف", "Target net", "", "money")] }; },
    noteAr: "لا تشمل النتيجة ضرائب أو رسوماً غير مدخلة.", noteEn: "The result excludes taxes or fees not entered.",
  },
  "stock-runout-calculator": {
    fields: [numeric("stock", "الكمية الحالية", "Current stock", 450), numeric("daily", "الاستهلاك اليومي", "Daily use", 15, 0.0001)],
    calculate: (v) => { const stock = n(v, "stock"), daily = n(v, "daily"); if (!ok(stock, daily) || stock < 0 || daily <= 0) return { results: [], error: "invalid" }; const days = stock / daily, end = today(); end.setDate(end.getDate() + Math.ceil(days)); return { results: [metric(days, "أيام حتى النفاد", "Days until empty"), metric(Math.ceil(days), "الأيام المقربة", "Rounded days"), metric(dateText(end), "تاريخ النفاد التقريبي — 00:00", "Estimated runout date — 00:00")] }; },
    noteAr: "يبدأ حساب التاريخ من بداية اليوم الحالي 00:00.", noteEn: "The date calculation starts at 00:00 today.",
  },
  "prorated-rent-calculator": {
    fields: [numeric("rent", "إيجار الشهر", "Monthly rent", 1200), numeric("days", "أيام الشهر", "Days in month", 30, 1, "1"), numeric("occupied", "أيام الإقامة", "Occupied days", 16, 0, "1")],
    calculate: (v) => { const rent = n(v, "rent"), days = n(v, "days"), occupied = n(v, "occupied"); if (!ok(rent, days, occupied) || rent < 0 || days <= 0 || occupied < 0 || occupied > days) return { results: [], error: "invalid" }; return { results: [metric(rent / days, "الإيجار اليومي", "Daily rent"), metric(rent * occupied / days, "الإيجار النسبي", "Prorated rent"), metric(rent - rent * occupied / days, "الجزء غير المستخدم", "Unused portion")] }; },
    noteAr: "حدد ما إذا كان يوم الدخول والخروج يُحسب وفق الاتفاق قبل إدخال عدد الأيام.", noteEn: "Decide how move-in and move-out days are counted under the agreement.",
  },
  "printer-cost-calculator": {
    fields: [numeric("pages", "عدد الصفحات", "Pages", 1000, 0, "1"), numeric("yield", "سعة الخرطوشة بالصفحات", "Cartridge yield pages", 2500, 1, "1"), numeric("price", "سعر الخرطوشة", "Cartridge price", 65)],
    calculate: (v) => { const pages = n(v, "pages"), yieldPages = n(v, "yield"), price = n(v, "price"); if (!ok(pages, yieldPages, price) || pages < 0 || yieldPages <= 0 || price < 0) return { results: [], error: "invalid" }; const perPage = price / yieldPages; return { results: [metric(perPage, "تكلفة الصفحة", "Cost per page"), metric(pages * perPage, "تكلفة العدد المطلوب", "Requested pages cost"), metric(Math.ceil(pages / yieldPages), "الخراطيش اللازمة نظرياً", "Theoretical cartridges")] }; },
    noteAr: "لا تشمل الورق والكهرباء والصيانة إلا إذا أضفتها إلى سعر الصفحة لاحقاً.", noteEn: "Excludes paper, power, and maintenance unless added separately.",
  },
  "printing-cost-calculator": {
    fields: [numeric("bw", "صفحات أبيض وأسود", "Black-and-white pages", 80, 0, "1"), numeric("bwRate", "سعر الصفحة الأسود", "B&W price per page", 0.08), numeric("color", "صفحات ملونة", "Color pages", 20, 0, "1"), numeric("colorRate", "سعر الصفحة الملونة", "Color price per page", 0.45), numeric("copies", "عدد النسخ", "Copies", 2, 1, "1")],
    calculate: (v) => { const bw = n(v, "bw"), bwRate = n(v, "bwRate"), color = n(v, "color"), colorRate = n(v, "colorRate"), copies = n(v, "copies"); if (![bw, bwRate, color, colorRate, copies].every(Number.isFinite) || [bw, bwRate, color, colorRate].some((x) => x < 0) || copies <= 0) return { results: [], error: "invalid" }; const one = bw * bwRate + color * colorRate; return { results: [metric(one, "تكلفة النسخة الواحدة", "One-copy cost"), metric(one * copies, "التكلفة الكلية", "Total cost"), metric((bw + color) * copies, "إجمالي الصفحات", "Total pages")] }; },
    noteAr: "تُحسب الصفحات الملونة والسوداء كلٌ بسعرها ثم تضرب بعدد النسخ.", noteEn: "Color and black-and-white pages use separate rates, then multiply by copies.",
  },
  "device-age-cost-calculator": {
    fields: [numeric("price", "سعر الجهاز", "Device price", 900), { key: "date", ar: "تاريخ الشراء — 00:00", en: "Purchase date — 00:00", value: "2024-01-01", type: "date" }],
    calculate: (v, now = new Date()) => { const result = deviceAgeCost(n(v, "price"), v.date, now); return !result ? { results: [], error: "invalid" } : { results: [metric(result.days, "عمر الجهاز بالأيام", "Device age days"), metric(result.months, "العمر بالأشهر", "Device age months"), metric(result.costPerDay, "التكلفة لكل يوم", "Cost per day")] }; },
    noteAr: "يبدأ تاريخ الشراء واليوم الحالي من الساعة 00:00 لتجنب اختلاف الساعات.", noteEn: "Purchase date and today both start at 00:00 to avoid partial-day differences.",
  },
  "repair-replace-comparison": {
    fields: [numeric("repair", "تكلفة الإصلاح", "Repair cost", 250), numeric("repairLife", "العمر المتوقع بعد الإصلاح بالأشهر", "Expected repair life months", 18, 1), numeric("replace", "تكلفة البديل", "Replacement cost", 900), numeric("replaceLife", "عمر البديل المتوقع بالأشهر", "Replacement life months", 48, 1)],
    calculate: (v) => { const repair = n(v, "repair"), repairLife = n(v, "repairLife"), replace = n(v, "replace"), replaceLife = n(v, "replaceLife"); if (!ok(repair, repairLife, replace, replaceLife) || repair < 0 || replace < 0 || repairLife <= 0 || replaceLife <= 0) return { results: [], error: "invalid" }; const repairMonthly = repair / repairLife, replaceMonthly = replace / replaceLife; return { results: [metric(repairMonthly, "تكلفة الإصلاح لكل شهر", "Repair cost per month"), metric(replaceMonthly, "تكلفة البديل لكل شهر", "Replacement cost per month"), metric(Math.abs(repairMonthly - replaceMonthly), "فرق التكلفة الشهرية", "Monthly cost difference")] }; },
    noteAr: "تعرض الأداة أرقاماً فقط ولا تقرر نيابة عن المستخدم.", noteEn: "The tool shows numeric comparison only and makes no decision for the user.",
  },
  "tv-size-calculator": {
    fields: [numeric("diagonal", "قطر الشاشة بالبوصة", "Diagonal inches", 65, 1), numeric("ratioW", "جزء العرض", "Ratio width", 16, 1), numeric("ratioH", "جزء الارتفاع", "Ratio height", 9, 1)],
    calculate: (v) => { const diagonal = n(v, "diagonal"), rw = n(v, "ratioW"), rh = n(v, "ratioH"); if (!ok(diagonal, rw, rh) || diagonal <= 0 || rw <= 0 || rh <= 0) return { results: [], error: "invalid" }; const factor = diagonal / Math.hypot(rw, rh), width = factor * rw, height = factor * rh; return { results: [metric(width * 2.54, "العرض", "Width", " cm"), metric(height * 2.54, "الارتفاع", "Height", " cm"), metric(width * height * 6.4516, "مساحة الشاشة", "Screen area", " cm²")] }; },
    noteAr: "المقاس التجاري هو القطر؛ العرض والارتفاع الفعليان يعتمدان على نسبة الأبعاد.", noteEn: "Commercial size is diagonal; physical width and height depend on aspect ratio.",
  },
  "viewing-distance-calculator": {
    fields: [numeric("diagonal", "حجم الشاشة بالبوصة", "Screen inches", 65, 1), numeric("min", "معامل المسافة الدنيا", "Minimum multiplier", 1.2, 0.1), numeric("max", "معامل المسافة المريحة", "Comfort multiplier", 1.6, 0.1)],
    calculate: (v) => { const diagonal = n(v, "diagonal"), min = n(v, "min"), max = n(v, "max"); if (!ok(diagonal, min, max) || diagonal <= 0 || min <= 0 || max < min) return { results: [], error: "invalid" }; return { results: [metric(diagonal * min * 2.54 / 100, "المسافة الدنيا", "Minimum distance", " m"), metric(diagonal * max * 2.54 / 100, "المسافة المريحة", "Comfort distance", " m"), metric((diagonal * (min + max) / 2) * 2.54 / 100, "المتوسط", "Average", " m")] }; },
    noteAr: "المعاملات يحددها المستخدم حسب الدقة والمعيار الذي يتبعه.", noteEn: "Set multipliers according to screen resolution and your chosen standard.",
  },
  "ppi-calculator": {
    fields: [numeric("width", "الدقة الأفقية px", "Horizontal pixels", 2560, 1), numeric("height", "الدقة العمودية px", "Vertical pixels", 1440, 1), numeric("diagonal", "قطر الشاشة inch", "Screen diagonal inches", 27, 0.1)],
    calculate: (v) => { const width = n(v, "width"), height = n(v, "height"), diagonal = n(v, "diagonal"); if (!ok(width, height, diagonal) || width <= 0 || height <= 0 || diagonal <= 0) return { results: [], error: "invalid" }; const ppi = Math.hypot(width, height) / diagonal; return { results: [metric(ppi, "كثافة البكسلات", "Pixel density", " PPI"), metric(25.4 / ppi, "حجم البكسل", "Pixel pitch", " mm"), metric((width * height) / 1_000_000, "إجمالي الدقة", "Megapixels", " MP")] }; },
    noteAr: "PPI تقيس عدد البكسلات لكل بوصة من الشاشة.", noteEn: "PPI measures pixels per inch of physical screen size.",
  },
  "print-resolution-calculator": {
    fields: [numeric("width", "عرض الصورة px", "Image width px", 3000, 1), numeric("height", "ارتفاع الصورة px", "Image height px", 2400, 1), numeric("dpi", "دقة الطباعة DPI", "Print DPI", 300, 1)],
    calculate: (v) => { const width = n(v, "width"), height = n(v, "height"), dpi = n(v, "dpi"); if (!ok(width, height, dpi) || width <= 0 || height <= 0 || dpi <= 0) return { results: [], error: "invalid" }; return { results: [metric(width / dpi, "عرض الطباعة", "Print width", " in"), metric(height / dpi, "ارتفاع الطباعة", "Print height", " in"), metric(width / dpi * 2.54, "العرض بالسنتيمتر", "Width centimeters", " cm"), metric(height / dpi * 2.54, "الارتفاع بالسنتيمتر", "Height centimeters", " cm")] }; },
    noteAr: "كلما ارتفع DPI صغر حجم الطباعة مع بقاء عدد البكسلات ثابتاً.", noteEn: "Higher DPI reduces physical print size for the same pixel dimensions.",
  },
  "sample-size-calculator": {
    fields: [numeric("z", "قيمة Z لمستوى الثقة", "Z value", 1.96, 0.1), numeric("p", "النسبة المتوقعة %", "Expected proportion %", 50, 0, "any"), numeric("margin", "هامش الخطأ %", "Margin of error %", 5, 0.1)],
    calculate: (v) => { const z = n(v, "z"), p = n(v, "p") / 100, margin = n(v, "margin") / 100; if (!ok(z, p, margin) || z <= 0 || p < 0 || p > 1 || margin <= 0) return { results: [], error: "invalid" }; const size = Math.ceil((z ** 2 * p * (1 - p)) / margin ** 2); return { results: [metric(size, "حجم العينة التقريبي", "Approximate sample size"), metric(z, "قيمة Z", "Z value"), metric(margin * 100, "هامش الخطأ", "Margin of error", "%")] }; },
    noteAr: "معادلة مبسطة لمجتمع كبير وعينة عشوائية؛ على الباحث مراجعة افتراضات دراسته.", noteEn: "A simplified large-population random-sample formula; verify assumptions for your study.",
  },
  "margin-of-error-calculator": {
    fields: [numeric("sample", "حجم العينة", "Sample size", 385, 1, "1"), numeric("z", "قيمة Z", "Z value", 1.96, 0.1), numeric("p", "النسبة المتوقعة %", "Expected proportion %", 50, 0, "any")],
    calculate: (v) => { const sample = n(v, "sample"), z = n(v, "z"), p = n(v, "p") / 100; if (!ok(sample, z, p) || sample <= 0 || z <= 0 || p < 0 || p > 1) return { results: [], error: "invalid" }; const margin = z * Math.sqrt(p * (1 - p) / sample) * 100; return { results: [metric(margin, "هامش الخطأ", "Margin of error", "%"), metric(sample, "حجم العينة", "Sample size"), metric(p * 100, "النسبة المستخدمة", "Proportion used", "%")] }; },
    noteAr: "الحساب تقريبي ولا يشمل تصحيح حجم المجتمع أو تصميم العينات المعقد.", noteEn: "Approximate only; excludes finite-population correction and complex sampling design.",
  },
};

export const formulaToolSlugs = Object.keys(formulaDefinitions);

export function FormulaToolWorkspace({ slug }: { slug: string }) {
  const { t, locale } = useLocale();
  const formula = formulaDefinitions[slug];
  const [values, setValues] = useState<Record<string, string>>(() =>
    Object.fromEntries(formula.fields.map((field) => [field.key, field.value])),
  );
  const [currency, setCurrency] = useState("SAR");
  const [calculationNow, setCalculationNow] = useState<Date | null>(null);
  const waitsForClientDate = slug === "device-age-cost-calculator" && calculationNow === null;
  useEffect(() => {
    if (slug !== "device-age-cost-calculator") return;
    queueMicrotask(() => setCalculationNow(new Date()));
  }, [slug]);
  const output = useMemo(
    () => waitsForClientDate ? { results: [] } : formula.calculate(values, calculationNow || undefined),
    [calculationNow, formula, values, waitsForClientDate],
  );
  const currencyOptions = [
    { value: "SAR", label: t("ريال سعودي (SAR)", "Saudi riyal (SAR)") },
    { value: "USD", label: t("دولار أمريكي (USD)", "US dollar (USD)") },
    { value: "IQD", label: t("دينار عراقي (IQD)", "Iraqi dinar (IQD)") },
    { value: "AED", label: t("درهم إماراتي (AED)", "UAE dirham (AED)") },
    { value: "EUR", label: t("يورو (EUR)", "Euro (EUR)") },
  ];
  const displayValue = (item: Result) =>
    item.kind === "money" ? `${item.value} ${currency}` : item.value;
  function updateFieldValue(fieldKey: string, value: string) {
    setValues((previous) => ({ ...previous, [fieldKey]: value }));
  }
  function handleFieldChange(fieldKey: string, event: ChangeEvent<HTMLInputElement>) {
    const value = event.currentTarget.value;
    updateFieldValue(fieldKey, value);
  }
  return (
    <div className="workspace-stack">
      {output.results.some((item) => item.kind === "money") && (
        <div className="field currency-field">
          <label>{t("العملة", "Currency")}</label>
          <CustomSelect
            value={currency}
            onChange={setCurrency}
            label={t("اختر وحدة العملة", "Choose currency unit")}
            options={currencyOptions}
          />
        </div>
      )}
      <div className="form-grid">
        {formula.fields.map((field) => {
          const inputId = `formula-${slug}-${field.key}`;
          const label = t(field.ar, field.en);
          return (
          <div className="field" key={field.key}>
            <label htmlFor={field.type === "select" ? undefined : inputId}>{label}</label>
            {field.type === "select" ? (
              <CustomSelect
                value={values[field.key]}
                onChange={(value) => updateFieldValue(field.key, value)}
                label={label}
                options={(field.options || []).map((option) => ({ value: option.value, label: locale === "en" ? option.en : option.ar }))}
              />
            ) : (
              <input
                id={inputId}
                type={field.type === "date" ? "date" : "number"}
                min={field.min}
                step={field.step || "any"}
                value={values[field.key]}
                aria-label={label}
                onChange={(event) => handleFieldChange(field.key, event)}
              />
            )}
          </div>
        )})}
      </div>
      {waitsForClientDate ? (
        <div className="notice" role="status">{t("جاري تهيئة تاريخ الحساب…", "Preparing the calculation date…")}</div>
      ) : output.error ? (
        <div className="error-notice">{t("تحقق من المدخلات؛ يجب أن تكون القيم صالحة وأكبر من الحدود المطلوبة.", "Check the inputs; values must be valid and within the required limits.")}</div>
      ) : (
        <>
          <div className="metric-grid">
            {output.results.map((item) => <div key={item.ar}><strong>{displayValue(item)}</strong><span>{t(item.ar, item.en)}</span></div>)}
          </div>
          <button
            type="button"
            className="secondary-button result-copy-button"
            onClick={(event) => copyWithFeedback(
              output.results.map((item) => `${t(item.ar, item.en)}: ${displayValue(item)}`).join("\n"),
              event.currentTarget,
            )}
          >
            <Icon name="copy" size={17} /> {t("نسخ النتائج", "Copy results")}
          </button>
        </>
      )}
      <p className="workspace-tip"><Icon name="calculator" size={18} /><span>{t(formula.noteAr, formula.noteEn)}</span></p>
    </div>
  );
}
