"use client";

import { useEffect, useState } from "react";
import { toolMap } from "@/lib/registry";
import { getFavorites } from "./FavoriteButton";
import { ToolCard } from "./Cards";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";

export function FavoritesGrid(){const {t}=useLocale();const [slugs,setSlugs]=useState<string[]>([]);useEffect(()=>{const update=()=>setSlugs(getFavorites());queueMicrotask(update);window.addEventListener("minjaz-favorites",update);return()=>window.removeEventListener("minjaz-favorites",update)},[]);const items=slugs.map((slug)=>toolMap[slug]).filter(Boolean);if(!items.length)return <div className="empty-state panel"><Icon name="star" size={40}/><h2>{t("لا توجد أدوات مفضلة بعد","No favorite tools yet")}</h2><p>{t("اضغط علامة النجمة داخل أي أداة لتجدها هنا بسرعة.","Tap the star on any tool to find it here quickly.")}</p></div>;return <div className="all-tools-grid">{items.map((item)=><ToolCard key={item.slug} tool={item}/>)}</div>}
