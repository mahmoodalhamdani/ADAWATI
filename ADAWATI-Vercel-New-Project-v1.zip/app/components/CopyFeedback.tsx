"use client";

import { useEffect, useRef, useState } from "react";
import { useLocale } from "./LocaleProvider";
import { Icon } from "./Icon";

export function CopyFeedback() {
  const { t } = useLocale();
  const [state, setState] = useState<"hidden" | "copy" | "download" | "error">("hidden");
  const timer = useRef<number | null>(null);
  useEffect(() => {
    const show = (event: Event) => {
      const ok = Boolean((event as CustomEvent<{ ok?: boolean }>).detail?.ok);
      setState(ok ? "copy" : "error");
      if (timer.current) window.clearTimeout(timer.current);
      timer.current = window.setTimeout(() => setState("hidden"), 1800);
    };
    const showDownload = () => {
      setState("download");
      if (timer.current) window.clearTimeout(timer.current);
      timer.current = window.setTimeout(() => setState("hidden"), 1800);
    };
    window.addEventListener("minjaz-copy-feedback", show);
    window.addEventListener("minjaz-download-feedback", showDownload);
    return () => {
      window.removeEventListener("minjaz-copy-feedback", show);
      window.removeEventListener("minjaz-download-feedback", showDownload);
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, []);
  return (
    <div className={`copy-feedback-toast ${state !== "hidden" ? "is-visible" : ""} ${state === "error" ? "is-error" : ""}`} role="status" aria-live="polite">
      <Icon name={state === "error" ? "x" : "check"} size={19} />
      <span>{state === "error" ? t("تعذر النسخ", "Could not copy") : state === "download" ? t("تم تجهيز التحميل بنجاح", "Download prepared successfully") : t("تم النسخ بنجاح", "Copied successfully")}</span>
    </div>
  );
}
