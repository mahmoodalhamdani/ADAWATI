/* eslint-disable @next/next/no-img-element */
"use client";

import { useMemo, useState } from "react";
import QRCode from "qrcode";
import { copyWithFeedback } from "@/lib/copy-feedback";
import {
  buildQrPayload,
  colorContrast,
  emptyQrFields,
  getQrCardLayout,
  qrCardFormats,
  qrCardTemplates,
  qrColorFamilies,
  qrGradientPresets,
  qrPlatformCategories,
  qrPlatforms,
  qrPresetIcons,
  qrPurposes,
  qrShapes,
  type QrPlatform,
  type QrPurposeId,
  type QrStudioFields,
} from "@/lib/qr-studio";
import { CustomSelect } from "./CustomSelect";
import { FileUploadZone } from "./FileUploadZone";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";
import { ModernDatePicker } from "./ModernDatePicker";
import { brandIconDataUrl, getBrandIcon } from "@/lib/brand-icons";

type StudioPanel = "content" | "style" | "color" | "image";
type ImageMode = "content" | "preset" | "upload" | "none";
type ColorSource = "template" | "palette" | "custom";

function roundedRect(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
) {
  const safe = Math.min(radius, width / 2, height / 2);
  context.beginPath();
  context.moveTo(x + safe, y);
  context.arcTo(x + width, y, x + width, y + height, safe);
  context.arcTo(x + width, y + height, x, y + height, safe);
  context.arcTo(x, y + height, x, y, safe);
  context.arcTo(x, y, x + width, y, safe);
  context.closePath();
}

function isFinderModule(row: number, column: number, count: number) {
  return (
    (row < 7 && column < 7) ||
    (row < 7 && column >= count - 7) ||
    (row >= count - 7 && column < 7)
  );
}

function drawModule(
  context: CanvasRenderingContext2D,
  shape: string,
  x: number,
  y: number,
  size: number,
  finder: boolean,
) {
  if (shape === "square") {
    context.fillRect(x, y, size + 0.35, size + 0.35);
    return;
  }
  const inset = finder
    ? size * 0.035
    : shape === "dense-dots"
      ? size * 0.04
      : shape === "pixel"
        ? size * 0.08
        : size * 0.1;
  const moduleSize = size - inset * 2;
  if (["dots", "dense-dots", "circle"].includes(shape)) {
    context.beginPath();
    context.arc(x + size / 2, y + size / 2, moduleSize / 2, 0, Math.PI * 2);
    context.fill();
    return;
  }
  if (shape === "diamond") {
    context.save();
    context.translate(x + size / 2, y + size / 2);
    context.rotate(Math.PI / 4);
    context.fillRect(-moduleSize * 0.36, -moduleSize * 0.36, moduleSize * 0.72, moduleSize * 0.72);
    context.restore();
    return;
  }
  if (shape === "horizontal" || shape === "vertical") {
    const horizontal = shape === "horizontal";
    const width = horizontal ? moduleSize : moduleSize * 0.68;
    const height = horizontal ? moduleSize * 0.68 : moduleSize;
    roundedRect(
      context,
      x + (size - width) / 2,
      y + (size - height) / 2,
      width,
      height,
      Math.min(width, height) * 0.45,
    );
    context.fill();
    return;
  }
  if (shape === "hexagon") {
    const centerX = x + size / 2;
    const centerY = y + size / 2;
    const radius = moduleSize / 2;
    context.beginPath();
    for (let index = 0; index < 6; index += 1) {
      const angle = Math.PI / 3 * index - Math.PI / 6;
      const pointX = centerX + Math.cos(angle) * radius;
      const pointY = centerY + Math.sin(angle) * radius;
      if (index === 0) context.moveTo(pointX, pointY);
      else context.lineTo(pointX, pointY);
    }
    context.closePath();
    context.fill();
    return;
  }
  if (shape === "cross") {
    const arm = moduleSize * 0.36;
    roundedRect(context, x + (size - arm) / 2, y + inset, arm, moduleSize, arm * 0.24);
    context.fill();
    roundedRect(context, x + inset, y + (size - arm) / 2, moduleSize, arm, arm * 0.24);
    context.fill();
    return;
  }
  const radius =
    shape === "classy" || shape === "extra-rounded"
      ? moduleSize * 0.48
      : shape === "soft-square"
        ? moduleSize * 0.18
        : shape === "pixel"
          ? moduleSize * 0.08
          : moduleSize * 0.3;
  roundedRect(context, x + inset, y + inset, moduleSize, moduleSize, radius);
  context.fill();
}

function drawQrModules(
  context: CanvasRenderingContext2D,
  payload: string,
  x: number,
  y: number,
  size: number,
  dark: string,
  light: string,
  shape: string,
) {
  const model = QRCode.create(payload, { errorCorrectionLevel: "H" });
  const modules = model.modules as unknown as {
    size: number;
    data: ArrayLike<number | boolean>;
  };
  const quiet = 4;
  const cell = size / (modules.size + quiet * 2);
  context.fillStyle = light;
  context.fillRect(x, y, size, size);
  context.fillStyle = dark;
  for (let row = 0; row < modules.size; row += 1) {
    for (let column = 0; column < modules.size; column += 1) {
      if (!modules.data[row * modules.size + column]) continue;
      drawModule(
        context,
        shape,
        x + (column + quiet) * cell,
        y + (row + quiet) * cell,
        cell,
        isFinderModule(row, column, modules.size),
      );
    }
  }
}

function readableInk(color: string) {
  const value = color.replace("#", "");
  const red = Number.parseInt(value.slice(0, 2), 16);
  const green = Number.parseInt(value.slice(2, 4), 16);
  const blue = Number.parseInt(value.slice(4, 6), 16);
  return red * 0.299 + green * 0.587 + blue * 0.114 > 168
    ? "#101828"
    : "#ffffff";
}

function fitCanvasText(
  context: CanvasRenderingContext2D,
  value: string,
  maxWidth: number,
  maxSize: number,
  minSize: number,
  weight: number,
) {
  const text = value.trim().replace(/\s+/g, " ");
  let size = maxSize;
  while (size > minSize) {
    context.font = `${weight} ${size}px Arial, Tahoma, sans-serif`;
    if (context.measureText(text).width <= maxWidth) return { text, size };
    size -= 1;
  }
  context.font = `${weight} ${minSize}px Arial, Tahoma, sans-serif`;
  if (context.measureText(text).width <= maxWidth) return { text, size: minSize };
  let low = 1;
  let high = text.length;
  let best = "…";
  while (low <= high) {
    const middle = Math.floor((low + high) / 2);
    const candidate = `${text.slice(0, middle).trimEnd()}…`;
    if (context.measureText(candidate).width <= maxWidth) {
      best = candidate;
      low = middle + 1;
    } else {
      high = middle - 1;
    }
  }
  return { text: best, size: minSize };
}

function drawFittedCanvasText(
  context: CanvasRenderingContext2D,
  value: string,
  x: number,
  y: number,
  maxWidth: number,
  maxSize: number,
  minSize: number,
  weight: number,
  color: string,
) {
  const fitted = fitCanvasText(context, value, maxWidth, maxSize, minSize, weight);
  context.save();
  context.fillStyle = color;
  context.textAlign = "center";
  context.textBaseline = "middle";
  context.direction = /[\u0600-\u06ff]/.test(fitted.text) ? "rtl" : "ltr";
  context.font = `${weight} ${fitted.size}px Arial, Tahoma, sans-serif`;
  context.fillText(fitted.text, x, y);
  context.restore();
}

function isHexColor(value: string) {
  return /^#[0-9a-f]{6}$/i.test(value.trim());
}

function loadCanvasImage(source: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("image"));
    image.src = source;
  });
}

function purposeMark(purpose: QrPurposeId) {
  const marks: Record<QrPurposeId, string> = {
    platform: "@",
    website: "WWW",
    text: "TXT",
    sms: "SMS",
    email: "@",
    phone: "☎",
    wifi: "WiFi",
    contact: "VC",
    location: "⌖",
    event: "31",
  };
  return marks[purpose];
}

function PlatformBrandIcon({
  platformId,
}: {
  platformId: string;
}) {
  const brand = getBrandIcon(platformId);
  return (
    <svg viewBox={`0 0 ${brand.width} ${brand.height}`} aria-hidden="true" focusable="false">
      {brand.paths.map((path, index) => <path key={`${platformId}-${index}`} d={path} fill="currentColor" />)}
    </svg>
  );
}

function inputHint(platform: QrPlatform, t: (ar: string, en: string) => string) {
  if (platform.input === "phone") return t("رقم الهاتف مع رمز الدولة", "Phone with country code");
  if (platform.input === "place") return t("اسم المكان أو العنوان", "Place name or address");
  if (platform.input === "url") return t("الرابط الكامل", "Full URL");
  return t("اسم المستخدم أو الرابط الكامل", "Username or full URL");
}

export function QrStudio() {
  const { locale, t } = useLocale();
  const [panel, setPanel] = useState<StudioPanel>("content");
  const [purpose, setPurpose] = useState<QrPurposeId>("platform");
  const [platformId, setPlatformId] = useState("instagram");
  const [platformCategory, setPlatformCategory] = useState("social");
  const [platformSearch, setPlatformSearch] = useState("");
  const [visiblePlatforms, setVisiblePlatforms] = useState(24);
  const [fields, setFields] = useState<QrStudioFields>({ ...emptyQrFields });
  const [templateId, setTemplateId] = useState("minjaz");
  const [shapeId, setShapeId] = useState("rounded");
  const [formatId, setFormatId] = useState<(typeof qrCardFormats)[number]["id"]>("square");
  const [colorSource, setColorSource] = useState<ColorSource>("template");
  const [colorFamilyId, setColorFamilyId] = useState("blue");
  const [colorShade, setColorShade] = useState("500");
  const [gradientId, setGradientId] = useState("template");
  const [customAccent, setCustomAccent] = useState("#0754e8");
  const [customInk, setCustomInk] = useState("#07184f");
  const [customLight, setCustomLight] = useState("#ffffff");
  const [customGradientStart, setCustomGradientStart] = useState("#0754e8");
  const [customGradientEnd, setCustomGradientEnd] = useState("#08cbd5");
  const [imageMode, setImageMode] = useState<ImageMode>("content");
  const [presetIconId, setPresetIconId] = useState("link");
  const [logoFiles, setLogoFiles] = useState<File[]>([]);
  const [logoDataUrl, setLogoDataUrl] = useState("");
  const [result, setResult] = useState("");
  const [payload, setPayload] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const selectedPlatform =
    qrPlatforms.find((item) => item.id === platformId) || qrPlatforms[0];
  const selectedTemplate =
    qrCardTemplates.find((item) => item.id === templateId) || qrCardTemplates[0];
  const selectedFormat =
    qrCardFormats.find((item) => item.id === formatId) || qrCardFormats[0];
  const selectedPreset =
    qrPresetIcons.find((item) => item[0] === presetIconId) || qrPresetIcons[0];
  const selectedPurpose =
    qrPurposes.find((item) => item.id === purpose) || qrPurposes[0];
  const selectedShape =
    qrShapes.find((item) => item.id === shapeId) || qrShapes[0];
  const selectedColorFamily =
    qrColorFamilies.find((item) => item.id === colorFamilyId) || qrColorFamilies[0];
  const selectedGradient = qrGradientPresets.find((item) => item[0] === gradientId);
  const activeColors = useMemo(() => {
    const shade = colorShade as keyof typeof selectedColorFamily.shades;
    const base = colorSource === "palette"
      ? {
          dark: selectedColorFamily.shades["900"],
          light: "#ffffff",
          accent: selectedColorFamily.shades[shade],
          frame: selectedColorFamily.shades["50"],
        }
      : colorSource === "custom"
        ? {
            dark: isHexColor(customInk) ? customInk : "#07184f",
            light: isHexColor(customLight) ? customLight : "#ffffff",
            accent: isHexColor(customAccent) ? customAccent : "#0754e8",
            frame: isHexColor(customLight) ? customLight : "#edf4ff",
          }
        : {
            dark: selectedTemplate.dark,
            light: selectedTemplate.light,
            accent: selectedTemplate.accent,
            frame: selectedTemplate.frame,
          };
    const background = gradientId === "custom"
      ? [isHexColor(customGradientStart) ? customGradientStart : base.frame, isHexColor(customGradientEnd) ? customGradientEnd : base.accent]
      : selectedGradient
        ? [selectedGradient[3], selectedGradient[4]]
        : [base.frame, base.accent];
    return { ...base, backgroundStart: background[0], backgroundEnd: background[1] };
  }, [colorShade, colorSource, customAccent, customGradientEnd, customGradientStart, customInk, customLight, gradientId, selectedColorFamily, selectedGradient, selectedTemplate]);
  const activeContrast = colorContrast(activeColors.dark, activeColors.light);

  const matchingPlatforms = useMemo(() => {
    const query = platformSearch.trim().toLocaleLowerCase();
    return qrPlatforms.filter((item) => {
      if (query) {
        return `${item.name} ${item.id}`.toLocaleLowerCase().includes(query);
      }
      return item.category === platformCategory;
    });
  }, [platformCategory, platformSearch]);

  function update(key: keyof QrStudioFields, value: string | boolean) {
    setFields((current) => ({ ...current, [key]: value }));
    setResult("");
    setError("");
  }

  function changePurpose(next: QrPurposeId) {
    setPurpose(next);
    setResult("");
    setError("");
  }

  function choosePlatform(item: QrPlatform) {
    setPlatformId(item.id);
    setImageMode("content");
    setFields((current) => ({ ...current, profile: "", cardTitle: item.name }));
    setResult("");
    setError("");
  }

  function chooseLogo(files: File[]) {
    const next = files.slice(0, 1);
    setLogoFiles(next);
    setLogoDataUrl("");
    setResult("");
    setError("");
    if (!next[0]) return;
    const reader = new FileReader();
    reader.onload = () => setLogoDataUrl(String(reader.result || ""));
    reader.onerror = () => setError(t("تعذر قراءة الصورة محلياً", "The image could not be read locally"));
    reader.readAsDataURL(next[0]);
  }

  function input(
    key: keyof QrStudioFields,
    ar: string,
    en: string,
    kind: "text" | "email" | "url" = "text",
  ) {
    return (
      <div className="field">
        <label>{t(ar, en)}</label>
        <input
          type={kind}
          value={String(fields[key])}
          onChange={(event) => update(key, event.target.value)}
        />
      </div>
    );
  }

  function iconMeta() {
    if (imageMode === "none") return { text: "", color: activeColors.accent, brandId: "" };
    if (imageMode === "preset") {
      return { text: String(selectedPreset[3]), color: activeColors.accent, brandId: "" };
    }
    if (purpose === "platform") {
      return { text: selectedPlatform.icon, color: selectedPlatform.color, brandId: selectedPlatform.id };
    }
    return { text: purposeMark(purpose), color: activeColors.accent, brandId: "" };
  }

  async function generate() {
    const nextPayload = buildQrPayload(purpose, fields, selectedPlatform);
    if (!nextPayload) {
      setError(
        purpose === "event" && fields.eventDate && fields.eventEndDate < fields.eventDate
          ? t("تاريخ النهاية يجب ألا يسبق تاريخ البداية", "The end date cannot be before the start date")
          : t("أكمل البيانات الأساسية بصيغة صحيحة قبل الإنشاء", "Complete the required details in a valid format"),
      );
      setPanel("content");
      return;
    }
    if (
      colorSource === "custom" &&
      ![customAccent, customInk, customLight, customGradientStart, customGradientEnd].every(isHexColor)
    ) {
      setError(t("اكتب كل ألوان HEX بصيغة كاملة مثل #0754e8", "Enter every HEX color in full, such as #0754e8"));
      setPanel("color");
      return;
    }
    if (activeContrast < 4.5) {
      setError(t("تباين لون QR مع خلفيته ضعيف. اختر لون رمز أغمق أو خلفية أفتح.", "QR contrast is too low. Choose a darker code color or a lighter background."));
      setPanel("color");
      return;
    }
    setBusy(true);
    setError("");
    setResult("");
    try {
      const canvas = document.createElement("canvas");
      canvas.width = selectedFormat.width;
      canvas.height = selectedFormat.height;
      const context = canvas.getContext("2d");
      if (!context) throw new Error("canvas");

      const width = canvas.width;
      const height = canvas.height;
      const layout = getQrCardLayout(formatId, width, height, selectedTemplate.variant);
      const gradient = context.createLinearGradient(0, 0, width, height);
      gradient.addColorStop(0, activeColors.backgroundStart);
      gradient.addColorStop(1, activeColors.backgroundEnd);
      context.fillStyle = gradient;
      context.fillRect(0, 0, width, height);

      context.globalAlpha = 0.16;
      context.fillStyle = activeColors.light;
      context.beginPath();
      context.arc(width * 0.12, height * 0.1, Math.min(width, height) * 0.18, 0, Math.PI * 2);
      context.fill();
      context.beginPath();
      context.arc(width * 0.92, height * 0.88, Math.min(width, height) * 0.26, 0, Math.PI * 2);
      context.fill();
      context.globalAlpha = 1;

      const margin = layout.margin;
      roundedRect(context, margin, margin, width - margin * 2, height - margin * 2, 54);
      context.fillStyle = activeColors.light;
      context.shadowColor = "rgba(7, 24, 79, .2)";
      context.shadowBlur = 42;
      context.shadowOffsetY = 18;
      context.fill();
      context.shadowColor = "transparent";

      if (selectedTemplate.variant === "outline") {
        context.lineWidth = 5;
        context.strokeStyle = activeColors.accent;
        context.stroke();
      }
      if (selectedTemplate.variant === "wave") {
        context.globalAlpha = 0.12;
        context.fillStyle = activeColors.accent;
        context.beginPath();
        context.ellipse(width * 0.5, height * 0.06, width * 0.46, height * 0.16, 0, 0, Math.PI * 2);
        context.fill();
        context.globalAlpha = 1;
      }
      if (selectedTemplate.variant === "spotlight" || selectedTemplate.variant === "glass") {
        const glow = context.createRadialGradient(width * 0.5, height * 0.42, 0, width * 0.5, height * 0.42, width * 0.48);
        glow.addColorStop(0, `${activeColors.accent}32`);
        glow.addColorStop(1, `${activeColors.accent}00`);
        context.fillStyle = glow;
        context.fillRect(margin, margin, width - margin * 2, height - margin * 2);
      }

      const compact = formatId === "compact";
      const { qrSize, qrX, qrY } = layout;
      roundedRect(context, qrX - 25, qrY - 25, qrSize + 50, qrSize + 50, 42);
      context.fillStyle = activeColors.frame;
      context.fill();
      roundedRect(context, qrX - 10, qrY - 10, qrSize + 20, qrSize + 20, 30);
      context.fillStyle = activeColors.light;
      context.fill();
      drawQrModules(
        context,
        nextPayload,
        qrX,
        qrY,
        qrSize,
        activeColors.dark,
        activeColors.light,
        shapeId,
      );

      const meta = iconMeta();
      let logoImage: HTMLImageElement | null = null;
      if (imageMode === "upload" && logoDataUrl) {
        logoImage = await loadCanvasImage(logoDataUrl);
      }
      const brandSource =
        purpose === "platform"
          ? brandIconDataUrl(selectedPlatform.id, readableInk(selectedPlatform.color))
          : "";
      const platformBrandImage = brandSource
        ? await loadCanvasImage(brandSource)
        : null;
      const coloredBrandSource =
        purpose === "platform"
          ? brandIconDataUrl(selectedPlatform.id, selectedPlatform.color)
          : "";
      const coloredPlatformBrandImage = coloredBrandSource
        ? await loadCanvasImage(coloredBrandSource)
        : null;
      const centerImage = logoImage || (imageMode === "content" ? platformBrandImage : null);
      if (imageMode !== "none" && (meta.text || centerImage)) {
        const centerX = qrX + qrSize / 2;
        const centerY = qrY + qrSize / 2;
        const badgeSize = qrSize * 0.17;
        context.beginPath();
        context.arc(centerX, centerY, badgeSize * 0.58, 0, Math.PI * 2);
        context.fillStyle = activeColors.light;
        context.fill();
        context.save();
        context.beginPath();
        context.arc(centerX, centerY, badgeSize * 0.46, 0, Math.PI * 2);
        context.clip();
        if (centerImage) {
          context.fillStyle = logoImage ? activeColors.light : meta.color;
          context.fillRect(centerX - badgeSize, centerY - badgeSize, badgeSize * 2, badgeSize * 2);
          const imageScale = logoImage ? 0.82 : 0.6;
          context.drawImage(
            centerImage,
            centerX - badgeSize * imageScale / 2,
            centerY - badgeSize * imageScale / 2,
            badgeSize * imageScale,
            badgeSize * imageScale,
          );
        } else {
          context.fillStyle = meta.color;
          context.fillRect(centerX - badgeSize, centerY - badgeSize, badgeSize * 2, badgeSize * 2);
          context.fillStyle = readableInk(meta.color);
          context.textAlign = "center";
          context.textBaseline = "middle";
          context.font = `800 ${meta.text.length > 3 ? badgeSize * 0.22 : badgeSize * 0.32}px Arial, sans-serif`;
          context.fillText(meta.text, centerX, centerY + 2);
        }
        context.restore();
      }
      const defaultTitle = purpose === "platform"
        ? selectedPlatform.name
        : locale === "en"
          ? selectedPurpose.en
          : selectedPurpose.ar;
      const cardTitle = fields.cardTitle || defaultTitle;
      const cardSubtitle = fields.cardSubtitle || t("امسح الرمز للفتح مباشرة", "Scan to open instantly");
      const { headerX, badgeY } = layout;
      const topMeta = purpose === "platform"
        ? { text: selectedPlatform.icon, color: selectedPlatform.color, brand: coloredPlatformBrandImage }
        : { text: purposeMark(purpose), color: activeColors.accent, brand: null };
      context.beginPath();
      context.arc(headerX, badgeY, layout.badgeRadius, 0, Math.PI * 2);
      context.fillStyle = activeColors.light;
      context.fill();
      context.lineWidth = 5;
      context.strokeStyle = topMeta.color;
      context.stroke();
      if (topMeta.brand) {
        const brandSize = layout.badgeRadius * 1.05;
        context.drawImage(topMeta.brand, headerX - brandSize / 2, badgeY - brandSize / 2, brandSize, brandSize);
      } else {
        context.fillStyle = topMeta.color;
        context.textAlign = "center";
        context.textBaseline = "middle";
        context.font = `800 ${topMeta.text.length > 3 ? 16 : 23}px Arial, sans-serif`;
        context.fillText(topMeta.text, headerX, badgeY + 1);
      }
      drawFittedCanvasText(context, cardTitle, headerX, layout.titleY, layout.textMaxWidth, layout.titleSize, compact ? 24 : 28, 800, activeColors.dark);
      drawFittedCanvasText(context, cardSubtitle, headerX, layout.subtitleY, layout.textMaxWidth, layout.subtitleSize, compact ? 16 : 18, 600, activeColors.accent);

      const footerY = layout.footerY;
      roundedRect(context, headerX - 132, footerY - 26, 264, 52, 26);
      context.fillStyle = activeColors.frame;
      context.fill();
      context.save();
      context.fillStyle = activeColors.dark;
      context.font = "800 18px Arial, sans-serif";
      context.textAlign = "center";
      context.textBaseline = "middle";
      context.direction = "ltr";
      context.fillText("ADAWATI QR STUDIO", headerX, footerY);
      context.restore();

      setPayload(nextPayload);
      setResult(canvas.toDataURL("image/png", 1));
    } catch {
      setError(
        t(
          "تعذر إنشاء البطاقة من البيانات أو الصورة المختارة",
          "The card could not be generated from the selected details or image",
        ),
      );
    } finally {
      setBusy(false);
    }
  }

  function download() {
    if (!result) return;
    const anchor = document.createElement("a");
    anchor.href = result;
    anchor.download = `adawati-qr-${purpose === "platform" ? selectedPlatform.id : purpose}-${formatId}-${shapeId}.png`;
    anchor.click();
    window.dispatchEvent(new CustomEvent("minjaz-download-feedback"));
  }

  return (
    <div className="workspace-stack qr-studio qr-studio-pro">
      <div className="qr-studio-summary">
        <div className="icon-tile color-blue"><Icon name="qr" size={28} /></div>
        <div>
          <strong>{t("استوديو QR متكامل", "Complete QR Studio")}</strong>
          <span>
            {t(
              `${qrPlatforms.length} منصة وخدمة، 14 شكلاً و264 درجة و36 تدرجاً، ومعالجة محلية بالكامل`,
              `${qrPlatforms.length} platforms, 14 shapes, 264 shades, 36 gradients, fully local processing`,
            )}
          </span>
        </div>
        <b><Icon name="shield" size={17} /> {t("محلي", "Local")}</b>
      </div>

      <nav className="qr-studio-tabs" aria-label={t("مراحل استوديو QR", "QR Studio steps")}>
        {([
          ["content", "1", "المحتوى والمنصة", "Content & platform", "globe"],
          ["style", "2", "شكل QR والبطاقة", "QR & card style", "sliders"],
          ["color", "3", "الألوان والتدرجات", "Colors & gradients", "sparkles"],
          ["image", "4", "الصورة أو الأيقونة", "Image or icon", "image"],
        ] as const).map((item) => (
          <button
            key={item[0]}
            type="button"
            className={panel === item[0] ? "active" : ""}
            aria-pressed={panel === item[0]}
            onClick={() => setPanel(item[0])}
          >
            <i>{item[1]}</i><Icon name={item[4]} size={20} />
            <span>{locale === "en" ? item[3] : item[2]}</span>
          </button>
        ))}
      </nav>

      {panel === "content" && (
        <section className="qr-stage-section qr-panel" aria-label={t("المحتوى والمنصة", "Content and platform")}>
          <header><span>1</span><div><h2>{t("اختر وظيفة الرمز", "Choose the QR purpose")}</h2><p>{t("كل وظيفة تعرض بياناتها فقط", "Only relevant fields are shown")}</p></div></header>
          <div className="qr-purpose-grid" role="radiogroup" aria-label={t("نوع رمز QR", "QR type")}>
            {qrPurposes.map((item) => (
              <button
                key={item.id}
                type="button"
                role="radio"
                data-qr-purpose={item.id}
                aria-checked={purpose === item.id}
                tabIndex={purpose === item.id ? 0 : -1}
                className={purpose === item.id ? "active" : ""}
                onClick={() => changePurpose(item.id)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    changePurpose(item.id);
                    return;
                  }
                  if (!["ArrowRight", "ArrowLeft", "ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) return;
                  event.preventDefault();
                  const currentIndex = qrPurposes.findIndex((purposeItem) => purposeItem.id === item.id);
                  const lastIndex = qrPurposes.length - 1;
                  const nextIndex = event.key === "Home"
                    ? 0
                    : event.key === "End"
                      ? lastIndex
                      : event.key === "ArrowRight" || event.key === "ArrowDown"
                        ? (currentIndex + 1) % qrPurposes.length
                        : (currentIndex - 1 + qrPurposes.length) % qrPurposes.length;
                  const nextPurpose = qrPurposes[nextIndex];
                  changePurpose(nextPurpose.id);
                  event.currentTarget.parentElement
                    ?.querySelector<HTMLButtonElement>(`button[data-qr-purpose="${nextPurpose.id}"]`)
                    ?.focus();
                }}
              >
                <Icon name={item.icon} size={21} />
                <span>{locale === "en" ? item.en : item.ar}</span>
              </button>
            ))}
          </div>

          {purpose === "platform" && (
            <div className="qr-platform-library">
              <div className="qr-platform-search">
                <Icon name="search" size={20} />
                <input
                  value={platformSearch}
                  onChange={(event) => { setPlatformSearch(event.target.value); setVisiblePlatforms(24); }}
                  placeholder={t("ابحث باسم أي منصة أو خدمة…", "Search any platform or service…")}
                  aria-label={t("البحث في المنصات", "Search platforms")}
                />
                {platformSearch && <button type="button" aria-label={t("مسح البحث", "Clear search")} onClick={() => setPlatformSearch("")}><Icon name="x" size={17} /></button>}
              </div>
              <div className="qr-platform-categories" role="tablist" aria-label={t("تصنيفات المنصات", "Platform categories")}>
                {qrPlatformCategories.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    role="tab"
                    aria-selected={!platformSearch && platformCategory === item.id}
                    className={!platformSearch && platformCategory === item.id ? "active" : ""}
                    onClick={() => { setPlatformSearch(""); setPlatformCategory(item.id); setVisiblePlatforms(24); }}
                  >
                    {locale === "en" ? item.en : item.ar}
                    <b>{qrPlatforms.filter((platformItem) => platformItem.category === item.id).length}</b>
                  </button>
                ))}
              </div>
              <div className="qr-platform-grid">
                {matchingPlatforms.slice(0, visiblePlatforms).map((item) => (
                  <button key={item.id} type="button" className={platformId === item.id ? "active" : ""} onClick={() => choosePlatform(item)}>
                    <i style={{ "--brand-color": item.color } as React.CSSProperties}><PlatformBrandIcon platformId={item.id} /></i>
                    <span>{item.name}</span>
                    {platformId === item.id && <Icon name="check" size={16} />}
                  </button>
                ))}
              </div>
              {matchingPlatforms.length > visiblePlatforms && (
                <button className="secondary-button qr-show-more" type="button" onClick={() => setVisiblePlatforms((current) => current + 24)}>
                  <Icon name="plus" size={18} /> {t("عرض منصات أكثر", "Show more platforms")}
                </button>
              )}
              {!matchingPlatforms.length && (
                <div className="notice"><Icon name="search" size={19} /> {t("ما لكينا الاسم؛ اختر «أي موقع أو منصة» والصق الرابط الكامل.", "No match found; choose “Any site or platform” and paste the full URL.")}</div>
              )}
              <div className="qr-selected-platform">
                <i style={{ "--brand-color": selectedPlatform.color } as React.CSSProperties}><PlatformBrandIcon platformId={selectedPlatform.id} /></i>
                <div><strong>{selectedPlatform.name}</strong><span>{inputHint(selectedPlatform, t)}</span></div>
              </div>
              <div className="form-grid">
                <div className="field full">
                  <label>{inputHint(selectedPlatform, t)}</label>
                  <input value={fields.profile} onChange={(event) => update("profile", event.target.value)} placeholder={selectedPlatform.input === "url" ? "https://" : selectedPlatform.input === "phone" ? "+964…" : "@username"} />
                </div>
                {selectedPlatform.id === "whatsapp" && (
                  <div className="field full"><label>{t("رسالة جاهزة اختيارية", "Optional prepared message")}</label><textarea value={fields.message} onChange={(event) => update("message", event.target.value)} /></div>
                )}
              </div>
            </div>
          )}

          {purpose !== "platform" && (
            <div className="form-grid qr-purpose-fields">
              {purpose === "website" && input("url", "رابط الموقع", "Website URL", "url")}
              {purpose === "text" && <div className="field full"><label>{t("النص", "Text")}</label><textarea value={fields.text} onChange={(event) => update("text", event.target.value)} /></div>}
              {purpose === "sms" && <>{input("phone", "رقم الهاتف مع رمز الدولة", "Phone with country code")}<div className="field full"><label>{t("نص الرسالة", "Message")}</label><textarea value={fields.message} onChange={(event) => update("message", event.target.value)} /></div></>}
              {purpose === "email" && <>{input("email", "البريد الإلكتروني", "Email", "email")}{input("subject", "موضوع الرسالة", "Subject")}<div className="field full"><label>{t("نص البريد", "Email body")}</label><textarea value={fields.body} onChange={(event) => update("body", event.target.value)} /></div></>}
              {purpose === "phone" && input("phone", "رقم الهاتف مع رمز الدولة", "Phone with country code")}
              {purpose === "wifi" && <>{input("ssid", "اسم الشبكة", "Network name")}{input("password", "كلمة المرور", "Password")}<div className="field"><label>{t("نوع الحماية", "Security")}</label><CustomSelect value={fields.encryption} onChange={(value) => update("encryption", value)} label={t("نوع الحماية", "Security")} options={["WPA", "WEP", "nopass"].map((value) => ({ value, label: value }))} /></div><label className="modern-check"><input type="checkbox" checked={fields.hidden} onChange={(event) => update("hidden", event.target.checked)} /><span>{t("الشبكة مخفية", "Hidden network")}</span></label></>}
              {purpose === "contact" && <>{input("name", "الاسم الكامل", "Full name")}{input("organization", "الشركة أو المنصب", "Company or title")}{input("phone", "رقم الهاتف", "Phone")}{input("email", "البريد", "Email", "email")}{input("website", "الموقع", "Website", "url")}{input("address", "العنوان", "Address")}</>}
              {purpose === "location" && <>{input("latitude", "خط العرض من ‎-90 إلى 90", "Latitude from -90 to 90")}{input("longitude", "خط الطول من ‎-180 إلى 180", "Longitude from -180 to 180")}{input("label", "اسم المكان", "Place label")}</>}
              {purpose === "event" && <>{input("eventTitle", "اسم الموعد", "Event title")}{input("eventLocation", "المكان", "Location")}<ModernDatePicker label={t("تاريخ البداية — يبدأ 00:00", "Start date — starts at 00:00")} value={fields.eventDate} onChange={(value) => update("eventDate", value)} /><ModernDatePicker label={t("تاريخ النهاية — يبدأ 00:00", "End date — starts at 00:00")} value={fields.eventEndDate} onChange={(value) => update("eventEndDate", value)} /></>}
            </div>
          )}
          <div className="qr-panel-footer"><button className="primary-button" type="button" onClick={() => setPanel("style")}>{t("التالي: اختيار الشكل", "Next: choose style")} <Icon name="back" size={18} /></button></div>
        </section>
      )}

      {panel === "style" && (
        <section className="qr-stage-section qr-panel" aria-label={t("شكل QR والبطاقة", "QR and card style")}>
          <header><span>2</span><div><h2>{t("شكل QR والبطاقة", "QR and card style")}</h2><p>{t("هذا القسم مستقل عن اختيار الصورة", "This section is separate from image selection")}</p></div></header>
          <div className="qr-option-block">
            <h3>{t("مقاس البطاقة", "Card format")}</h3>
            <div className="qr-format-grid">
              {qrCardFormats.map((item) => <button key={item.id} type="button" className={formatId === item.id ? "active" : ""} onClick={() => { setFormatId(item.id); setResult(""); }}><i style={{ aspectRatio: `${item.width}/${item.height}` }} /><span>{locale === "en" ? item.en : item.ar}</span><small>{item.width}×{item.height}</small></button>)}
            </div>
          </div>
          <div className="qr-option-block">
            <h3>{t("شكل وحدات QR", "QR module shape")}</h3>
            <div className="qr-shape-grid">
              {qrShapes.map((item) => <button key={item.id} type="button" className={shapeId === item.id ? "active" : ""} onClick={() => { setShapeId(item.id); setResult(""); }}><i className={`shape-${item.id}`} /><span>{locale === "en" ? item.en : item.ar}</span></button>)}
            </div>
          </div>
          <div className="qr-option-block">
            <h3>{t("20 بطاقة حديثة", "20 modern cards")}</h3>
            <div className="qr-template-grid qr-card-template-grid">
              {qrCardTemplates.map((item) => <button key={item.id} type="button" className={templateId === item.id ? "active" : ""} onClick={() => { setTemplateId(item.id); setResult(""); }} style={{ "--qr-dark": item.dark, "--qr-light": item.light, "--qr-accent": item.accent, "--qr-frame": item.frame } as React.CSSProperties}><i /><span>{locale === "en" ? item.en : item.ar}</span></button>)}
            </div>
          </div>
          <div className="form-grid qr-card-copy-fields">
            {input("cardTitle", "عنوان البطاقة — اختياري", "Card title — optional")}
            {input("cardSubtitle", "النص أسفل العنوان — اختياري", "Subtitle — optional")}
          </div>
          <div className="qr-panel-footer"><button className="secondary-button" type="button" onClick={() => setPanel("content")}>{t("رجوع للمحتوى", "Back to content")}</button><button className="primary-button" type="button" onClick={() => setPanel("color")}>{t("التالي: اختيار الألوان", "Next: choose colors")} <Icon name="sparkles" size={18} /></button></div>
        </section>
      )}

      {panel === "color" && (
        <section className="qr-stage-section qr-panel" aria-label={t("الألوان والتدرجات", "Colors and gradients")}>
          <header><span>3</span><div><h2>{t("الألوان والتدرجات", "Colors and gradients")}</h2><p>{t("24 عائلة و264 درجة و36 تدرجاً، مع فحص التباين تلقائياً", "24 families, 264 shades, 36 gradients, with automatic contrast checks")}</p></div></header>
          <div className="qr-color-source-grid">
            {([
              ["template", "layers", "ألوان البطاقة", "Card colors"],
              ["palette", "grid", "مكتبة الألوان", "Color library"],
              ["custom", "edit", "ألوان HEX خاصة", "Custom HEX colors"],
            ] as const).map((item) => <button key={item[0]} type="button" className={colorSource === item[0] ? "active" : ""} onClick={() => { setColorSource(item[0]); setResult(""); }}><Icon name={item[1]} size={21} /><span>{locale === "en" ? item[3] : item[2]}</span></button>)}
          </div>

          {colorSource === "palette" && (
            <div className="qr-option-block">
              <h3>{t("اختر عائلة اللون", "Choose a color family")}</h3>
              <div className="qr-color-family-grid">
                {qrColorFamilies.map((item) => <button key={item.id} type="button" className={colorFamilyId === item.id ? "active" : ""} onClick={() => { setColorFamilyId(item.id); setResult(""); }}><i style={{ background: `linear-gradient(135deg, ${item.shades["200"]}, ${item.shades["700"]})` }} /><span>{locale === "en" ? item.en : item.ar}</span></button>)}
              </div>
              <h3>{t("اختر الدرجة الأساسية", "Choose the primary shade")}</h3>
              <div className="qr-color-shade-grid">
                {Object.entries(selectedColorFamily.shades).map(([shade, color]) => <button key={shade} type="button" className={colorShade === shade ? "active" : ""} onClick={() => { setColorShade(shade); setResult(""); }} aria-label={`${locale === "en" ? selectedColorFamily.en : selectedColorFamily.ar} ${shade}`}><i style={{ background: color }} /><span>{shade}</span><small>{color}</small></button>)}
              </div>
              <p className="qr-color-safety-note"><Icon name="shield" size={18} /> {t("تستخدم البطاقة الدرجة التي اخترتها، بينما يستخدم QR درجة 900 تلقائياً مع خلفية بيضاء لضمان القراءة.", "The card uses your chosen shade, while QR automatically uses shade 900 on white for reliable scanning.")}</p>
            </div>
          )}

          {colorSource === "custom" && (
            <div className="form-grid qr-custom-color-fields">
              <div className="field"><label>{t("لون QR الغامق", "Dark QR color")}</label><input value={customInk} onChange={(event) => { setCustomInk(event.target.value); setResult(""); }} placeholder="#07184f" dir="ltr" /></div>
              <div className="field"><label>{t("خلفية QR الفاتحة", "Light QR background")}</label><input value={customLight} onChange={(event) => { setCustomLight(event.target.value); setResult(""); }} placeholder="#ffffff" dir="ltr" /></div>
              <div className="field"><label>{t("اللون الأساسي", "Accent color")}</label><input value={customAccent} onChange={(event) => { setCustomAccent(event.target.value); setResult(""); }} placeholder="#0754e8" dir="ltr" /></div>
            </div>
          )}

          <div className={`qr-contrast-meter ${activeContrast >= 7 ? "excellent" : activeContrast >= 4.5 ? "good" : "weak"}`}>
            <div className="qr-contrast-sample" style={{ color: activeColors.dark, background: activeColors.light }}><Icon name="qr" size={30} /></div>
            <div><strong>{t("تباين QR", "QR contrast")}: {activeContrast.toFixed(2)}:1</strong><span>{activeContrast >= 7 ? t("ممتاز للمسح", "Excellent for scanning") : activeContrast >= 4.5 ? t("جيد للمسح", "Good for scanning") : t("ضعيف — لن نسمح بالتوليد", "Too weak — generation is blocked")}</span></div>
          </div>

          <div className="qr-option-block">
            <h3>{t("تدرج خلفية البطاقة", "Card background gradient")}</h3>
            <div className="qr-gradient-grid">
              <button type="button" className={gradientId === "template" ? "active" : ""} onClick={() => { setGradientId("template"); setResult(""); }}><i style={{ background: `linear-gradient(135deg, ${activeColors.frame}, ${activeColors.accent})` }} /><span>{t("حسب البطاقة", "From card")}</span></button>
              {qrGradientPresets.map((item) => <button key={item[0]} type="button" className={gradientId === item[0] ? "active" : ""} onClick={() => { setGradientId(item[0]); setResult(""); }}><i style={{ background: `linear-gradient(135deg, ${item[3]}, ${item[4]})` }} /><span>{locale === "en" ? item[2] : item[1]}</span></button>)}
              <button type="button" className={gradientId === "custom" ? "active" : ""} onClick={() => { setGradientId("custom"); setResult(""); }}><i style={{ background: `linear-gradient(135deg, ${isHexColor(customGradientStart) ? customGradientStart : "#0754e8"}, ${isHexColor(customGradientEnd) ? customGradientEnd : "#08cbd5"})` }} /><span>{t("تدرج مخصص", "Custom gradient")}</span></button>
            </div>
          </div>
          {gradientId === "custom" && (
            <div className="form-grid qr-custom-color-fields">
              <div className="field"><label>{t("بداية التدرج HEX", "Gradient start HEX")}</label><input value={customGradientStart} onChange={(event) => { setCustomGradientStart(event.target.value); setResult(""); }} dir="ltr" /></div>
              <div className="field"><label>{t("نهاية التدرج HEX", "Gradient end HEX")}</label><input value={customGradientEnd} onChange={(event) => { setCustomGradientEnd(event.target.value); setResult(""); }} dir="ltr" /></div>
            </div>
          )}
          <div className="qr-color-preview" style={{ background: `linear-gradient(135deg, ${activeColors.backgroundStart}, ${activeColors.backgroundEnd})` }}><div style={{ background: activeColors.light, color: activeColors.dark }}><Icon name="qr" size={36} /><strong>{t("معاينة الألوان", "Color preview")}</strong><span style={{ color: activeColors.accent }}>ADAWATI QR</span></div></div>
          <div className="qr-panel-footer"><button className="secondary-button" type="button" onClick={() => setPanel("style")}>{t("رجوع للشكل", "Back to style")}</button><button className="primary-button" type="button" onClick={() => setPanel("image")}>{t("التالي: اختيار الصورة", "Next: choose image")} <Icon name="image" size={18} /></button></div>
        </section>
      )}

      {panel === "image" && (
        <section className="qr-stage-section qr-panel" aria-label={t("الصورة أو الأيقونة", "Image or icon")}>
          <header><span>4</span><div><h2>{t("اختر الصورة أو الأيقونة", "Choose image or icon")}</h2><p>{t("اختيار منفصل تماماً عن الشكل والألوان", "Completely separate from style and colors")}</p></div></header>
          <div className="qr-image-mode-grid">
            {([
              ["content", "sparkles", "أيقونة المحتوى", "Content icon"],
              ["preset", "grid", "أيقونة جاهزة", "Preset icon"],
              ["upload", "upload", "رفع صورة خاصة", "Upload image"],
              ["none", "x", "بدون صورة", "No image"],
            ] as const).map((item) => <button key={item[0]} type="button" className={imageMode === item[0] ? "active" : ""} onClick={() => { setImageMode(item[0]); setResult(""); }}><Icon name={item[1]} size={22} /><span>{locale === "en" ? item[3] : item[2]}</span></button>)}
          </div>
          {imageMode === "content" && (
            <div className="qr-content-icon-preview">
              <i style={{ "--brand-color": purpose === "platform" ? selectedPlatform.color : activeColors.accent } as React.CSSProperties}>{purpose === "platform" ? <PlatformBrandIcon platformId={selectedPlatform.id} /> : purposeMark(purpose)}</i>
              <div><strong>{purpose === "platform" ? selectedPlatform.name : locale === "en" ? selectedPurpose.en : selectedPurpose.ar}</strong><span>{t("أيقونة محلية خاصة بالمحتوى المختار", "A local icon for the selected content")}</span></div>
            </div>
          )}
          {imageMode === "preset" && (
            <div className="qr-icon-grid qr-preset-icon-grid">
              {qrPresetIcons.map((item) => <button key={item[0]} type="button" className={presetIconId === item[0] ? "active" : ""} onClick={() => { setPresetIconId(item[0]); setResult(""); }}><b>{item[3]}</b><span>{locale === "en" ? item[2] : item[1]}</span></button>)}
            </div>
          )}
          {imageMode === "upload" && (
            <FileUploadZone files={logoFiles} onFiles={chooseLogo} accept="image/png,image/jpeg,image/webp,image/svg+xml" maxFiles={1} icon="image" title={t("اختر شعاراً أو صورة", "Choose a logo or image")} helper={t("تُحمّل داخل الأداة فقط وتظهر رسالة تأكيد", "Loaded only inside the tool with confirmation")} />
          )}
          {imageMode === "none" && <div className="notice"><Icon name="shield" size={19} /> {t("سيُنشأ الرمز من دون صورة في المنتصف لأعلى بساطة.", "The QR will be generated without a center image for maximum simplicity.")}</div>}
          <div className="qr-panel-footer"><button className="secondary-button" type="button" onClick={() => setPanel("color")}>{t("رجوع للألوان", "Back to colors")}</button></div>
        </section>
      )}

      <div className="qr-generate-dock">
        <div><strong>{t("جاهز للإنشاء؟", "Ready to generate?")}</strong><span>{t("المعالجة والتنزيل داخل جهازك", "Processing and download stay on your device")}</span></div>
        <button className="primary-button qr-generate-button" type="button" disabled={busy || (imageMode === "upload" && !logoDataUrl)} onClick={generate}>
          <Icon name="qr" size={20} /> {busy ? t("جاري الإنشاء…", "Generating…") : t("إنشاء بطاقة QR", "Generate QR card")}
        </button>
      </div>
      {imageMode === "upload" && !logoDataUrl && <div className="notice"><Icon name="upload" size={18} /> {logoFiles.length ? t("جاري تجهيز الصورة داخل جهازك…", "Preparing the image on your device…") : t("اختر صورة أولاً أو غيّر خيار الصورة.", "Choose an image first or change the image option.")}</div>}
      {error && <div className="error-notice" role="alert">{error}</div>}
      {result && (
        <div className="qr-studio-result">
          <img src={result} alt={t("بطاقة QR المصممة", "Designed QR card")} />
          <div>
            <strong>{t("البطاقة جاهزة", "Your card is ready")}</strong>
            <span>{t("يمكن تنزيلها أو نسخ المحتوى المشفّر", "Download it or copy its encoded content")}</span>
            <small>{t("شكل QR المحفوظ", "Saved QR shape")}: {locale === "en" ? selectedShape.en : selectedShape.ar}</small>
            <button className="primary-button" type="button" onClick={download}><Icon name="download" size={18} /> {t("تحميل PNG", "Download PNG")}</button>
            <button className="secondary-button" type="button" onClick={(event) => copyWithFeedback(payload, event.currentTarget)}><Icon name="copy" size={18} /> {t("نسخ محتوى QR", "Copy QR content")}</button>
          </div>
        </div>
      )}
      <p className="workspace-tip"><Icon name="shield" size={18} />{t("كل البيانات والصور وإنشاء QR تتم داخل جهازك، من دون رفع أو قاعدة بيانات", "All details, images, and QR generation stay on your device, with no upload or database")}</p>
    </div>
  );
}
