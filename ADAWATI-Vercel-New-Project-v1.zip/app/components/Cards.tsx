"use client";

import Link from "next/link";
import { getToolDescription, type Category, type Tool } from "@/lib/registry";
import { FavoriteButton } from "./FavoriteButton";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";

export function ToolCard({ tool, compact = false }: { tool: Tool; compact?: boolean }) {
  const { locale, t } = useLocale();
  return (
    <article className={`tool-card color-${tool.color} ${compact ? "tool-card--compact" : ""}`}>
      {!compact && <FavoriteButton slug={tool.slug} compact />}
      <Link href={`/tools/${tool.slug}`} prefetch className="tool-card__link" aria-label={t(`فتح أداة ${tool.name}`, `Open ${tool.nameEn}`)}>
        <span className="icon-tile"><Icon name={tool.icon} size={compact ? 26 : 30} /></span>
        <span className="tool-card__copy"><strong>{locale === "en" ? tool.nameEn : tool.name}</strong>{!compact && <small>{getToolDescription(tool, locale)}</small>}</span>
      </Link>
    </article>
  );
}
export function CategoryCard({ category }: { category: Category }) {
  const { locale } = useLocale();
  return <Link href={`/tools/${category.slug}`} prefetch className={`category-card color-${category.color}`}><span className="icon-tile icon-tile--small"><Icon name={category.icon} size={24} /></span><strong>{locale === "en" ? category.nameEn : category.name}</strong></Link>;
}

export function AllToolsCategoryCard() {
  const { t } = useLocale();
  return <Link href="/tools" className="category-card category-card--all color-blue"><span className="icon-tile icon-tile--small"><Icon name="grid" size={24} /></span><strong>{t("كل الأدوات", "All tools")}</strong><small>{t("عرض الأدوات كاملة", "View every tool")}</small></Link>;
}
