"use client";

import {
  useCallback,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
} from "react";
import { Icon } from "./Icon";

export type SelectOption = {
  value: string;
  label: string;
  hint?: string;
  disabled?: boolean;
};

export function CustomSelect({
  value,
  options,
  onChange,
  label,
  name,
  className = "",
  searchable,
}: {
  value: string;
  options: SelectOption[];
  onChange: (value: string) => void;
  label: string;
  name?: string;
  className?: string;
  searchable?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [activeValue, setActiveValue] = useState(value);
  const root = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const optionRefs = useRef(new Map<string, HTMLButtonElement>());
  const menuId = useId();
  const selected =
    options.find((option) => option.value === value) || options[0];
  const canSearch = searchable ?? options.length > 12;
  const normalizedQuery = query.trim().toLocaleLowerCase();
  const visibleOptions = useMemo(
    () =>
      normalizedQuery
        ? options.filter((option) =>
            `${option.label} ${option.hint || ""} ${option.value}`
              .toLocaleLowerCase()
              .includes(normalizedQuery),
          )
        : options,
    [normalizedQuery, options],
  );

  const close = useCallback((restoreFocus = false) => {
    setOpen(false);
    setQuery("");
    if (restoreFocus) requestAnimationFrame(() => trigger.current?.focus());
  }, []);

  function move(step: 1 | -1) {
    const enabled = visibleOptions.filter((option) => !option.disabled);
    if (!enabled.length) return;
    const index = enabled.findIndex((option) => option.value === activeValue);
    const next = enabled[(index + step + enabled.length) % enabled.length];
    setActiveValue(next.value);
    requestAnimationFrame(() => optionRefs.current.get(next.value)?.focus());
  }

  function choose(option: SelectOption) {
    if (option.disabled) return;
    onChange(option.value);
    close(true);
  }

  useEffect(() => {
    function dismiss(event: PointerEvent) {
      if (!root.current?.contains(event.target as Node)) close();
    }
    function handleKeyboard(event: KeyboardEvent) {
      if (!open) return;
      if (event.key === "Escape") {
        event.preventDefault();
        close(true);
      } else if (event.key === "Tab") {
        close();
      }
    }
    document.addEventListener("pointerdown", dismiss);
    document.addEventListener("keydown", handleKeyboard);
    return () => {
      document.removeEventListener("pointerdown", dismiss);
      document.removeEventListener("keydown", handleKeyboard);
    };
  }, [close, open]);

  return (
    <div
      className={`custom-select ${open ? "is-open" : ""} ${className}`}
      ref={root}
      onKeyDown={(event) => {
        if (!open && (event.key === "ArrowDown" || event.key === "ArrowUp")) {
          event.preventDefault();
          const initial =
            options.find(
              (option) => option.value === value && !option.disabled,
            ) || options.find((option) => !option.disabled);
          if (initial) setActiveValue(initial.value);
          setOpen(true);
          return;
        }
        if (!open) return;
        if (event.key === "ArrowDown" || event.key === "ArrowUp") {
          event.preventDefault();
          move(event.key === "ArrowDown" ? 1 : -1);
        } else if (event.key === "Home" || event.key === "End") {
          event.preventDefault();
          const enabled = visibleOptions.filter((option) => !option.disabled);
          const next = event.key === "Home" ? enabled[0] : enabled.at(-1);
          if (next) {
            setActiveValue(next.value);
            requestAnimationFrame(() =>
              optionRefs.current.get(next.value)?.focus(),
            );
          }
        }
      }}
    >
      {name && <input type="hidden" name={name} value={value} />}
      <button
        ref={trigger}
        type="button"
        className="custom-select__trigger"
        aria-label={label}
        aria-haspopup="listbox"
        aria-controls={menuId}
        aria-expanded={open}
        onClick={() => {
          setOpen((current) => {
            if (!current) {
              const initial =
                options.find(
                  (option) => option.value === value && !option.disabled,
                ) || options.find((option) => !option.disabled);
              if (initial) setActiveValue(initial.value);
            }
            return !current;
          });
          setQuery("");
        }}
      >
        <span>
          <strong>{selected?.label}</strong>
          {selected?.hint && <small>{selected.hint}</small>}
        </span>
        <Icon name="chevron-down" size={18} />
      </button>
      {open && (
        <div
          id={menuId}
          className="custom-select__menu"
          role="listbox"
          aria-label={label}
        >
          <div className="custom-select__menu-head">
            <span>{label}</span>
            <small>{visibleOptions.length}</small>
          </div>
          {canSearch && (
            <div className="custom-select__search">
              <Icon name="search" size={17} />
              <input
                autoFocus
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder={`${label}...`}
                aria-label={label}
              />
            </div>
          )}
          <div className="custom-select__options">
            {visibleOptions.map((option) => (
              <button
                ref={(node) => {
                  if (node) optionRefs.current.set(option.value, node);
                  else optionRefs.current.delete(option.value);
                }}
                type="button"
                key={option.value}
                role="option"
                disabled={option.disabled}
                aria-disabled={option.disabled}
                aria-selected={option.value === value}
                tabIndex={option.value === activeValue ? 0 : -1}
                className={option.value === value ? "active" : ""}
                onFocus={() => setActiveValue(option.value)}
                onClick={() => choose(option)}
              >
                <span>
                  <strong>{option.label}</strong>
                  {option.hint && <small>{option.hint}</small>}
                </span>
                {option.value === value && <Icon name="check" size={18} />}
              </button>
            ))}
            {!visibleOptions.length && (
              <p className="custom-select__empty">لا توجد نتيجة / No results</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
