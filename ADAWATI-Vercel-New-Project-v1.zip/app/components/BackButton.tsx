"use client";

import { useRouter } from "next/navigation";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";

export function BackButton() {
  const router = useRouter();
  const { t } = useLocale();

  function goBack() {
    if (window.history.length > 1) {
      window.history.back();
      return;
    }
    router.replace("/tools");
  }

  return <button type="button" className="page-back-button" onClick={goBack} aria-label={t("الرجوع إلى الصفحة السابقة", "Go back to the previous page")}><Icon name="back" size={20} /><span>{t("رجوع", "Back")}</span></button>;
}
