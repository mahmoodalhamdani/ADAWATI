"use client";

import Image from "next/image";
import Link from "next/link";
import { useLocale } from "./LocaleProvider";

export function Logo({ variant = "header" }: { variant?: "header" | "hero" }) {
  const { t } = useLocale();
  const sizes = variant === "hero" ? "(max-width: 600px) 104px, 156px" : "52px";
  return (
    <Link href="/" className={`brand-logo brand-logo--${variant}`} aria-label={t("أدواتي - الرئيسية", "ADAWATI - Home")}>
      <span className="brand-logo__crest">
        <Image
          src="/brand/adawati-logo.webp"
          alt={t("شعار أدواتي", "ADAWATI logo")}
          width={1024}
          height={1024}
          sizes={sizes}
          priority
          unoptimized
        />
      </span>
      <span className="brand-logo__wordmark">
        <strong>{t("أدواتي", "ADAWATI")}</strong>
        <small>{t("ADAWATI", "أدواتي")}</small>
      </span>
    </Link>
  );
}
