"use client";

import { useEffect } from "react";

let fieldSequence = 0;

function appendToken(current: string | null, token: string) {
  return [...new Set([...(current || "").split(/\s+/).filter(Boolean), token])].join(" ");
}

function enhanceFields() {
  document.querySelectorAll<HTMLElement>(".field").forEach((field) => {
    const controls = field.querySelectorAll<HTMLElement>(
      'input:not([type="hidden"]), textarea, select',
    );
    controls.forEach((control) => {
      if (!control.id) {
        fieldSequence += 1;
        control.id = `minjaz-field-${fieldSequence}`;
      }

      const labels = [...field.querySelectorAll<HTMLLabelElement>("label")];
      const label =
        labels.find((candidate) => candidate.contains(control)) || labels[0];
      const labelText = label?.textContent?.replace(/\s+/g, " ").trim();
      if (label) label.htmlFor = control.id;
      if (labelText && !control.getAttribute("aria-label"))
        control.setAttribute("aria-label", labelText);

      const helper = field.querySelector<HTMLElement>("small");
      if (!helper) return;
      if (!helper.id) helper.id = `${control.id}-description`;
      control.setAttribute(
        "aria-describedby",
        appendToken(control.getAttribute("aria-describedby"), helper.id),
      );
    });
  });
}

/** Adds durable labels and descriptions to calculator fields rendered by any workspace. */
export function AccessibleFieldBehavior() {
  useEffect(() => {
    enhanceFields();
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        record.addedNodes.forEach((node) => {
          if (!(node instanceof HTMLElement)) return;
          if (node.matches(".field") || node.querySelector(".field"))
            enhanceFields();
        });
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, []);

  return null;
}
