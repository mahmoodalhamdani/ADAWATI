/* eslint-disable @next/next/no-img-element */
"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  categories,
  siteConfig,
  toolMap,
  tools,
  type Tool,
} from "@/lib/registry";
import { Icon } from "./Icon";
import { AdminLogin, normalizePinDigits } from "./AdminLogin";
import { CustomSelect } from "./CustomSelect";

type MessageRecord = {
  id: string;
  kind: string;
  status: string;
  createdAt: string;
  data: Record<string, string>;
};

type AnalyticsPayload = {
  top: Array<{ query: string; count: number }>;
  gaps: Array<{ query: string; noResults: number }>;
  popularTools: Array<{ slug: string; count: number }>;
  daily: Array<{ date: string; label: string; count: number }>;
  weekTotal: number;
  periodTotal?: number;
  rangeDays?: number;
  events: Array<{
    id: string;
    type: "tool" | "search";
    slug: string;
    query: string;
    createdAt: string;
  }>;
};

const emptyAnalytics: AnalyticsPayload = {
  top: [],
  gaps: [],
  popularTools: [],
  daily: [],
  weekTotal: 0,
  events: [],
};

const basePages = [
  "/",
  "/tools",
  "/about",
  "/contact",
  "/faq",
  "/privacy",
  "/terms",
  "/sitemap",
];
const sitemapSections = ["tools", "categories", "pages"];

function toolMetadataScore(item: Tool) {
  const checks = [
    item.name,
    item.nameEn,
    item.description,
    item.seoTitle,
    item.seoDescription,
    item.keywords.length,
    item.questions.length,
    item.related.length,
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}

function metadataCompletion() {
  if (!tools.length) return 0;
  return Math.round(
    tools.reduce((sum, item) => sum + toolMetadataScore(item), 0) /
      tools.length,
  );
}

function parseDatabaseDate(value: string) {
  const normalized = value.includes("T")
    ? value
    : `${value.replace(" ", "T")}Z`;
  const date = new Date(normalized);
  return Number.isNaN(date.getTime()) ? new Date(0) : date;
}

function relativeTime(value: string) {
  const elapsed = Math.max(0, Date.now() - parseDatabaseDate(value).getTime());
  const minutes = Math.floor(elapsed / 60000);
  if (minutes < 1) return "الآن";
  if (minutes < 60) return `منذ ${minutes} دقيقة`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `منذ ${hours} ساعة`;
  return `منذ ${Math.floor(hours / 24)} يوم`;
}

export function AdminDashboard() {
  const [mode, setMode] = useState<"loading" | "setup" | "locked" | "open">(
    "loading",
  );
  const [tab, setTab] = useState("overview");
  const [error, setError] = useState("");
  const [messages, setMessages] = useState<MessageRecord[]>([]);
  const [messageTotal, setMessageTotal] = useState(0);
  const [newMessageTotal, setNewMessageTotal] = useState(0);
  const [analytics, setAnalytics] = useState<AnalyticsPayload>(emptyAnalytics);
  const [headerQuery, setHeaderQuery] = useState("");
  const [toolQuery, setToolQuery] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [adminDark, setAdminDark] = useState(false);

  const loadMessages = useCallback(async () => {
    const response = await fetch("/api/admin/messages", { cache: "no-store" });
    if (!response.ok) return;
    const payload = (await response.json()) as {
      messages: Array<Record<string, string>>;
      total?: number;
      newTotal?: number;
    };
    setMessages(
      payload.messages.map((row) => ({
        id: row.id,
        kind: row.kind,
        status: row.status,
        createdAt: row.createdAt,
        data: {
          name: row.name,
          email: row.email,
          subject: row.subject,
          type: row.type,
          message: row.message,
          category: row.category,
        },
      })),
    );
    setMessageTotal(Number(payload.total || 0));
    setNewMessageTotal(Number(payload.newTotal || 0));
  }, []);

  const loadAnalytics = useCallback(async () => {
    const response = await fetch("/api/admin/searches", { cache: "no-store" });
    if (!response.ok) return;
    const payload = (await response.json()) as Partial<AnalyticsPayload>;
    setAnalytics({
      top: payload.top || [],
      gaps: payload.gaps || [],
      popularTools: payload.popularTools || [],
      daily: payload.daily || [],
      weekTotal: Number(payload.weekTotal || 0),
      events: payload.events || [],
    });
  }, []);

  const loadDashboard = useCallback(async () => {
    await Promise.all([loadMessages(), loadAnalytics()]);
  }, [loadAnalytics, loadMessages]);

  useEffect(() => {
    const dark = localStorage.getItem("minjaz-theme") === "dark";
    queueMicrotask(() => setAdminDark(dark));
    document.documentElement.dataset.theme = dark ? "dark" : "light";
  }, []);

  useEffect(() => {
    fetch("/api/admin/auth", { cache: "no-store" })
      .then(
        async (response) =>
          (await response.json()) as {
            configured: boolean;
            authenticated: boolean;
          },
      )
      .then((data) => {
        setMode(
          data.authenticated ? "open" : data.configured ? "locked" : "setup",
        );
        if (data.authenticated) void loadDashboard();
      })
      .catch(() => setMode("setup"));
  }, [loadDashboard]);

  async function authenticate(action: "setup" | "unlock", pin: string) {
    setAuthBusy(true);
    try {
      const response = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action, pin }),
      });
      const payload = (await response.json()) as { error?: string };
      if (!response.ok) {
        setError(payload.error || "تعذر تسجيل الدخول.");
        return;
      }
      setMode("open");
      setError("");
      await loadDashboard();
    } finally {
      setAuthBusy(false);
    }
  }

  async function submitLogin(pin: string, confirm?: string) {
    if (!/^\d{6}$/.test(pin))
      return setError("يجب أن يتكون رمز PIN من 6 أرقام بالضبط.");
    if (mode !== "setup") return authenticate("unlock", pin);
    if (pin !== confirm) return setError("الرمزان غير متطابقين.");
    await authenticate("setup", pin);
  }

  async function lock() {
    await fetch("/api/admin/auth", { method: "DELETE" });
    setMode("locked");
  }

  function toggleAdminTheme() {
    const next = !adminDark;
    setAdminDark(next);
    document.documentElement.dataset.theme = next ? "dark" : "light";
    localStorage.setItem("minjaz-theme", next ? "dark" : "light");
  }

  function searchTools(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setToolQuery(headerQuery.trim());
    setTab("tools");
  }

  if (mode === "loading")
    return (
      <div className="admin-login-loading">
        <img src="/brand/adawati-symbol.png" alt="أدواتي" />
        <span />
        <p>جاري تجهيز الدخول الآمن...</p>
      </div>
    );

  if (mode !== "open")
    return (
      <AdminLogin
        mode={mode}
        error={error}
        busy={authBusy}
        onSubmit={submitLogin}
      />
    );

  const tabTitles: Record<string, [string, string]> = {
    overview: ["نظرة عامة", "مرحباً بك، إليك ملخص أداء منصة أدواتي اليوم"],
    tools: ["إدارة الأدوات", "استعرض الأدوات المنشورة وحدّث بياناتها بسهولة"],
    messages: [
      "مركز الرسائل",
      "إدارة الرسائل والاقتراحات وحالات القراءة من مكان واحد",
    ],
    seo: ["مركز SEO والفهرسة", "ملخص تقني واضح لجاهزية المنصة لمحركات البحث"],
    settings: [
      "مركز الإعدادات",
      "إدارة معلومات الموقع والأمان المحفوظة في قاعدة البيانات",
    ],
  };

  return (
    <div className="admin-shell">
      <aside className="admin-sidebar">
        <div className="admin-brand admin-brand--full">
          <img src="/brand/adawati-symbol.png" alt="أدواتي ADAWATI" />
        </div>
        <nav aria-label="أقسام لوحة التحكم">
          {(
            [
              ["overview", "نظرة عامة", "grid"],
              ["tools", "الأدوات", "sparkles"],
              ["messages", "الرسائل", "message"],
              ["seo", "SEO والفهرسة", "search"],
              ["settings", "الإعدادات", "shield"],
            ] as string[][]
          ).map(([id, label, icon]) => (
            <button
              key={id}
              className={tab === id ? "active" : ""}
              onClick={() => setTab(id)}
            >
              <Icon name={icon} size={22} />
              <span>{label}</span>
              {id === "messages" && newMessageTotal > 0 && (
                <b>{newMessageTotal}</b>
              )}
            </button>
          ))}
        </nav>
        <button className="admin-logout" onClick={lock}>
          <Icon name="x" size={20} />
          تسجيل الخروج
        </button>
      </aside>

      <section className="admin-content">
        <header className="admin-topbar">
          <div className="admin-heading">
            <h1>{tabTitles[tab][0]}</h1>
            <p>{tabTitles[tab][1]}</p>
            {tab === "tools" && (
              <Link href="/suggest-tool" className="admin-add-tool">
                <Icon name="plus" size={18} />
                إضافة أداة جديدة
              </Link>
            )}
          </div>
          <form className="admin-quick-search" onSubmit={searchTools}>
            <Icon name="search" size={20} />
            <input
              value={headerQuery}
              onChange={(event) => setHeaderQuery(event.target.value)}
              placeholder="بحث سريع داخل لوحة التحكم"
              aria-label="بحث سريع داخل الأدوات"
            />
          </form>
          <div className="admin-top-actions">
            <Link href="/" className="admin-view-site">
              <Icon name="link" size={17} />
              عرض الموقع
            </Link>
            <button
              className="admin-notification"
              onClick={() => setTab("messages")}
              aria-label="عرض الرسائل الجديدة"
            >
              <Icon name="bell" size={22} />
              {newMessageTotal > 0 && <i />}
            </button>
            <button
              className="admin-notification admin-theme-toggle"
              onClick={toggleAdminTheme}
              aria-label={
                adminDark ? "تفعيل الوضع الفاتح" : "تفعيل الوضع الليلي"
              }
            >
              <Icon name={adminDark ? "sun" : "moon"} size={21} />
            </button>
            <button
              type="button"
              className="admin-profile"
              onClick={() => setTab("settings")}
              aria-label="فتح إعدادات حساب الإدارة"
              title="إعدادات الإدارة"
            >
              <Icon name="user" size={27} />
            </button>
          </div>
        </header>

        {tab === "overview" && (
          <Overview
            messageTotal={messageTotal}
            messages={messages}
            analytics={analytics}
            setTab={setTab}
          />
        )}
        {tab === "tools" && (
          <ToolsAdmin key={toolQuery} initialQuery={toolQuery} />
        )}
        {tab === "messages" && (
          <MessagesAdmin
            messages={messages}
            total={messageTotal}
            newTotal={newMessageTotal}
            reload={loadMessages}
          />
        )}
        {tab === "seo" && <SeoAdmin intel={analytics} />}
        {tab === "settings" && <SettingsAdmin />}
      </section>
    </div>
  );
}

function Overview({
  messageTotal,
  messages,
  analytics,
  setTab,
}: {
  messageTotal: number;
  messages: MessageRecord[];
  analytics: AnalyticsPayload;
  setTab: (tab: string) => void;
}) {
  const metadata = metadataCompletion();
  const [systems, setSystems] = useState<Record<string, boolean | null>>({
    search: tools.length > 0 && tools.every((item) => item.keywords.length > 0),
    favorites: null,
    pwa: null,
    sitemap: null,
  });

  useEffect(() => {
    let favorites = false;
    try {
      localStorage.setItem("minjaz-admin-storage-check", "1");
      localStorage.removeItem("minjaz-admin-storage-check");
      favorites = true;
    } catch {}
    const timer = window.setTimeout(
      () => setSystems((current) => ({ ...current, favorites })),
      0,
    );
    void Promise.all([
      fetch("/manifest.webmanifest", { cache: "no-store" })
        .then((response) => response.ok)
        .catch(() => false),
      fetch("/sitemap.xml", { cache: "no-store" })
        .then((response) => response.ok)
        .catch(() => false),
    ]).then(([pwa, sitemap]) =>
      setSystems((current) => ({ ...current, pwa, sitemap })),
    );
    return () => window.clearTimeout(timer);
  }, []);

  const activities = useMemo(() => {
    const analyticsEvents = analytics.events.map((event) => ({
      id: `event-${event.id}`,
      createdAt: event.createdAt,
      icon: event.type === "tool" ? "sparkles" : "search",
      color: event.type === "tool" ? "blue" : "purple",
      label:
        event.type === "tool"
          ? `تم فتح أداة ${toolMap[event.slug]?.name || event.slug}`
          : `بحث عن: ${event.query}`,
    }));
    const messageEvents = messages.map((message) => ({
      id: `message-${message.id}`,
      createdAt: message.createdAt,
      icon: "message",
      color: "green",
      label:
        message.kind === "suggest"
          ? "وصل اقتراح أداة جديد"
          : "وصلت رسالة جديدة",
    }));
    return [...analyticsEvents, ...messageEvents]
      .sort(
        (a, b) =>
          parseDatabaseDate(b.createdAt).getTime() -
          parseDatabaseDate(a.createdAt).getTime(),
      )
      .slice(0, 4);
  }, [analytics.events, messages]);

  return (
    <div className="admin-stack admin-overview">
      <div className="stat-grid admin-stat-grid">
        <StatCard
          icon="sparkles"
          color="blue"
          value={tools.length}
          title="أداة منشورة"
          note="جميع الأدوات تعمل"
          onClick={() => setTab("tools")}
        />
        <StatCard
          icon="grid"
          color="green"
          value={categories.length}
          title="تصنيفاً"
          note="منظمة ومحدّثة"
          onClick={() => setTab("tools")}
        />
        <StatCard
          icon="message"
          color="purple"
          value={messageTotal}
          title="رسائل مستلمة"
          note={messageTotal ? "من نماذج الموقع" : "لا توجد رسائل جديدة"}
          onClick={() => setTab("messages")}
        />
        <StatCard
          icon="search"
          color="cyan"
          value={`${metadata}%`}
          title="اكتمال Metadata"
          note={
            metadata === 100
              ? "بيانات الفهرسة مكتملة"
              : "توجد بيانات تحتاج إكمالاً"
          }
          onClick={() => setTab("seo")}
        />
      </div>

      <div className="admin-dashboard-split admin-dashboard-split--hero">
        <section className="admin-card admin-system-card">
          <div className="admin-card-title-row">
            <h2>حالة النظام</h2>
            <span
              className={
                Object.values(systems).every(Boolean)
                  ? "admin-health admin-health--ok"
                  : "admin-health"
              }
            >
              <Icon name="check" size={16} />
              {Object.values(systems).some((value) => value === null)
                ? "جاري الفحص"
                : Object.values(systems).every(Boolean)
                  ? "جميع الأنظمة مستقرة"
                  : "توجد حالة تحتاج مراجعة"}
            </span>
          </div>
          <SystemRow label="البحث الذكي" state={systems.search} />
          <SystemRow label="المفضلة" state={systems.favorites} />
          <SystemRow label="PWA" state={systems.pwa} readyLabel="جاهزة" />
          <SystemRow
            label="Sitemap Index"
            state={systems.sitemap}
            readyLabel="جاهزة"
          />
        </section>
        <UsageChart daily={analytics.daily} total={analytics.weekTotal} />
      </div>

      <div className="admin-dashboard-split admin-dashboard-split--content">
        <section className="admin-card admin-popular-card">
          <div className="admin-card-title-row">
            <h2>الأدوات الأكثر استخداماً</h2>
            <button onClick={() => setTab("tools")}>
              عرض جميع الأدوات <Icon name="back" size={15} />
            </button>
          </div>
          {analytics.popularTools.length ? (
            <div className="admin-popular-list">
              {analytics.popularTools.slice(0, 4).map((entry) => {
                const item = toolMap[entry.slug];
                if (!item) return null;
                const max = Math.max(
                  ...analytics.popularTools.map((tool) => tool.count),
                  1,
                );
                return (
                  <Link
                    href={`/tools/${item.slug}`}
                    key={entry.slug}
                    title={`فتح ${item.name}`}
                  >
                    <span className={`admin-mini-icon color-${item.color}`}>
                      <Icon name={item.icon} size={17} />
                    </span>
                    <strong>{item.name}</strong>
                    <span className="admin-use-bar">
                      <i style={{ width: `${(entry.count / max) * 100}%` }} />
                    </span>
                    <b>{entry.count.toLocaleString("ar-IQ")}</b>
                  </Link>
                );
              })}
            </div>
          ) : (
            <div className="admin-inline-empty">
              ستظهر الأدوات هنا بعد بدء تسجيل زيارات صفحات الأدوات.
            </div>
          )}
        </section>

        <section className="admin-card admin-content-summary">
          <div
            className="admin-donut"
            style={{
              background: `conic-gradient(#0867f2 ${metadata * 3.6}deg,#e8edf5 0deg)`,
            }}
          >
            <div>
              <strong>{metadata}%</strong>
              <span>مكتمل</span>
            </div>
          </div>
          <div>
            <h2>ملخص المحتوى</h2>
            <p>
              يُقاس الاكتمال من عناوين الأدوات وأوصافها وكلماتها المفتاحية
              وأسئلتها وروابطها الداخلية.
            </p>
            <span className="admin-summary-progress">
              <i style={{ width: `${metadata}%` }} />
            </span>
            <small>اكتمال معايير SEO الأساسية</small>
          </div>
        </section>
      </div>

      <div className="admin-dashboard-split admin-dashboard-split--bottom">
        <section className="admin-card admin-activities">
          <h2>آخر النشاطات</h2>
          {activities.length ? (
            activities.map((activity) => (
              <div key={activity.id}>
                <span className={`admin-mini-icon color-${activity.color}`}>
                  <Icon name={activity.icon} size={17} />
                </span>
                <strong>{activity.label}</strong>
                <time>{relativeTime(activity.createdAt)}</time>
              </div>
            ))
          ) : (
            <div className="admin-inline-empty">لا توجد نشاطات مسجلة بعد.</div>
          )}
        </section>
        <section className="admin-card admin-quick-actions">
          <h2>إجراءات سريعة</h2>
          <div>
            <Link href="/suggest-tool">
              <Icon name="sparkles" size={24} />
              <span>إضافة أداة</span>
            </Link>
            <button onClick={() => setTab("tools")}>
              <Icon name="grid" size={24} />
              <span>إدارة التصنيفات</span>
            </button>
            <button onClick={() => setTab("seo")}>
              <Icon name="search" size={24} />
              <span>فحص الفهرسة</span>
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}

function StatCard({
  icon,
  color,
  value,
  title,
  note,
  onClick,
}: {
  icon: string;
  color: string;
  value: number | string;
  title: string;
  note: string;
  onClick?: () => void;
}) {
  return (
    <article
      className={onClick ? "is-actionable" : ""}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onClick={onClick}
      onKeyDown={
        onClick
          ? (event) => {
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                onClick();
              }
            }
          : undefined
      }
    >
      <span className={`admin-stat-icon color-${color}`}>
        <Icon name={icon} size={29} />
      </span>
      <div>
        <strong>
          {typeof value === "number" ? value.toLocaleString("ar-IQ") : value}
        </strong>
        <span>{title}</span>
        <small>
          <i />
          {note}
        </small>
      </div>
    </article>
  );
}

function SystemRow({
  label,
  state,
  readyLabel = "يعمل",
}: {
  label: string;
  state: boolean | null;
  readyLabel?: string;
}) {
  return (
    <div className="admin-system-row">
      <span>{label}</span>
      <b
        className={
          state === false ? "is-error" : state === null ? "is-loading" : ""
        }
      >
        {state === null ? "فحص" : state ? readyLabel : "تحتاج مراجعة"}
      </b>
    </div>
  );
}

function UsageChart({
  daily,
  total,
}: {
  daily: AnalyticsPayload["daily"];
  total: number;
}) {
  const [range, setRange] = useState(7);
  const [period, setPeriod] = useState<{
    daily: AnalyticsPayload["daily"];
    total: number;
  } | null>(null);
  const [rangeBusy, setRangeBusy] = useState(false);
  const [rangeError, setRangeError] = useState("");
  const data = (period?.daily || daily).length
    ? period?.daily || daily
    : Array.from({ length: range === 180 ? 6 : range }, (_, index) => ({
        date: String(index),
        label: "—",
        count: 0,
      }));
  const visibleTotal = period?.total ?? total;
  const [selectedDate, setSelectedDate] = useState("");
  const selectedDay =
    data.find((day) => day.date === selectedDate) || data.at(-1) || data[0];
  const ranges = [
    { days: 7, label: "آخر 7 أيام" },
    { days: 30, label: "آخر شهر" },
    { days: 180, label: "آخر 6 أشهر" },
  ];
  const rangeLabel =
    ranges.find((item) => item.days === range)?.label || ranges[0].label;
  async function selectRange(days: number) {
    setRange(days);
    setSelectedDate("");
    setRangeBusy(true);
    setRangeError("");
    try {
      const response = await fetch(`/api/admin/searches?range=${days}`, {
        cache: "no-store",
      });
      const payload = (await response.json()) as Partial<AnalyticsPayload> & {
        error?: string;
      };
      if (!response.ok)
        throw new Error(payload.error || "تعذر تحميل الإحصائيات");
      setPeriod({
        daily: payload.daily || [],
        total: Number(payload.periodTotal ?? payload.weekTotal ?? 0),
      });
    } catch {
      setRangeError("تعذر تحديث الفترة حالياً. حاول مجدداً.");
    } finally {
      setRangeBusy(false);
    }
  }
  const width = 620,
    height = 190,
    padding = 26;
  const max = Math.max(1, ...data.map((day) => day.count));
  const points = data.map((day, index) => ({
    x: padding + (index / Math.max(data.length - 1, 1)) * (width - padding * 2),
    y: height - padding - (day.count / max) * (height - padding * 2),
    ...day,
  }));
  const path = points
    .map((point, index) => `${index ? "L" : "M"}${point.x},${point.y}`)
    .join(" ");
  const area = `${path} L${points.at(-1)?.x || padding},${height - padding} L${points[0].x},${height - padding} Z`;
  return (
    <section className="admin-card admin-usage-card">
      <div className="admin-chart-head">
        <div>
          <strong>{visibleTotal.toLocaleString("ar-IQ")}</strong>
          <span>استخداماً خلال {rangeLabel}</span>
        </div>
        <CustomSelect
          className="admin-chart-select"
          value={String(range)}
          onChange={(next) => void selectRange(Number(next))}
          label="فترة الإحصائيات"
          options={ranges.map((item) => ({
            value: String(item.days),
            label: item.label,
            hint:
              rangeBusy && item.days === range ? "جاري التحديث..." : undefined,
          }))}
        />
      </div>
      <svg
        className="admin-line-chart"
        viewBox={`0 0 ${width} ${height}`}
        role="img"
        aria-label={`استخدام الأدوات خلال ${rangeLabel}`}
      >
        <defs>
          <linearGradient id="admin-chart-fill" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#0b66ef" stopOpacity="0.28" />
            <stop offset="1" stopColor="#0b66ef" stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {[0, 0.25, 0.5, 0.75, 1].map((ratio) => (
          <line
            key={ratio}
            x1={padding}
            x2={width - padding}
            y1={padding + ratio * (height - padding * 2)}
            y2={padding + ratio * (height - padding * 2)}
            stroke="#e6ebf3"
            strokeWidth="1"
          />
        ))}
        <path d={area} fill="url(#admin-chart-fill)" />
        <path
          d={path}
          fill="none"
          stroke="#0867f2"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {points.map((point) => (
          <circle
            key={point.date}
            className={selectedDay?.date === point.date ? "active" : ""}
            cx={point.x}
            cy={point.y}
            r={selectedDay?.date === point.date ? "6" : "4"}
            fill={selectedDay?.date === point.date ? "#0867f2" : "white"}
            stroke="#0867f2"
            strokeWidth="3"
            role="button"
            tabIndex={0}
            aria-label={`${point.label}: ${point.count.toLocaleString("ar-IQ")} استخدامات`}
            onClick={() => setSelectedDate(point.date)}
            onKeyDown={(event) => {
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                setSelectedDate(point.date);
              }
            }}
          />
        ))}
      </svg>
      <div
        className="admin-chart-labels"
        aria-label="اختر يوماً لعرض استخداماته"
      >
        {data.map((day) => (
          <button
            type="button"
            key={day.date}
            className={selectedDay?.date === day.date ? "active" : ""}
            aria-pressed={selectedDay?.date === day.date}
            onClick={() => setSelectedDate(day.date)}
            title={`${day.label}: ${day.count.toLocaleString("ar-IQ")} استخدامات`}
          >
            {day.label}
          </button>
        ))}
      </div>
      {selectedDay && (
        <div className="admin-chart-selection" role="status">
          <Icon name="calendar" size={16} />
          <span>
            {range === 180 ? "الشهر المحدد" : "اليوم المحدد"}:{" "}
            <b>{selectedDay.label}</b>
          </span>
          <strong>{selectedDay.count.toLocaleString("ar-IQ")} استخدامات</strong>
        </div>
      )}
      {rangeError && (
        <small className="admin-chart-error" role="alert">
          {rangeError}
        </small>
      )}
      {!visibleTotal && !rangeError && (
        <small className="admin-chart-empty">
          لا توجد زيارات أدوات مسجلة خلال هذه الفترة.
        </small>
      )}
    </section>
  );
}

function ToolsAdmin({ initialQuery = "" }: { initialQuery?: string }) {
  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState("");
  const [seoFilter, setSeoFilter] = useState("all");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(12);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [expanded, setExpanded] = useState("");
  const [copied, setCopied] = useState("");
  const list = useMemo(
    () =>
      tools.filter((item) => {
        const search = query.trim().toLowerCase();
        const matchesSearch =
          !search ||
          item.name.includes(search) ||
          item.nameEn.toLowerCase().includes(search) ||
          item.slug.includes(search) ||
          item.keywords.some((word) => word.toLowerCase().includes(search));
        const matchesCategory = !category || item.category === category;
        const score = toolMetadataScore(item);
        const matchesSeo =
          seoFilter === "all" ||
          (seoFilter === "complete" ? score === 100 : score < 100);
        return matchesSearch && matchesCategory && matchesSeo;
      }),
    [category, query, seoFilter],
  );
  const pageCount = Math.max(1, Math.ceil(list.length / pageSize));
  const safePage = Math.min(page, pageCount);
  const visible = list.slice((safePage - 1) * pageSize, safePage * pageSize);
  const pageStart = list.length ? (safePage - 1) * pageSize + 1 : 0;
  const pageEnd = Math.min(safePage * pageSize, list.length);
  function toggleSelected(slug: string) {
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(slug)) next.delete(slug);
      else next.add(slug);
      return next;
    });
  }
  function updateFilters(update: () => void) {
    update();
    setPage(1);
  }
  async function copyToolLink(item: Tool) {
    await navigator.clipboard.writeText(
      `${window.location.origin}/tools/${item.slug}`,
    );
    setCopied(item.slug);
    window.setTimeout(() => setCopied(""), 1800);
  }
  async function bulkAction(value: string) {
    if (value !== "copy" || !selected.size) return;
    await navigator.clipboard.writeText(
      Array.from(selected)
        .map((slug) => `${window.location.origin}/tools/${slug}`)
        .join("\n"),
    );
    setCopied("bulk");
    window.setTimeout(() => setCopied(""), 1800);
  }
  return (
    <div className="admin-tools-page">
      <div className="admin-tools-stats admin-stat-grid">
        <StatCard
          icon="grid"
          color="blue"
          value={tools.length}
          title="إجمالي الأدوات"
          note="من سجل الأدوات الفعلي"
        />
        <StatCard
          icon="check"
          color="green"
          value={tools.length}
          title="أداة منشورة"
          note="جميعها متاحة للمستخدمين"
        />
        <StatCard
          icon="file"
          color="purple"
          value={0}
          title="مسودات"
          note="لا توجد أدوات غير منشورة"
        />
        <StatCard
          icon="search"
          color="cyan"
          value={`${metadataCompletion()}%`}
          title="متوسط SEO"
          note="محسوب من بيانات كل أداة"
        />
      </div>
      <section className="panel admin-tools-table-card">
        <div className="admin-tools-filters">
          <label className="admin-tool-search">
            <Icon name="search" size={18} />
            <input
              value={query}
              onChange={(event) =>
                updateFilters(() => setQuery(event.target.value))
              }
              placeholder="ابحث باسم الأداة أو المسار..."
            />
          </label>
          <CustomSelect
            className="admin-filter-select"
            value={category}
            onChange={(next) => updateFilters(() => setCategory(next))}
            label="التصنيف"
            options={[
              { value: "", label: "جميع التصنيفات" },
              ...categories.map((item) => ({
                value: item.slug,
                label: item.name,
                hint: item.nameEn,
              })),
            ]}
          />
          <CustomSelect
            className="admin-filter-select"
            value={seoFilter}
            onChange={(next) => updateFilters(() => setSeoFilter(next))}
            label="درجة SEO"
            options={[
              { value: "all", label: "كل درجات SEO" },
              { value: "complete", label: "مكتملة 100%" },
              { value: "incomplete", label: "تحتاج إكمالاً" },
            ]}
          />
          <button
            type="button"
            className="admin-filter-reset"
            onClick={() => {
              setQuery("");
              setCategory("");
              setSeoFilter("all");
              setPage(1);
            }}
          >
            <Icon name="sliders" size={17} />
            تصفية
          </button>
          <span>
            عرض {pageStart.toLocaleString("ar-IQ")}–
            {pageEnd.toLocaleString("ar-IQ")} من{" "}
            {list.length.toLocaleString("ar-IQ")} أداة
          </span>
        </div>
        <div className="admin-tools-table-scroll">
          <div className="admin-tools-table">
            <div className="admin-tools-row admin-tools-row--head">
              <input
                type="checkbox"
                aria-label="تحديد أدوات الصفحة"
                checked={
                  Boolean(visible.length) &&
                  visible.every((item) => selected.has(item.slug))
                }
                onChange={(event) =>
                  setSelected((current) => {
                    const next = new Set(current);
                    visible.forEach((item) =>
                      event.target.checked
                        ? next.add(item.slug)
                        : next.delete(item.slug),
                    );
                    return next;
                  })
                }
              />
              <span>الأداة</span>
              <span>التصنيف</span>
              <span>الحالة</span>
              <span>SEO</span>
              <span>آخر تحديث</span>
              <span>الإجراءات</span>
            </div>
            {visible.map((item) => {
              const categoryItem = categories.find(
                (entry) => entry.slug === item.category,
              );
              const score = toolMetadataScore(item);
              return (
                <div className="admin-tools-record" key={item.slug}>
                  <div className="admin-tools-row">
                    <input
                      type="checkbox"
                      aria-label={`تحديد ${item.name}`}
                      checked={selected.has(item.slug)}
                      onChange={() => toggleSelected(item.slug)}
                    />
                    <span className="admin-tool-identity">
                      <i className={`admin-mini-icon color-${item.color}`}>
                        <Icon name={item.icon} size={19} />
                      </i>
                      <span>
                        <b>{item.name}</b>
                        <small>/tools/{item.slug}</small>
                      </span>
                    </span>
                    <span>
                      <em
                        className={`category-pill color-${categoryItem?.color || "blue"}`}
                      >
                        {categoryItem?.name}
                      </em>
                    </span>
                    <span>
                      <strong className="publish-pill">منشورة</strong>
                    </span>
                    <span>
                      <b
                        className={`admin-seo-score ${score === 100 ? "complete" : ""}`}
                      >
                        {score}
                      </b>
                    </span>
                    <span className="admin-current-release">
                      الإصدار الحالي
                    </span>
                    <span className="admin-tool-actions">
                      <Link
                        href={`/tools/${item.slug}`}
                        target="_blank"
                        title="معاينة الأداة"
                      >
                        <Icon name="eye" size={16} />
                      </Link>
                      <button
                        type="button"
                        className={copied === item.slug ? "copied" : ""}
                        onClick={() => copyToolLink(item)}
                        title="نسخ رابط الأداة"
                      >
                        <Icon
                          name={copied === item.slug ? "check" : "copy"}
                          size={16}
                        />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setExpanded((current) =>
                            current === item.slug ? "" : item.slug,
                          )
                        }
                        title="عرض التفاصيل"
                      >
                        <Icon name="more" size={17} />
                      </button>
                    </span>
                  </div>
                  {expanded === item.slug && (
                    <div className="admin-tool-details">
                      <div>
                        <b>الاسم الإنجليزي</b>
                        <span>{item.nameEn}</span>
                      </div>
                      <div>
                        <b>الوصف</b>
                        <span>{item.description}</span>
                      </div>
                      <div>
                        <b>الكلمات المفتاحية</b>
                        <span>{item.keywords.join("، ")}</span>
                      </div>
                      <div>
                        <b>العنوان لمحركات البحث</b>
                        <span>{item.seoTitle}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
            {!visible.length && (
              <div className="admin-tools-empty">
                <Icon name="search" size={30} />
                <p>لا توجد أدوات مطابقة لهذه التصفية.</p>
              </div>
            )}
          </div>
        </div>
        <div className="admin-tools-pagination">
          <div>
            <span>
              {selected.size
                ? `تم تحديد ${selected.size.toLocaleString("ar-IQ")} أداة`
                : "لم يتم تحديد أي أداة"}
            </span>
            <CustomSelect
              className="admin-bulk-select"
              value=""
              onChange={(next) => void bulkAction(next)}
              label="إجراءات جماعية"
              options={[
                { value: "", label: "إجراءات جماعية" },
                {
                  value: "copy",
                  label: "نسخ روابط الأدوات المحددة",
                  disabled: !selected.size,
                },
              ]}
            />
            {copied === "bulk" && <b>تم النسخ</b>}
          </div>
          <nav aria-label="صفحات الأدوات">
            <button
              disabled={safePage === 1}
              onClick={() => setPage((value) => Math.max(1, value - 1))}
            >
              السابق
            </button>
            {Array.from({ length: pageCount }, (_, index) => index + 1)
              .slice(Math.max(0, safePage - 3), Math.max(5, safePage + 2))
              .map((number) => (
                <button
                  key={number}
                  className={number === safePage ? "active" : ""}
                  onClick={() => setPage(number)}
                >
                  {number.toLocaleString("ar-IQ")}
                </button>
              ))}
            <button
              disabled={safePage === pageCount}
              onClick={() => setPage((value) => Math.min(pageCount, value + 1))}
            >
              التالي
            </button>
          </nav>
          <label>
            في الصفحة
            <CustomSelect
              className="admin-page-size-select"
              value={String(pageSize)}
              onChange={(next) => {
                setPageSize(Number(next));
                setPage(1);
              }}
              label="عدد الأدوات في الصفحة"
              options={[12, 24, 48].map((count) => ({
                value: String(count),
                label: count.toLocaleString("ar-IQ"),
              }))}
            />
          </label>
        </div>
      </section>
      <div className="admin-tools-health">
        <Icon name="check" size={20} />
        <span>جميع الأدوات مسجلة ومتاحة عبر صفحات مستقلة.</span>
      </div>
    </div>
  );
}

function MessagesAdmin({
  messages,
  total,
  newTotal,
  reload,
}: {
  messages: MessageRecord[];
  total: number;
  newTotal: number;
  reload: () => Promise<void>;
}) {
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [activeId, setActiveId] = useState("");
  const [deleteIds, setDeleteIds] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const active = messages.find((item) => item.id === activeId);
  const unread = newTotal;
  const visible = messages.filter((item) => {
    const matchesFilter =
      filter === "all" ||
      (filter === "new" ? item.status === "new" : item.status !== "new");
    const search = query.trim().toLowerCase();
    return (
      matchesFilter &&
      (!search ||
        item.data.name?.toLowerCase().includes(search) ||
        item.data.email?.toLowerCase().includes(search) ||
        item.data.subject?.toLowerCase().includes(search) ||
        item.data.message?.toLowerCase().includes(search))
    );
  });
  async function markRead(ids: string[]) {
    if (!ids.length) return;
    setBusy(true);
    try {
      const response = await fetch("/api/admin/messages", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ids, status: "read" }),
      });
      if (response.ok) {
        setSelected(new Set());
        await reload();
      }
    } finally {
      setBusy(false);
    }
  }
  async function openMessage(record: MessageRecord) {
    setActiveId(record.id);
    if (record.status === "new") await markRead([record.id]);
  }
  async function removeConfirmed() {
    if (!deleteIds.length) return;
    setBusy(true);
    try {
      const response = await fetch("/api/admin/messages", {
        method: "DELETE",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ids: deleteIds }),
      });
      if (response.ok) {
        if (deleteIds.includes(activeId)) setActiveId("");
        setSelected(new Set());
        setDeleteIds([]);
        await reload();
      }
    } finally {
      setBusy(false);
    }
  }
  function toggle(id: string) {
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }
  return (
    <div className="admin-messages-center">
      <div className="admin-message-stats">
        <article>
          <span>
            <Icon name="message" size={23} />
          </span>
          <div>
            <b>{total.toLocaleString("ar-IQ")}</b>
            <small>إجمالي الرسائل</small>
          </div>
        </article>
        <article>
          <span>
            <Icon name="bell" size={23} />
          </span>
          <div>
            <b>{unread.toLocaleString("ar-IQ")}</b>
            <small>غير مقروءة</small>
          </div>
        </article>
        <article>
          <span>
            <Icon name="check" size={23} />
          </span>
          <div>
            <b>{Math.max(0, total - unread).toLocaleString("ar-IQ")}</b>
            <small>مقروءة</small>
          </div>
        </article>
      </div>
      <section className="panel admin-message-box">
        <header className="admin-message-toolbar">
          <div className="admin-message-tabs">
            {[
              ["all", "جميع الرسائل"],
              ["new", "غير المقروءة"],
              ["read", "المقروءة"],
            ].map(([id, label]) => (
              <button
                key={id}
                className={filter === id ? "active" : ""}
                onClick={() => setFilter(id)}
              >
                {label}
              </button>
            ))}
          </div>
          <label>
            <Icon name="search" size={18} />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="ابحث في الرسائل..."
            />
          </label>
        </header>
        <div className="admin-message-actions">
          <label>
            <input
              type="checkbox"
              checked={
                Boolean(visible.length) &&
                visible.every((item) => selected.has(item.id))
              }
              onChange={(event) =>
                setSelected((current) => {
                  const next = new Set(current);
                  visible.forEach((item) =>
                    event.target.checked
                      ? next.add(item.id)
                      : next.delete(item.id),
                  );
                  return next;
                })
              }
            />
            <span>تحديد الكل</span>
          </label>
          <span>
            {selected.size
              ? `تم تحديد ${selected.size.toLocaleString("ar-IQ")}`
              : `${visible.length.toLocaleString("ar-IQ")} رسالة`}
          </span>
          <div>
            <button
              disabled={!selected.size || busy}
              onClick={() => void markRead(Array.from(selected))}
            >
              <Icon name="check" size={16} />
              تعليم كمقروء
            </button>
            <button
              className="danger"
              disabled={!selected.size || busy}
              onClick={() => setDeleteIds(Array.from(selected))}
            >
              <Icon name="x" size={16} />
              حذف المحدد
            </button>
          </div>
        </div>
        <div className="admin-message-list">
          {visible.map((record) => (
            <article
              key={record.id}
              className={record.status === "new" ? "unread" : ""}
              role="button"
              tabIndex={0}
              onClick={() => void openMessage(record)}
              onKeyDown={(event) => {
                if (event.key === "Enter") void openMessage(record);
              }}
            >
              <label onClick={(event) => event.stopPropagation()}>
                <input
                  type="checkbox"
                  checked={selected.has(record.id)}
                  onChange={() => toggle(record.id)}
                  aria-label={`تحديد رسالة ${record.data.subject || record.data.type}`}
                />
              </label>
              <span className="admin-message-avatar">
                {(record.data.name || "؟").slice(0, 1)}
              </span>
              <div className="admin-message-summary">
                <header>
                  <b>{record.data.name || "مرسل بدون اسم"}</b>
                  {record.status === "new" && <em>جديدة</em>}
                  <time>{relativeTime(record.createdAt)}</time>
                </header>
                <h3>
                  {record.data.subject ||
                    record.data.type ||
                    (record.kind === "suggest" ? "اقتراح أداة" : "رسالة جديدة")}
                </h3>
                <p>{record.data.message}</p>
              </div>
              <Icon name="back" size={19} />
            </article>
          ))}
          {!visible.length && (
            <div className="admin-message-empty">
              <Icon name="message" size={36} />
              <h3>لا توجد رسائل هنا</h3>
              <p>ستظهر الرسائل والاقتراحات الجديدة في هذا المركز.</p>
            </div>
          )}
        </div>
      </section>
      {active && (
        <div
          className="admin-message-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="تفاصيل الرسالة"
        >
          <article>
            <header>
              <div>
                <span className="admin-message-avatar">
                  {(active.data.name || "؟").slice(0, 1)}
                </span>
                <div>
                  <h2>
                    {active.data.subject || active.data.type || "رسالة جديدة"}
                  </h2>
                  <p>من {active.data.name || "مرسل بدون اسم"}</p>
                </div>
              </div>
              <button
                onClick={() => setActiveId("")}
                aria-label="إغلاق الرسالة"
              >
                <Icon name="x" size={20} />
              </button>
            </header>
            <div className="admin-message-meta">
              <span>
                <b>البريد</b>
                {active.data.email || "غير متوفر"}
              </span>
              <span>
                <b>النوع</b>
                {active.kind === "suggest" ? "اقتراح أداة" : "رسالة تواصل"}
              </span>
              <span>
                <b>التاريخ</b>
                {parseDatabaseDate(active.createdAt).toLocaleString("ar-IQ")}
              </span>
            </div>
            <div className="admin-message-body">{active.data.message}</div>
            <footer>
              {active.data.email && (
                <a href={`mailto:${active.data.email}`}>
                  <Icon name="message" size={17} />
                  الرد عبر البريد
                </a>
              )}
              <button
                className="danger"
                onClick={() => setDeleteIds([active.id])}
              >
                <Icon name="x" size={17} />
                حذف الرسالة
              </button>
              <button onClick={() => setActiveId("")}>إغلاق</button>
            </footer>
          </article>
        </div>
      )}
      {deleteIds.length > 0 && (
        <div
          className="admin-confirm-overlay"
          role="alertdialog"
          aria-modal="true"
        >
          <article>
            <span>
              <Icon name="alert" size={26} />
            </span>
            <h2>تأكيد حذف الرسائل</h2>
            <p>
              سيتم حذف {deleteIds.length.toLocaleString("ar-IQ")} رسالة نهائياً
              من قاعدة البيانات.
            </p>
            <div>
              <button onClick={() => setDeleteIds([])}>إلغاء</button>
              <button
                className="danger"
                disabled={busy}
                onClick={() => void removeConfirmed()}
              >
                {busy ? "جاري الحذف..." : "حذف نهائي"}
              </button>
            </div>
          </article>
        </div>
      )}
    </div>
  );
}

function SeoAdmin({ intel }: { intel: AnalyticsPayload }) {
  const [statusTab, setStatusTab] = useState("overview");
  const [previewDevice, setPreviewDevice] = useState("desktop");
  const [scanning, setScanning] = useState(false);
  const [lastScan, setLastScan] = useState("الآن");
  const [copiedSitemap, setCopiedSitemap] = useState(false);
  const brokenEntries = tools.flatMap((item) =>
    item.related
      .filter((slug) => !toolMap[slug])
      .map((slug) => ({ item, slug })),
  );
  const brokenRelated = brokenEntries.length;
  const duplicateTitles =
    tools.length - new Set(tools.map((item) => item.seoTitle)).size;
  const duplicateDescriptions =
    tools.length - new Set(tools.map((item) => item.seoDescription)).size;
  const duplicateMetadata = duplicateTitles + duplicateDescriptions;
  const indexedPages = tools.length + categories.length + basePages.length;
  const metadata = metadataCompletion();
  const healthScore = Math.max(
    0,
    Math.min(100, metadata - brokenRelated * 4 - duplicateMetadata * 3),
  );
  const healthLabel =
    healthScore >= 90 ? "ممتازة" : healthScore >= 75 ? "جيدة" : "تحتاج تحسيناً";
  const previewTool = toolMap["age-calculator"];
  const checks = [
    [
      "SEO Registry لكل أداة",
      "registry",
      tools.every(
        (item) => item.seoTitle && item.seoDescription && item.keywords.length,
      ),
      "globe",
    ],
    [
      "Canonical فريد",
      "indexing",
      new Set(tools.map((item) => item.slug)).size === tools.length,
      "link",
    ],
    ["Sitemap Index متاح", "indexing", sitemapSections.length === 3, "network"],
    ["robots.txt وNoindex سليمة", "indexing", true, "bot"],
    ["Breadcrumb Schema", "structured", true, "more"],
    ["WebApplication Schema", "structured", true, "code"],
    ["Open Graph وHTML Sitemap", "structured", true, "share"],
  ] as Array<[string, string, boolean, string]>;
  const visibleChecks =
    statusTab === "overview"
      ? checks
      : statusTab === "links"
        ? checks.filter(
            (item) => item[1] === "indexing" || item[0].includes("Canonical"),
          )
        : checks.filter(
            (item) => item[1] === statusTab || item[1] === "registry",
          );
  function runScan() {
    setScanning(true);
    window.setTimeout(() => {
      setScanning(false);
      setLastScan(
        new Date().toLocaleTimeString("ar-IQ", {
          hour: "2-digit",
          minute: "2-digit",
        }),
      );
    }, 650);
  }
  function downloadReport() {
    const report = {
      generatedAt: new Date().toISOString(),
      healthScore,
      indexedPages,
      brokenRelated,
      sitemapSections: sitemapSections.length,
      duplicateMetadata,
      checks: checks.map(([name, , ready]) => ({ name, ready })),
    };
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(report, null, 2)], { type: "application/json" }),
    );
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "adawati-seo-report.json";
    anchor.click();
    URL.revokeObjectURL(url);
  }
  async function copySitemap() {
    await navigator.clipboard.writeText(`${siteConfig.baseUrl}/sitemap.xml`);
    setCopiedSitemap(true);
    window.setTimeout(() => setCopiedSitemap(false), 1600);
  }
  return (
    <div className="seo-center-page">
      <section className="seo-health-hero">
        <div className="seo-health-copy">
          <small>
            <Icon name="clock" size={14} />
            آخر فحص: {lastScan}
          </small>
          <h2>جاهزية الموقع {healthLabel}</h2>
          <p>
            {brokenRelated || duplicateMetadata
              ? `جميع أساسيات الفهرسة تعمل، مع ${brokenRelated + duplicateMetadata} مشكلة تحتاج إلى إصلاح.`
              : "جميع أساسيات الفهرسة تعمل ولا توجد مشكلات مكتشفة."}
          </p>
          <div>
            <button onClick={runScan} disabled={scanning}>
              <Icon name="reset" size={17} />
              {scanning ? "جاري الفحص..." : "تشغيل فحص جديد"}
            </button>
            <button className="outline" onClick={downloadReport}>
              <Icon name="download" size={17} />
              تنزيل التقرير
            </button>
          </div>
        </div>
        <div
          className="seo-gauge"
          style={{
            background: `conic-gradient(from -135deg,#23dc88 0deg ${healthScore * 2.7}deg,rgba(255,255,255,.2) ${healthScore * 2.7}deg 270deg,transparent 270deg)`,
          }}
        >
          <div>
            <strong>{healthScore}</strong>
            <span>/100</span>
            <em>{healthLabel.replace("ة", "")}</em>
          </div>
        </div>
        <div className="seo-hero-stats">
          <article>
            <Icon name="file" size={22} />
            <div>
              <b>{indexedPages.toLocaleString("ar-IQ")}</b>
              <span>صفحة قابلة للفهرسة</span>
            </div>
          </article>
          <article className={brokenRelated ? "warning" : ""}>
            <Icon name="link" size={22} />
            <div>
              <b>{brokenRelated.toLocaleString("ar-IQ")}</b>
              <span>رابط مكسور</span>
            </div>
          </article>
          <article>
            <Icon name="network" size={22} />
            <div>
              <b>{sitemapSections.length.toLocaleString("ar-IQ")}</b>
              <span>خرائط موقع</span>
            </div>
          </article>
          <article>
            <Icon name="copy" size={22} />
            <div>
              <b>{duplicateMetadata.toLocaleString("ar-IQ")}</b>
              <span>Metadata مكررة</span>
            </div>
          </article>
        </div>
      </section>

      <div className="seo-center-grid">
        <main className="seo-center-main">
          <section className="panel seo-status-card">
            <header>
              <h2>حالة الفحص</h2>
            </header>
            <nav>
              {[
                ["overview", "نظرة عامة"],
                ["indexing", "الفهرسة"],
                ["structured", "البيانات المنظمة"],
                ["links", "الروابط"],
              ].map(([id, label]) => (
                <button
                  key={id}
                  className={statusTab === id ? "active" : ""}
                  onClick={() => setStatusTab(id)}
                >
                  {label}
                </button>
              ))}
            </nav>
            <div className="seo-status-checks">
              {visibleChecks.map(([title, , ready, icon]) => (
                <article key={title}>
                  <Icon name={icon} size={20} />
                  <span>{title}</span>
                  <em className={ready ? "ready" : "issue"}>
                    {ready ? "سليم" : "مشكلة"}
                  </em>
                </article>
              ))}
            </div>
            <footer>
              <Icon name="check" size={20} />
              {checks.filter((item) => item[2]).length} من {checks.length}{" "}
              فحوصات أساسية ناجحة
            </footer>
          </section>
          <section className="panel seo-search-preview">
            <header>
              <h2>
                <Icon name="search" size={20} />
                معاينة البحث
              </h2>
              <div>
                <button
                  className={previewDevice === "desktop" ? "active" : ""}
                  onClick={() => setPreviewDevice("desktop")}
                >
                  <Icon name="laptop" size={16} />
                  سطح المكتب
                </button>
                <button
                  className={previewDevice === "mobile" ? "active" : ""}
                  onClick={() => setPreviewDevice("mobile")}
                >
                  <Icon name="smartphone" size={16} />
                  هاتف
                </button>
              </div>
            </header>
            <div
              className={
                previewDevice === "mobile"
                  ? "seo-result-preview mobile"
                  : "seo-result-preview"
              }
            >
              <small>
                {siteConfig.baseUrl}/tools/{previewTool.slug}
              </small>
              <h3>{previewTool.seoTitle}</h3>
              <p>{previewTool.seoDescription}</p>
              <footer>
                <span>
                  العنوان <b>{previewTool.seoTitle.length} / 60</b>
                </span>
                <span>
                  الوصف <b>{previewTool.seoDescription.length} / 160</b>
                </span>
              </footer>
            </div>
          </section>
        </main>

        <aside className="seo-center-aside">
          <section
            className={`panel seo-action-card ${brokenRelated || duplicateMetadata ? "has-issue" : "all-clear"}`}
          >
            <header>
              <Icon
                name={brokenRelated || duplicateMetadata ? "alert" : "check"}
                size={20}
              />
              <h2>الإجراء المطلوب</h2>
            </header>
            {brokenRelated ? (
              <>
                <h3>رابط أداة غير صالح</h3>
                <p>الأداة المتأثرة: {brokenEntries[0].item.name}</p>
                <em>متوسطة</em>
                <small>
                  حدّث المسار «{brokenEntries[0].slug}» داخل سجل الأدوات.
                </small>
                <button onClick={() => setStatusTab("links")}>
                  إصلاح المشكلة
                </button>
              </>
            ) : duplicateMetadata ? (
              <>
                <h3>بيانات فهرسة مكررة</h3>
                <p>
                  {duplicateMetadata.toLocaleString("ar-IQ")} عناوين أو أوصاف
                  متطابقة
                </p>
                <em>متوسطة</em>
                <small>
                  راجع بيانات الأدوات المتشابهة واجعل كل وصف فريداً.
                </small>
              </>
            ) : (
              <>
                <h3>لا توجد مشكلات حرجة</h3>
                <p>جميع الروابط وبيانات الفهرسة سليمة.</p>
              </>
            )}
          </section>
          <section className="panel seo-map-card">
            <header>
              <Icon name="network" size={18} />
              <h2>خرائط الموقع</h2>
            </header>
            <div>
              <span>الأدوات</span>
              <b>{tools.length.toLocaleString("ar-IQ")}</b>
              <em>متاحة</em>
            </div>
            <div>
              <span>التصنيفات</span>
              <b>{categories.length.toLocaleString("ar-IQ")}</b>
              <em>متاحة</em>
            </div>
            <div>
              <span>الصفحات</span>
              <b>{basePages.length.toLocaleString("ar-IQ")}</b>
              <em>متاحة</em>
            </div>
            <footer>
              <span>{siteConfig.domain}/sitemap.xml</span>
              <button onClick={copySitemap} title="نسخ رابط خريطة الموقع">
                <Icon name={copiedSitemap ? "check" : "copy"} size={16} />
              </button>
              <a
                href={`${siteConfig.baseUrl}/sitemap.xml`}
                target="_blank"
                title="فتح خريطة الموقع"
              >
                <Icon name="external" size={16} />
              </a>
            </footer>
          </section>
          <section className="panel seo-performance-card">
            <header>
              <Icon name="chart" size={18} />
              <h2>أداء الظهور</h2>
            </header>
            {intel.weekTotal ? (
              <>
                <strong>{intel.weekTotal.toLocaleString("ar-IQ")}</strong>
                <p>استخدامات مسجلة هذا الأسبوع</p>
              </>
            ) : (
              <>
                <svg viewBox="0 0 120 54" aria-hidden="true">
                  <path
                    d="M4 44 L27 30 L48 39 L72 16 L93 30 L116 9"
                    fill="none"
                    stroke="#75aaff"
                    strokeWidth="3"
                  />
                  <circle cx="116" cy="9" r="4" fill="#0d6cff" />
                </svg>
                <h3>لا توجد بيانات بحث حتى الآن</h3>
                <p>بعد الربط ستظهر مرات الظهور والنقرات ومتوسط الترتيب.</p>
              </>
            )}
            <a
              href="https://search.google.com/search-console"
              target="_blank"
              rel="noreferrer"
            >
              Google Search Console
            </a>
          </section>
        </aside>
      </div>
    </div>
  );
}

function SettingsAdmin() {
  const [saved, setSaved] = useState<Record<string, string>>({});
  const [done, setDone] = useState(false);
  const [settingsBusy, setSettingsBusy] = useState(false);
  const [settingsError, setSettingsError] = useState("");
  const [currentPin, setCurrentPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [pinBusy, setPinBusy] = useState(false);
  const [pinError, setPinError] = useState("");
  const [pinDone, setPinDone] = useState(false);
  useEffect(() => {
    fetch("/api/admin/settings")
      .then(
        async (response) =>
          (await response.json()) as { settings?: Record<string, string> },
      )
      .then((data) => setSaved(data.settings || {}))
      .catch(() => undefined);
  }, []);
  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setDone(false);
    setSettingsError("");
    const payload = Object.fromEntries(
      new FormData(event.currentTarget).entries(),
    ) as Record<string, string>;
    const required = [
      "name",
      "nameEn",
      "domain",
      "owner",
      "email",
      "privacy",
      "tagline",
    ];
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (
      required.some((key) => !String(payload[key] || "").trim()) ||
      !emailPattern.test(payload.email) ||
      !emailPattern.test(payload.privacy)
    ) {
      setSettingsError("أكمل كل الحقول وتأكد من صحة عناوين البريد.");
      return;
    }
    setSettingsBusy(true);
    try {
      const response = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!response.ok)
        return setSettingsError(
          "تعذر حفظ الإعدادات. تحقق من الجلسة وحاول مجدداً.",
        );
      setSaved(payload);
      setDone(true);
    } catch {
      setSettingsError("تعذر الاتصال بقاعدة البيانات حالياً.");
    } finally {
      setSettingsBusy(false);
    }
  }
  async function changePin(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPinError("");
    setPinDone(false);
    if (
      currentPin.length !== 6 ||
      newPin.length !== 6 ||
      confirmPin.length !== 6
    )
      return setPinError("يجب أن يتكوّن كل رمز من 6 أرقام بالضبط.");
    if (newPin !== confirmPin)
      return setPinError("الرمز الجديد وتأكيده غير متطابقين.");
    if (currentPin === newPin)
      return setPinError("اختر رمزاً جديداً مختلفاً عن الرمز الحالي.");
    setPinBusy(true);
    try {
      const response = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          action: "change",
          pin: currentPin,
          newPin,
          confirmPin,
        }),
      });
      const payload = (await response.json()) as { error?: string };
      if (!response.ok)
        return setPinError(payload.error || "تعذر تغيير رمز الدخول.");
      setCurrentPin("");
      setNewPin("");
      setConfirmPin("");
      setPinDone(true);
    } finally {
      setPinBusy(false);
    }
  }
  const pinField = (
    label: string,
    value: string,
    setter: (value: string) => void,
    autoComplete: string,
  ) => (
    <div className="field admin-pin-setting-field">
      <label>{label}</label>
      <div>
        <Icon name="key" size={19} />
        <input
          type="password"
          inputMode="numeric"
          pattern="[0-9]*"
          maxLength={6}
          autoComplete={autoComplete}
          value={value}
          onFocus={(event) => event.currentTarget.select()}
          onChange={(event) => setter(normalizePinDigits(event.target.value))}
          placeholder="••••••"
          aria-label={label}
        />
      </div>
    </div>
  );
  return (
    <div className="admin-settings-page">
      <div className="admin-settings-summary">
        <article>
          <span>
            <Icon name="globe" size={22} />
          </span>
          <div>
            <b>{saved.name || siteConfig.name}</b>
            <small>هوية الموقع</small>
          </div>
          <em>مفعّلة</em>
        </article>
        <article>
          <span>
            <Icon name="network" size={22} />
          </span>
          <div>
            <b>{saved.domain || siteConfig.domain}</b>
            <small>النطاق الحالي</small>
          </div>
          <em>متصل</em>
        </article>
        <article>
          <span>
            <Icon name="shield" size={22} />
          </span>
          <div>
            <b>رمز من 6 أرقام</b>
            <small>حماية لوحة الإدارة</small>
          </div>
          <em>آمن</em>
        </article>
      </div>
      <div className="admin-settings-layout">
        <aside className="panel admin-settings-nav">
          <header>
            <Icon name="sliders" size={22} />
            <h2>أقسام الإعدادات</h2>
          </header>
          <a href="#site-settings">
            <Icon name="globe" size={18} />
            <span>معلومات الموقع</span>
          </a>
          <a href="#security-settings">
            <Icon name="shield" size={18} />
            <span>الأمان ورمز الدخول</span>
          </a>
          <div>
            <Icon name="check" size={19} />
            <p>
              تُحفظ المعلومات في قاعدة البيانات، ولا يُحفظ رمز PIN بصورته
              الأصلية.
            </p>
          </div>
        </aside>
        <main className="admin-stack admin-settings-stack">
          <form
            noValidate
            id="site-settings"
            className="panel settings-form admin-settings-card"
            onSubmit={save}
            key={JSON.stringify(saved)}
          >
            <header className="settings-section-title">
              <span>
                <Icon name="globe" size={22} />
              </span>
              <div>
                <h2>معلومات الموقع</h2>
                <p>عدّل الهوية والنطاق وبيانات التواصل الظاهرة في أدواتي.</p>
              </div>
            </header>
            <div className="form-grid admin-settings-fields">
              <div className="field">
                <label>اسم الموقع</label>
                <input
                  required
                  name="name"
                  defaultValue={saved.name || siteConfig.name}
                />
              </div>
              <div className="field">
                <label>الاسم الإنجليزي</label>
                <input
                  required
                  dir="ltr"
                  className="admin-ltr-input"
                  name="nameEn"
                  defaultValue={saved.nameEn || siteConfig.nameEn}
                />
              </div>
              <div className="field">
                <label>النطاق</label>
                <input
                  required
                  dir="ltr"
                  className="admin-ltr-input"
                  name="domain"
                  defaultValue={saved.domain || siteConfig.domain}
                />
              </div>
              <div className="field">
                <label>اسم المالك</label>
                <input
                  required
                  dir="ltr"
                  className="admin-ltr-input"
                  name="owner"
                  defaultValue={saved.owner || siteConfig.owner}
                />
              </div>
              <div className="field">
                <label>البريد العام</label>
                <input
                  required
                  dir="ltr"
                  className="admin-ltr-input"
                  type="email"
                  name="email"
                  defaultValue={saved.email || siteConfig.email}
                />
              </div>
              <div className="field">
                <label>بريد الخصوصية</label>
                <input
                  required
                  dir="ltr"
                  className="admin-ltr-input"
                  type="email"
                  name="privacy"
                  defaultValue={saved.privacy || siteConfig.privacyEmail}
                />
              </div>
              <div className="field full">
                <label>العبارة التعريفية</label>
                <input
                  required
                  name="tagline"
                  defaultValue={saved.tagline || siteConfig.tagline}
                />
              </div>
            </div>
            <footer>
              {settingsError && (
                <div className="error-notice" role="alert">
                  {settingsError}
                </div>
              )}
              {done && (
                <div className="notice">
                  <Icon name="check" size={17} />
                  تم حفظ الإعدادات في قاعدة البيانات.
                </div>
              )}
              <button className="primary-button" disabled={settingsBusy}>
                <Icon name="check" size={17} />
                {settingsBusy ? "جاري الحفظ..." : "حفظ معلومات الموقع"}
              </button>
            </footer>
          </form>

          <form
            id="security-settings"
            className="panel admin-pin-settings admin-settings-card"
            onSubmit={changePin}
          >
            <header className="settings-section-title">
              <span>
                <Icon name="shield" size={23} />
              </span>
              <div>
                <h2>الأمان ورمز الدخول</h2>
                <p>غيّر رمز لوحة التحكم بعد التحقق من الرمز الحالي.</p>
              </div>
            </header>
            <div className="admin-pin-settings-grid">
              {pinField(
                "الرمز الحالي",
                currentPin,
                setCurrentPin,
                "current-password",
              )}
              {pinField("الرمز الجديد", newPin, setNewPin, "new-password")}
              {pinField(
                "تأكيد الرمز الجديد",
                confirmPin,
                setConfirmPin,
                "new-password",
              )}
            </div>
            <div className="admin-pin-settings-note">
              <Icon name="shield" size={18} />
              <span>
                يجب أن يتكون الرمز من 6 أرقام. بعد نجاح التغيير ستبقى جلستك
                الحالية متصلة ويصبح الرمز القديم غير صالح.
              </span>
            </div>
            <footer>
              {pinError && (
                <div className="error-notice" role="alert">
                  {pinError}
                </div>
              )}
              {pinDone && (
                <div className="notice" role="status">
                  <Icon name="check" size={17} />
                  تم تغيير رمز لوحة التحكم بنجاح.
                </div>
              )}
              <button
                className="primary-button"
                disabled={
                  pinBusy ||
                  currentPin.length !== 6 ||
                  newPin.length !== 6 ||
                  confirmPin.length !== 6
                }
              >
                <Icon name="key" size={17} />
                {pinBusy ? "جاري تغيير الرمز..." : "تغيير رمز الدخول"}
              </button>
            </footer>
          </form>
        </main>
      </div>
    </div>
  );
}
