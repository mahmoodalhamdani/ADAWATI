"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";

type UploadState = "idle" | "loading" | "complete" | "error";

function formatSize(bytes: number, locale: "ar" | "en") {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toLocaleString(locale === "ar" ? "ar-IQ" : "en-US", { maximumFractionDigits: 2 })} MB`;
}

function matchesAccept(file: File, accept?: string) {
  if (!accept) return true;
  const name = file.name.toLocaleLowerCase();
  const extension = name.includes(".") ? name.split(".").pop() || "" : "";
  const mimeExtensions: Record<string, string[]> = {
    "application/pdf": ["pdf"],
    "image/jpeg": ["jpg", "jpeg"],
    "image/png": ["png"],
    "image/webp": ["webp"],
    "text/html": ["html", "htm"],
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [
      "docx",
    ],
    "application/vnd.openxmlformats-officedocument.presentationml.presentation":
      ["pptx"],
  };
  return accept
    .split(",")
    .map((token) => token.trim().toLocaleLowerCase())
    .some((token) => {
      if (!token) return false;
      if (token.startsWith(".")) return name.endsWith(token);
      if (token.endsWith("/*")) {
        if (file.type.toLocaleLowerCase().startsWith(token.slice(0, -1)))
          return true;
        return (
          token === "image/*" &&
          ["jpg", "jpeg", "png", "webp", "gif", "bmp", "avif"].includes(
            extension,
          )
        );
      }
      return (
        file.type.toLocaleLowerCase() === token ||
        (!file.type && (mimeExtensions[token] || []).includes(extension))
      );
    });
}

export function FileUploadZone({
  files,
  onFiles,
  accept,
  multiple = false,
  icon = "upload",
  title,
  helper,
  maxFiles,
  compact = false,
}: {
  files: File[];
  onFiles: (files: File[]) => void;
  accept?: string;
  multiple?: boolean;
  icon?: string;
  title: string;
  helper?: string;
  maxFiles?: number;
  compact?: boolean;
}) {
  const { locale, t } = useLocale();
  const [state, setState] = useState<UploadState>(
    files.length ? "complete" : "idle",
  );
  const [progress, setProgress] = useState(files.length ? 100 : 0);
  const [dragging, setDragging] = useState(false);
  const [messageVisible, setMessageVisible] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const messageTimer = useRef(0);
  const fingerprint = files
    .map((file) => `${file.name}:${file.size}:${file.lastModified}`)
    .join("|");
  const totalSize = useMemo(
    () => files.reduce((sum, file) => sum + file.size, 0),
    [files],
  );

  useEffect(() => {
    let interval = 0;
    let done = 0;
    let current = 8;
    const begin = window.setTimeout(() => {
      if (!files.length) {
        setState("idle");
        setProgress(0);
        return;
      }
      window.clearTimeout(messageTimer.current);
      setErrorMessage("");
      setMessageVisible(true);
      setState("loading");
      setProgress(8);
      interval = window.setInterval(() => {
        current = Math.min(
          92,
          current + Math.max(3, Math.round((96 - current) * 0.22)),
        );
        setProgress(current);
      }, 70);
      done = window.setTimeout(() => {
        window.clearInterval(interval);
        setProgress(100);
        setState("complete");
        messageTimer.current = window.setTimeout(
          () => setMessageVisible(false),
          2600,
        );
      }, 720);
    }, 0);
    return () => {
      window.clearTimeout(begin);
      window.clearInterval(interval);
      window.clearTimeout(done);
    };
  }, [fingerprint, files.length]);

  useEffect(() => () => window.clearTimeout(messageTimer.current), []);

  function fail(message: string) {
    window.clearTimeout(messageTimer.current);
    setProgress(0);
    setState("error");
    setErrorMessage(message);
    setMessageVisible(true);
    messageTimer.current = window.setTimeout(() => {
      setMessageVisible(false);
      setState(files.length ? "complete" : "idle");
    }, 3400);
  }

  function select(next: File[]) {
    if (maxFiles && next.length > maxFiles) {
      fail(
        t(
          `يمكن رفع ${maxFiles} ملفات كحد أقصى.`,
          `You can upload up to ${maxFiles} files.`,
        ),
      );
      return;
    }
    const rejected = next.find((file) => !matchesAccept(file, accept));
    if (rejected) {
      fail(
        t(
          `نوع الملف ${rejected.name} غير مدعوم في هذه الأداة.`,
          `${rejected.name} is not supported by this tool.`,
        ),
      );
      return;
    }
    const limited = maxFiles ? next.slice(0, maxFiles) : next;
    onFiles(multiple ? limited : limited.slice(0, 1));
  }

  const status =
    state === "loading"
      ? t("جاري تحميل الملف داخل الأداة…", "Loading into the tool…")
      : state === "error"
        ? errorMessage
        : t("اكتمل تحميل الملف", "File loaded successfully");

  return (
    <label
      className={`upload-zone smart-upload ${compact ? "is-compact" : ""} ${dragging ? "is-dragging" : ""} ${state === "loading" ? "is-loading" : ""} ${state === "complete" ? "is-complete" : ""} ${state === "error" ? "is-error" : ""}`}
      onDragEnter={(event) => {
        event.preventDefault();
        setDragging(true);
      }}
      onDragOver={(event) => {
        event.preventDefault();
        setDragging(true);
      }}
      onDragLeave={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget as Node | null))
          setDragging(false);
      }}
      onDrop={(event) => {
        event.preventDefault();
        setDragging(false);
        select(Array.from(event.dataTransfer.files));
      }}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        onClick={() => {
          if (inputRef.current) inputRef.current.value = "";
        }}
        onChange={(event) => select(Array.from(event.target.files || []))}
      />
      {messageVisible && (
        <div
          className="upload-status"
          role={state === "error" ? "alert" : "status"}
          aria-live="polite"
        >
          <Icon
            name={
              state === "error"
                ? "alert"
                : state === "complete"
                  ? "check"
                  : "upload"
            }
            size={17}
          />
          <span>{status}</span>
          {state !== "error" && <b>{progress}%</b>}
        </div>
      )}
      <span className="upload-icon">
        <Icon
          name={state === "complete" ? "check" : icon}
          size={compact ? 28 : 34}
        />
      </span>
      <strong>
        {files.length > 1
          ? t(`${files.length} ملفات جاهزة`, `${files.length} files ready`)
          : files[0]?.name || title}
      </strong>
      <span>
        {files.length
          ? `${formatSize(totalSize, locale)} · ${t("اضغط لتغيير الاختيار", "Click to change selection")}`
          : helper ||
            t(
              "اضغط للاختيار أو اسحب الملف إلى هنا",
              "Click to choose or drag a file here",
            )}
      </span>
      {files.length > 0 && state !== "error" && messageVisible && (
        <div className="upload-progress" aria-hidden="true">
          <i style={{ width: `${progress}%` }} />
        </div>
      )}
    </label>
  );
}
