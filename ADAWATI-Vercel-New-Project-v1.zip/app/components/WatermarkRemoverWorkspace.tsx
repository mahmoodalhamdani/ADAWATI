"use client";

/* eslint-disable @next/next/no-img-element */

import { useEffect, useRef, useState } from "react";
import { FileUploadZone } from "./FileUploadZone";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";
import {
  canvasPointFromClient,
  smartFillMaskedPixels,
} from "@/lib/image-tools";

type SelectionMode = "brush" | "eraser" | "rectangle";

function download(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  window.dispatchEvent(new CustomEvent("minjaz-download-feedback"));
  setTimeout(() => URL.revokeObjectURL(url), 1200);
}

export function WatermarkRemoverWorkspace() {
  const { t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [brush, setBrush] = useState(42);
  const [mode, setMode] = useState<SelectionMode>("brush");
  const [expand, setExpand] = useState(4);
  const [feather, setFeather] = useState(2);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ url: string; blob: Blob } | null>(
    null,
  );
  const [error, setError] = useState("");
  const [cursor, setCursor] = useState({ x: 0, y: 0, visible: false });
  const editorRef = useRef<HTMLDivElement>(null);
  const displayRef = useRef<HTMLCanvasElement>(null);
  const maskRef = useRef<HTMLCanvasElement | null>(null);
  const sourceRef = useRef<ImageData | null>(null);
  const drawing = useRef(false);
  const last = useRef({ x: 0, y: 0 });
  const rectangleStart = useRef({ x: 0, y: 0 });
  const rectangleBase = useRef<ImageData | null>(null);
  const history = useRef<ImageData[]>([]);

  useEffect(
    () => () => {
      if (result) URL.revokeObjectURL(result.url);
    },
    [result],
  );

  function render() {
    const canvas = displayRef.current,
      source = sourceRef.current,
      mask = maskRef.current;
    if (!canvas || !source || !mask) return;
    const context = canvas.getContext("2d")!;
    context.putImageData(source, 0, 0);
    context.save();
    context.globalAlpha = 0.58;
    context.drawImage(mask, 0, 0);
    context.restore();
  }

  function clearResult() {
    setResult((current) => {
      if (current) URL.revokeObjectURL(current.url);
      return null;
    });
  }

  async function choose(next: File | null) {
    if (!next) return;
    setError("");
    setReady(false);
    try {
      const bitmap = await createImageBitmap(next);
      const longest = Math.max(bitmap.width, bitmap.height);
      const scale = Math.min(1, 1800 / longest);
      const canvas = displayRef.current!;
      canvas.width = Math.max(1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      const context = canvas.getContext("2d")!;
      context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      sourceRef.current = context.getImageData(
        0,
        0,
        canvas.width,
        canvas.height,
      );
      const mask = document.createElement("canvas");
      mask.width = canvas.width;
      mask.height = canvas.height;
      maskRef.current = mask;
      history.current = [];
      setFile(next);
      setReady(true);
      clearResult();
      bitmap.close();
      render();
    } catch {
      setError(
        t(
          "تعذر قراءة الصورة. استخدم PNG أو JPG أو WebP سليماً.",
          "Could not read the image. Use a valid PNG, JPG, or WebP file.",
        ),
      );
    }
  }

  function point(event: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = displayRef.current!,
      rect = canvas.getBoundingClientRect();
    return canvasPointFromClient(
      event.clientX,
      event.clientY,
      rect,
      canvas.width,
      canvas.height,
    );
  }

  function moveCursor(event: React.PointerEvent<HTMLCanvasElement>) {
    const editor = editorRef.current;
    if (!editor) return;
    const rect = editor.getBoundingClientRect();
    setCursor({
      x: event.clientX - rect.left + editor.scrollLeft,
      y: event.clientY - rect.top + editor.scrollTop,
      visible: true,
    });
  }

  function paint(from: { x: number; y: number }, to: { x: number; y: number }) {
    const mask = maskRef.current,
      canvas = displayRef.current;
    if (!mask || !canvas) return;
    const rect = canvas.getBoundingClientRect(),
      ratio = (canvas.width / rect.width + canvas.height / rect.height) / 2;
    const context = mask.getContext("2d")!;
    context.strokeStyle = "#ff3158";
    context.lineWidth = brush * ratio;
    context.lineCap = "round";
    context.lineJoin = "round";
    context.globalCompositeOperation =
      mode === "eraser" ? "destination-out" : "source-over";
    context.beginPath();
    context.moveTo(from.x, from.y);
    context.lineTo(to.x, to.y);
    context.stroke();
    render();
  }

  function paintRectangle(
    from: { x: number; y: number },
    to: { x: number; y: number },
  ) {
    const mask = maskRef.current,
      base = rectangleBase.current;
    if (!mask || !base) return;
    const context = mask.getContext("2d")!;
    context.putImageData(base, 0, 0);
    context.globalCompositeOperation = "source-over";
    context.fillStyle = "#ff3158";
    context.fillRect(
      Math.min(from.x, to.x),
      Math.min(from.y, to.y),
      Math.abs(to.x - from.x),
      Math.abs(to.y - from.y),
    );
    render();
  }

  function pointerDown(event: React.PointerEvent<HTMLCanvasElement>) {
    if (!ready || !maskRef.current) return;
    moveCursor(event);
    event.currentTarget.setPointerCapture(event.pointerId);
    const snapshot = maskRef.current
      .getContext("2d")!
      .getImageData(0, 0, maskRef.current.width, maskRef.current.height);
    history.current.push(snapshot);
    if (history.current.length > 12) history.current.shift();
    clearResult();
    drawing.current = true;
    last.current = point(event);
    if (mode === "rectangle") {
      rectangleStart.current = last.current;
      rectangleBase.current = snapshot;
    } else {
      paint(last.current, last.current);
    }
  }

  function pointerMove(event: React.PointerEvent<HTMLCanvasElement>) {
    moveCursor(event);
    if (!drawing.current) return;
    const next = point(event);
    if (mode === "rectangle") paintRectangle(rectangleStart.current, next);
    else paint(last.current, next);
    last.current = next;
  }

  function pointerUp() {
    drawing.current = false;
    rectangleBase.current = null;
  }
  function clearMask() {
    const mask = maskRef.current;
    if (!mask) return;
    mask.getContext("2d")!.clearRect(0, 0, mask.width, mask.height);
    history.current = [];
    render();
  }
  function undo() {
    const mask = maskRef.current,
      previous = history.current.pop();
    if (!mask || !previous) return;
    mask.getContext("2d")!.putImageData(previous, 0, 0);
    render();
  }

  async function remove() {
    const source = sourceRef.current,
      maskCanvas = maskRef.current,
      canvas = displayRef.current;
    if (!source || !maskCanvas || !canvas) return;
    setBusy(true);
    setError("");
    await new Promise((resolve) => setTimeout(resolve, 20));
    try {
      const width = source.width,
        height = source.height;
      const prepared = document.createElement("canvas");
      prepared.width = width;
      prepared.height = height;
      const preparedContext = prepared.getContext("2d")!;
      const displayWidth = Math.max(
        1,
        displayRef.current?.getBoundingClientRect().width || width,
      );
      const pixelRatio = width / displayWidth;
      const expansion = Math.max(0, expand * pixelRatio);
      if (expansion > 0) {
        const samples = Math.min(32, Math.max(12, Math.ceil(expansion * 1.5)));
        for (let index = 0; index < samples; index += 1) {
          const angle = (index / samples) * Math.PI * 2;
          preparedContext.drawImage(
            maskCanvas,
            Math.cos(angle) * expansion,
            Math.sin(angle) * expansion,
          );
        }
      }
      preparedContext.drawImage(maskCanvas, 0, 0);
      if (feather > 0) {
        const softened = document.createElement("canvas");
        softened.width = width;
        softened.height = height;
        const softenedContext = softened.getContext("2d")!;
        softenedContext.filter = `blur(${Math.max(0.5, feather * pixelRatio)}px)`;
        softenedContext.drawImage(prepared, 0, 0);
        preparedContext.clearRect(0, 0, width, height);
        preparedContext.drawImage(softened, 0, 0);
      }
      const mask = preparedContext.getImageData(0, 0, width, height).data;
      const work = smartFillMaskedPixels(source.data, mask, width, height);
      const output = document.createElement("canvas");
      output.width = width;
      output.height = height;
      output
        .getContext("2d")!
        .putImageData(new ImageData(work, width, height), 0, 0);
      const blob = await new Promise<Blob>((resolve, reject) =>
        output.toBlob(
          (value) => (value ? resolve(value) : reject(new Error("output"))),
          "image/png",
        ),
      );
      setResult((current) => {
        if (current) URL.revokeObjectURL(current.url);
        return { url: URL.createObjectURL(blob), blob };
      });
    } catch (reason) {
      setError(
        reason instanceof Error && reason.message.includes("selection")
          ? t(
              "لوّن العلامة المائية بالفرشاة أولاً.",
              "Paint over the watermark with the brush first.",
            )
          : t(
              "تعذرت معالجة المنطقة المحددة.",
              "Could not process the selected area.",
            ),
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="workspace-stack watermark-remover">
      <FileUploadZone
        files={file ? [file] : []}
        onFiles={(files) => void choose(files[0] || null)}
        accept="image/png,image/jpeg,image/webp"
        icon="eraser"
        title={t(
          "ارفع الصورة التي تحتوي على العلامة",
          "Upload the image containing the watermark",
        )}
        helper={t(
          "حدد العلامة بالفرشاة الحمراء ثم شغّل التعبئة الذكية",
          "Paint over the watermark in red, then run smart fill",
        )}
      />
      <div
        ref={editorRef}
        className={`watermark-editor ${ready ? "is-ready" : ""}`}
      >
        <canvas
          ref={displayRef}
          onPointerDown={pointerDown}
          onPointerMove={pointerMove}
          onPointerUp={pointerUp}
          onPointerCancel={pointerUp}
          onPointerEnter={moveCursor}
          onPointerLeave={() =>
            setCursor((current) => ({ ...current, visible: false }))
          }
        />
        {ready && cursor.visible && (
          <span
            className={`watermark-brush-cursor is-${mode}`}
            aria-hidden="true"
            style={{
              left: cursor.x,
              top: cursor.y,
              width: mode === "rectangle" ? 18 : brush,
              height: mode === "rectangle" ? 18 : brush,
            }}
          />
        )}
        {!ready && (
          <div>
            <Icon name="eraser" size={34} />
            <span>
              {t(
                "ستظهر الصورة هنا بعد الرفع",
                "Your image will appear here after upload",
              )}
            </span>
          </div>
        )}
      </div>
      {ready && (
        <>
          <div className="watermark-toolbar">
            <div
              className="watermark-tool-modes"
              role="toolbar"
              aria-label={t("أدوات التحديد", "Selection tools")}
            >
              <button
                type="button"
                className={mode === "brush" ? "active" : ""}
                aria-pressed={mode === "brush"}
                onClick={() => setMode("brush")}
              >
                <Icon name="edit" size={17} />
                {t("فرشاة", "Brush")}
              </button>
              <button
                type="button"
                className={mode === "eraser" ? "active" : ""}
                aria-pressed={mode === "eraser"}
                onClick={() => setMode("eraser")}
              >
                <Icon name="eraser" size={17} />
                {t("ممحاة التحديد", "Selection eraser")}
              </button>
              <button
                type="button"
                className={mode === "rectangle" ? "active" : ""}
                aria-pressed={mode === "rectangle"}
                onClick={() => setMode("rectangle")}
              >
                <Icon name="crop" size={17} />
                {t("مستطيل", "Rectangle")}
              </button>
            </div>
            <label className="range-field">
              <span>
                {t("حجم فرشاة التحديد", "Selection brush size")}: {brush}px
              </span>
              <input
                type="range"
                min="10"
                max="120"
                value={brush}
                onChange={(event) => setBrush(Number(event.target.value))}
              />
            </label>
            <label className="range-field">
              <span>
                {t("توسيع التحديد", "Selection expansion")}: {expand}px
              </span>
              <input
                type="range"
                min="0"
                max="20"
                value={expand}
                onChange={(event) => setExpand(Number(event.target.value))}
              />
            </label>
            <label className="range-field">
              <span>
                {t("نعومة الحواف", "Edge softness")}: {feather}px
              </span>
              <input
                type="range"
                min="0"
                max="12"
                value={feather}
                onChange={(event) => setFeather(Number(event.target.value))}
              />
            </label>
            <button className="secondary-button" onClick={undo}>
              <Icon name="reset" size={18} />
              {t("تراجع", "Undo")}
            </button>
            <button className="secondary-button" onClick={clearMask}>
              <Icon name="trash" size={18} />
              {t("مسح التحديد", "Clear selection")}
            </button>
          </div>
          <button className="primary-button" onClick={remove} disabled={busy}>
            {busy
              ? t("جاري إعادة بناء المنطقة…", "Rebuilding selected area…")
              : t(
                  "إزالة العلامة من المنطقة المحددة",
                  "Remove watermark from selection",
                )}
          </button>
        </>
      )}
      {error && <div className="error-notice">{error}</div>}
      {result && (
        <div className="watermark-result">
          <img
            src={result.url}
            alt={t(
              "النتيجة بعد إزالة العلامة",
              "Result after watermark removal",
            )}
          />
          <button
            className="primary-button"
            onClick={() =>
              download(result.blob, "adawati-watermark-removed.png")
            }
          >
            <Icon name="download" size={18} />
            {t("تنزيل النتيجة PNG", "Download PNG result")}
          </button>
        </div>
      )}
      <p className="workspace-tip">
        <Icon name="sparkles" size={18} />
        {t(
          "التعبئة المحلية ممتازة للخلفيات البسيطة والمتدرجة. التفاصيل المعقدة التي كانت مخفية تماماً قد تحتاج تنقيحاً إضافياً.",
          "Local fill works best on simple or gradual backgrounds. Complex details that were fully hidden may need additional retouching.",
        )}
      </p>
    </div>
  );
}
