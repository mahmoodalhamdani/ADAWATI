"use client";

import { useState } from "react";
import { CustomSelect } from "./CustomSelect";
import { useLocale } from "./LocaleProvider";

export function ContactForm({
  kind = "contact",
}: {
  kind?: "contact" | "suggest";
}) {
  const { t } = useLocale();
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [messageType, setMessageType] = useState("");
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    const element = event.currentTarget;
    const form = new FormData(element);
    const values = Object.fromEntries(form.entries()) as Record<string, string>;
    const emailOkay =
      !values.email || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email);
    const invalid =
      kind === "contact"
        ? !values.name?.trim() ||
          values.name.trim().length < 2 ||
          !emailOkay ||
          !values.email ||
          !values.subject?.trim() ||
          values.subject.trim().length < 3 ||
          !messageType ||
          !values.message?.trim() ||
          values.message.trim().length < 10
        : !values.tool?.trim() ||
          values.tool.trim().length < 2 ||
          !values.category?.trim() ||
          !values.description?.trim() ||
          values.description.trim().length < 10 ||
          !emailOkay;
    if (invalid) {
      setError(
        t(
          "راجع الحقول المطلوبة وتأكد من صحة البريد وطول الرسالة.",
          "Review the required fields, email address, and message length.",
        ),
      );
      return;
    }
    const response = await fetch("/api/messages", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ kind, ...values }),
    });
    const payload = (await response.json()) as { error?: string };
    if (!response.ok) {
      setError(
        payload.error ||
          t(
            "تعذر إرسال الرسالة حالياً.",
            "The message could not be sent right now.",
          ),
      );
      return;
    }
    setSent(true);
    setMessageType("");
    element.reset();
  }
  if (sent)
    return (
      <div className="success-card panel">
        <span>✓</span>
        <h2>
          {kind === "suggest"
            ? t("تم استلام اقتراحك", "Your suggestion was received")
            : t("تم استلام رسالتك بنجاح", "Your message was received")}
        </h2>
        <p>
          {t(
            "شكراً لتواصلك معنا. سنراجع رسالتك في أقرب وقت ممكن.",
            "Thank you for contacting us. We will review your message soon.",
          )}
        </p>
        <button className="secondary-button" onClick={() => setSent(false)}>
          {t("إرسال رسالة أخرى", "Send another message")}
        </button>
      </div>
    );
  const typeOptions = [
    { value: "", label: t("اختر النوع", "Choose type") },
    { value: "استفسار", label: t("استفسار", "Question") },
    { value: "اقتراح", label: t("اقتراح", "Suggestion") },
    {
      value: "الإبلاغ عن مشكلة",
      label: t("الإبلاغ عن مشكلة", "Report a problem"),
    },
    { value: "اقتراح أداة", label: t("اقتراح أداة", "Suggest a tool") },
    { value: "تعاون", label: t("تعاون", "Collaboration") },
    { value: "أخرى", label: t("أخرى", "Other") },
  ];
  return (
    <form noValidate className="panel contact-form" onSubmit={submit}>
      <input
        name="website"
        tabIndex={-1}
        autoComplete="off"
        className="honeypot"
        aria-hidden="true"
      />
      <div className="form-grid">
        <div className="field">
          <label htmlFor="name">{t("الاسم", "Name")}</label>
          <input id="name" name="name" required minLength={2} maxLength={80} />
        </div>
        <div className="field">
          <label htmlFor="email">
            {t("البريد الإلكتروني", "Email")}{" "}
            {kind === "suggest" && t("(اختياري)", "(optional)")}
          </label>
          <input
            id="email"
            name="email"
            type="email"
            required={kind === "contact"}
          />
        </div>
        {kind === "contact" ? (
          <>
            <div className="field">
              <label htmlFor="subject">{t("الموضوع", "Subject")}</label>
              <input
                id="subject"
                name="subject"
                required
                minLength={3}
                maxLength={120}
              />
            </div>
            <div className="field">
              <label>{t("نوع الرسالة", "Message type")}</label>
              <CustomSelect
                value={messageType}
                onChange={setMessageType}
                options={typeOptions}
                label={t("نوع الرسالة", "Message type")}
                name="type"
              />
            </div>
            <div className="field full">
              <label htmlFor="message">{t("الرسالة", "Message")}</label>
              <textarea
                id="message"
                name="message"
                required
                minLength={10}
                maxLength={3000}
              />
            </div>
          </>
        ) : (
          <>
            <div className="field">
              <label htmlFor="tool">
                {t("اسم الأداة المقترحة", "Suggested tool name")}
              </label>
              <input id="tool" name="tool" required minLength={2} />
            </div>
            <div className="field">
              <label htmlFor="category">
                {t("التصنيف المقترح", "Suggested category")}
              </label>
              <input id="category" name="category" required />
            </div>
            <div className="field full">
              <label htmlFor="description">
                {t(
                  "وصف الأداة وسبب الحاجة إليها",
                  "Describe the tool and why it is needed",
                )}
              </label>
              <textarea
                id="description"
                name="description"
                required
                minLength={10}
              />
            </div>
          </>
        )}
      </div>
      {error && (
        <div className="error-notice" role="alert">
          {error}
        </div>
      )}
      <button className="primary-button" type="submit">
        {kind === "suggest"
          ? t("إرسال الاقتراح", "Send suggestion")
          : t("إرسال الرسالة", "Send message")}
      </button>
      <p className="form-note">
        {t(
          "نستخدم بيانات النموذج للرد على رسالتك فقط، ولا نبيعها أو نشاركها لأغراض تسويقية.",
          "We use this form only to reply to your message and never sell it for marketing.",
        )}
      </p>
    </form>
  );
}
