"use client";

import { useLocale } from "./LocaleProvider";

export function Localized({ ar, en }: { ar: React.ReactNode; en: React.ReactNode }) {
  const { isEnglish } = useLocale();
  return <>{isEnglish ? en : ar}</>;
}
