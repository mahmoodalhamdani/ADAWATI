"use client";

import {
  AlertTriangle, Archive, ArrowLeftRight, BarChart3, Bell, Bot, BookOpen, BriefcaseBusiness, Braces, Calculator, CalendarDays, Check, ChevronDown, ChevronLeft,
  CircleUserRound, Clock3, Code2, Coins, Copy, Dice5, Download, Eye, EyeOff, FileImage, FileText,
  Crop, Edit3, Eraser, ExternalLink, FileOutput, FilePlus2, FileSpreadsheet, Fingerprint, Globe2, GraduationCap, Grid2X2, HardDrive, Hash, Heart, Home, ImageIcon, Laptop, Layers3, ListOrdered, LockKeyhole,
  KeyRound, Languages, Link2, Menu, MessageCircle, MoreVertical, Moon, Percent, PiggyBank, Plus, QrCode,
  MapPinned,
  Minimize2, Network, Presentation, ReceiptText, RotateCcw, RotateCw, ScanLine, ScanText, Scissors, Search, Share2, ShieldCheck, Shuffle, Signature, Smartphone, Sparkles, Split, Stamp, Star, Sun, Tag, Trash2,
  SlidersHorizontal, Text, TimerReset, Type, UnlockKeyhole, Upload, UsersRound, WalletCards, Wrench, X, Zap,
} from "lucide-react";

const icons = {
  alert: AlertTriangle, chart: BarChart3,
  bell: Bell, book: BookOpen, briefcase: BriefcaseBusiness, braces: Braces,
  calculator: Calculator, calendar: CalendarDays, check: Check, "chevron-down": ChevronDown, back: ChevronLeft, user: CircleUserRound,
  clock: Clock3, code: Code2, coins: Coins, copy: Copy, dice: Dice5, download: Download, eye: Eye, "eye-off": EyeOff,
  archive: Archive, compare: ArrowLeftRight, crop: Crop, edit: Edit3, eraser: Eraser,
  bot: Bot, external: ExternalLink, "file-image": FileImage, "file-output": FileOutput, "file-plus": FilePlus2, "file-text": FileText, file: FileText, fingerprint: Fingerprint, globe: Globe2,
  graduation: GraduationCap, grid: Grid2X2, "hard-drive": HardDrive, heart: Heart,
  hash: Hash, home: Home, image: ImageIcon, key: KeyRound, languages: Languages, laptop: Laptop, layers: Layers3, "list-ordered": ListOrdered, link: Link2, lock: LockKeyhole,
  menu: Menu, message: MessageCircle, more: MoreVertical, moon: Moon, percent: Percent, "piggy-bank": PiggyBank, plus: Plus,
  map: MapPinned,
  minimize: Minimize2, network: Network, presentation: Presentation, qr: QrCode, receipt: ReceiptText, reset: RotateCcw, rotate: RotateCw, scan: ScanLine, "scan-text": ScanText, search: Search, share: Share2, sheet: FileSpreadsheet, shield: ShieldCheck, signature: Signature, split: Split, stamp: Stamp,
  shuffle: Shuffle, sliders: SlidersHorizontal, smartphone: Smartphone, sparkles: Sparkles, star: Star, sun: Sun, tag: Tag, text: Text,
  timer: TimerReset, trash: Trash2, type: Type, unlock: UnlockKeyhole, upload: Upload, users: UsersRound, wallet: WalletCards, wrench: Wrench,
  x: X, zap: Zap, resize: ImageIcon, scissors: Scissors,
};

export function Icon({ name, size = 22, strokeWidth = 1.9, className = "" }: { name: string; size?: number; strokeWidth?: number; className?: string }) {
  const Component = icons[name as keyof typeof icons] ?? Sparkles;
  return <Component size={size} strokeWidth={strokeWidth} className={className} aria-hidden="true" />;
}
