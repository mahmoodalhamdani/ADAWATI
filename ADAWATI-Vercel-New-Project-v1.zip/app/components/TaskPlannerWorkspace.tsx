"use client";

import { useEffect, useMemo, useState } from "react";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";
import { CustomSelect } from "./CustomSelect";

type PlannerTask = {
  id: string;
  title: string;
  dueDate: string;
  reminderTime?: string;
  priority?: "low" | "medium" | "high";
  completed: boolean;
  createdAt: number;
};

function createId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}

function isPlannerTask(value: unknown): value is PlannerTask {
  if (!value || typeof value !== "object") return false;
  const task = value as Partial<PlannerTask>;
  return (
    typeof task.id === "string" &&
    typeof task.title === "string" &&
    typeof task.dueDate === "string" &&
    (task.reminderTime === undefined || typeof task.reminderTime === "string") &&
    (task.priority === undefined || ["low", "medium", "high"].includes(task.priority)) &&
    typeof task.completed === "boolean" &&
    typeof task.createdAt === "number"
  );
}

export function TaskPlannerWorkspace({
  storageKey = "minjaz-task-planner",
}: {
  storageKey?: string;
}) {
  const { t } = useLocale();
  const [title, setTitle] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [reminderTime, setReminderTime] = useState("");
  const [priority, setPriority] = useState<"low" | "medium" | "high">("medium");
  const [tasks, setTasks] = useState<PlannerTask[]>([]);
  const [generatedTaskId, setGeneratedTaskId] = useState("");
  const [ready, setReady] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    let storedTasks: PlannerTask[] = [];
    try {
      const stored = JSON.parse(localStorage.getItem(storageKey) || "[]");
      if (Array.isArray(stored)) storedTasks = stored.filter(isPlannerTask);
    } catch {
      localStorage.removeItem(storageKey);
    }
    queueMicrotask(() => {
      if (cancelled) return;
      setTasks(storedTasks);
      setReady(true);
    });
    return () => {
      cancelled = true;
    };
  }, [storageKey]);

  useEffect(() => {
    if (ready) localStorage.setItem(storageKey, JSON.stringify(tasks));
  }, [ready, storageKey, tasks]);

  const completedCount = useMemo(
    () => tasks.filter((task) => task.completed).length,
    [tasks],
  );

  const generatedTask = tasks.find((task) => task.id === generatedTaskId);
  const priorityLabel = (value: PlannerTask["priority"]) =>
    value === "high"
      ? t("عالية", "High")
      : value === "low"
        ? t("منخفضة", "Low")
        : t("متوسطة", "Medium");

  function completionSteps(task: PlannerTask) {
    const due = `${task.dueDate}${task.reminderTime ? ` ${task.reminderTime}` : ""}`;
    return [
      t(
        `ابدأ بتحديد أول خطوة صغيرة للمهمة «${task.title}».`,
        `Start by defining the first small action for “${task.title}”.`,
      ),
      t(
        `نفّذ جلسة العمل الأساسية بأولوية ${priorityLabel(task.priority)} وسجّل التقدم.`,
        `Complete the main work session at ${priorityLabel(task.priority)} priority and record progress.`,
      ),
      t(
        `راجع الناتج وعلّم المهمة مكتملة قبل ${due}.`,
        `Review the result and mark the task complete before ${due}.`,
      ),
    ];
  }

  function addTask() {
    const cleanTitle = title.trim();
    setError("");
    setNotice("");
    if (!cleanTitle) {
      setError(t("اكتب عنوان المهمة أولاً.", "Enter a task title first."));
      return;
    }
    if (!dueDate) {
      setError(t("اختر تاريخ الاستحقاق.", "Choose a due date."));
      return;
    }
    if (!reminderTime) {
      setError(t("اختر وقت التذكير.", "Choose a reminder time."));
      return;
    }
    const task: PlannerTask = {
      id: createId(),
      title: cleanTitle,
      dueDate,
      reminderTime,
      priority,
      completed: false,
      createdAt: Date.now(),
    };
    setTasks((current) => [...current, task]);
    setGeneratedTaskId(task.id);
    setTitle("");
    setDueDate("");
    setReminderTime("");
    setPriority("medium");
    setNotice(t("تم حفظ المهمة في مخططك.", "Task saved to your planner."));
  }

  function toggleTask(id: string) {
    setTasks((current) =>
      current.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task,
      ),
    );
  }

  return (
    <div className="workspace-stack task-planner-workspace">
      <div className="form-grid task-planner-form">
        <div className="field">
          <label htmlFor={`${storageKey}-title`}>{t("عنوان المهمة", "Task title")}</label>
          <input
            id={`${storageKey}-title`}
            value={title}
            onChange={(event) => {
              setTitle(event.target.value);
              setError("");
              setNotice("");
            }}
            onKeyDown={(event) => {
              if (event.key === "Enter") addTask();
            }}
            placeholder={t("مثال: مراجعة الفصل الثالث", "Example: Review chapter three")}
            autoComplete="off"
          />
        </div>
        <div className="field">
          <label htmlFor={`${storageKey}-due`}>{t("تاريخ الاستحقاق", "Due date")}</label>
          <input
            id={`${storageKey}-due`}
            type="date"
            value={dueDate}
            onChange={(event) => {
              setDueDate(event.target.value);
              setError("");
              setNotice("");
            }}
            onInput={(event) => setDueDate(event.currentTarget.value)}
          />
        </div>
        <div className="field">
          <label htmlFor={`${storageKey}-reminder-time`}>{t("وقت التذكير", "Reminder time")}</label>
          <input
            id={`${storageKey}-reminder-time`}
            type="time"
            value={reminderTime}
            onInput={(event) => setReminderTime(event.currentTarget.value)}
            onChange={(event) => {
              setReminderTime(event.target.value);
              setError("");
              setNotice("");
            }}
          />
        </div>
        <div className="field">
          <label>{t("أولوية المهمة", "Task priority")}</label>
          <CustomSelect
            value={priority}
            onChange={(value) => setPriority(value as "low" | "medium" | "high")}
            label={t("اختر أولوية المهمة", "Choose task priority")}
            options={[
              { value: "high", label: t("عالية", "High") },
              { value: "medium", label: t("متوسطة", "Medium") },
              { value: "low", label: t("منخفضة", "Low") },
            ]}
          />
        </div>
      </div>
      <button className="primary-button task-create-button" type="button" onClick={addTask}>
        <Icon name="plus" size={18} />
        {t("حفظ وإنشاء المهمة", "Save and create task")}
      </button>
      {notice && <div className="notice" role="status">{notice}</div>}
      {error && <div className="error-notice" role="alert">{error}</div>}
      {generatedTask && (
        <section className="panel task-completion-plan" aria-live="polite">
          <h3>{t("خطة إنجاز المهمة", "Task completion plan")}</h3>
          <p>
            <strong>{generatedTask.title}</strong> — {t("الأولوية", "Priority")}: {priorityLabel(generatedTask.priority)}
          </p>
          <ol>
            {completionSteps(generatedTask).map((step) => <li key={step}>{step}</li>)}
          </ol>
        </section>
      )}
      <section className="task-list" aria-label={t("قائمة المهام", "Task list")}>
        <header>
          <div>
            <h3>{t("قائمة المهام", "Task list")}</h3>
            <p>
              {t(
                `${completedCount} مكتملة من ${tasks.length}`,
                `${completedCount} of ${tasks.length} completed`,
              )}
            </p>
          </div>
          {tasks.some((task) => task.completed) && (
            <button
              className="secondary-button"
              type="button"
              onClick={() => setTasks((current) => current.filter((task) => !task.completed))}
            >
              <Icon name="trash" size={17} />
              {t("حذف المكتملة", "Delete completed")}
            </button>
          )}
        </header>
        {tasks.length ? (
          <div className="task-list-items">
            {tasks.map((task) => (
              <article className={task.completed ? "is-completed" : ""} key={task.id}>
                <label className="task-check">
                  <input
                    type="checkbox"
                    checked={task.completed}
                    onChange={() => toggleTask(task.id)}
                    aria-label={t(`إكمال مهمة ${task.title}`, `Complete task ${task.title}`)}
                  />
                  <span><Icon name="check" size={16} /></span>
                </label>
                <div>
                  <strong>{task.title}</strong>
                  <small>
                    {t("الاستحقاق", "Due")}: <bdi>{task.dueDate} {task.reminderTime || "--:--"}</bdi>
                    {" · "}{t("الأولوية", "Priority")}: {priorityLabel(task.priority)}
                  </small>
                </div>
                <button
                  type="button"
                  onClick={() => setTasks((current) => current.filter((item) => item.id !== task.id))}
                  aria-label={t(`حذف مهمة ${task.title}`, `Delete task ${task.title}`)}
                >
                  <Icon name="trash" size={18} />
                </button>
              </article>
            ))}
          </div>
        ) : (
          <div className="empty-result-hint">
            <Icon name="check" size={20} />
            <span>{t("لا توجد مهام بعد. أنشئ مهمتك الأولى أعلاه.", "No tasks yet. Create your first task above.")}</span>
          </div>
        )}
      </section>
      <p className="workspace-tip">
        <Icon name="shield" size={18} />
        {t("تُحفظ المهام تلقائياً على هذا الجهاز وتبقى بعد إغلاق الصفحة.", "Tasks are saved automatically on this device and remain after closing the page.")}
      </p>
    </div>
  );
}
