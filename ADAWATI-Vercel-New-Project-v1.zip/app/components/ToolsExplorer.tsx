"use client";

import { useMemo, useState } from "react";
import { categories, categoryForSearch, pdfSections, searchTools, tools } from "@/lib/registry";
import { ToolCard } from "./Cards";
import { Icon } from "./Icon";
import { CustomSelect } from "./CustomSelect";
import { useLocale } from "./LocaleProvider";

export function ToolsExplorer({ initialCategory = "all", initialQuery = "" }: { initialCategory?: string; initialQuery?: string }) {
  const { locale, t } = useLocale();
  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState(initialCategory);
  const [sort, setSort] = useState("popular");
  const results = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase("ar");
    const categoryMatch = categoryForSearch(query);
    const effectiveCategory = category !== "all" ? category : categoryMatch;
    const base = normalizedQuery && !categoryMatch ? searchTools(query) : tools;
    const filtered = effectiveCategory
      ? base.filter((item) => item.category === effectiveCategory)
      : base;
    return [...filtered].sort((a, b) => sort === "name" ? a.name.localeCompare(b.name, "ar") : Number(Boolean(b.popular)) - Number(Boolean(a.popular)));
  }, [query, category, sort]);
  const categoryOptions = [{ value: "all", label: t("كل التصنيفات", "All categories") }, ...categories.map((item) => ({ value: item.slug, label: locale === "en" ? item.nameEn : item.name }))];
  const sortOptions = [{ value: "popular", label: t("الأكثر استخداماً", "Most used") }, { value: "name", label: t("حسب الاسم", "Name") }];
  const showPdfSections = category === "pdf-files" && !query.trim();
  return <div className="tools-explorer">
    <div className="explorer-toolbar panel"><div className="smart-search__field explorer-search"><Icon name="search" size={21} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t("ابحث بالاسم أو اكتب ما تريد إنجازه...", "Search by name or describe what you need...")} aria-label={t("بحث الأدوات", "Search tools")} />{query && <button onClick={() => setQuery("")} aria-label={t("مسح", "Clear")}><Icon name="x" size={18} /></button>}</div><CustomSelect value={category} options={categoryOptions} onChange={setCategory} label={t("التصنيف", "Category")} /><CustomSelect value={sort} options={sortOptions} onChange={setSort} label={t("الترتيب", "Sort")} /></div>
    <div className="results-summary" role="status" aria-live="polite"><strong>{results.length}</strong> {query ? t("نتيجة مطابقة", "matching results") : t("أداة متاحة", "tools available")} {query && <span>{t("للبحث", "for")}: «{query}»</span>}</div>
    {results.length ? showPdfSections ? <div className="pdf-sections">{pdfSections.map((section) => {
      const sectionTools = results.filter((item) => item.pdfSection === section.slug);
      if (!sectionTools.length) return null;
      return <section className={`pdf-section pdf-section--${section.color}`} key={section.slug} id={`pdf-${section.slug}`}>
        <header><span className={`icon-tile color-${section.color}`}><Icon name={section.icon} size={25}/></span><div><h2>{locale === "en" ? section.nameEn : section.name}</h2><p>{locale === "en" ? section.descriptionEn : section.description}</p></div><b>{sectionTools.length} {t("أدوات", "tools")}</b></header>
        <div className="all-tools-grid pdf-tools-grid">{sectionTools.map((item) => <ToolCard key={item.slug} tool={item} />)}</div>
      </section>;
    })}</div> : <div className="all-tools-grid">{results.map((item) => <ToolCard key={item.slug} tool={item} />)}</div> : <div className="empty-state panel"><Icon name="search" size={38} /><h2>{t("لم نجد أداة مطابقة", "No matching tool found")}</h2><p>{t("جرّب كلمة أخرى أو اختر تصنيفاً مختلفاً. يمكنك أيضاً اقتراح أداة جديدة.", "Try another phrase or choose a different category. You can also suggest a new tool.")}</p><button className="secondary-button" onClick={() => { setQuery(""); setCategory("all"); }}>{t("عرض كل الأدوات", "View all tools")}</button></div>}
  </div>;
}
