/* eslint-disable @next/next/no-img-element */
"use client";

import { useEffect, useMemo, useState } from "react";
import QRCode from "qrcode";
import { CustomSelect } from "./CustomSelect";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";

type Orientation = "portrait" | "landscape";

export const paperSizes = [
  { value: "a3", label: "A3", width: 297, height: 420 },
  { value: "a4", label: "A4", width: 210, height: 297 },
  { value: "a5", label: "A5", width: 148, height: 210 },
  { value: "letter", label: "US Letter", width: 215.9, height: 279.4 },
  { value: "square", label: "Square 210 × 210", width: 210, height: 210 },
] as const;

const designTemplates = [
  { value: "modern", ar: "حديث متدرّج", en: "Modern gradient", background: "#eef5ff", accent: "#0754e8", ink: "#07184f" },
  { value: "bold", ar: "جريء داكن", en: "Bold dark", background: "#07152f", accent: "#08cbd5", ink: "#ffffff" },
  { value: "editorial", ar: "تحريري", en: "Editorial", background: "#fffaf0", accent: "#c2410c", ink: "#2f1b0c" },
  { value: "corporate", ar: "أعمال", en: "Corporate", background: "#f7f9fc", accent: "#1d4ed8", ink: "#172554" },
  { value: "event", ar: "فعالية", en: "Event", background: "#fdf2f8", accent: "#be185d", ink: "#500724" },
  { value: "minimal", ar: "بسيط", en: "Minimal", background: "#ffffff", accent: "#111827", ink: "#111827" },
] as const;

function dimensions(paper: string, orientation: Orientation) {
  const selected = paperSizes.find((item) => item.value === paper) || paperSizes[1];
  return orientation === "landscape"
    ? { width: selected.height, height: selected.width, label: selected.label }
    : { width: selected.width, height: selected.height, label: selected.label };
}

function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  window.dispatchEvent(new CustomEvent("minjaz-download-feedback"));
  setTimeout(() => URL.revokeObjectURL(url), 1200);
}

function loadImage(source: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("image"));
    image.src = source;
  });
}

function wrapText(
  context: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  maxLines: number,
) {
  const words = text.trim().split(/\s+/).filter(Boolean);
  let line = "";
  let row = 0;
  for (const word of words) {
    const next = line ? `${line} ${word}` : word;
    if (context.measureText(next).width > maxWidth && line) {
      context.fillText(line, x, y + row * lineHeight);
      row += 1;
      line = word;
      if (row >= maxLines - 1) break;
    } else {
      line = next;
    }
  }
  if (line && row < maxLines) context.fillText(line, x, y + row * lineHeight);
}

function PageSetupWorkspace() {
  const { t } = useLocale();
  const [paper, setPaper] = useState("a4");
  const [orientation, setOrientation] = useState<Orientation>("portrait");
  const [margins, setMargins] = useState({ top: 15, right: 15, bottom: 15, left: 15 });
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const size = dimensions(paper, orientation);
  const updateMargin = (key: keyof typeof margins, value: number) => {
    setMargins((current) => ({ ...current, [key]: Math.max(0, value) }));
    setReady(false);
  };

  async function downloadPdf() {
    setBusy(true);
    try {
      const { PDFDocument, rgb } = await import("pdf-lib");
      const document = await PDFDocument.create();
      const points = 72 / 25.4;
      const page = document.addPage([size.width * points, size.height * points]);
      page.drawRectangle({
        x: margins.left * points,
        y: margins.bottom * points,
        width: Math.max(1, (size.width - margins.left - margins.right) * points),
        height: Math.max(1, (size.height - margins.top - margins.bottom) * points),
        borderColor: rgb(0.03, 0.33, 0.91),
        borderWidth: 0.8,
        opacity: 0.42,
      });
      const bytes = await document.save();
      downloadBlob(new Blob([bytes as BlobPart], { type: "application/pdf" }), `adawati-page-setup-${paper}-${orientation}.pdf`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="workspace-stack">
      <div className="print-designer-layout">
        <div className="workspace-stack">
          <div className="form-grid">
            <div className="field">
              <label>{t("حجم الورق", "Paper size")}</label>
              <CustomSelect value={paper} onChange={(value) => { setPaper(value); setReady(false); }} label={t("حجم الورق", "Paper size")} options={paperSizes.map((item) => ({ value: item.value, label: item.label }))} />
            </div>
            <div className="field">
              <label>{t("اتجاه الصفحة", "Page orientation")}</label>
              <CustomSelect value={orientation} onChange={(value) => { setOrientation(value as Orientation); setReady(false); }} label={t("اتجاه الصفحة", "Page orientation")} options={[{ value: "portrait", label: t("عمودي", "Portrait") }, { value: "landscape", label: t("أفقي", "Landscape") }]} />
            </div>
            {(["top", "right", "bottom", "left"] as const).map((key) => (
              <div className="field" key={key}>
                <label>{t({ top: "الهامش العلوي", right: "الهامش الأيمن", bottom: "الهامش السفلي", left: "الهامش الأيسر" }[key], { top: "Top margin", right: "Right margin", bottom: "Bottom margin", left: "Left margin" }[key])} (mm)</label>
                <input type="number" min="0" value={margins[key]} onChange={(event) => updateMargin(key, Number(event.target.value))} />
              </div>
            ))}
          </div>
          <div className="button-row">
            <button type="button" className="primary-button" onClick={() => setReady(true)}><Icon name="check" size={18} /> {t("إنشاء تخطيط جاهز", "Generate ready layout")}</button>
            {ready && <button type="button" className="secondary-button" disabled={busy} onClick={downloadPdf}><Icon name="download" size={18} /> {busy ? t("جاري التجهيز…", "Preparing…") : t("تنزيل مخطط PDF", "Download layout PDF")}</button>}
          </div>
          {ready && <div className="success-notice" role="status"><Icon name="check" size={19} /> {t(`التخطيط جاهز: ${size.label} ${orientation === "portrait" ? "عمودي" : "أفقي"}.`, `Layout ready: ${size.label} ${orientation}.`)}</div>}
        </div>
        <div className="page-setup-stage" aria-label={t("معاينة إعداد الصفحة", "Page setup preview")}>
          <div className="page-setup-sheet" style={{ aspectRatio: `${size.width}/${size.height}`, padding: `${Math.min(18, margins.top / 2 + 4)}px ${Math.min(18, margins.right / 2 + 4)}px ${Math.min(18, margins.bottom / 2 + 4)}px ${Math.min(18, margins.left / 2 + 4)}px` }}>
            <div><strong>{size.label}</strong><span>{size.width.toFixed(1)} × {size.height.toFixed(1)} mm</span><small>{t("منطقة المحتوى داخل الهوامش", "Content area inside margins")}</small></div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PrintCanvasWorkspace({ slug }: { slug: string }) {
  const { locale, t } = useLocale();
  const isPoster = slug === "poster-maker";
  const isQrAsset = slug === "qr-print-designer";
  const [paper, setPaper] = useState(isPoster ? "a3" : isQrAsset ? "square" : "a5");
  const [orientation, setOrientation] = useState<Orientation>("portrait");
  const [template, setTemplate] = useState(isPoster ? "bold" : "modern");
  const [dpi, setDpi] = useState("300");
  const [margin, setMargin] = useState(14);
  const [title, setTitle] = useState(isPoster ? t("عنوان الملصق", "Poster headline") : isQrAsset ? t("امسح الرمز", "Scan the code") : t("عنوان الفلاير", "Flyer headline"));
  const [subtitle, setSubtitle] = useState(t("اكتب رسالة قصيرة وواضحة", "Add a short, clear message"));
  const [body, setBody] = useState(t("أضف تفاصيل الفعالية أو العرض أو الخدمة هنا.", "Add event, offer, or service details here."));
  const [action, setAction] = useState(t("اعرف المزيد", "Learn more"));
  const [includeQr, setIncludeQr] = useState(true);
  const [qrContent, setQrContent] = useState("https://sawi-adawati.mahmoodalhamdani.chatgpt.site");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [output, setOutput] = useState<{ url: string; blob: Blob; width: number; height: number } | null>(null);
  const size = dimensions(paper, orientation);
  const style = useMemo(() => designTemplates.find((item) => item.value === template) || designTemplates[0], [template]);

  useEffect(() => () => { if (output) URL.revokeObjectURL(output.url); }, [output]);

  async function generate() {
    if (!title.trim() || (includeQr && !qrContent.trim())) {
      setError(t("اكتب العنوان ومحتوى QR قبل الإنشاء.", "Enter a title and QR content before generating."));
      return;
    }
    setBusy(true);
    setError("");
    try {
      const scale = Number(dpi) / 25.4;
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(size.width * scale);
      canvas.height = Math.round(size.height * scale);
      const context = canvas.getContext("2d");
      if (!context) throw new Error("canvas");
      const width = canvas.width;
      const height = canvas.height;
      const padding = Math.max(40, margin * scale);

      context.fillStyle = style.background;
      context.fillRect(0, 0, width, height);
      const gradient = context.createLinearGradient(0, 0, width, height);
      gradient.addColorStop(0, `${style.accent}22`);
      gradient.addColorStop(1, `${style.accent}00`);
      context.fillStyle = gradient;
      context.fillRect(0, 0, width, height);
      context.fillStyle = style.accent;
      context.fillRect(0, 0, Math.max(18, width * 0.025), height);
      context.beginPath();
      context.arc(width * 0.84, height * 0.12, Math.min(width, height) * 0.18, 0, Math.PI * 2);
      context.globalAlpha = 0.12;
      context.fill();
      context.globalAlpha = 1;

      const align = locale === "en" ? "left" : "right";
      const textX = locale === "en" ? padding : width - padding;
      context.textAlign = align;
      context.textBaseline = "top";
      context.fillStyle = style.accent;
      context.font = `800 ${Math.max(28, width * 0.025)}px Arial, sans-serif`;
      context.fillText(subtitle.trim(), textX, padding);
      context.fillStyle = style.ink;
      context.font = `900 ${Math.max(62, width * (isPoster ? 0.075 : 0.06))}px Arial, sans-serif`;
      wrapText(context, title, textX, padding + height * 0.09, width - padding * 2, Math.max(74, height * 0.072), 4);
      context.globalAlpha = 0.84;
      context.font = `500 ${Math.max(30, width * 0.026)}px Arial, sans-serif`;
      wrapText(context, body, textX, height * 0.48, width - padding * 2, Math.max(42, height * 0.038), 6);
      context.globalAlpha = 1;

      const actionY = height - padding - Math.max(95, height * 0.075);
      const actionWidth = Math.min(width * 0.52, context.measureText(action).width + 100);
      context.fillStyle = style.accent;
      context.beginPath();
      context.roundRect(locale === "en" ? padding : width - padding - actionWidth, actionY, actionWidth, Math.max(70, height * 0.052), 22);
      context.fill();
      context.fillStyle = "#ffffff";
      context.font = `800 ${Math.max(28, width * 0.024)}px Arial, sans-serif`;
      context.textAlign = "center";
      context.textBaseline = "middle";
      context.fillText(action, locale === "en" ? padding + actionWidth / 2 : width - padding - actionWidth / 2, actionY + Math.max(70, height * 0.052) / 2);

      if (includeQr) {
        const qrSize = Math.round(Math.min(width, height) * (isQrAsset ? 0.34 : 0.22));
        const qrUrl = await QRCode.toDataURL(qrContent.trim(), { errorCorrectionLevel: "H", margin: 2, width: qrSize, color: { dark: style.ink, light: "#ffffff" } });
        const qrImage = await loadImage(qrUrl);
        const qrX = width - padding - qrSize;
        const qrY = height - padding - qrSize;
        context.fillStyle = "#ffffff";
        context.fillRect(qrX - 14, qrY - 14, qrSize + 28, qrSize + 28);
        context.drawImage(qrImage, qrX, qrY, qrSize, qrSize);
      }

      const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error("blob")), "image/png", 1));
      if (output) URL.revokeObjectURL(output.url);
      setOutput({ url: URL.createObjectURL(blob), blob, width, height });
    } catch {
      setError(t("تعذر إنشاء التصميم. تحقق من المدخلات وحاول مجدداً.", "The design could not be generated. Check the inputs and try again."));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="workspace-stack">
      <div className="print-designer-layout">
        <div className="workspace-stack">
          <div className="form-grid">
            <div className="field"><label>{t("القالب", "Template")}</label><CustomSelect value={template} onChange={(value) => { setTemplate(value); setOutput(null); }} label={t("قالب التصميم", "Design template")} options={designTemplates.map((item) => ({ value: item.value, label: locale === "en" ? item.en : item.ar }))} /></div>
            <div className="field"><label>{t("حجم الورق", "Paper size")}</label><CustomSelect value={paper} onChange={(value) => { setPaper(value); setOutput(null); }} label={t("حجم الورق", "Paper size")} options={paperSizes.map((item) => ({ value: item.value, label: item.label }))} /></div>
            <div className="field"><label>{t("الاتجاه", "Orientation")}</label><CustomSelect value={orientation} onChange={(value) => { setOrientation(value as Orientation); setOutput(null); }} label={t("اتجاه التصميم", "Design orientation")} options={[{ value: "portrait", label: t("عمودي", "Portrait") }, { value: "landscape", label: t("أفقي", "Landscape") }]} /></div>
            <div className="field"><label>{t("دقة الطباعة", "Print resolution")}</label><CustomSelect value={dpi} onChange={(value) => { setDpi(value); setOutput(null); }} label={t("دقة الطباعة", "Print resolution")} options={[{ value: "150", label: "150 DPI" }, { value: "300", label: "300 DPI" }]} /></div>
            <div className="field"><label>{t("الهامش mm", "Margin mm")}</label><input type="number" min="0" max="40" value={margin} onChange={(event) => { setMargin(Math.max(0, Number(event.target.value))); setOutput(null); }} /></div>
            <div className="field full"><label>{t("العنوان", "Headline")}</label><input value={title} onChange={(event) => { setTitle(event.target.value); setOutput(null); }} /></div>
            <div className="field full"><label>{t("العنوان الثانوي", "Subtitle")}</label><input value={subtitle} onChange={(event) => { setSubtitle(event.target.value); setOutput(null); }} /></div>
            <div className="field full"><label>{t("التفاصيل", "Details")}</label><textarea value={body} onChange={(event) => { setBody(event.target.value); setOutput(null); }} /></div>
            <div className="field"><label>{t("نص زر الدعوة", "Call-to-action text")}</label><input value={action} onChange={(event) => { setAction(event.target.value); setOutput(null); }} /></div>
            <label className="modern-check"><input type="checkbox" checked={includeQr} onChange={(event) => { setIncludeQr(event.target.checked); setOutput(null); }} /><span>{t("إضافة محتوى QR إلى التصميم", "Add QR content to design")}</span></label>
            {includeQr && <div className="field full"><label>{t("رابط أو نص QR", "QR URL or text")}</label><input dir="ltr" value={qrContent} onChange={(event) => { setQrContent(event.target.value); setOutput(null); }} /></div>}
          </div>
          <button className="primary-button" type="button" disabled={busy} onClick={generate}><Icon name="presentation" size={19} /> {busy ? t("جاري إنشاء التصميم…", "Generating design…") : t("إنشاء ومعاينة التصميم", "Generate and preview design")}</button>
          {error && <div className="error-notice" role="alert">{error}</div>}
        </div>
        <div className="print-canvas-stage">
          {output ? <img src={output.url} alt={t("معاينة تصميم الطباعة", "Print design preview")} /> : <div style={{ aspectRatio: `${size.width}/${size.height}` }}><Icon name="presentation" size={44} /><strong>{t("ستظهر المعاينة هنا", "Preview will appear here")}</strong><span>{size.label} · {dpi} DPI</span></div>}
        </div>
      </div>
      {output && <div className="ready-download" role="status"><span><Icon name="check" size={20} /> {t(`التصميم جاهز للطباعة بدقة ${dpi} DPI`, `Print design ready at ${dpi} DPI`)}</span><button className="primary-button" type="button" onClick={() => downloadBlob(output.blob, `adawati-${slug}-${paper}-${orientation}-${dpi}dpi.png`)}><Icon name="download" size={18} /> {t("تنزيل PNG للطباعة", "Download print PNG")}</button></div>}
    </div>
  );
}

export function PrintDesignWorkspace({ slug }: { slug: string }) {
  if (slug === "page-setup") return <PageSetupWorkspace />;
  if (["qr-print-designer", "flyer-maker", "poster-maker"].includes(slug))
    return <PrintCanvasWorkspace slug={slug} />;
  return null;
}
