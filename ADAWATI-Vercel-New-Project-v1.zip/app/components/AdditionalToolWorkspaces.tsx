/* eslint-disable @next/next/no-img-element */
"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { CustomSelect } from "./CustomSelect";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";
import { ModernDatePicker } from "./ModernDatePicker";
import { FileUploadZone } from "./FileUploadZone";
import { circularCropPlacement } from "@/lib/image-tools";
import {
  calendarDaysBetween,
  cleanList,
  compareUnitPrices,
  convertDigitShapes,
  convertFuelEconomy,
  countdownToStartOfDay,
  electricityUsage,
  expensePlan,
  fuelStopPlan,
  fuelTripCost,
  installmentPayment,
  internetUsage,
  requiredFinalGrade,
  shiftDate,
  taskDivision,
  wageBreakdown,
  workMinutes,
  zonedDateTimeToUtc,
  type FuelEconomyUnit,
} from "@/lib/tool-calculations";

function n(value: string | number) {
  const result = Number(value);
  return Number.isFinite(result) ? result : 0;
}
function fixed(value: number, digits = 2) {
  return new Intl.NumberFormat(undefined, {
    maximumFractionDigits: digits,
  }).format(value);
}
function download(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  window.dispatchEvent(new CustomEvent("minjaz-download-feedback"));
  setTimeout(() => URL.revokeObjectURL(url), 1200);
}
function Tip({ ar, en }: { ar: string; en: string }) {
  const { t } = useLocale();
  return (
    <p className="workspace-tip">
      <Icon name="sparkles" size={18} />
      <span>{t(ar, en)}</span>
    </p>
  );
}
function Metrics({
  items,
}: {
  items: { value: string; ar: string; en: string }[];
}) {
  const { t } = useLocale();
  return (
    <div className="metric-grid">
      {items.map((item) => (
        <div key={item.ar}>
          <strong>{item.value}</strong>
          <span>{t(item.ar, item.en)}</span>
        </div>
      ))}
    </div>
  );
}
function Numeric({
  label,
  value,
  onChange,
  min = 0,
  step = "any",
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min?: number;
  step?: string;
}) {
  return (
    <div className="field">
      <label>{label}</label>
      <input
        type="number"
        min={min}
        step={step}
        value={value}
        onChange={(e) => onChange(Math.max(min, n(e.target.value)))}
      />
    </div>
  );
}

function BlankNumeric({
  label,
  value,
  onChange,
  min = "0",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  min?: string;
}) {
  return (
    <div className="field">
      <label>{label}</label>
      <input
        type="number"
        inputMode="decimal"
        autoComplete="off"
        min={min}
        step="any"
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder="0"
      />
    </div>
  );
}

function ExpensePlanner() {
  const { t } = useLocale();
  const [income, setIncome] = useState(1500);
  const [fixedCost, setFixed] = useState(650);
  const [variable, setVariable] = useState(350);
  const [days, setDays] = useState(30);
  const [dailyTarget, setDailyTarget] = useState(25);
  const [savedNotice, setSavedNotice] = useState("");
  const plan = expensePlan(income, fixedCost, variable, days);
  const targetDifference = (plan?.daily ?? 0) - dailyTarget;

  useEffect(() => {
    let cancelled = false;
    try {
      const saved = JSON.parse(
        localStorage.getItem("minjaz-expense-budget") || "null",
      );
      if (!saved || typeof saved !== "object") return;
      queueMicrotask(() => {
        if (cancelled) return;
        if (Number.isFinite(saved.income) && saved.income >= 0)
          setIncome(saved.income);
        if (Number.isFinite(saved.fixedCost) && saved.fixedCost >= 0)
          setFixed(saved.fixedCost);
        if (Number.isFinite(saved.variable) && saved.variable >= 0)
          setVariable(saved.variable);
        if (Number.isFinite(saved.days) && saved.days >= 1) setDays(saved.days);
        if (Number.isFinite(saved.dailyTarget) && saved.dailyTarget >= 0)
          setDailyTarget(saved.dailyTarget);
        setSavedNotice(
          t(
            "تمت استعادة الميزانية المحفوظة على هذا الجهاز.",
            "Saved budget restored on this device.",
          ),
        );
      });
    } catch {
      localStorage.removeItem("minjaz-expense-budget");
    }
    return () => {
      cancelled = true;
    };
  }, [t]);

  function update(setter: (value: number) => void, value: number) {
    setter(value);
    setSavedNotice("");
  }

  function saveBudget() {
    localStorage.setItem(
      "minjaz-expense-budget",
      JSON.stringify({ income, fixedCost, variable, days, dailyTarget }),
    );
    setSavedNotice(
      t(
        "تم حفظ الميزانية والهدف اليومي بنجاح.",
        "Budget and daily target saved successfully.",
      ),
    );
  }
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <Numeric
          label={t("الدخل الشهري", "Monthly income")}
          value={income}
          onChange={(value) => update(setIncome, value)}
        />
        <Numeric
          label={t("المصاريف الثابتة", "Fixed expenses")}
          value={fixedCost}
          onChange={(value) => update(setFixed, value)}
        />
        <Numeric
          label={t("المصاريف المتغيرة", "Variable expenses")}
          value={variable}
          onChange={(value) => update(setVariable, value)}
        />
        <Numeric
          label={t("أيام الميزانية", "Budget days")}
          value={days}
          onChange={(value) => update(setDays, value)}
          min={1}
        />
        <Numeric
          label={t("هدف الإنفاق اليومي", "Daily spending target")}
          value={dailyTarget}
          onChange={(value) => update(setDailyTarget, value)}
        />
      </div>
      <Metrics
        items={[
          {
            value: fixed(plan?.remaining ?? 0),
            ar: "المتبقي الشهري",
            en: "Monthly remaining",
          },
          {
            value: fixed(plan?.daily ?? 0),
            ar: "المتاح يومياً",
            en: "Available per day",
          },
          {
            value:
              plan?.expenseRatio === null || plan?.expenseRatio === undefined
                ? "—"
                : fixed(plan.expenseRatio) + "%",
            ar: "نسبة المصروف",
            en: "Expense ratio",
          },
          {
            value: `${targetDifference >= 0 ? "+" : ""}${fixed(targetDifference)}`,
            ar: "فارق المتاح عن الهدف",
            en: "Available vs target",
          },
        ]}
      />
      <div className="button-row">
        <button className="primary-button" type="button" onClick={saveBudget}>
          <Icon name="check" size={18} />
          {t("حفظ الميزانية والهدف", "Save budget and target")}
        </button>
      </div>
      {savedNotice && (
        <div className="notice" role="status">
          {savedNotice}
        </div>
      )}
      {plan?.expenseRatio === null && (
        <div className="error-notice">
          {t(
            "أدخل دخلاً أكبر من صفر لحساب نسبة المصروف.",
            "Enter income greater than zero to calculate the expense ratio.",
          )}
        </div>
      )}
      <Tip
        ar="اجمع المصاريف المتكررة في الثابتة والمشتريات المرنة في المتغيرة لتعرف الحد اليومي الآمن"
        en="Put recurring bills under fixed expenses and flexible spending under variable expenses to find a safe daily limit"
      />
    </div>
  );
}

function FuelTrip() {
  const { t } = useLocale();
  const [workspaceGeneration, setWorkspaceGeneration] = useState(0);
  const [calculationMode, setCalculationMode] = useState("");
  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("");
  const [distance, setDistance] = useState("");
  const [consumption, setConsumption] = useState("");
  const [fuelUsed, setFuelUsed] = useState("");
  const [price, setPrice] = useState("");
  const [currency, setCurrency] = useState("");
  const [tankCapacity, setTankCapacity] = useState("");
  const [startingFuel, setStartingFuel] = useState("");
  const [reserveFuel, setReserveFuel] = useState("");
  const [round, setRound] = useState(false);
  const [hasResult, setHasResult] = useState(false);
  const [error, setError] = useState("");
  const clearWorkspace = useCallback(() => {
    setCalculationMode("");
    setOrigin("");
    setDestination("");
    setDistance("");
    setConsumption("");
    setFuelUsed("");
    setPrice("");
    setCurrency("");
    setTankCapacity("");
    setStartingFuel("");
    setReserveFuel("");
    setRound(false);
    setHasResult(false);
    setError("");
    setWorkspaceGeneration((previous) => previous + 1);
  }, []);

  useEffect(() => {
    const restoreBlankState = () => clearWorkspace();
    queueMicrotask(restoreBlankState);
    window.addEventListener("pageshow", restoreBlankState);
    return () => window.removeEventListener("pageshow", restoreBlankState);
  }, [clearWorkspace]);
  const distanceValue = n(distance);
  const consumptionValue = n(consumption);
  const fuelUsedValue = n(fuelUsed);
  const priceValue = n(price);
  const tankCapacityValue = n(tankCapacity);
  const startingFuelValue = n(startingFuel);
  const reserveFuelValue = n(reserveFuel);
  const calculatedKilometers = distanceValue * (round ? 2 : 1);
  const measuredConsumption =
    fuelUsedValue > 0 && calculatedKilometers > 0
      ? (fuelUsedValue / calculatedKilometers) * 100
      : 0;
  const activeConsumption =
    calculationMode === "efficiency" ? measuredConsumption : consumptionValue;
  const trip = fuelTripCost(
    distanceValue,
    activeConsumption,
    priceValue,
    round,
  );
  const plan = fuelStopPlan(
    distanceValue,
    activeConsumption,
    tankCapacityValue,
    startingFuelValue,
    reserveFuelValue,
    round,
  );
  const routeLabel =
    origin.trim() && destination.trim()
      ? round
        ? `${origin.trim()} → ${destination.trim()} → ${origin.trim()}`
        : `${origin.trim()} → ${destination.trim()}`
      : t("المسار غير مسمى", "Unnamed route");
  const directionsUrl =
    origin.trim() && destination.trim()
      ? `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin.trim())}&destination=${encodeURIComponent(destination.trim())}`
      : "";

  function invalidateResult() {
    setHasResult(false);
    setError("");
  }

  function updateText(setter: (value: string) => void, value: string) {
    setter(value);
    invalidateResult();
  }

  function calculateRoute() {
    const requiredValues = [
      distance,
      price,
      tankCapacity,
      startingFuel,
      reserveFuel,
      calculationMode === "efficiency" ? fuelUsed : consumption,
    ];
    if (
      !calculationMode ||
      !currency ||
      requiredValues.some((value) => !value.trim())
    ) {
      setHasResult(false);
      setError(
        t(
          "اختر طريقة الحساب والعملة وأكمل جميع الحقول الرقمية.",
          "Choose a calculation method and currency, then complete every numeric field.",
        ),
      );
      return;
    }
    if (
      distanceValue <= 0 ||
      activeConsumption <= 0 ||
      priceValue < 0 ||
      tankCapacityValue <= 0 ||
      startingFuelValue < 0 ||
      reserveFuelValue < 0 ||
      !trip ||
      !plan
    ) {
      setHasResult(false);
      setError(
        t(
          "تحقق من القيم: يجب أن تكون المسافة والاستهلاك وسعة الخزان أكبر من صفر، وألا يتجاوز الوقود المتوفر أو الاحتياطي حدود الخزان.",
          "Check the values: distance, consumption, and tank capacity must be greater than zero, and starting fuel or reserve cannot exceed the tank limits.",
        ),
      );
      return;
    }
    setError("");
    setHasResult(true);
  }

  function reset() {
    clearWorkspace();
  }

  return (
    <div className="workspace-stack">
      <div className="form-grid" key={workspaceGeneration}>
        <div className="field full">
          <label>{t("وضع الحاسبة", "Calculator mode")}</label>
          <CustomSelect
            value={calculationMode}
            onChange={(value) => {
              setCalculationMode(value);
              invalidateResult();
            }}
            label={t("اختر طريقة الحساب", "Choose calculation mode")}
            options={[
              {
                value: "",
                label: t("اختر طريقة الحساب", "Choose calculation mode"),
                disabled: true,
              },
              {
                value: "trip",
                label: t("تكلفة ووقود الرحلة", "Trip fuel and cost"),
              },
              {
                value: "efficiency",
                label: t(
                  "كفاءة الوقود من المستخدم فعلياً",
                  "Efficiency from fuel used",
                ),
              },
            ]}
          />
        </div>
        <div className="field">
          <label>{t("نقطة الانطلاق", "Starting point")}</label>
          <input
            value={origin}
            onChange={(event) => updateText(setOrigin, event.target.value)}
            autoComplete="off"
            placeholder={t("مثال: بغداد", "Example: Minneapolis")}
          />
        </div>
        <div className="field">
          <label>{t("الوجهة", "Destination")}</label>
          <input
            value={destination}
            onChange={(event) => updateText(setDestination, event.target.value)}
            autoComplete="off"
            placeholder={t("مثال: أربيل", "Example: Chicago")}
          />
        </div>
        <BlankNumeric
          label={t("المسافة بالكيلومتر", "Distance in km")}
          value={distance}
          onChange={(value) => updateText(setDistance, value)}
          min="0.01"
        />
        {calculationMode === "trip" ? (
          <BlankNumeric
            label={t("استهلاك السيارة لتر لكل 100 كم", "Vehicle L/100 km")}
            value={consumption}
            onChange={(value) => updateText(setConsumption, value)}
            min="0.01"
          />
        ) : calculationMode === "efficiency" ? (
          <BlankNumeric
            label={t(
              "كمية الوقود المستخدمة فعلياً باللتر",
              "Actual fuel used in liters",
            )}
            value={fuelUsed}
            onChange={(value) => updateText(setFuelUsed, value)}
            min="0.01"
          />
        ) : null}
        <BlankNumeric
          label={t("سعر لتر الوقود", "Fuel price per liter")}
          value={price}
          onChange={(value) => updateText(setPrice, value)}
        />
        <div className="field">
          <label>{t("عملة التكلفة", "Cost currency")}</label>
          <CustomSelect
            value={currency}
            onChange={(value) => {
              setCurrency(value);
              invalidateResult();
            }}
            label={t("اختر العملة", "Choose currency")}
            options={[
              {
                value: "",
                label: t("اختر العملة", "Choose currency"),
                disabled: true,
              },
              { value: "USD", label: "USD — $" },
              { value: "IQD", label: "IQD — د.ع" },
              { value: "EUR", label: "EUR — €" },
              { value: "SAR", label: "SAR — ر.س" },
              { value: "JOD", label: "JOD — د.أ" },
            ]}
          />
        </div>
        <BlankNumeric
          label={t("سعة خزان الوقود باللتر", "Fuel tank capacity in liters")}
          value={tankCapacity}
          onChange={(value) => updateText(setTankCapacity, value)}
          min="0.01"
        />
        <BlankNumeric
          label={t(
            "الوقود المتوفر عند الانطلاق",
            "Fuel available at departure",
          )}
          value={startingFuel}
          onChange={(value) => updateText(setStartingFuel, value)}
        />
        <BlankNumeric
          label={t("احتياطي الأمان باللتر", "Safety reserve in liters")}
          value={reserveFuel}
          onChange={(value) => updateText(setReserveFuel, value)}
        />
        <label className="modern-check">
          <input
            type="checkbox"
            checked={round}
            onChange={(e) => {
              setRound(e.target.checked);
              invalidateResult();
            }}
          />
          <span>{t("ذهاب وعودة", "Round trip")}</span>
        </label>
      </div>
      <div className="button-row">
        <button
          className="primary-button"
          type="button"
          onClick={calculateRoute}
        >
          <Icon name="map" size={18} />
          {t("احسب وخطط المسار", "Calculate and plan route")}
        </button>
        <button className="secondary-button" type="button" onClick={reset}>
          <Icon name="reset" size={18} />
          {t("مسح وإعادة تعيين", "Clear and reset")}
        </button>
      </div>
      {error && (
        <div className="error-notice" role="alert">
          {error}
        </div>
      )}
      {hasResult && trip && plan && (
        <Metrics
          items={[
            {
              value: fixed(trip?.kilometers ?? 0),
              ar: "المسافة المحسوبة كم",
              en: "Calculated km",
            },
            {
              value: fixed(trip?.liters ?? 0),
              ar: "الوقود المطلوب لتر",
              en: "Fuel needed L",
            },
            {
              value: `${fixed(trip?.cost ?? 0)} ${currency}`,
              ar: `تكلفة الرحلة (${currency})`,
              en: `Trip cost (${currency})`,
            },
            ...(calculationMode === "efficiency"
              ? [
                  {
                    value: `${fixed(measuredConsumption)} L/100 km`,
                    ar: "الاستهلاك الفعلي",
                    en: "Measured consumption",
                  },
                  {
                    value: `${fixed(fuelUsedValue > 0 ? calculatedKilometers / fuelUsedValue : 0)} km/L`,
                    ar: "كفاءة الوقود",
                    en: "Fuel efficiency",
                  },
                ]
              : []),
            {
              value: String(plan?.stops ?? 0),
              ar: "محطات التزوّد المقترحة",
              en: "Suggested fuel stops",
            },
          ]}
        />
      )}
      {hasResult && trip && plan && (
        <div className="route-plan" role="status">
          <div>
            <Icon name="map" size={20} />
            <strong>{routeLabel}</strong>
          </div>
          <p>
            {plan.stops === 0
              ? t(
                  "لا تحتاج إلى محطة وقود قبل الوصول مع الاحتياطي المحدد.",
                  "No fuel stop is needed before arrival with the selected reserve.",
                )
              : t(
                  `خطّة التزوّد: ${plan.stopKilometers.map((value, index) => `المحطة ${index + 1} قرب الكيلومتر ${fixed(value, 0)}`).join("، ")}.`,
                  `Refueling plan: ${plan.stopKilometers.map((value, index) => `stop ${index + 1} near km ${fixed(value, 0)}`).join(", ")}.`,
                )}
          </p>
          <small>
            {t(
              `المدى قبل أول محطة ${fixed(plan.firstLeg, 0)} كم، وبعد ملء الخزان ${fixed(plan.fullLeg, 0)} كم مع إبقاء الاحتياطي.`,
              `Range before the first stop is ${fixed(plan.firstLeg, 0)} km; a full tank then covers ${fixed(plan.fullLeg, 0)} km while preserving the reserve.`,
            )}
          </small>
          {directionsUrl && (
            <a
              className="secondary-button"
              href={directionsUrl}
              target="_blank"
              rel="noreferrer"
            >
              <Icon name="map" size={18} />
              {t(
                "فتح الاتجاهات والتحقق من المسافة",
                "Open directions and verify distance",
              )}
            </a>
          )}
        </div>
      )}
      <Tip
        ar="أدخل المسافة الفعلية بين نقطة الانطلاق والوجهة؛ التخطيط يحسب محطات الوقود رياضياً ولا يستبدل تطبيق الملاحة أو بيانات المحطات الحية"
        en="Enter the actual distance between start and destination. Stop planning is mathematical and does not replace live navigation or station data"
      />
    </div>
  );
}

function WorkHours() {
  const { t } = useLocale();
  const [start, setStart] = useState("08:00");
  const [end, setEnd] = useState("17:00");
  const [breakMin, setBreak] = useState(60);
  const [result, setResult] = useState<number | null>(null);
  function run() {
    setResult(workMinutes(start, end, breakMin));
  }
  function reset() {
    setStart("");
    setEnd("");
    setBreak(0);
    setResult(null);
  }
  const startLabel = t("وقت الدخول", "Check-in time");
  const endLabel = t("وقت الخروج", "Check-out time");
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field">
          <label htmlFor="work-hours-start">{startLabel}</label>
          <input
            id="work-hours-start"
            type="time"
            value={start}
            aria-label={startLabel}
            onInput={(event) => {
              setStart(event.currentTarget.value);
              setResult(null);
            }}
            onChange={(e) => {
              setStart(e.target.value);
              setResult(null);
            }}
          />
        </div>
        <div className="field">
          <label htmlFor="work-hours-end">{endLabel}</label>
          <input
            id="work-hours-end"
            type="time"
            value={end}
            aria-label={endLabel}
            onInput={(event) => {
              setEnd(event.currentTarget.value);
              setResult(null);
            }}
            onChange={(e) => {
              setEnd(e.target.value);
              setResult(null);
            }}
          />
        </div>
        <Numeric
          label={t("الاستراحة بالدقائق", "Break in minutes")}
          value={breakMin}
          onChange={(value) => {
            setBreak(value);
            setResult(null);
          }}
        />
      </div>
      <div className="button-row">
        <button className="primary-button" onClick={run}>
          {t("احسب ساعات العمل", "Calculate work hours")}
        </button>
        <button className="secondary-button" type="button" onClick={reset}>
          <Icon name="reset" size={18} />
          {t("مسح وإعادة تعيين", "Clear and reset")}
        </button>
      </div>
      {result !== null && (
        <Metrics
          items={[
            {
              value: `${Math.floor(result / 60)}:${String(result % 60).padStart(2, "0")}`,
              ar: "ساعات ودقائق",
              en: "Hours and minutes",
            },
            {
              value: fixed(result / 60),
              ar: "ساعات عشرية",
              en: "Decimal hours",
            },
          ]}
        />
      )}
      <Tip
        ar="تدعم الحاسبة الوردية التي تنتهي بعد منتصف الليل وتطرح وقت الاستراحة من المجموع"
        en="The calculator supports overnight shifts and subtracts break time from the total"
      />
    </div>
  );
}

function HourlyWage() {
  const { t } = useLocale();
  const [mode, setMode] = useState("monthly");
  const [amount, setAmount] = useState(1200);
  const [days, setDays] = useState(22);
  const [hours, setHours] = useState(8);
  const wage = wageBreakdown(
    mode as "monthly" | "daily" | "hourly",
    amount,
    days,
    hours,
  );
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field">
          <label>{t("نوع القيمة المدخلة", "Input type")}</label>
          <CustomSelect
            value={mode}
            onChange={setMode}
            label={t("نوع القيمة", "Value type")}
            options={[
              { value: "monthly", label: t("راتب شهري", "Monthly salary") },
              { value: "daily", label: t("أجر يومي", "Daily wage") },
              { value: "hourly", label: t("أجر بالساعة", "Hourly wage") },
            ]}
          />
        </div>
        <Numeric
          label={t("القيمة", "Amount")}
          value={amount}
          onChange={setAmount}
        />
        <Numeric
          label={t("أيام العمل في الشهر", "Workdays per month")}
          value={days}
          onChange={setDays}
          min={1}
        />
        <Numeric
          label={t("ساعات العمل يومياً", "Hours per day")}
          value={hours}
          onChange={setHours}
          min={1}
        />
      </div>
      <Metrics
        items={[
          { value: fixed(wage?.monthly ?? 0), ar: "شهرياً", en: "Monthly" },
          {
            value: fixed(wage?.daily ?? 0),
            ar: "يومياً",
            en: "Daily",
          },
          { value: fixed(wage?.hourly ?? 0), ar: "بالساعة", en: "Hourly" },
        ]}
      />
      <Tip
        ar="التحويل يعتمد على عدد أيام وساعات عملك الفعلية وليس على متوسط ثابت"
        en="The conversion uses your actual working days and hours instead of a fixed average"
      />
    </div>
  );
}

function Installments() {
  const { t } = useLocale();
  const [price, setPrice] = useState(5000);
  const [down, setDown] = useState(500);
  const [months, setMonths] = useState(12);
  const [interest, setInterest] = useState(0);
  const result = installmentPayment(price, down, months, interest);
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <Numeric
          label={t("مبلغ الشراء", "Purchase amount")}
          value={price}
          onChange={setPrice}
        />
        <Numeric
          label={t("الدفعة الأولى", "Down payment")}
          value={down}
          onChange={setDown}
        />
        <Numeric
          label={t("عدد الأشهر", "Number of months")}
          value={months}
          onChange={setMonths}
          min={1}
        />
        <Numeric
          label={t("الفائدة السنوية % اختياري", "Annual interest % optional")}
          value={interest}
          onChange={setInterest}
        />
      </div>
      {result ? (
        <Metrics
          items={[
            {
              value: fixed(result.payment),
              ar: "القسط الشهري",
              en: "Monthly payment",
            },
            {
              value: fixed(result.total),
              ar: "إجمالي المدفوع",
              en: "Total paid",
            },
            {
              value: fixed(result.financingCost),
              ar: "تكلفة التمويل",
              en: "Financing cost",
            },
          ]}
        />
      ) : (
        <div className="error-notice">
          {t(
            "تحقق من مبلغ الشراء والدفعة والمدة والفائدة",
            "Check the purchase amount, down payment, term, and interest",
          )}
        </div>
      )}
      <Tip
        ar="عند إدخال فائدة سنوية تستخدم الحاسبة القسط المتناقص، أما صفر فيقسم المبلغ بالتساوي"
        en="With annual interest the tool uses amortized payments; at zero interest it divides the balance equally"
      />
      <p className="workspace-disclaimer">
        {t(
          "النتائج تقديرية وتحقق من جدول الجهة الممولة قبل الالتزام",
          "Results are estimates; verify the lender schedule before committing",
        )}
      </p>
    </div>
  );
}

function DateShift() {
  const { t } = useLocale();
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [days, setDays] = useState(45);
  const [direction, setDirection] = useState("after");
  const shifted = shiftDate(
    date,
    (direction === "after" ? 1 : -1) * Math.max(0, days),
  );
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <ModernDatePicker
          label={t("التاريخ الأساسي", "Starting date")}
          value={date}
          onChange={setDate}
        />
        <Numeric
          label={t("عدد الأيام", "Number of days")}
          value={days}
          onChange={setDays}
        />
        <div className="field full">
          <label>{t("الاتجاه", "Direction")}</label>
          <CustomSelect
            value={direction}
            onChange={setDirection}
            label={t("قبل أو بعد", "Before or after")}
            options={[
              { value: "after", label: t("بعد التاريخ", "After date") },
              { value: "before", label: t("قبل التاريخ", "Before date") },
            ]}
          />
        </div>
      </div>
      {shifted && (
        <Metrics
          items={[
            {
              value: new Intl.DateTimeFormat(undefined, {
                dateStyle: "full",
                timeZone: "UTC",
              }).format(new Date(`${shifted}T12:00:00Z`)),
              ar: "التاريخ الناتج",
              en: "Result date",
            },
          ]}
        />
      )}
      <Tip
        ar="يُحسب عدد الأيام تقويمياً ويشمل عطلات نهاية الأسبوع"
        en="Days are counted as calendar days and include weekends"
      />
    </div>
  );
}

function Countdown() {
  const { t } = useLocale();
  const [target, setTarget] = useState("");
  const [name, setName] = useState("");
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 30_000);
    return () => window.clearInterval(timer);
  }, []);
  const remaining = target ? countdownToStartOfDay(target, now) : null;
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field">
          <label>{t("اسم الموعد", "Event name")}</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t("سفر أو امتحان", "Trip or exam")}
          />
        </div>
        <ModernDatePicker
          label={t("تاريخ الموعد — يبدأ 00:00", "Event date — starts at 00:00")}
          value={target}
          onChange={setTarget}
        />
      </div>
      {remaining && (
        <Metrics
          items={[
            {
              value: String(remaining.days),
              ar: "يوم متبقٍ",
              en: "Days remaining",
            },
            {
              value: String(remaining.hours),
              ar: "ساعة إضافية",
              en: "Extra hours",
            },
            {
              value: String(remaining.minutes),
              ar: "دقيقة إضافية",
              en: "Extra minutes",
            },
            {
              value: remaining.reached
                ? t("حلّ الموعد", "Due now")
                : name || t("الموعد", "Event"),
              ar: "الحالة",
              en: "Status",
            },
          ]}
        />
      )}
      <Tip
        ar="يُحسب الموعد من الساعة 00:00 في بداية اليوم المختار، وليس من نهاية ذلك اليوم"
        en="The countdown targets 00:00 at the start of the selected date, not the end of that day"
      />
    </div>
  );
}

function worldTimeZones(locale: string) {
  const supported = (
    Intl as typeof Intl & { supportedValuesOf?: (key: "timeZone") => string[] }
  ).supportedValuesOf?.("timeZone") || [
    "Africa/Cairo",
    "America/Chicago",
    "America/Los_Angeles",
    "America/New_York",
    "Asia/Baghdad",
    "Asia/Dubai",
    "Asia/Riyadh",
    "Asia/Tokyo",
    "Australia/Sydney",
    "Europe/Istanbul",
    "Europe/London",
    "UTC",
  ];
  return [...new Set([...supported, "UTC"])]
    .map((value) => {
      const pieces = value.split("/"),
        city = (pieces.at(-1) || value).replaceAll("_", " "),
        region = pieces
          .slice(0, -1)
          .map((part) => part.replaceAll("_", " "))
          .join(" · ");
      return {
        value,
        label: city,
        hint: region || tZone(locale, "توقيت عالمي", "Universal time"),
      };
    })
    .sort((a, b) => a.label.localeCompare(b.label, locale));
}
function tZone(locale: string, ar: string, en: string) {
  return locale === "en" ? en : ar;
}
function TimezoneConverter() {
  const { t, locale } = useLocale();
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [time, setTime] = useState("20:00");
  const [from, setFrom] = useState("Asia/Baghdad");
  const [to, setTo] = useState("America/New_York");
  const zones = worldTimeZones(locale);
  const instant = zonedDateTimeToUtc(date, time, from);
  const output = instant
    ? new Intl.DateTimeFormat(locale === "en" ? "en-US" : "ar-IQ", {
        timeZone: to,
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
        timeZoneName: "long",
      }).format(instant)
    : t("أدخل تاريخاً ووقتاً صالحين", "Enter a valid date and time");
  const timeLabel = t("الوقت", "Time");
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <ModernDatePicker
          label={t("التاريخ", "Date")}
          value={date}
          onChange={setDate}
        />
        <div className="field">
          <label htmlFor="timezone-source-time">{timeLabel}</label>
          <input
            id="timezone-source-time"
            type="time"
            value={time}
            aria-label={timeLabel}
            onInput={(event) => setTime(event.currentTarget.value)}
            onChange={(e) => setTime(e.target.value)}
          />
        </div>
        <div className="field">
          <label>
            {t("من دولة أو ولاية أو مدينة", "From country state or city")}
          </label>
          <CustomSelect
            value={from}
            onChange={setFrom}
            label={t("ابحث عن المنطقة الأصلية", "Search source location")}
            options={zones}
          />
        </div>
        <div className="field">
          <label>
            {t("إلى دولة أو ولاية أو مدينة", "To country state or city")}
          </label>
          <CustomSelect
            value={to}
            onChange={setTo}
            label={t("ابحث عن المنطقة الهدف", "Search target location")}
            options={zones}
          />
        </div>
      </div>
      <Metrics
        items={[
          { value: output, ar: "الوقت المحول", en: "Converted time" },
          {
            value: String(zones.length),
            ar: "منطقة زمنية حقيقية متاحة",
            en: "Real time zones available",
          },
        ]}
      />
      <Tip
        ar="القائمة مأخوذة من قاعدة IANA المدمجة في المتصفح وتشمل المناطق العالمية المدعومة وتحسب التوقيت الصيفي بحسب التاريخ المختار"
        en="The list comes from the browser IANA database and covers its supported world regions with daylight saving calculated for the selected date"
      />
    </div>
  );
}

const unitGroups = {
  length: {
    m: 1,
    km: 1000,
    cm: 0.01,
    mm: 0.001,
    in: 0.0254,
    ft: 0.3048,
    mi: 1609.344,
  },
  weight: { kg: 1, g: 0.001, lb: 0.45359237, oz: 0.0283495 },
  area: { "m²": 1, "km²": 1e6, "ft²": 0.092903, acre: 4046.856 },
  volume: { L: 1, mL: 0.001, "m³": 1000, gal: 3.78541 },
  speed: { "m/s": 1, "km/h": 1 / 3.6, mph: 0.44704 },
  data: { B: 1, KB: 1024, MB: 1048576, GB: 1073741824, TB: 1099511627776 },
} as const;
const fuelEconomyUnits: FuelEconomyUnit[] = [
  "L/100 km",
  "km/L",
  "mpg (US)",
  "mpg (UK)",
];
function UnitConverter() {
  const { t } = useLocale();
  const [group, setGroup] = useState("length");
  const [value, setValue] = useState(1);
  const names: Record<string, string> = {
    length: t("الطول", "Length"),
    weight: t("الوزن", "Weight"),
    temperature: t("الحرارة", "Temperature"),
    area: t("المساحة", "Area"),
    volume: t("الحجم", "Volume"),
    speed: t("السرعة", "Speed"),
    data: t("البيانات", "Data"),
    fuelEconomy: t("استهلاك الوقود", "Fuel economy"),
  };
  const options =
    group === "temperature"
      ? ["C", "F", "K"]
      : group === "fuelEconomy"
        ? fuelEconomyUnits
        : Object.keys(unitGroups[group as keyof typeof unitGroups]);
  const [from, setFrom] = useState("m"),
    [to, setTo] = useState("km");
  function changeGroup(next: string) {
    const nextOptions =
      next === "temperature"
        ? ["C", "F", "K"]
        : next === "fuelEconomy"
          ? fuelEconomyUnits
          : Object.keys(unitGroups[next as keyof typeof unitGroups]);
    setGroup(next);
    setFrom(nextOptions[0]);
    setTo(nextOptions[1] || nextOptions[0]);
  }
  let result = 0;
  if (group === "temperature") {
    const c =
      from === "C"
        ? value
        : from === "F"
          ? ((value - 32) * 5) / 9
          : value - 273.15;
    result = to === "C" ? c : to === "F" ? (c * 9) / 5 + 32 : c + 273.15;
  } else if (group === "fuelEconomy") {
    result =
      convertFuelEconomy(
        value,
        from as FuelEconomyUnit,
        to as FuelEconomyUnit,
      ) ?? 0;
  } else {
    const table = unitGroups[group as keyof typeof unitGroups] as Record<
      string,
      number
    >;
    result = (value * (table[from] || 1)) / (table[to] || 1);
  }
  function unitLabel(unit: string) {
    if (group !== "fuelEconomy") return unit;
    return (
      {
        "L/100 km": t("لتر/100 كم (L/100 km)", "Liters per 100 km (L/100 km)"),
        "km/L": t("كم/لتر (km/L)", "Kilometers per liter (km/L)"),
        "mpg (US)": t(
          "ميل/غالون أمريكي (mpg US)",
          "Miles per US gallon (mpg US)",
        ),
        "mpg (UK)": t(
          "ميل/غالون بريطاني (mpg UK)",
          "Miles per UK gallon (mpg UK)",
        ),
      }[unit] || unit
    );
  }
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field full">
          <label>{t("نوع الوحدة", "Unit category")}</label>
          <CustomSelect
            value={group}
            onChange={changeGroup}
            label={t("نوع الوحدة", "Unit category")}
            options={Object.entries(names).map(([value, label]) => ({
              value,
              label,
            }))}
          />
        </div>
        <Numeric
          label={t("القيمة", "Value")}
          value={value}
          onChange={setValue}
          min={
            group === "temperature"
              ? from === "K"
                ? 0
                : from === "F"
                  ? -459.67
                  : -273.15
              : group === "fuelEconomy"
                ? 0.000001
                : 0
          }
        />
        <div className="field">
          <label>{t("من", "From")}</label>
          <CustomSelect
            value={from}
            onChange={setFrom}
            label={t("الوحدة الأصلية", "Source unit")}
            options={options.map((x) => ({ value: x, label: unitLabel(x) }))}
          />
        </div>
        <div className="field">
          <label>{t("إلى", "To")}</label>
          <CustomSelect
            value={to}
            onChange={setTo}
            label={t("الوحدة الهدف", "Target unit")}
            options={options.map((x) => ({ value: x, label: unitLabel(x) }))}
          />
        </div>
      </div>
      <Metrics
        items={[
          { value: `${fixed(result, 6)} ${to}`, ar: "النتيجة", en: "Result" },
        ]}
      />
      <Tip
        ar={
          group === "fuelEconomy"
            ? "يدعم التحويل بين لتر لكل 100 كم، كيلومتر لكل لتر، وMPG الأمريكي والبريطاني"
            : "تحويل البيانات يستخدم النظام الثنائي حيث كل 1 KB يساوي 1024 بايت"
        }
        en={
          group === "fuelEconomy"
            ? "Convert between L/100 km, km/L, US mpg, and UK mpg"
            : "Data conversion uses the binary system where 1 KB equals 1024 bytes"
        }
      />
    </div>
  );
}

function Electricity() {
  const { t } = useLocale();
  const [watts, setWatts] = useState(1000),
    [hours, setHours] = useState(5),
    [days, setDays] = useState(30),
    [price, setPrice] = useState(0.1);
  const usage = electricityUsage(watts, hours, days, price);
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <Numeric
          label={t("قدرة الجهاز بالواط", "Device wattage")}
          value={watts}
          onChange={setWatts}
        />
        <Numeric
          label={t("ساعات التشغيل يومياً", "Hours per day")}
          value={hours}
          onChange={setHours}
        />
        <Numeric
          label={t("عدد الأيام", "Days")}
          value={days}
          onChange={setDays}
        />
        <Numeric
          label={t("سعر الكيلوواط ساعة", "Price per kWh")}
          value={price}
          onChange={setPrice}
        />
      </div>
      <Metrics
        items={[
          {
            value: fixed(usage?.kwh ?? 0),
            ar: "الاستهلاك kWh",
            en: "Usage kWh",
          },
          {
            value: fixed(usage?.cost ?? 0),
            ar: "التكلفة التقريبية",
            en: "Estimated cost",
          },
        ]}
      />
      <Tip
        ar="اقرأ القدرة W من ملصق الجهاز والنتيجة تقديرية لأن بعض الأجهزة تعمل بقدرة متغيرة"
        en="Find wattage W on the device label; the result is approximate because some devices vary their power draw"
      />
    </div>
  );
}

const dataRates = {
  sd: 0.7,
  hd: 1.5,
  fullhd: 3,
  uhd: 7,
  meeting: 1,
  browsing: 0.15,
};
function InternetData() {
  const { t } = useLocale();
  const [activity, setActivity] = useState("hd"),
    [hours, setHours] = useState(2),
    [days, setDays] = useState(30);
  const usage = internetUsage(
    dataRates[activity as keyof typeof dataRates],
    hours,
    days,
  );
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field">
          <label>{t("النشاط أو الجودة", "Activity or quality")}</label>
          <CustomSelect
            value={activity}
            onChange={setActivity}
            label={t("الاستخدام", "Usage")}
            options={[
              { value: "sd", label: "Video SD" },
              { value: "hd", label: "Video HD" },
              { value: "fullhd", label: "Video Full HD" },
              { value: "uhd", label: "Video 4K" },
              { value: "meeting", label: t("اجتماع فيديو", "Video meeting") },
              {
                value: "browsing",
                label: t("تصفح اجتماعي", "Social browsing"),
              },
            ]}
          />
        </div>
        <Numeric
          label={t("ساعات يومياً", "Hours per day")}
          value={hours}
          onChange={setHours}
        />
        <Numeric
          label={t("عدد الأيام", "Days")}
          value={days}
          onChange={setDays}
        />
      </div>
      <Metrics
        items={[
          {
            value: fixed(usage?.gigabytes ?? 0) + " GB",
            ar: "الاستهلاك المتوقع",
            en: "Estimated usage",
          },
          {
            value: fixed(usage?.suggestedPlan ?? 0) + " GB",
            ar: "باقة مقترحة مع هامش",
            en: "Suggested plan with buffer",
          },
        ]}
      />
      <Tip
        ar="القيم تقريبية وقد تختلف حسب ضغط الفيديو وجودة الصوت وسياسة التطبيق"
        en="Values are estimates and vary with compression, audio quality, and app behavior"
      />
    </div>
  );
}

type ShopItem = {
  id: string;
  name: string;
  qty: number;
  price: number;
  done: boolean;
};
function ShoppingList() {
  const { t } = useLocale();
  const [items, setItems] = useState<ShopItem[]>([
    { id: "first-item", name: "", qty: 1, price: 0, done: false },
  ]);
  const total = items.reduce((s, x) => s + x.qty * x.price, 0);
  function update(id: string, patch: Partial<ShopItem>) {
    setItems((current) =>
      current.map((x) => (x.id === id ? { ...x, ...patch } : x)),
    );
  }
  return (
    <div className="workspace-stack">
      <div className="shopping-list">
        {items.map((item, index) => (
          <div key={item.id} className={item.done ? "done" : ""}>
            <label className="modern-check">
              <input
                type="checkbox"
                checked={item.done}
                onChange={(e) => update(item.id, { done: e.target.checked })}
              />
              <span>{index + 1}</span>
            </label>
            <input
              aria-label={t("اسم العنصر", "Item name")}
              value={item.name}
              onChange={(e) => update(item.id, { name: e.target.value })}
              placeholder={t("اسم المنتج", "Item")}
            />
            <input
              aria-label={t("الكمية", "Quantity")}
              type="number"
              min="1"
              value={item.qty}
              onChange={(e) =>
                update(item.id, { qty: Math.max(1, n(e.target.value)) })
              }
            />
            <input
              aria-label={t("السعر", "Price")}
              type="number"
              min="0"
              value={item.price}
              onChange={(e) =>
                update(item.id, { price: Math.max(0, n(e.target.value)) })
              }
            />
            <strong>{fixed(item.qty * item.price)}</strong>
            <button
              onClick={() =>
                setItems((current) => current.filter((x) => x.id !== item.id))
              }
              aria-label={t("حذف", "Delete")}
            >
              <Icon name="x" size={18} />
            </button>
          </div>
        ))}
      </div>
      <button
        className="secondary-button"
        onClick={() =>
          setItems((current) => [
            ...current,
            {
              id: crypto.randomUUID(),
              name: "",
              qty: 1,
              price: 0,
              done: false,
            },
          ])
        }
      >
        {t("إضافة عنصر", "Add item")}
      </button>
      <Metrics
        items={[
          { value: fixed(total), ar: "المجموع", en: "Total" },
          {
            value: String(items.filter((x) => x.done).length),
            ar: "تم شراؤها",
            en: "Purchased",
          },
          {
            value: String(items.length - items.filter((x) => x.done).length),
            ar: "متبقية",
            en: "Remaining",
          },
        ]}
      />
      <Tip
        ar="علّم العنصر أثناء التسوق ليبقى المجموع والقائمة أمامك في شاشة واحدة"
        en="Check items while shopping to keep the list and total together on one screen"
      />
    </div>
  );
}

function UnitPrice() {
  const { t } = useLocale();
  const [q1, setQ1] = useState(12),
    [p1, setP1] = useState(20),
    [q2, setQ2] = useState(18),
    [p2, setP2] = useState(27);
  const comparison = compareUnitPrices(q1, p1, q2, p2);
  return (
    <div className="workspace-stack">
      <div className="comparison-grid">
        <section>
          <h3>{t("العرض الأول", "First offer")}</h3>
          <Numeric
            label={t("الكمية", "Quantity")}
            value={q1}
            onChange={setQ1}
            min={1}
          />
          <Numeric label={t("السعر", "Price")} value={p1} onChange={setP1} />
        </section>
        <section>
          <h3>{t("العرض الثاني", "Second offer")}</h3>
          <Numeric
            label={t("الكمية", "Quantity")}
            value={q2}
            onChange={setQ2}
            min={1}
          />
          <Numeric label={t("السعر", "Price")} value={p2} onChange={setP2} />
        </section>
      </div>
      <Metrics
        items={[
          {
            value: fixed(comparison?.first ?? 0),
            ar: "سعر وحدة العرض الأول",
            en: "First unit price",
          },
          {
            value: fixed(comparison?.second ?? 0),
            ar: "سعر وحدة العرض الثاني",
            en: "Second unit price",
          },
          {
            value:
              comparison?.better === "equal"
                ? t("متساويان", "Equal")
                : comparison?.better === "first"
                  ? t("العرض الأول", "First offer")
                  : t("العرض الثاني", "Second offer"),
            ar: "الأوفر",
            en: "Better value",
          },
        ]}
      />
      <Tip
        ar="المقارنة تقسم السعر على الكمية لذلك تبقى عادلة حتى لو اختلف حجم العرضين"
        en="The comparison divides price by quantity, keeping it fair even when pack sizes differ"
      />
    </div>
  );
}

const currencies = [
  "IQD",
  "USD",
  "EUR",
  "GBP",
  "AED",
  "SAR",
  "TRY",
  "JPY",
  "CAD",
  "AUD",
  "CHF",
  "KWD",
  "QAR",
  "JOD",
];
function CurrencyConverter() {
  const { t } = useLocale();
  const [amount, setAmount] = useState(100),
    [from, setFrom] = useState("USD"),
    [to, setTo] = useState("IQD"),
    [rate, setRate] = useState(1320),
    [result, setResult] = useState<{
      value: number;
      rate: number;
    } | null>(null);
  function run() {
    const appliedRate = from === to ? 1 : rate;
    if (
      !Number.isFinite(amount) ||
      amount < 0 ||
      !Number.isFinite(appliedRate) ||
      appliedRate <= 0
    )
      return;
    setResult({ value: amount * appliedRate, rate: appliedRate });
  }
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <Numeric
          label={t("المبلغ", "Amount")}
          value={amount}
          onChange={setAmount}
        />
        <div className="field">
          <label>{t("من عملة", "From currency")}</label>
          <CustomSelect
            value={from}
            onChange={setFrom}
            label={t("العملة الأصلية", "Source currency")}
            options={currencies.map((x) => ({ value: x, label: x }))}
          />
        </div>
        <div className="field">
          <label>{t("إلى عملة", "To currency")}</label>
          <CustomSelect
            value={to}
            onChange={setTo}
            label={t("العملة الهدف", "Target currency")}
            options={currencies.map((x) => ({ value: x, label: x }))}
          />
        </div>
        <Numeric
          label={t(`سعر 1 ${from} بعملة ${to}`, `Value of 1 ${from} in ${to}`)}
          value={from === to ? 1 : rate}
          onChange={setRate}
        />
      </div>
      <button className="primary-button" onClick={run}>
        {t("تحويل محلياً", "Convert locally")}
      </button>
      {result && (
        <Metrics
          items={[
            {
              value: `${fixed(result.value, 4)} ${to}`,
              ar: "المبلغ المحول",
              en: "Converted amount",
            },
            {
              value: `1 ${from} = ${fixed(result.rate, 6)} ${to}`,
              ar: "سعر الصرف",
              en: "Exchange rate",
            },
            {
              value: t("مدخل يدوياً", "Entered manually"),
              ar: "مصدر السعر",
              en: "Rate source",
            },
          ]}
        />
      )}
      <Tip
        ar="أدخل سعر الصرف الذي تثق به؛ الحساب يتم بالكامل على جهازك ولا يتصل بأي مصدر خارجي"
        en="Enter a rate from a source you trust; calculation stays entirely on your device"
      />
    </div>
  );
}

function RequiredGrade() {
  const { t } = useLocale();
  const [current, setCurrent] = useState(75),
    [currentWeight, setWeight] = useState(60),
    [target, setTarget] = useState(80);
  const needed = requiredFinalGrade(current, currentWeight, target);
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <Numeric
          label={t("المعدل الحالي", "Current average")}
          value={current}
          onChange={setCurrent}
        />
        <Numeric
          label={t("وزن الأعمال الحالية %", "Completed weight %")}
          value={currentWeight}
          onChange={setWeight}
        />
        <Numeric
          label={t("المعدل المطلوب", "Target average")}
          value={target}
          onChange={setTarget}
        />
      </div>
      {needed === null ? (
        <div className="error-notice">
          {t(
            "وزن الأعمال الحالية يجب أن يكون من 0 إلى أقل من 100",
            "Completed weight must be from 0 to less than 100",
          )}
        </div>
      ) : (
        <Metrics
          items={[
            {
              value: fixed(needed) + "%",
              ar: "درجة النهائي المطلوبة",
              en: "Required final grade",
            },
            {
              value:
                needed <= 100 && needed >= 0
                  ? t("ممكنة", "Achievable")
                  : t("غير ممكنة ضمن 100", "Not possible within 100"),
              ar: "الحالة",
              en: "Status",
            },
          ]}
        />
      )}
      <Tip
        ar="أدخل وزن أعمال السنة المنجزة وسيكون الباقي هو وزن الامتحان النهائي"
        en="Enter the completed coursework weight; the remaining percentage is treated as the final exam"
      />
    </div>
  );
}

function TaskDivider() {
  const { t } = useLocale();
  const [tasks, setTasks] = useState(180),
    [days, setDays] = useState(30),
    [rest, setRest] = useState(0);
  const division = taskDivision(tasks, days, rest);
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <Numeric
          label={t("عدد المهام", "Number of tasks")}
          value={tasks}
          onChange={setTasks}
          min={1}
        />
        <Numeric
          label={t("عدد الأيام", "Number of days")}
          value={days}
          onChange={setDays}
          min={1}
        />
        <Numeric
          label={t("أيام الراحة", "Rest days")}
          value={rest}
          onChange={setRest}
        />
      </div>
      {division ? (
        <Metrics
          items={[
            {
              value: String(division.tasksPerDay),
              ar: "مهمة يومياً",
              en: "Tasks per day",
            },
            {
              value: String(division.activeDays),
              ar: "يوم عمل",
              en: "Working days",
            },
            {
              value: String(division.spareCapacity),
              ar: "سعة زائدة في آخر يوم",
              en: "Spare capacity on final day",
            },
          ]}
        />
      ) : (
        <div className="error-notice">
          {t(
            "يجب أن تكون أيام الراحة أقل من مجموع الأيام",
            "Rest days must be fewer than total days",
          )}
        </div>
      )}
      <Tip
        ar="وزّع أيام الراحة أولاً ثم نفّذ العدد اليومي ويمكنك إنجاز الزيادة في الأيام المبكرة"
        en="Set rest days first, then follow the daily target and use early days for any extra capacity"
      />
    </div>
  );
}

function DigitConverter() {
  const { t } = useLocale();
  const [value, setValue] = useState("");
  const [result, setResult] = useState("");
  return (
    <div className="workspace-stack">
      <div className="field">
        <label>{t("النص أو الأرقام", "Text or digits")}</label>
        <textarea
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="١٢٣ أو 123"
        />
      </div>
      <div className="button-row">
        <button
          className="primary-button"
          onClick={() => setResult(convertDigitShapes(value, "ar"))}
        >
          {t("إلى أرقام عربية", "To Arabic digits")}
        </button>
        <button
          className="secondary-button"
          onClick={() => setResult(convertDigitShapes(value, "en"))}
        >
          {t("إلى أرقام إنجليزية", "To English digits")}
        </button>
      </div>
      {result && (
        <div className="field">
          <label>{t("النتيجة", "Result")}</label>
          <textarea readOnly value={result} />
        </div>
      )}
      <Tip
        ar="يتغير شكل الأرقام فقط ويبقى النص والرموز الأخرى كما هي"
        en="Only digit shapes change; all other text and symbols stay unchanged"
      />
    </div>
  );
}

function ListCleaner() {
  const { t } = useLocale();
  const [value, setValue] = useState("");
  const [sort, setSort] = useState(true);
  const { items, unique, duplicateCount } = cleanList(value, sort);
  return (
    <div className="workspace-stack">
      <div className="field">
        <label>{t("القائمة", "List")}</label>
        <textarea
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder={t("كل عنصر في سطر", "One item per line")}
        />
      </div>
      <label className="modern-check">
        <input
          type="checkbox"
          checked={sort}
          onChange={(e) => setSort(e.target.checked)}
        />
        <span>
          {t("ترتيب أبجدي بعد إزالة التكرار", "Sort after removing duplicates")}
        </span>
      </label>
      <Metrics
        items={[
          {
            value: String(items.length),
            ar: "قبل التنظيف",
            en: "Before cleaning",
          },
          {
            value: String(unique.length),
            ar: "بعد التنظيف",
            en: "After cleaning",
          },
          {
            value: String(duplicateCount),
            ar: "عناصر مكررة",
            en: "Duplicates",
          },
        ]}
      />
      <div className="field">
        <label>{t("القائمة النظيفة", "Clean list")}</label>
        <textarea readOnly value={unique.join("\n")} />
      </div>
      <Tip
        ar="تتجاهل الأداة اختلاف حالة الأحرف الإنجليزية عند اكتشاف التكرار"
        en="Duplicate detection ignores English letter case"
      />
    </div>
  );
}

function SubscriptionDuration() {
  const { t } = useLocale();
  const [start, setStart] = useState(""),
    [end, setEnd] = useState("");
  const now = new Date(),
    today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`,
    total = start && end ? calendarDaysBetween(start, end) : null,
    elapsedRaw = start ? calendarDaysBetween(start, today) : null,
    elapsed =
      total !== null && total >= 0
        ? Math.max(0, Math.min(total, elapsedRaw || 0))
        : 0;
  return (
    <div className="workspace-stack">
      <div className="date-card-grid">
        <section className="date-input-card">
          <ModernDatePicker
            label={t("بداية الاشتراك", "Subscription start")}
            value={start}
            onChange={setStart}
          />
        </section>
        <section className="date-input-card">
          <ModernDatePicker
            label={t("نهاية الاشتراك", "Subscription end")}
            value={end}
            onChange={setEnd}
          />
        </section>
      </div>
      {start &&
        end &&
        (total === null || total < 0 ? (
          <div className="error-notice">
            {t(
              "تاريخ النهاية يجب أن يأتي بعد تاريخ البداية",
              "The end date must be after the start date",
            )}
          </div>
        ) : (
          <Metrics
            items={[
              {
                value: String(total),
                ar: "مدة الاشتراك بالأيام",
                en: "Subscription days",
              },
              {
                value: String(elapsed),
                ar: "أيام مستخدمة",
                en: "Days elapsed",
              },
              {
                value: String(Math.max(0, total - elapsed)),
                ar: "أيام متبقية",
                en: "Days remaining",
              },
            ]}
          />
        ))}
      <Tip
        ar="إذا بدأ الاشتراك مستقبلاً تبقى الأيام المستخدمة صفراً حتى يحين موعده"
        en="If the subscription starts in the future, elapsed days remain zero until it begins"
      />
    </div>
  );
}

type Reminder = { id: string; name: string; date: string };
function ExpiryReminder() {
  const { t, locale } = useLocale();
  const [name, setName] = useState("");
  const [date, setDate] = useState("");
  const [items, setItems] = useState<Reminder[]>([]);
  const [notice, setNotice] = useState("");
  useEffect(() => {
    queueMicrotask(() => {
      let saved: Reminder[] = [];
      try {
        const parsed = JSON.parse(
          localStorage.getItem("minjaz-reminders") || "[]",
        );
        saved = Array.isArray(parsed)
          ? parsed.filter((item): item is Reminder =>
              Boolean(
                item &&
                typeof item.id === "string" &&
                typeof item.name === "string" &&
                typeof item.date === "string",
              ),
            )
          : [];
      } catch {
        localStorage.removeItem("minjaz-reminders");
      }
      setItems(saved);
      saved
        .filter((x) => new Date(`${x.date}T00:00:00`) <= new Date())
        .forEach((x) => {
          if ("Notification" in window && Notification.permission === "granted")
            new Notification(
              locale === "en" ? "ADAWATI reminder" : "تذكير أدواتي",
              { body: x.name },
            );
        });
    });
  }, [locale]);
  function save() {
    if (!name.trim() || !date) {
      setNotice(
        t(
          "أدخل اسم الموعد وتاريخ الانتهاء",
          "Enter a reminder name and expiry date",
        ),
      );
      return;
    }
    const next = [
      ...items,
      { id: crypto.randomUUID(), name: name.trim(), date },
    ];
    setItems(next);
    localStorage.setItem("minjaz-reminders", JSON.stringify(next));
    setName("");
    setDate("");
    setNotice(t("تم حفظ التذكير على جهازك", "Reminder saved on your device"));
  }
  async function permission() {
    if (!("Notification" in window)) {
      setNotice(
        t(
          "الإشعارات غير مدعومة في هذا المتصفح",
          "Notifications are not supported in this browser",
        ),
      );
      return;
    }
    try {
      const status = await Notification.requestPermission();
      setNotice(
        status === "granted"
          ? t("تم تفعيل الإشعارات", "Notifications enabled")
          : t(
              "لم يتم منح إذن الإشعارات",
              "Notification permission was not granted",
            ),
      );
    } catch {
      setNotice(
        t(
          "تعذر طلب إذن الإشعارات من المتصفح",
          "The browser could not request notification permission",
        ),
      );
    }
  }
  function remove(id: string) {
    const next = items.filter((x) => x.id !== id);
    setItems(next);
    localStorage.setItem("minjaz-reminders", JSON.stringify(next));
  }
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field">
          <label>{t("اسم الشيء أو الاشتراك", "Item or subscription")}</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t("تجديد الوثيقة", "Document renewal")}
          />
        </div>
        <ModernDatePicker
          label={t(
            "تاريخ الانتهاء — يبدأ 00:00",
            "Expiry date — starts at 00:00",
          )}
          value={date}
          onChange={setDate}
        />
      </div>
      <div className="button-row">
        <button className="primary-button" onClick={save}>
          {t("حفظ التذكير", "Save reminder")}
        </button>
        <button className="secondary-button" onClick={permission}>
          <Icon name="bell" size={18} />
          {t("تفعيل الإشعارات", "Enable notifications")}
        </button>
      </div>
      {notice && <div className="notice">{notice}</div>}
      <div className="reminder-list">
        {items.map((x) => (
          <div key={x.id}>
            <span>
              <strong>{x.name}</strong>
              <small>{x.date}</small>
            </span>
            <button
              onClick={() => remove(x.id)}
              aria-label={t("حذف التذكير", "Delete reminder")}
            >
              <Icon name="x" size={18} />
            </button>
          </div>
        ))}
      </div>
      <Tip
        ar="تُحفظ التذكيرات على جهازك ويبدأ استحقاقها عند 00:00 في بداية اليوم المحدد"
        en="Reminders stay on your device and become due at 00:00 at the start of the selected date"
      />
    </div>
  );
}

function OptionComparison() {
  const { t } = useLocale();
  const [a, setA] = useState({ price: 100, fees: 10, months: 12, rating: 8 }),
    [b, setB] = useState({ price: 120, fees: 0, months: 18, rating: 9 });
  const totalA = a.price + a.fees,
    totalB = b.price + b.fees;
  function card(label: string, value: typeof a, set: (v: typeof a) => void) {
    return (
      <section>
        <h3>{label}</h3>
        <Numeric
          label={t("السعر", "Price")}
          value={value.price}
          onChange={(price) => set({ ...value, price })}
        />
        <Numeric
          label={t("الرسوم", "Fees")}
          value={value.fees}
          onChange={(fees) => set({ ...value, fees })}
        />
        <Numeric
          label={t("المدة بالأشهر", "Duration months")}
          value={value.months}
          onChange={(months) => set({ ...value, months })}
          min={1}
        />
        <Numeric
          label={t("تقييمك من 10", "Your rating out of 10")}
          value={value.rating}
          onChange={(rating) => set({ ...value, rating })}
        />
      </section>
    );
  }
  return (
    <div className="workspace-stack">
      <div className="comparison-grid">
        {card(t("الخيار الأول", "First option"), a, setA)}
        {card(t("الخيار الثاني", "Second option"), b, setB)}
      </div>
      <Metrics
        items={[
          {
            value: fixed(totalA),
            ar: "كلفة الخيار الأول",
            en: "First total cost",
          },
          {
            value: fixed(totalB),
            ar: "كلفة الخيار الثاني",
            en: "Second total cost",
          },
          {
            value:
              totalA === totalB
                ? t("متساويان بالكلفة", "Equal cost")
                : totalA < totalB
                  ? t("الخيار الأول", "First option")
                  : t("الخيار الثاني", "Second option"),
            ar: "الأقل كلفة",
            en: "Lower cost",
          },
        ]}
      />
      <Tip
        ar="لا تعتمد على السعر فقط وراجع المدة والرسوم والتقييم قبل اتخاذ القرار"
        en="Do not rely on price alone; review duration, fees, and rating before deciding"
      />
    </div>
  );
}

async function loadBitmap(file: File) {
  return await createImageBitmap(file);
}
type CollageKind =
  | "grid"
  | "rows"
  | "columns"
  | "hero-left"
  | "hero-right"
  | "hero-top"
  | "hero-bottom"
  | "mosaic-left"
  | "mosaic-right"
  | "mosaic-top"
  | "mosaic-bottom"
  | "center-horizontal"
  | "center-vertical";
type CollageTemplate = {
  id: string;
  ar: string;
  en: string;
  kind: CollageKind;
  aspect: [number, number];
  cols?: number;
  gap: number;
  radius: number;
};
type CollageRect = { x: number; y: number; w: number; h: number };
const collageTemplates: CollageTemplate[] = [
  {
    id: "classic-square",
    ar: "شبكة مربعة",
    en: "Square grid",
    kind: "grid",
    aspect: [1, 1],
    gap: 0.008,
    radius: 0,
  },
  {
    id: "soft-square",
    ar: "مربعات ناعمة",
    en: "Soft squares",
    kind: "grid",
    aspect: [1, 1],
    gap: 0.018,
    radius: 22,
  },
  {
    id: "wide-grid",
    ar: "شبكة عريضة",
    en: "Wide grid",
    kind: "grid",
    aspect: [16, 9],
    gap: 0.012,
    radius: 12,
  },
  {
    id: "portrait-grid",
    ar: "شبكة طولية",
    en: "Portrait grid",
    kind: "grid",
    aspect: [4, 5],
    gap: 0.012,
    radius: 12,
  },
  {
    id: "story-grid",
    ar: "شبكة ستوري",
    en: "Story grid",
    kind: "grid",
    aspect: [9, 16],
    gap: 0.012,
    radius: 18,
  },
  {
    id: "three-column",
    ar: "ثلاثة أعمدة",
    en: "Three columns",
    kind: "grid",
    aspect: [3, 2],
    cols: 3,
    gap: 0.012,
    radius: 10,
  },
  {
    id: "horizontal-strips",
    ar: "شرائط أفقية",
    en: "Horizontal strips",
    kind: "rows",
    aspect: [4, 5],
    gap: 0.012,
    radius: 10,
  },
  {
    id: "horizontal-wide",
    ar: "شرائط عريضة",
    en: "Wide strips",
    kind: "rows",
    aspect: [16, 9],
    gap: 0.01,
    radius: 8,
  },
  {
    id: "vertical-strips",
    ar: "شرائط عمودية",
    en: "Vertical strips",
    kind: "columns",
    aspect: [1, 1],
    gap: 0.012,
    radius: 10,
  },
  {
    id: "vertical-wide",
    ar: "أعمدة بانورامية",
    en: "Panorama columns",
    kind: "columns",
    aspect: [16, 9],
    gap: 0.01,
    radius: 8,
  },
  {
    id: "hero-left-square",
    ar: "بارزة يسار",
    en: "Hero left",
    kind: "hero-left",
    aspect: [1, 1],
    gap: 0.014,
    radius: 14,
  },
  {
    id: "hero-right-square",
    ar: "بارزة يمين",
    en: "Hero right",
    kind: "hero-right",
    aspect: [1, 1],
    gap: 0.014,
    radius: 14,
  },
  {
    id: "hero-left-wide",
    ar: "مجلة عريضة يسار",
    en: "Wide hero left",
    kind: "hero-left",
    aspect: [16, 9],
    gap: 0.012,
    radius: 12,
  },
  {
    id: "hero-right-wide",
    ar: "مجلة عريضة يمين",
    en: "Wide hero right",
    kind: "hero-right",
    aspect: [16, 9],
    gap: 0.012,
    radius: 12,
  },
  {
    id: "hero-top-square",
    ar: "بارزة أعلى",
    en: "Hero top",
    kind: "hero-top",
    aspect: [1, 1],
    gap: 0.014,
    radius: 14,
  },
  {
    id: "hero-bottom-square",
    ar: "بارزة أسفل",
    en: "Hero bottom",
    kind: "hero-bottom",
    aspect: [1, 1],
    gap: 0.014,
    radius: 14,
  },
  {
    id: "hero-top-story",
    ar: "غلاف علوي",
    en: "Top cover",
    kind: "hero-top",
    aspect: [4, 5],
    gap: 0.014,
    radius: 16,
  },
  {
    id: "hero-bottom-story",
    ar: "غلاف سفلي",
    en: "Bottom cover",
    kind: "hero-bottom",
    aspect: [4, 5],
    gap: 0.014,
    radius: 16,
  },
  {
    id: "mosaic-left",
    ar: "فسيفساء يسار",
    en: "Mosaic left",
    kind: "mosaic-left",
    aspect: [1, 1],
    gap: 0.012,
    radius: 14,
  },
  {
    id: "mosaic-right",
    ar: "فسيفساء يمين",
    en: "Mosaic right",
    kind: "mosaic-right",
    aspect: [1, 1],
    gap: 0.012,
    radius: 14,
  },
  {
    id: "mosaic-top",
    ar: "فسيفساء أعلى",
    en: "Mosaic top",
    kind: "mosaic-top",
    aspect: [4, 5],
    gap: 0.012,
    radius: 14,
  },
  {
    id: "mosaic-bottom",
    ar: "فسيفساء أسفل",
    en: "Mosaic bottom",
    kind: "mosaic-bottom",
    aspect: [4, 5],
    gap: 0.012,
    radius: 14,
  },
  {
    id: "center-wide",
    ar: "محور أفقي",
    en: "Horizontal focus",
    kind: "center-horizontal",
    aspect: [16, 9],
    gap: 0.012,
    radius: 16,
  },
  {
    id: "center-tall",
    ar: "محور عمودي",
    en: "Vertical focus",
    kind: "center-vertical",
    aspect: [4, 5],
    gap: 0.012,
    radius: 16,
  },
  {
    id: "square-magazine-top",
    ar: "مجلة مربعة علوية",
    en: "Square magazine top",
    kind: "hero-top",
    aspect: [1, 1],
    gap: 0.012,
    radius: 16,
  },
  {
    id: "square-magazine-bottom",
    ar: "مجلة مربعة سفلية",
    en: "Square magazine bottom",
    kind: "hero-bottom",
    aspect: [1, 1],
    gap: 0.012,
    radius: 16,
  },
  {
    id: "landscape-classic",
    ar: "أفقي كلاسيكي 4:3",
    en: "Classic landscape 4:3",
    kind: "grid",
    aspect: [4, 3],
    gap: 0.012,
    radius: 12,
  },
  {
    id: "landscape-photo-left",
    ar: "صورة أفقية يسار 3:2",
    en: "Photo landscape left 3:2",
    kind: "hero-left",
    aspect: [3, 2],
    gap: 0.012,
    radius: 14,
  },
  {
    id: "landscape-photo-right",
    ar: "صورة أفقية يمين 3:2",
    en: "Photo landscape right 3:2",
    kind: "hero-right",
    aspect: [3, 2],
    gap: 0.012,
    radius: 14,
  },
  {
    id: "landscape-banner",
    ar: "بانر أفقي 2:1",
    en: "Landscape banner 2:1",
    kind: "center-horizontal",
    aspect: [2, 1],
    gap: 0.01,
    radius: 12,
  },
  {
    id: "landscape-cinematic",
    ar: "سينمائي عريض 21:9",
    en: "Cinematic wide 21:9",
    kind: "mosaic-left",
    aspect: [21, 9],
    gap: 0.009,
    radius: 11,
  },
  {
    id: "portrait-classic",
    ar: "عمودي كلاسيكي 3:4",
    en: "Classic portrait 3:4",
    kind: "grid",
    aspect: [3, 4],
    gap: 0.012,
    radius: 13,
  },
  {
    id: "portrait-poster",
    ar: "ملصق عمودي 2:3",
    en: "Portrait poster 2:3",
    kind: "hero-top",
    aspect: [2, 3],
    gap: 0.012,
    radius: 15,
  },
  {
    id: "portrait-reel-top",
    ar: "ريل عمودي علوي 9:16",
    en: "Vertical reel top 9:16",
    kind: "mosaic-top",
    aspect: [9, 16],
    gap: 0.011,
    radius: 15,
  },
  {
    id: "portrait-reel-bottom",
    ar: "ريل عمودي سفلي 9:16",
    en: "Vertical reel bottom 9:16",
    kind: "mosaic-bottom",
    aspect: [9, 16],
    gap: 0.011,
    radius: 15,
  },
  {
    id: "portrait-focus",
    ar: "تركيز عمودي 4:5",
    en: "Portrait focus 4:5",
    kind: "center-vertical",
    aspect: [4, 5],
    gap: 0.012,
    radius: 16,
  },
];

function collageOrientation(template: CollageTemplate) {
  const [width, height] = template.aspect;
  return width === height
    ? "square"
    : width > height
      ? "landscape"
      : "portrait";
}
function gridRects(
  count: number,
  x: number,
  y: number,
  w: number,
  h: number,
  cols?: number,
  gap = 0,
): CollageRect[] {
  if (count <= 0) return [];
  const safe = count,
    columns = Math.min(
      safe,
      cols || Math.max(1, Math.ceil(Math.sqrt((safe * w) / h))),
    ),
    rows = Math.ceil(safe / columns);
  return Array.from({ length: safe }, (_, index) => {
    const row = Math.floor(index / columns),
      column = index % columns,
      itemsInRow = row === rows - 1 ? safe - row * columns : columns,
      cellW = (w - gap * (itemsInRow - 1)) / itemsInRow,
      cellH = (h - gap * (rows - 1)) / rows;
    return {
      x: x + column * (cellW + gap),
      y: y + row * (cellH + gap),
      w: cellW,
      h: cellH,
    };
  });
}
function collageRects(template: CollageTemplate, count: number): CollageRect[] {
  const gap = template.gap,
    inside = { x: gap, y: gap, w: 1 - gap * 2, h: 1 - gap * 2 };
  if (count <= 1) return [inside];
  if (template.kind === "grid")
    return gridRects(
      count,
      inside.x,
      inside.y,
      inside.w,
      inside.h,
      template.cols,
      gap,
    );
  if (template.kind === "rows")
    return gridRects(count, inside.x, inside.y, inside.w, inside.h, 1, gap);
  if (template.kind === "columns")
    return gridRects(count, inside.x, inside.y, inside.w, inside.h, count, gap);
  if (template.kind === "center-horizontal") {
    const firstSide = Math.floor((count - 1) / 2),
      secondSide = count - 1 - firstSide,
      side = 0.22;
    return [
      ...gridRects(
        firstSide,
        inside.x,
        inside.y,
        side - gap / 2,
        inside.h,
        1,
        gap,
      ),
      {
        x: inside.x + side + gap / 2,
        y: inside.y,
        w: inside.w - side * 2 - gap,
        h: inside.h,
      },
      ...gridRects(
        secondSide,
        inside.x + inside.w - side + gap / 2,
        inside.y,
        side - gap / 2,
        inside.h,
        1,
        gap,
      ),
    ];
  }
  if (template.kind === "center-vertical") {
    const firstSide = Math.floor((count - 1) / 2),
      secondSide = count - 1 - firstSide,
      side = 0.22;
    return [
      ...gridRects(
        firstSide,
        inside.x,
        inside.y,
        inside.w,
        side - gap / 2,
        firstSide,
        gap,
      ),
      {
        x: inside.x,
        y: inside.y + side + gap / 2,
        w: inside.w,
        h: inside.h - side * 2 - gap,
      },
      ...gridRects(
        secondSide,
        inside.x,
        inside.y + inside.h - side + gap / 2,
        inside.w,
        side - gap / 2,
        secondSide,
        gap,
      ),
    ];
  }
  const vertical =
      template.kind.includes("left") || template.kind.includes("right"),
    mosaic = template.kind.startsWith("mosaic"),
    first = 0.58;
  if (vertical) {
    const heroW = inside.w * first - gap / 2,
      otherW = inside.w - heroW - gap,
      heroRight = template.kind.endsWith("right"),
      heroX = heroRight ? inside.x + otherW + gap : inside.x,
      otherX = heroRight ? inside.x : inside.x + heroW + gap;
    return [
      { x: heroX, y: inside.y, w: heroW, h: inside.h },
      ...gridRects(
        count - 1,
        otherX,
        inside.y,
        otherW,
        inside.h,
        mosaic ? 2 : 1,
        gap,
      ),
    ];
  }
  const heroH = inside.h * first - gap / 2,
    otherH = inside.h - heroH - gap,
    heroBottom = template.kind.endsWith("bottom"),
    heroY = heroBottom ? inside.y + otherH + gap : inside.y,
    otherY = heroBottom ? inside.y : inside.y + heroH + gap;
  return [
    { x: inside.x, y: heroY, w: inside.w, h: heroH },
    ...gridRects(
      count - 1,
      inside.x,
      otherY,
      inside.w,
      otherH,
      mosaic ? Math.ceil((count - 1) / 2) : count - 1,
      gap,
    ),
  ];
}
function roundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const radius = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}
function drawCover(
  ctx: CanvasRenderingContext2D,
  img: ImageBitmap,
  rect: CollageRect,
  canvas: HTMLCanvasElement,
  radius: number,
) {
  const x = rect.x * canvas.width,
    y = rect.y * canvas.height,
    w = rect.w * canvas.width,
    h = rect.h * canvas.height,
    scale = Math.max(w / img.width, h / img.height),
    dw = img.width * scale,
    dh = img.height * scale;
  ctx.save();
  roundedRect(ctx, x, y, w, h, radius);
  ctx.clip();
  ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
  ctx.restore();
}
function ImageCollage() {
  const { t } = useLocale();
  const [files, setFiles] = useState<File[]>([]),
    [templateId, setTemplateId] = useState(collageTemplates[0].id),
    [orientation, setOrientation] = useState("all"),
    [outputLong, setOutputLong] = useState("1600"),
    [result, setResult] = useState<{
      url: string;
      blob: Blob;
      width: number;
      height: number;
    } | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const template =
    collageTemplates.find((item) => item.id === templateId) ||
    collageTemplates[0];
  const visibleTemplates =
    orientation === "all"
      ? collageTemplates
      : collageTemplates.filter(
          (item) => collageOrientation(item) === orientation,
        );
  useEffect(
    () => () => {
      if (result) URL.revokeObjectURL(result.url);
    },
    [result],
  );
  function clearResult() {
    setResult((current) => {
      if (current) URL.revokeObjectURL(current.url);
      return null;
    });
  }
  async function run() {
    if (files.length < 2) return;
    setBusy(true);
    setError("");
    try {
      const bitmaps = await Promise.all(files.slice(0, 8).map(loadBitmap));
      const [aw, ah] = template.aspect,
        long = Number(outputLong),
        canvas = document.createElement("canvas");
      if (aw >= ah) {
        canvas.width = long;
        canvas.height = Math.round((long * ah) / aw);
      } else {
        canvas.height = long;
        canvas.width = Math.round((long * aw) / ah);
      }
      const ctx = canvas.getContext("2d")!;
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      const rects = collageRects(template, bitmaps.length);
      bitmaps.forEach((img, index) => {
        drawCover(ctx, img, rects[index], canvas, template.radius);
        img.close();
      });
      const blob = await new Promise<Blob>((resolve, reject) =>
        canvas.toBlob(
          (value) => (value ? resolve(value) : reject(new Error("collage"))),
          "image/jpeg",
          0.92,
        ),
      );
      setResult((current) => {
        if (current) URL.revokeObjectURL(current.url);
        return {
          url: URL.createObjectURL(blob),
          blob,
          width: canvas.width,
          height: canvas.height,
        };
      });
    } catch {
      setError(
        t(
          "تعذر دمج إحدى الصور تحقق من أن جميع الصور سليمة",
          "One of the images could not be merged Make sure every image is valid",
        ),
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="workspace-stack">
      <FileUploadZone
        files={files}
        onFiles={(next) => {
          setFiles(next);
          clearResult();
          setError("");
        }}
        multiple
        maxFiles={8}
        accept="image/*"
        icon="image"
        title={t("اختر من صورتين إلى 8 صور", "Choose 2 to 8 images")}
        helper={t(
          "يمكنك تجربة أي نموذج بعد اختيار الصور",
          "You can try any layout after choosing your images",
        )}
      />
      <section className="collage-templates">
        <div className="collage-templates__heading">
          <h3>{t("اختر نموذج الدمج", "Choose a collage layout")}</h3>
          <span>{t("36 نموذجاً جاهزاً", "36 ready layouts")}</span>
        </div>
        <div className="collage-output-options">
          <div className="field">
            <label>{t("اتجاه الصورة", "Image orientation")}</label>
            <CustomSelect
              value={orientation}
              onChange={(next) => {
                setOrientation(next);
                const first =
                  next === "all"
                    ? collageTemplates[0]
                    : collageTemplates.find(
                        (item) => collageOrientation(item) === next,
                      );
                if (first) setTemplateId(first.id);
                clearResult();
              }}
              label={t("اتجاه الصورة", "Image orientation")}
              options={[
                { value: "all", label: t("كل المقاسات", "All sizes") },
                { value: "square", label: t("مربعة", "Square") },
                { value: "landscape", label: t("أفقية", "Landscape") },
                { value: "portrait", label: t("عمودية", "Portrait") },
              ]}
            />
          </div>
          <div className="field">
            <label>{t("دقة الصورة النهائية", "Output resolution")}</label>
            <CustomSelect
              value={outputLong}
              onChange={(next) => {
                setOutputLong(next);
                clearResult();
              }}
              label={t("دقة الصورة النهائية", "Output resolution")}
              options={[
                {
                  value: "1080",
                  label: t("قياسية 1080px", "Standard 1080px"),
                },
                {
                  value: "1600",
                  label: t("عالية 1600px", "High 1600px"),
                },
                {
                  value: "2400",
                  label: t("فائقة 2400px", "Ultra 2400px"),
                },
              ]}
            />
          </div>
        </div>
        <div
          className="collage-template-grid"
          role="radiogroup"
          aria-label={t("نماذج دمج الصور", "Collage layouts")}
        >
          {visibleTemplates.map((item) => (
            <button
              type="button"
              role="radio"
              aria-checked={templateId === item.id}
              className={templateId === item.id ? "selected" : ""}
              key={item.id}
              onClick={() => {
                setTemplateId(item.id);
                clearResult();
                setError("");
              }}
            >
              <span
                className="collage-template-preview"
                style={{ aspectRatio: `${item.aspect[0]}/${item.aspect[1]}` }}
              >
                {collageRects(
                  item,
                  Math.max(2, Math.min(files.length || 5, 8)),
                ).map((rect, index) => (
                  <i
                    key={index}
                    style={{
                      left: `${rect.x * 100}%`,
                      top: `${rect.y * 100}%`,
                      width: `${rect.w * 100}%`,
                      height: `${rect.h * 100}%`,
                      borderRadius: `${Math.min(item.radius / 3, 8)}px`,
                    }}
                  />
                ))}
              </span>
              <small>{t(item.ar, item.en)}</small>
            </button>
          ))}
        </div>
      </section>
      <button
        className="primary-button"
        onClick={run}
        disabled={files.length < 2 || busy}
      >
        {busy
          ? t("جاري تجهيز النموذج", "Building collage")
          : t(`دمج بنموذج ${template.ar}`, `Create with ${template.en}`)}
      </button>
      {error && <div className="error-notice">{error}</div>}
      {result && (
        <div className="image-preview collage-result">
          <img
            src={result.url}
            alt={t("معاينة دمج الصور", "Collage preview")}
          />
          <div className="collage-result__actions">
            <span>
              {t("المقاس النهائي", "Final size")}: {result.width} ×{" "}
              {result.height}px
            </span>
            <button
              className="primary-button"
              onClick={() =>
                download(
                  result.blob,
                  `adawati-collage-${template.id}-${result.width}x${result.height}.jpg`,
                )
              }
            >
              <Icon name="download" size={18} />
              {t("تحميل الصورة", "Download image")}
            </button>
          </div>
        </div>
      )}
      <Tip
        ar="اختر الشكل المناسب ثم تُقص الصور من المنتصف داخل كل خانة وتتم المعالجة كاملة داخل جهازك"
        en="Choose a layout Images are center-cropped into each slot and all processing stays on your device"
      />
    </div>
  );
}

function CircularImageCropper() {
  const { t } = useLocale();
  const frame = 360;
  const cropDiameter = 328;
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [natural, setNatural] = useState({ width: 1, height: 1 });
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [size, setSize] = useState("1024");
  const [result, setResult] = useState<{ url: string; blob: Blob } | null>(
    null,
  );
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const gesture = useRef({
    x: 0,
    y: 0,
    offsetX: 0,
    offsetY: 0,
    distance: 0,
    zoom: 1,
  });
  const baseScale = Math.max(
    cropDiameter / natural.width,
    cropDiameter / natural.height,
  );
  const imageWidth = natural.width * baseScale * zoom;
  const imageHeight = natural.height * baseScale * zoom;

  useEffect(
    () => () => {
      if (preview) URL.revokeObjectURL(preview);
    },
    [preview],
  );
  useEffect(
    () => () => {
      if (result) URL.revokeObjectURL(result.url);
    },
    [result],
  );

  function clampOffset(next: { x: number; y: number }, nextZoom = zoom) {
    const width = natural.width * baseScale * nextZoom;
    const height = natural.height * baseScale * nextZoom;
    return {
      x: Math.max(
        -(width - cropDiameter) / 2,
        Math.min((width - cropDiameter) / 2, next.x),
      ),
      y: Math.max(
        -(height - cropDiameter) / 2,
        Math.min((height - cropDiameter) / 2, next.y),
      ),
    };
  }

  async function choose(next: File | null) {
    setError("");
    if (!next) return;
    if (!next.type.startsWith("image/"))
      return setError(t("اختر صورة صالحة", "Choose a valid image"));
    try {
      const bitmap = await createImageBitmap(next);
      if (preview) URL.revokeObjectURL(preview);
      if (result) URL.revokeObjectURL(result.url);
      setFile(next);
      setNatural({ width: bitmap.width, height: bitmap.height });
      setPreview(URL.createObjectURL(next));
      setZoom(1);
      setOffset({ x: 0, y: 0 });
      setResult(null);
      bitmap.close();
    } catch {
      setError(
        t(
          "تعذر قراءة الصورة، تأكد من سلامة الملف",
          "The image could not be read; make sure it is valid",
        ),
      );
    }
  }

  function setSafeZoom(next: number) {
    const value = Math.max(1, Math.min(4, next));
    setZoom(value);
    setOffset((current) => clampOffset(current, value));
    setResult(null);
  }

  function distance() {
    const [a, b] = [...pointers.current.values()];
    return a && b ? Math.hypot(a.x - b.x, a.y - b.y) : 0;
  }

  function pointerDown(event: React.PointerEvent<HTMLDivElement>) {
    event.currentTarget.setPointerCapture(event.pointerId);
    pointers.current.set(event.pointerId, {
      x: event.clientX,
      y: event.clientY,
    });
    if (pointers.current.size === 1)
      gesture.current = {
        ...gesture.current,
        x: event.clientX,
        y: event.clientY,
        offsetX: offset.x,
        offsetY: offset.y,
      };
    if (pointers.current.size === 2)
      gesture.current = { ...gesture.current, distance: distance(), zoom };
  }

  function pointerMove(event: React.PointerEvent<HTMLDivElement>) {
    if (!pointers.current.has(event.pointerId)) return;
    pointers.current.set(event.pointerId, {
      x: event.clientX,
      y: event.clientY,
    });
    if (pointers.current.size >= 2) {
      const next = gesture.current.distance
        ? (gesture.current.zoom * distance()) / gesture.current.distance
        : zoom;
      setSafeZoom(next);
    } else {
      setOffset(
        clampOffset({
          x: gesture.current.offsetX + event.clientX - gesture.current.x,
          y: gesture.current.offsetY + event.clientY - gesture.current.y,
        }),
      );
      setResult(null);
    }
  }

  function pointerUp(event: React.PointerEvent<HTMLDivElement>) {
    pointers.current.delete(event.pointerId);
    const remaining = [...pointers.current.values()][0];
    if (remaining)
      gesture.current = {
        ...gesture.current,
        x: remaining.x,
        y: remaining.y,
        offsetX: offset.x,
        offsetY: offset.y,
      };
  }

  async function generate() {
    if (!file) return;
    setBusy(true);
    setError("");
    try {
      const outputSize = Number(size);
      const bitmap = await createImageBitmap(file);
      const canvas = document.createElement("canvas");
      canvas.width = outputSize;
      canvas.height = outputSize;
      const context = canvas.getContext("2d")!;
      const placement = circularCropPlacement(
        bitmap.width,
        bitmap.height,
        zoom,
        offset.x,
        offset.y,
        outputSize,
        frame,
        cropDiameter,
      );
      context.beginPath();
      context.arc(
        outputSize / 2,
        outputSize / 2,
        outputSize / 2,
        0,
        Math.PI * 2,
      );
      context.clip();
      context.drawImage(
        bitmap,
        placement.x,
        placement.y,
        placement.width,
        placement.height,
      );
      const blob = await new Promise<Blob>((resolve, reject) =>
        canvas.toBlob(
          (value) => (value ? resolve(value) : reject(new Error("png"))),
          "image/png",
        ),
      );
      setResult((current) => {
        if (current) URL.revokeObjectURL(current.url);
        return { url: URL.createObjectURL(blob), blob };
      });
      bitmap.close();
    } catch {
      setError(
        t("تعذر إنشاء الصورة الدائرية", "Could not create the circular image"),
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="workspace-stack circular-cropper">
      <FileUploadZone
        files={file ? [file] : []}
        onFiles={(files) => void choose(files[0] || null)}
        accept="image/*"
        icon="crop"
        title={t(
          "ارفع الصورة التي تريد قصّها",
          "Upload the image you want to crop",
        )}
        helper={t(
          "PNG أو JPG أو WebP — المعالجة داخل جهازك",
          "PNG, JPG, or WebP — processed on your device",
        )}
      />
      {preview && (
        <div className="circle-crop-layout">
          <div
            className="circle-crop-stage"
            role="application"
            tabIndex={0}
            aria-label={t(
              "اسحب الصورة لتحديد الجزء الظاهر",
              "Drag the image to choose the visible area",
            )}
            onPointerDown={pointerDown}
            onPointerMove={pointerMove}
            onPointerUp={pointerUp}
            onPointerCancel={pointerUp}
            onWheel={(event) => {
              event.preventDefault();
              setSafeZoom(zoom + (event.deltaY < 0 ? 0.08 : -0.08));
            }}
            onKeyDown={(event) => {
              const step = event.shiftKey ? 10 : 3;
              if (
                ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(
                  event.key,
                )
              )
                event.preventDefault();
              if (event.key === "ArrowLeft")
                setOffset((value) =>
                  clampOffset({ ...value, x: value.x - step }),
                );
              if (event.key === "ArrowRight")
                setOffset((value) =>
                  clampOffset({ ...value, x: value.x + step }),
                );
              if (event.key === "ArrowUp")
                setOffset((value) =>
                  clampOffset({ ...value, y: value.y - step }),
                );
              if (event.key === "ArrowDown")
                setOffset((value) =>
                  clampOffset({ ...value, y: value.y + step }),
                );
            }}
          >
            <img
              src={preview}
              alt=""
              draggable={false}
              style={{
                width: imageWidth,
                height: imageHeight,
                transform: `translate(-50%,-50%) translate(${offset.x}px,${offset.y}px)`,
              }}
            />
            <span className="circle-crop-mask" />
            <span className="circle-crop-hint">
              <Icon name="crop" size={18} />
              {t("اسحب للتحريك · قرّب بإصبعين", "Drag to move · pinch to zoom")}
            </span>
          </div>
          <div className="circle-crop-controls">
            <label className="range-field">
              <span>
                {t("التكبير", "Zoom")}: {zoom.toFixed(2)}×
              </span>
              <input
                type="range"
                min="1"
                max="4"
                step=".01"
                value={zoom}
                onChange={(event) => setSafeZoom(Number(event.target.value))}
              />
            </label>
            <div className="field">
              <label>{t("مقاس الصورة النهائية", "Final image size")}</label>
              <CustomSelect
                value={size}
                onChange={setSize}
                label={t("اختر المقاس", "Choose size")}
                options={["256", "512", "1024", "2048"].map((value) => ({
                  value,
                  label: `${value} × ${value} px`,
                }))}
              />
            </div>
            <button
              className="secondary-button"
              onClick={() => {
                setZoom(1);
                setOffset({ x: 0, y: 0 });
                setResult(null);
              }}
            >
              <Icon name="reset" size={18} />
              {t("توسيط الصورة", "Center image")}
            </button>
            <button
              className="primary-button"
              onClick={generate}
              disabled={busy}
            >
              {busy
                ? t("جاري القص…", "Cropping…")
                : t("قص ومعاينة الصورة الدائرية", "Crop and preview circle")}
            </button>
          </div>
        </div>
      )}
      {error && <div className="error-notice">{error}</div>}
      {result && (
        <div className="circle-crop-result">
          <img
            src={result.url}
            alt={t("معاينة الصورة الدائرية", "Circular image preview")}
          />
          <div>
            <strong>
              {t("الصورة الدائرية جاهزة", "Your circular image is ready")}
            </strong>
            <span>
              {size} × {size} PNG
            </span>
            <button
              className="primary-button"
              onClick={() =>
                download(result.blob, `adawati-circular-${size}.png`)
              }
            >
              <Icon name="download" size={18} />
              {t("تنزيل PNG بخلفية شفافة", "Download transparent PNG")}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function OfficialPhoto() {
  const { t } = useLocale();
  const [file, setFile] = useState<File | null>(null),
    [preset, setPreset] = useState("600x600"),
    [result, setResult] = useState(""),
    [error, setError] = useState("");
  async function run() {
    if (!file) return;
    setError("");
    try {
      const [w, h] = preset.split("x").map(Number),
        img = await loadBitmap(file),
        canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d")!;
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, w, h);
      const scale = Math.max(w / img.width, h / img.height),
        dw = img.width * scale,
        dh = img.height * scale;
      ctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
      img.close();
      setResult(canvas.toDataURL("image/jpeg", 0.94));
    } catch {
      setError(
        t(
          "تعذر تجهيز الصورة تحقق من أن الملف سليم",
          "The photo could not be prepared Make sure the file is valid",
        ),
      );
    }
  }
  return (
    <div className="workspace-stack">
      <FileUploadZone
        files={file ? [file] : []}
        onFiles={(next) => {
          setFile(next[0] || null);
          setResult("");
          setError("");
        }}
        accept="image/*"
        icon="image"
        title={t("اختر الصورة", "Choose photo")}
      />
      <div className="field">
        <label>{t("المقاس بالبكسل", "Pixel size")}</label>
        <CustomSelect
          value={preset}
          onChange={(value) => {
            setPreset(value);
            setResult("");
          }}
          label={t("المقاس", "Size")}
          options={[
            { value: "600x600", label: "600 × 600" },
            { value: "413x531", label: "413 × 531" },
            { value: "1200x1600", label: "1200 × 1600" },
            { value: "900x1200", label: "900 × 1200" },
          ]}
        />
      </div>
      <button className="primary-button" onClick={run} disabled={!file}>
        {t("تجهيز ومعاينة", "Prepare and preview")}
      </button>
      {error && <div className="error-notice">{error}</div>}
      {result && (
        <div className="image-preview official-photo-preview">
          <img
            src={result}
            alt={t("معاينة الصورة الرسمية", "Official photo preview")}
          />
          <button
            className="primary-button"
            onClick={() =>
              fetch(result)
                .then((r) => r.blob())
                .then((b) => download(b, "adawati-official-photo.jpg"))
            }
          >
            {t("تنزيل الصورة", "Download photo")}
          </button>
        </div>
      )}
      <Tip
        ar="يتم قص الصورة من المنتصف لتعبئة المقاس لذلك تأكد من تمركز الوجه قبل التنزيل"
        en="The image is center-cropped to fill the size, so check face alignment before downloading"
      />
    </div>
  );
}

function FileSizeTotal() {
  const { t } = useLocale();
  const [files, setFiles] = useState<File[]>([]);
  const total = files.reduce((s, f) => s + f.size, 0);
  return (
    <div className="workspace-stack">
      <FileUploadZone
        files={files}
        onFiles={setFiles}
        multiple
        icon="hard-drive"
        title={t("اختر الملفات", "Choose files")}
      />
      {files.length > 0 && (
        <Metrics
          items={[
            { value: String(files.length), ar: "عدد الملفات", en: "Files" },
            {
              value: fixed(total / 1048576) + " MB",
              ar: "الحجم الكلي",
              en: "Total size",
            },
            {
              value: fixed(total / 1073741824, 4) + " GB",
              ar: "بالجيجابايت",
              en: "In gigabytes",
            },
          ]}
        />
      )}
      <Tip
        ar="تُقرأ أحجام الملفات محلياً ولا يتم رفع أي ملف إلى الخادم"
        en="File sizes are read locally and no files are uploaded"
      />
    </div>
  );
}

function BatchRenamer() {
  const { t } = useLocale();
  const [files, setFiles] = useState<File[]>([]),
    [prefix, setPrefix] = useState("invoice"),
    [start, setStart] = useState(1);
  function name(file: File, i: number) {
    const ext = file.name.includes(".") ? `.${file.name.split(".").pop()}` : "";
    return `${prefix}-${String(start + i).padStart(3, "0")}${ext}`;
  }
  return (
    <div className="workspace-stack">
      <FileUploadZone
        files={files}
        onFiles={setFiles}
        multiple
        icon="hard-drive"
        title={t("اختر الملفات", "Choose files")}
      />
      <div className="form-grid">
        <div className="field">
          <label>{t("نمط الاسم", "Name prefix")}</label>
          <input
            value={prefix}
            onChange={(e) =>
              setPrefix(e.target.value.replace(/[^a-zA-Z0-9_-]/g, ""))
            }
          />
        </div>
        <Numeric
          label={t("رقم البداية", "Starting number")}
          value={start}
          onChange={setStart}
        />
      </div>
      <div className="rename-list">
        {files.map((file, i) => (
          <div key={`${file.name}-${i}`}>
            <span>
              <small>{file.name}</small>
              <strong>{name(file, i)}</strong>
            </span>
            <button
              className="secondary-button"
              onClick={() => download(file, name(file, i))}
            >
              {t("تنزيل بالاسم الجديد", "Download renamed")}
            </button>
          </div>
        ))}
      </div>
      <Tip
        ar="المتصفح لا يغيّر الملف الأصلي بل ينزّل نسخة جديدة بالاسم المرتب"
        en="The browser keeps the original file and downloads a copy with the new name"
      />
    </div>
  );
}

function DocumentSigner() {
  const { t } = useLocale();
  const [doc, setDoc] = useState<File | null>(null),
    [signature, setSignature] = useState<File | null>(null),
    [busy, setBusy] = useState(false),
    [target, setTarget] = useState("first"),
    [position, setPosition] = useState("bottom-right"),
    [size, setSize] = useState(28),
    [notice, setNotice] = useState(""),
    [error, setError] = useState(""),
    [output, setOutput] = useState<{ blob: Blob; name: string } | null>(null);
  async function run() {
    if (!doc || !signature) return;
    setBusy(true);
    setNotice("");
    setError("");
    setOutput(null);
    try {
      const sigBytes = await signature.arrayBuffer();
      if (doc.type === "application/pdf") {
        const { signPdfDocument } = await import("@/lib/pdf-tools");
        const output = await signPdfDocument(
          await doc.arrayBuffer(),
          sigBytes,
          {
            target: target as "first" | "last" | "all",
            position: position as
              | "bottom-right"
              | "bottom-left"
              | "top-right"
              | "top-left"
              | "center",
            sizePercent: size,
            signatureType: signature.type as "image/png" | "image/jpeg",
          },
        );
        const blob = new Blob([output.bytes as BlobPart], {
          type: "application/pdf",
        });
        setOutput({ blob, name: "adawati-signed.pdf" });
        download(blob, "adawati-signed.pdf");
        setNotice(
          target === "all"
            ? t(
                `تم وضع الصورة على جميع الصفحات وعددها ${output.pageCount} وتنزيل الملف`,
                `The image was placed on all ${output.pageCount} pages and the file was downloaded`,
              )
            : target === "last"
              ? t(
                  `تم وضع الصورة على الصفحة الأخيرة رقم ${output.pageCount} وتنزيل الملف`,
                  `The image was placed on the last page ${output.pageCount} and the file was downloaded`,
                )
              : t(
                  "تم وضع الصورة على الصفحة الأولى وتنزيل الملف",
                  "The image was placed on the first page and the file was downloaded",
                ),
        );
      } else {
        const base = await loadBitmap(doc),
          sig = await loadBitmap(signature),
          canvas = document.createElement("canvas");
        canvas.width = base.width;
        canvas.height = base.height;
        const ctx = canvas.getContext("2d")!;
        ctx.drawImage(base, 0, 0);
        const width = (base.width * size) / 100,
          height = (width * sig.height) / sig.width,
          margin = base.width * 0.04;
        const x = position.endsWith("left")
            ? margin
            : position === "center"
              ? (base.width - width) / 2
              : base.width - width - margin,
          y = position.startsWith("top")
            ? margin
            : position === "center"
              ? (base.height - height) / 2
              : base.height - height - margin;
        ctx.drawImage(sig, x, y, width, height);
        const blob = await new Promise<Blob>((resolve, reject) =>
          canvas.toBlob(
            (value) => (value ? resolve(value) : reject(new Error("image"))),
            "image/png",
          ),
        );
        download(blob, "adawati-signed.png");
        setOutput({ blob, name: "adawati-signed.png" });
        base.close();
        sig.close();
        setNotice(
          t(
            "تم وضع التوقيع على الصورة وتنزيل النسخة الجديدة",
            "The signature was placed on the image and the new copy was downloaded",
          ),
        );
      }
    } catch {
      setError(
        t(
          "تعذر إدراج الصورة داخل الملف تأكد أن PDF غير محمي وأن صورة التوقيع بصيغة PNG أو JPG",
          "Could not place the image Make sure the PDF is not protected and the signature is PNG or JPG",
        ),
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <FileUploadZone
          files={doc ? [doc] : []}
          onFiles={(next) => {
            setDoc(next[0] || null);
            setNotice("");
            setError("");
            setOutput(null);
          }}
          accept="application/pdf,image/*"
          icon="file"
          title={t("اختر صورة أو PDF", "Choose image or PDF")}
          compact
        />
        <FileUploadZone
          files={signature ? [signature] : []}
          onFiles={(next) => {
            setSignature(next[0] || null);
            setNotice("");
            setError("");
            setOutput(null);
          }}
          accept="image/png,image/jpeg"
          icon="signature"
          title={t("اختر صورة التوقيع", "Choose signature image")}
          compact
        />
      </div>
      {doc && signature && (
        <div className="form-grid signer-options">
          {doc.type === "application/pdf" && (
            <div className="field">
              <label>
                {t("الصفحة التي يظهر عليها التوقيع", "Page to sign")}
              </label>
              <CustomSelect
                value={target}
                onChange={setTarget}
                label={t("اختر الصفحة", "Choose page")}
                options={[
                  { value: "first", label: t("الصفحة الأولى", "First page") },
                  { value: "last", label: t("الصفحة الأخيرة", "Last page") },
                  { value: "all", label: t("جميع الصفحات", "All pages") },
                ]}
              />
            </div>
          )}
          <div className="field">
            <label>{t("مكان التوقيع", "Signature position")}</label>
            <CustomSelect
              value={position}
              onChange={setPosition}
              label={t("اختر المكان", "Choose position")}
              options={[
                {
                  value: "bottom-right",
                  label: t("أسفل اليمين", "Bottom right"),
                },
                {
                  value: "bottom-left",
                  label: t("أسفل اليسار", "Bottom left"),
                },
                { value: "top-right", label: t("أعلى اليمين", "Top right") },
                { value: "top-left", label: t("أعلى اليسار", "Top left") },
                { value: "center", label: t("المنتصف", "Center") },
              ]}
            />
          </div>
          <label className="range-field full">
            <span>
              {t("حجم التوقيع", "Signature size")}: {size}%
            </span>
            <input
              type="range"
              min="10"
              max="55"
              value={size}
              onChange={(e) => setSize(n(e.target.value))}
            />
          </label>
        </div>
      )}
      <button
        className="primary-button"
        disabled={!doc || !signature || busy}
        onClick={run}
      >
        {busy
          ? t("جاري إدراج التوقيع", "Placing signature")
          : t("توقيع وتنزيل", "Sign and download")}
      </button>
      {notice && (
        <div className="notice success-notice">
          <Icon name="check" size={19} />
          {notice}
        </div>
      )}
      {output && (
        <div className="ready-download" role="status">
          <span>
            <Icon name="check" size={18} />
            {t("الملف الموقّع جاهز", "Signed file ready")}
          </span>
          <button
            className="primary-button"
            onClick={() => download(output.blob, output.name)}
          >
            <Icon name="download" size={18} />
            {t("تحميل الملف", "Download file")}
          </button>
        </div>
      )}
      {error && <div className="error-notice">{error}</div>}
      <Tip
        ar="الصفحة الأولى محددة افتراضياً حتى ترى الصورة فور فتح PDF ويمكنك اختيار الصفحة الأخيرة أو جميع الصفحات"
        en="The first page is selected by default so the image is visible as soon as the PDF opens You can choose the last page or all pages"
      />
    </div>
  );
}

function DocumentScanner() {
  const { t } = useLocale();
  const [file, setFile] = useState<File | null>(null),
    [crop, setCrop] = useState(3),
    [contrast, setContrast] = useState(130),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [output, setOutput] = useState<Blob | null>(null);
  async function run() {
    if (!file) return;
    setBusy(true);
    setError("");
    setOutput(null);
    try {
      const img = await loadBitmap(file),
        margin = Math.round((Math.min(img.width, img.height) * crop) / 100),
        w = img.width - margin * 2,
        h = img.height - margin * 2,
        canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d")!;
      ctx.filter = `grayscale(1) contrast(${contrast}%)`;
      ctx.drawImage(img, margin, margin, w, h, 0, 0, w, h);
      const blob = await new Promise<Blob>((resolve, reject) =>
        canvas.toBlob((b) => (b ? resolve(b) : reject()), "image/jpeg", 0.92),
      );
      const { jpegToPdf } = await import("@/lib/pdf-tools");
      const pdf = new Blob(
        [(await jpegToPdf(await blob.arrayBuffer())) as BlobPart],
        { type: "application/pdf" },
      );
      setOutput(pdf);
      download(pdf, "adawati-scan.pdf");
      img.close();
    } catch {
      setError(
        t(
          "تعذر قراءة الصورة أو إنشاء المستند تحقق من أن الصورة سليمة",
          "Could not read the image or create the document Make sure the image is valid",
        ),
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="workspace-stack">
      <FileUploadZone
        files={file ? [file] : []}
        onFiles={(next) => {
          setFile(next[0] || null);
          setError("");
          setOutput(null);
        }}
        accept="image/*"
        icon="file-image"
        title={t("اختر صورة المستند", "Choose document photo")}
      />
      <label className="range-field">
        <span>
          {t("قص الحواف", "Edge crop")}: {crop}%
        </span>
        <input
          type="range"
          min="0"
          max="15"
          value={crop}
          onChange={(e) => setCrop(n(e.target.value))}
        />
      </label>
      <label className="range-field">
        <span>
          {t("التباين", "Contrast")}: {contrast}%
        </span>
        <input
          type="range"
          min="80"
          max="200"
          value={contrast}
          onChange={(e) => setContrast(n(e.target.value))}
        />
      </label>
      <button className="primary-button" onClick={run} disabled={!file || busy}>
        {busy
          ? t("جاري التحسين", "Enhancing")
          : t("تحسين وتنزيل PDF", "Enhance and download PDF")}
      </button>
      {error && <div className="error-notice">{error}</div>}
      {output && (
        <div className="ready-download" role="status">
          <span>
            <Icon name="check" size={18} />
            {t("ملف المسح جاهز", "Scanned PDF ready")}
          </span>
          <button
            className="primary-button"
            onClick={() => download(output, "adawati-scan.pdf")}
          >
            <Icon name="download" size={18} />
            {t("تحميل PDF", "Download PDF")}
          </button>
        </div>
      )}
      <Tip
        ar="التصحيح يزيل الألوان ويرفع التباين ويقص نسبة متساوية من الحواف للحصول على ورقة أوضح"
        en="Processing removes color, increases contrast, and crops an equal edge percentage for a clearer page"
      />
    </div>
  );
}

export const additionalToolSlugs = [
  "expense-planner",
  "fuel-trip",
  "work-hours",
  "hourly-wage",
  "installment-calculator",
  "date-shift",
  "countdown",
  "timezone-converter",
  "unit-converter",
  "electricity-cost",
  "internet-data",
  "shopping-list",
  "unit-price-comparison",
  "currency-converter",
  "required-grade",
  "task-divider",
  "digit-converter",
  "list-cleaner",
  "subscription-duration",
  "expiry-reminder",
  "option-comparison",
  "image-collage",
  "circular-image-cropper",
  "official-photo",
  "file-size-total",
  "batch-file-renamer",
  "document-signer",
  "document-scanner",
];
export function AdditionalToolWorkspace({ slug }: { slug: string }) {
  switch (slug) {
    case "expense-planner":
      return <ExpensePlanner />;
    case "fuel-trip":
      return <FuelTrip />;
    case "work-hours":
      return <WorkHours />;
    case "hourly-wage":
      return <HourlyWage />;
    case "installment-calculator":
      return <Installments />;
    case "date-shift":
      return <DateShift />;
    case "countdown":
      return <Countdown />;
    case "timezone-converter":
      return <TimezoneConverter />;
    case "unit-converter":
      return <UnitConverter />;
    case "electricity-cost":
      return <Electricity />;
    case "internet-data":
      return <InternetData />;
    case "shopping-list":
      return <ShoppingList />;
    case "unit-price-comparison":
      return <UnitPrice />;
    case "currency-converter":
      return <CurrencyConverter />;
    case "required-grade":
      return <RequiredGrade />;
    case "task-divider":
      return <TaskDivider />;
    case "digit-converter":
      return <DigitConverter />;
    case "list-cleaner":
      return <ListCleaner />;
    case "subscription-duration":
      return <SubscriptionDuration />;
    case "expiry-reminder":
      return <ExpiryReminder />;
    case "option-comparison":
      return <OptionComparison />;
    case "image-collage":
      return <ImageCollage />;
    case "circular-image-cropper":
      return <CircularImageCropper />;
    case "official-photo":
      return <OfficialPhoto />;
    case "file-size-total":
      return <FileSizeTotal />;
    case "batch-file-renamer":
      return <BatchRenamer />;
    case "document-signer":
      return <DocumentSigner />;
    case "document-scanner":
      return <DocumentScanner />;
    default:
      return null;
  }
}
