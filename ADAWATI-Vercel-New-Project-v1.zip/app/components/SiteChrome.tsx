"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Logo } from "./Logo";
import { Icon } from "./Icon";
import { useLocale } from "./LocaleProvider";
import { BackButton } from "./BackButton";

const nav = [
  { href: "/", ar: "الرئيسية", en: "Home" },
  { href: "/tools", ar: "الأدوات", en: "Tools" },
  { href: "/#categories", ar: "التصنيفات", en: "Categories" },
  { href: "/favorites", ar: "المفضلة", en: "Favorites" },
];

export function SiteChrome({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [dark, setDark] = useState(false);
  const [menu, setMenu] = useState(false);
  const [languageMenu, setLanguageMenu] = useState(false);
  const [hash, setHash] = useState("");
  const languageControl = useRef<HTMLDivElement>(null);
  const { locale, setLocale, t } = useLocale();

  useEffect(() => {
    const saved = localStorage.getItem("minjaz-theme");
    const enabled = saved
      ? saved === "dark"
      : window.matchMedia("(prefers-color-scheme: dark)").matches;
    queueMicrotask(() => setDark(enabled));
    document.documentElement.dataset.theme = enabled ? "dark" : "light";
  }, []);

  useEffect(() => {
    const updateHash = () => setHash(window.location.hash);
    updateHash();
    window.addEventListener("hashchange", updateHash);
    return () => window.removeEventListener("hashchange", updateHash);
  }, [pathname]);

  useEffect(() => {
    function dismiss(event: PointerEvent) {
      if (!languageControl.current?.contains(event.target as Node))
        setLanguageMenu(false);
    }
    function escape(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setLanguageMenu(false);
        setMenu(false);
      }
    }
    document.addEventListener("pointerdown", dismiss);
    document.addEventListener("keydown", escape);
    return () => {
      document.removeEventListener("pointerdown", dismiss);
      document.removeEventListener("keydown", escape);
    };
  }, []);

  function toggleTheme() {
    const next = !dark;
    setDark(next);
    document.documentElement.dataset.theme = next ? "dark" : "light";
    localStorage.setItem("minjaz-theme", next ? "dark" : "light");
  }

  const active = (href: string) => {
    if (href === "/#categories")
      return pathname === "/" && hash === "#categories";
    if (href === "/") return pathname === "/" && hash !== "#categories";
    return pathname?.startsWith(href);
  };
  const label = (item: (typeof nav)[number]) =>
    locale === "en" ? item.en : item.ar;

  if (pathname?.startsWith("/admin"))
    return <main id="main-content" tabIndex={-1}>{children}</main>;

  return (
    <>
      <header className="site-header">
        <div className="header-inner">
          <Logo />
          <nav
            className="desktop-nav"
            aria-label={t("التنقل الرئيسي", "Main navigation")}
          >
            {nav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={active(item.href) ? "active" : ""}
              >
                {label(item)}
              </Link>
            ))}
          </nav>
          <div className="header-actions">
            <div className="language-control" ref={languageControl}>
              <button
                className="action-pill language-pill"
                aria-label={t("اختيار اللغة", "Choose language")}
                aria-expanded={languageMenu}
                onClick={() => setLanguageMenu(!languageMenu)}
              >
                <Icon name="globe" size={18} />
                <span>{locale === "en" ? "English" : "العربية"}</span>
              </button>
              {languageMenu && (
                <div className="language-popover" role="menu">
                  <button
                    className={locale === "ar" ? "active" : ""}
                    onClick={() => {
                      setLocale("ar");
                      setLanguageMenu(false);
                    }}
                  >
                    <span>العربية</span>
                    <small>Arabic</small>
                  </button>
                  <button
                    className={locale === "en" ? "active" : ""}
                    onClick={() => {
                      setLocale("en");
                      setLanguageMenu(false);
                    }}
                  >
                    <span>English</span>
                    <small>الإنجليزية</small>
                  </button>
                </div>
              )}
            </div>
            <button
              className="action-pill action-pill--icon"
              onClick={toggleTheme}
              aria-label={
                dark
                  ? t("تفعيل الوضع الفاتح", "Use light mode")
                  : t("تفعيل الوضع الداكن", "Use dark mode")
              }
            >
              <Icon name={dark ? "sun" : "moon"} size={19} />
            </button>
            <button
              className="action-pill action-pill--icon mobile-menu-button"
              onClick={() => setMenu(!menu)}
              aria-label={t("القائمة", "Menu")}
            >
              <Icon name={menu ? "x" : "menu"} size={21} />
            </button>
          </div>
        </div>
        {menu && (
          <nav
            className="mobile-menu"
            aria-label={t("قائمة الهاتف", "Mobile menu")}
          >
            {nav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMenu(false)}
              >
                {label(item)}
              </Link>
            ))}
          </nav>
        )}
      </header>
      <main id="main-content" tabIndex={-1}>
        {pathname !== "/" && (
          <div className="global-back-shell page-width">
            <BackButton />
          </div>
        )}
        {children}
      </main>
      <nav
        className="bottom-nav"
        aria-label={t("تنقل الهاتف", "Mobile navigation")}
      >
        <Link href="/" className={pathname === "/" ? "active" : ""}>
          <Icon name="home" size={23} />
          <span>{t("الرئيسية", "Home")}</span>
        </Link>
        <Link
          href="/tools"
          className={pathname?.startsWith("/tools") ? "active" : ""}
        >
          <Icon name="grid" size={23} />
          <span>{t("الأدوات", "Tools")}</span>
        </Link>
        <Link
          href="/favorites"
          className={pathname === "/favorites" ? "active" : ""}
        >
          <Icon name="star" size={23} />
          <span>{t("المفضلة", "Favorites")}</span>
        </Link>
      </nav>
    </>
  );
}
