/* eslint-disable @next/next/no-img-element */
"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Icon } from "./Icon";

const PIN_LENGTH = 6;

export function normalizePinDigits(value: string) {
  const arabic = "٠١٢٣٤٥٦٧٨٩";
  const eastern = "۰۱۲۳۴۵۶۷۸۹";
  return value
    .replace(/[٠-٩]/g, (digit) => String(arabic.indexOf(digit)))
    .replace(/[۰-۹]/g, (digit) => String(eastern.indexOf(digit)))
    .replace(/\D/g, "")
    .slice(0, PIN_LENGTH);
}

function PinBoxes({ value, onChange, label, autoFocus = false, invalid = false }: {
  value: string;
  onChange: (value: string) => void;
  label: string;
  autoFocus?: boolean;
  invalid?: boolean;
}) {
  const [visible, setVisible] = useState(false);
  const inputs = useRef<Array<HTMLInputElement | null>>([]);

  useEffect(() => {
    if (autoFocus) inputs.current[0]?.focus();
  }, [autoFocus]);

  function applyFrom(index: number, raw: string) {
    const digits = normalizePinDigits(raw);
    if (!digits) return;
    const current = value.padEnd(PIN_LENGTH, " ").split("");
    digits.split("").forEach((digit, offset) => {
      if (index + offset < PIN_LENGTH) current[index + offset] = digit;
    });
    const next = current.join("").trimEnd();
    onChange(next);
    inputs.current[Math.min(index + digits.length, PIN_LENGTH - 1)]?.focus();
  }

  function removeAt(index: number) {
    const current = value.padEnd(PIN_LENGTH, " ").split("");
    current[index] = " ";
    onChange(current.join("").trimEnd());
  }

  return <div className="admin-pin-field">
    <div className="admin-pin-label"><strong>{label}</strong><button type="button" onClick={() => setVisible((current) => !current)}><Icon name={visible ? "eye-off" : "eye"} size={17}/>{visible ? "إخفاء الرمز" : "إظهار الرمز"}</button></div>
    <div className={`admin-pin-boxes ${invalid ? "is-invalid" : ""}`} dir="ltr" onPaste={(event) => { event.preventDefault(); applyFrom(0, event.clipboardData.getData("text")); }}>
      {Array.from({ length: PIN_LENGTH }, (_, index) => <input
        key={index}
        ref={(node) => { inputs.current[index] = node; }}
        type={visible ? "text" : "password"}
        inputMode="numeric"
        autoComplete={index === 0 ? "one-time-code" : "off"}
        pattern="[0-9]*"
        maxLength={1}
        value={value[index] || ""}
        aria-label={`${label} الرقم ${index + 1}`}
        aria-invalid={invalid}
        onFocus={(event) => event.currentTarget.select()}
        onChange={(event) => {
          const digits = normalizePinDigits(event.target.value);
          if (!digits) return removeAt(index);
          applyFrom(index, digits);
        }}
        onKeyDown={(event) => {
          if (event.key === "Backspace") {
            event.preventDefault();
            if (value[index]) removeAt(index);
            else if (index > 0) { removeAt(index - 1); inputs.current[index - 1]?.focus(); }
          }
          if (event.key === "ArrowLeft" && index > 0) inputs.current[index - 1]?.focus();
          if (event.key === "ArrowRight" && index < PIN_LENGTH - 1) inputs.current[index + 1]?.focus();
        }}
      />)}
    </div>
  </div>;
}

export function AdminLogin({ mode, error, busy, onSubmit }: {
  mode: "setup" | "locked";
  error: string;
  busy: boolean;
  onSubmit: (pin: string, confirm?: string) => Promise<void>;
}) {
  const [pin, setPin] = useState("");
  const [confirm, setConfirm] = useState("");
  const isSetup = mode === "setup";
  const ready = pin.length === PIN_LENGTH && (!isSetup || confirm.length === PIN_LENGTH);

  return <div className="admin-login-layout">
    <section className="admin-login-form-side">
      <Link href="/" className="admin-login-back"><Icon name="back" size={20}/><span>رجوع</span></Link>
      <div className="admin-login-card">
        <span className="admin-login-card__icon"><Icon name="shield" size={34}/></span>
        <span className="admin-login-eyebrow">الوصول الإداري</span>
        <h1>{isSetup ? "إنشاء الدخول الآمن" : "تسجيل الدخول الآمن"}</h1>
        <p>{isSetup ? "أنشئ رمز PIN من ستة أرقام للوصول إلى لوحة الإدارة." : "أدخل رمز PIN للوصول إلى لوحة الإدارة."}</p>
        <span className="admin-login-online"><i/>النظام متصل وآمن</span>
        <form onSubmit={async (event) => { event.preventDefault(); if (ready && !busy) await onSubmit(pin, isSetup ? confirm : undefined); }}>
          <PinBoxes value={pin} onChange={setPin} label="رمز PIN" autoFocus invalid={Boolean(error)}/>
          {isSetup && <PinBoxes value={confirm} onChange={setConfirm} label="تأكيد رمز PIN" invalid={Boolean(error)}/>} 
          <small className="admin-pin-help">أدخل الرمز المكوّن من 6 أرقام</small>
          {error && <div className="admin-login-error" role="alert">{error}</div>}
          <button className="admin-login-submit" disabled={!ready || busy}>{busy ? "جاري التحقق..." : isSetup ? "إنشاء الرمز ودخول لوحة الإدارة" : "دخول إلى لوحة الإدارة"}<Icon name="back" size={20}/></button>
        </form>
        <p className="admin-login-security"><Icon name="key" size={18}/>لن يتم حفظ رمز الدخول على هذا الجهاز.</p>
        <Link href="/" className="admin-login-return">العودة إلى الموقع<Icon name="back" size={18}/></Link>
      </div>
      <footer className="admin-login-footer"><span>© {new Date().getFullYear()} أدواتي — جميع الحقوق محفوظة</span><span><Link href="/privacy">الخصوصية</Link><i/><Link href="/terms">الأمان</Link></span></footer>
    </section>

    <aside className="admin-login-visual" aria-label="إدارة أدواتي الآمنة">
      <div className="admin-login-brand"><img src="/brand/adawati-symbol.png" alt="شعار أدواتي ADAWATI"/></div>
      <div className="admin-login-shield"><span/><Icon name="shield" size={190} strokeWidth={1.15}/></div>
      <div className="admin-login-copy"><h2>إدارة آمنة وواضحة</h2><p>وصول محمي إلى أدوات إدارة منصة أدواتي.</p></div>
      <div className="admin-login-features">
        <div><Icon name="key" size={27}/><strong>اتصال مشفّر</strong></div>
        <div><Icon name="user" size={27}/><strong>جلسة إدارية محمية</strong></div>
        <div><Icon name="file" size={27}/><strong>تحقق آمن للدخول</strong></div>
      </div>
    </aside>
  </div>;
}
