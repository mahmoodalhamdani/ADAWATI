import { siteConfig } from "@/lib/registry";
export const dynamic="force-static";
export function GET(){const base=siteConfig.baseUrl;const xml=`<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><sitemap><loc>${base}/sitemaps/tools.xml</loc></sitemap><sitemap><loc>${base}/sitemaps/categories.xml</loc></sitemap><sitemap><loc>${base}/sitemaps/pages.xml</loc></sitemap></sitemapindex>`;return new Response(xml,{headers:{"content-type":"application/xml; charset=utf-8","cache-control":"public, max-age=3600"}})}
