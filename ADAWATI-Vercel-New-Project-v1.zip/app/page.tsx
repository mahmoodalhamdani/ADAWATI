"use client";

import { useState } from "react";
import { categories, tools } from "@/lib/registry";
import { Logo } from "./components/Logo";
import { HomeSearch } from "./components/HomeSearch";
import { CategoryCard, ToolCard } from "./components/Cards";
import { Icon } from "./components/Icon";
import { useLocale } from "./components/LocaleProvider";

export default function HomePage() {
  const { t } = useLocale();
  const [showAllTools, setShowAllTools] = useState(false);
  const homeTools = showAllTools ? tools : tools.slice(0, 18);
  return (
    <div className="home-page">
      <div className="ambient ambient--right" />
      <div className="ambient ambient--left" />
      <section className="hero page-width" aria-labelledby="home-title">
        <h1 id="home-title" className="sr-only">
          {t(
            "أدواتي — منصة الأدوات الرقمية العربية",
            "ADAWATI – Smart digital tools",
          )}
        </h1>
        <Logo variant="hero" />
        <p className="tagline">
          {t("أدواتي لتجعل حياتك أسهل", "ADAWATI makes your life easier")}
        </p>
        <HomeSearch large />
      </section>
      <section
        className="home-section page-width"
        id="categories"
        aria-labelledby="categories-title"
      >
        <div className="section-heading">
          <h2 id="categories-title">{t("التصنيفات", "Categories")}</h2>
        </div>
        <div className="category-grid">
          {categories.map((item) => (
            <CategoryCard key={item.slug} category={item} />
          ))}
        </div>
      </section>
      <section
        className="home-section home-all-tools page-width"
        id="all-tools"
        aria-labelledby="all-tools-title"
      >
        <div className="section-heading home-tools-heading">
          <div>
            <h2 id="all-tools-title">{t("كل الأدوات", "All tools")}</h2>
            <p>
              {t(
                "مجموعة مختارة من أدوات أدواتي، ويمكنك فتح القائمة الكاملة.",
                "A selection of ADAWATI tools, with the full collection one click away.",
              )}
            </p>
          </div>
          <button
            type="button"
            className="view-all-tools-button"
            aria-expanded={showAllTools}
            aria-controls="home-tools-grid"
            onClick={() => setShowAllTools((current) => !current)}
          >
            <Icon name={showAllTools ? "x" : "grid"} size={18} />
            <span>{showAllTools ? t("عرض أقل", "Show less") : t("عرض الكل", "View all")}</span>
          </button>
        </div>
        <div id="home-tools-grid" className="all-tools-grid home-all-tools-grid">
          {homeTools.map((item) => (
            <ToolCard key={item.slug} tool={item} />
          ))}
        </div>
      </section>
    </div>
  );
}
