import { PDFDocument } from "pdf-lib";

export function parsePdfPageSelection(
  value: string,
  pageCount: number,
  allowAll = true,
) {
  if (!Number.isInteger(pageCount) || pageCount < 1)
    throw new Error("The PDF has no pages");
  const normalized = value.trim().toLowerCase();
  if (allowAll && (!normalized || normalized === "all"))
    return Array.from({ length: pageCount }, (_, index) => index);
  if (!normalized) throw new Error("A page range is required");
  const pages: number[] = [];
  for (const token of normalized.split(/[،,\s]+/).filter(Boolean)) {
    const match = token.match(/^(\d+)(?:-(\d+))?$/);
    if (!match) throw new Error(`Invalid page token: ${token}`);
    const start = Number(match[1]);
    const end = Number(match[2] || match[1]);
    if (start < 1 || end < 1 || start > pageCount || end > pageCount)
      throw new Error(`Page is outside 1-${pageCount}`);
    const direction = start <= end ? 1 : -1;
    for (let page = start; page !== end + direction; page += direction)
      pages.push(page - 1);
  }
  if (!pages.length) throw new Error("A page range is required");
  return pages;
}

export async function mergePdfDocuments(inputs: ArrayBuffer[]) {
  if (!inputs.length) throw new Error("At least one PDF is required");
  const output = await PDFDocument.create();
  for (const input of inputs) {
    const source = await PDFDocument.load(input);
    const pages = await output.copyPages(source, source.getPageIndices());
    pages.forEach((page) => output.addPage(page));
  }
  if (!output.getPageCount()) throw new Error("The PDFs contain no pages");
  return output.save({ useObjectStreams: false });
}

export async function splitPdfDocument(
  input: ArrayBuffer,
  pagesPerFile = 1,
) {
  const perFile = Math.max(1, Math.min(100, Math.trunc(pagesPerFile) || 1));
  const source = await PDFDocument.load(input);
  const pageCount = source.getPageCount();
  if (!pageCount) throw new Error("The PDF contains no pages");
  const parts: Uint8Array[] = [];
  for (let start = 0; start < pageCount; start += perFile) {
    const output = await PDFDocument.create();
    const indices = Array.from(
      { length: Math.min(perFile, pageCount - start) },
      (_, index) => start + index,
    );
    const pages = await output.copyPages(source, indices);
    pages.forEach((page) => output.addPage(page));
    parts.push(await output.save({ useObjectStreams: false }));
  }
  return parts;
}

export async function imagesToPdfDocuments(
  inputs: { bytes: ArrayBuffer; type: string }[],
) {
  if (!inputs.length) throw new Error("At least one image is required");
  const output = await PDFDocument.create();
  for (const input of inputs) {
    const image =
      input.type === "image/png"
        ? await output.embedPng(input.bytes)
        : await output.embedJpg(input.bytes);
    const page = output.addPage([image.width, image.height]);
    page.drawImage(image, {
      x: 0,
      y: 0,
      width: image.width,
      height: image.height,
    });
  }
  return output.save({ useObjectStreams: false });
}

export type SignatureOptions = {
  target: "first" | "last" | "all";
  position:
    "bottom-right" | "bottom-left" | "top-right" | "top-left" | "center";
  sizePercent: number;
  signatureType: "image/png" | "image/jpeg";
};

export async function signPdfDocument(
  pdfBytes: ArrayBuffer,
  signatureBytes: ArrayBuffer,
  options: SignatureOptions,
) {
  const pdf = await PDFDocument.load(pdfBytes);
  const pages = pdf.getPages();
  if (!pages.length) throw new Error("The PDF contains no pages");
  const signature =
    options.signatureType === "image/png"
      ? await pdf.embedPng(signatureBytes)
      : await pdf.embedJpg(signatureBytes);
  const selected =
    options.target === "all"
      ? pages
      : options.target === "last"
        ? [pages.at(-1)!]
        : [pages[0]];
  for (const page of selected) {
    const width = Math.min(
      page.getWidth() * 0.6,
      (page.getWidth() * Math.min(55, Math.max(10, options.sizePercent))) / 100,
    );
    const height = (width * signature.height) / signature.width;
    const margin = Math.max(18, page.getWidth() * 0.035);
    let x = options.position.endsWith("left")
      ? margin
      : options.position === "center"
        ? (page.getWidth() - width) / 2
        : page.getWidth() - width - margin;
    let y = options.position.startsWith("top")
      ? page.getHeight() - height - margin
      : options.position === "center"
        ? (page.getHeight() - height) / 2
        : margin;
    x = Math.max(0, Math.min(x, page.getWidth() - width));
    y = Math.max(0, Math.min(y, page.getHeight() - height));
    page.drawImage(signature, { x, y, width, height });
  }
  return {
    bytes: await pdf.save({ useObjectStreams: false }),
    pageCount: pages.length,
    signedPages: selected.length,
  };
}

export async function jpegToPdf(bytes: ArrayBuffer) {
  const pdf = await PDFDocument.create();
  const image = await pdf.embedJpg(bytes);
  const page = pdf.addPage([image.width, image.height]);
  page.drawImage(image, {
    x: 0,
    y: 0,
    width: image.width,
    height: image.height,
  });
  return pdf.save({ useObjectStreams: false });
}
