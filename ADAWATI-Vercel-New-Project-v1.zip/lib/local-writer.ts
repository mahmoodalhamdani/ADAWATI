export function limitWords(text: string, count: number) {
  const words = text.trim().split(/\s+/).filter(Boolean);
  if (words.length <= count) return text.trim();
  return `${words.slice(0, count).join(" ").replace(/[،,;؛:]$/, "")}.`;
}

export function extractSubject(request: string, locale: "ar" | "en") {
  if (locale === "en") {
    const cleaned = request
      .replace(/^(?:please\s+)?(?:can you\s+|could you\s+|i want you to\s+)?(?:write|create|draft|generate|compose)\s+(?:me\s+|us\s+)?/i, "")
      .replace(/^(?:a|an|the)?\s*(?:morning|evening|short|formal|friendly|romantic)?\s*(?:message|letter|article|essay|paragraph|post|tweet|poem|text)\s*(?:about|on|for|regarding)?\s*/i, "")
      .trim();
    return cleaned || "the requested topic";
  }
  const cleaned = request
    .replace(/^(?:من فضلك|لو سمحت|رجاءً|رجاء|ممكن)?\s*(?:أريدك|اريدك)?\s*(?:أن|ان)?\s*(?:تكتب|اكتب|أنشئ|انشئ|ولّد|ولد|صغ|جهّز|جهز)\s*(?:لي|لنا)?\s*/i, "")
    .replace(/^(?:رسال[ةه]|مقال(?:اً|ا|ة)?|موضوع(?:اً|ا)?|فقرة|منشور(?:اً|ا)?|بوست|تغريدة|قصيدة|شعر|نص(?:اً|ا)?)\s*(?:صباحي[ةه]?|مسائي[ةه]?|قصير[ةه]?|رسمي[ةه]?|ودي[ةه]?|رومانسي[ةه]?)?\s*(?:عن|حول|بخصوص|لـ|ل)?\s*/i, "")
    .trim();
  return cleaned || "الموضوع المطلوب";
}

export function buildLocalDraft(request: string, count: number, locale: "ar" | "en") {
  const subject = extractSubject(request, locale);
  const isMessage = locale === "en" ? /\b(message|letter|email|wish|greeting)\b/i.test(request) : /(رسال[ةه]|خطاب|تهنئ[ةه]|معايد[ةه]|اعتذار)/i.test(request);
  const isMorning = locale === "en" ? /\bmorning\b/i.test(request) : /(صباح|صباحي)/i.test(request);
  const isRomantic = locale === "en" ? /\b(love|romantic|beloved)\b/i.test(request) : /(حب|حبيب|رومانسي|عشق)/i.test(request);
  const isPost = locale === "en" ? /\b(post|tweet|caption)\b/i.test(request) : /(منشور|بوست|تغريد[ةه]|كابشن)/i.test(request);
  if (locale === "en") {
    if (isMessage && isMorning && isRomantic) return limitWords("Good morning, my love. You are the first beautiful thought of my day. I hope your morning is calm, your heart is light, and every step brings you closer to what makes you happy. Your presence gives ordinary moments warmth and your smile makes the whole day brighter. Have a wonderful morning and an even lovelier day.", count);
    if (isMessage) return limitWords(`Hello, I wanted to write to you about ${subject} and share these sincere words. I hope this message reaches you at a good moment and brings warmth, clarity, and encouragement. May the coming days be kinder, the next steps easier, and every effort rewarded with a result worth celebrating. Please accept my best wishes and genuine appreciation.`, count);
    if (isPost) return limitWords(`${subject} can change how we see ordinary moments and remind us where real value lives. Small choices, sincere effort, and clear intention often create the strongest results. Start with what you have, keep learning, and let every step move you forward. Progress does not need to be loud to be meaningful; it only needs to continue.`, count);
    return limitWords(`${subject} is closely connected to the quality of daily life and the way we understand ourselves and others. Its value appears in the choices we make, the relationships we build, and the habits we repeat. Real progress begins when knowledge becomes practice and good intentions become consistent actions. Challenges may appear, but patience, honest dialogue, and a willingness to learn can turn them into useful lessons.`, count);
  }
  if (isMessage && isMorning && isRomantic) return limitWords("صباح الخير يا أجمل ما يبدأ به يومي. أنت أول خاطر دافئ يمرّ في قلبي كل صباح، وأجمل سبب يجعل الوقت أكثر لطفاً. أتمنى أن تستقبل يومك بابتسامة هادئة، وأن ترافقك السعادة في كل خطوة، وأن تجد أمامك ما يطمئن قلبك ويحقق أمنياتك. صباحك حب وراحة ونجاح، ويومك أجمل مما تتمنى.", count);
  if (isMessage) return limitWords(`مرحباً، أكتب إليك اليوم بخصوص ${subject}، وأرسل لك هذه الكلمات بكل صدق وتقدير. أتمنى أن تصلك رسالتي في وقت جميل، وأن تحمل معها شيئاً من الطمأنينة والفرح والتشجيع. كل محاولة مخلصة تقرّبك من هدف يستحق الوصول. تقبّل رسالتي مع خالص الأمنيات والمحبة والتقدير.`, count);
  if (isPost) return limitWords(`${subject} يغيّر نظرتنا إلى التفاصيل ويذكّرنا بأن القيمة الحقيقية تبدأ من الاختيارات الصغيرة. خطوة صادقة، وقرار واضح، واستمرار هادئ قد تصنع نتائج أكبر مما نتوقع. ابدأ بما تملك، وتعلّم من كل تجربة، ولا تقلّل من شأن التقدم البسيط. النجاح لا يحتاج دائماً إلى ضجيج؛ يكفي أن تواصل السير بثبات.`, count);
  return limitWords(`${subject} موضوع يرتبط بتفاصيل حياتنا اليومية، ويؤثر في طريقة فهمنا لأنفسنا وعلاقاتنا والقرارات التي نتخذها. تظهر قيمته حين ننتقل من الانطباعات السريعة إلى فهم أعمق يقوم على الوعي والتجربة والحوار الصادق. ولا يتحقق أثره الحقيقي بالكلام وحده، بل بالممارسات الصغيرة التي نكررها باهتمام ومسؤولية. كل خطوة إيجابية، مهما بدت بسيطة، تترك أثراً يتراكم مع الوقت ويصنع فرقاً واضحاً.`, count);
}
