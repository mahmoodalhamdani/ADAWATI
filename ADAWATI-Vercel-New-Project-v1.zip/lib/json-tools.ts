function likelyJsonErrorOffset(source: string) {
  let cursor = 0;
  const skipSpace = () => {
    while (/\s/.test(source[cursor] || "")) cursor += 1;
  };
  const fail = () => {
    throw cursor;
  };
  const parseString = () => {
    if (source[cursor] !== '"') fail();
    cursor += 1;
    while (cursor < source.length) {
      const character = source[cursor];
      if (character === '"') {
        cursor += 1;
        return;
      }
      if (character === "\\") {
        cursor += 1;
        const escape = source[cursor];
        if (!'"\\/bfnrtu'.includes(escape || "")) fail();
        if (escape === "u") {
          const hex = source.slice(cursor + 1, cursor + 5);
          if (!/^[0-9a-f]{4}$/i.test(hex)) fail();
          cursor += 4;
        }
      } else if (character.charCodeAt(0) < 0x20) fail();
      cursor += 1;
    }
    fail();
  };
  const parseValue = () => {
    skipSpace();
    const character = source[cursor];
    if (character === '"') return parseString();
    if (character === "{") {
      cursor += 1;
      skipSpace();
      if (source[cursor] === "}") {
        cursor += 1;
        return;
      }
      while (cursor < source.length) {
        parseString();
        skipSpace();
        if (source[cursor] !== ":") fail();
        cursor += 1;
        parseValue();
        skipSpace();
        if (source[cursor] === "}") {
          cursor += 1;
          return;
        }
        if (source[cursor] !== ",") fail();
        cursor += 1;
        skipSpace();
        if (source[cursor] === "}") fail();
      }
      fail();
    }
    if (character === "[") {
      cursor += 1;
      skipSpace();
      if (source[cursor] === "]") {
        cursor += 1;
        return;
      }
      while (cursor < source.length) {
        parseValue();
        skipSpace();
        if (source[cursor] === "]") {
          cursor += 1;
          return;
        }
        if (source[cursor] !== ",") fail();
        cursor += 1;
        skipSpace();
        if (source[cursor] === "]") fail();
      }
      fail();
    }
    for (const literal of ["true", "false", "null"])
      if (source.startsWith(literal, cursor)) {
        cursor += literal.length;
        return;
      }
    const number = source.slice(cursor).match(/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/);
    if (number) {
      cursor += number[0].length;
      return;
    }
    fail();
  };
  try {
    parseValue();
    skipSpace();
    if (cursor !== source.length) fail();
  } catch (offset) {
    return typeof offset === "number" ? offset : cursor;
  }
  return cursor;
}

export function jsonErrorDetails(source: string, error: unknown) {
  const message = error instanceof Error ? error.message : String(error);
  const explicit = message.match(/line\s+(\d+)(?:\s+column\s+(\d+))?/i);
  const positionMatch = message.match(/position\s+(\d+)/i);
  let line = explicit ? Number(explicit[1]) : 1;
  let column = explicit?.[2] ? Number(explicit[2]) : 1;
  if (!explicit) {
    const position = positionMatch
      ? Math.max(0, Number(positionMatch[1]))
      : likelyJsonErrorOffset(source);
    const before = source.slice(0, position);
    const lines = before.split("\n");
    line = lines.length;
    column = (lines.at(-1)?.length || 0) + 1;
  }
  const reason = message
    .replace(/^JSON\.parse:\s*/i, "")
    .replace(/\s+at position\s+\d+[\s\S]*$/i, "")
    .replace(/\s*\(line\s+\d+\s+column\s+\d+\)\s*$/i, "")
    .trim();
  return { line, column, reason: reason || "Invalid JSON syntax" };
}
