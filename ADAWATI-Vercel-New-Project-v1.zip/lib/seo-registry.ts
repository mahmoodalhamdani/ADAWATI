import { siteConfig, tools } from "./registry";

export const seoRegistry = Object.fromEntries(tools.map((tool)=>[tool.slug,{
  nameAr:tool.name,nameEn:tool.nameEn,slugAr:tool.slug,slugEn:tool.slug,
  primaryKeyword:tool.name,secondaryKeywords:tool.keywords.slice(0,5),longTailKeywords:tool.questions,
  synonyms:tool.keywords,arabicSynonyms:tool.keywords.filter(value=>/[\u0600-\u06FF]/.test(value)),englishSynonyms:tool.keywords.filter(value=>/[A-Za-z]/.test(value)),
  commonQueries:tool.keywords,questionQueries:tool.questions,searchIntent:["tool","how-to","question"],
  title:tool.seoTitle,description:tool.seoDescription,headings:[`كيفية استخدام ${tool.name}`,`ما هي ${tool.name}؟`,`أسئلة شائعة`],faq:tool.questions,
  schema:"WebApplication",relatedTools:tool.related,internalLinks:tool.related.map(slug=>`/tools/${slug}`),
  ogTitle:tool.seoTitle,ogDescription:tool.seoDescription,ogImage:"/og.png",
  canonical:`${siteConfig.baseUrl}/tools/${tool.slug}`,hreflang:{ar:`${siteConfig.baseUrl}/tools/${tool.slug}`,"x-default":`${siteConfig.baseUrl}/tools/${tool.slug}`},
}]));
