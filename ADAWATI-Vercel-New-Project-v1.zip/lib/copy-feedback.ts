export async function copyWithFeedback(text: string, button?: HTMLElement | null) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
    } else {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.setAttribute("readonly", "");
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      textarea.remove();
    }
    if (button) {
      button.classList.remove("copy-confirmed");
      void button.offsetWidth;
      button.classList.add("copy-confirmed");
      window.setTimeout(() => button.classList.remove("copy-confirmed"), 1500);
    }
    window.dispatchEvent(new CustomEvent("minjaz-copy-feedback", { detail: { ok: true } }));
  } catch {
    window.dispatchEvent(new CustomEvent("minjaz-copy-feedback", { detail: { ok: false } }));
  }
}
