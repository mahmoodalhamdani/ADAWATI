export const additionalToolSlugs = [
  "expense-planner", "fuel-trip", "work-hours", "hourly-wage", "installment-calculator",
  "date-shift", "countdown", "timezone-converter", "unit-converter", "electricity-cost",
  "internet-data", "shopping-list", "unit-price-comparison", "currency-converter",
  "required-grade", "task-divider", "digit-converter", "list-cleaner",
  "subscription-duration", "expiry-reminder", "option-comparison", "image-collage",
  "circular-image-cropper", "official-photo", "file-size-total", "batch-file-renamer",
  "document-signer", "document-scanner",
];

export const priorityToolSlugs = [
  "timesheet", "file-transfer-time", "typing-speed-test", "google-result-preview",
  "favicon-generator", "file-hash-verifier", "attendance-calculator", "maintenance-schedule",
];

export const printDesignToolSlugs = [
  "page-setup",
  "qr-print-designer",
  "flyer-maker",
  "poster-maker",
];

export const formulaToolSlugs = [
  "overtime-calculator", "monthly-annual-comparison", "cost-per-use", "break-even-calculator",
  "profit-margin-calculator", "home-area-calculator", "tile-calculator", "paint-calculator",
  "tank-volume-calculator", "water-consumption-calculator", "reading-time-calculator",
  "speech-time-calculator", "car-cost-per-km", "installment-comparison", "storage-estimator",
  "parking-cost-calculator", "battery-runtime-calculator", "power-bank-calculator",
  "aspect-ratio-calculator", "delivery-cost-calculator", "depreciation-calculator",
  "reorder-point-calculator", "inventory-balance-calculator", "shipping-volume-calculator",
  "box-count-calculator", "mixing-ratio-calculator", "commission-calculator",
  "platform-fee-calculator", "target-sale-price-calculator", "stock-runout-calculator",
  "prorated-rent-calculator", "printer-cost-calculator", "printing-cost-calculator",
  "device-age-cost-calculator", "repair-replace-comparison", "tv-size-calculator",
  "viewing-distance-calculator", "ppi-calculator", "print-resolution-calculator",
  "sample-size-calculator", "margin-of-error-calculator",
];

export const pdfToolSlugs = [
  "pdf-split", "pdf-delete-pages", "pdf-extract-pages", "pdf-organize", "pdf-compress",
  "pdf-repair", "pdf-rotate", "pdf-protect", "pdf-unlock", "pdf-page-numbers",
  "pdf-watermark", "pdf-crop", "pdf-edit", "pdf-redact", "pdf-to-pdfa", "word-to-pdf",
  "powerpoint-to-pdf", "excel-to-pdf", "html-to-pdf", "pdf-to-jpg", "pdf-to-word",
  "pdf-to-powerpoint", "pdf-to-excel", "pdf-ocr", "pdf-summary", "pdf-to-markdown",
  "pdf-forms", "pdf-compare",
];
