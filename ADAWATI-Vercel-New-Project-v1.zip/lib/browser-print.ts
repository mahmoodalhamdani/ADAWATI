export type BrowserPrintOptions = {
  title: string;
  bodyHtml: string;
  headHtml?: string;
  styles?: string;
  direction?: "rtl" | "ltr" | "auto";
};

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function waitForImage(image: HTMLImageElement) {
  if (image.complete) return Promise.resolve();
  return new Promise<void>((resolve) => {
    image.addEventListener("load", () => resolve(), { once: true });
    image.addEventListener("error", () => resolve(), { once: true });
  });
}

/**
 * Opens the browser's native print-to-PDF dialog from an isolated, scriptless
 * frame. Because the browser lays out the HTML, CSS, fonts, images, tables and
 * bidirectional text remain real print content instead of flattened text.
 */
export async function printHtmlDocument(options: BrowserPrintOptions) {
  const frame = document.createElement("iframe");
  frame.title = options.title;
  frame.className = "browser-print-frame";
  frame.setAttribute("sandbox", "allow-modals allow-same-origin");
  Object.assign(frame.style, {
    position: "fixed",
    width: "1px",
    height: "1px",
    insetInlineEnd: "0",
    bottom: "0",
    border: "0",
    opacity: "0",
    pointerEvents: "none",
  });

  const direction = options.direction || "auto";
  frame.srcdoc = `<!doctype html><html dir="${direction}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(options.title)}</title>${options.headHtml || ""}<style>html,body{margin:0;padding:0;background:#fff;color:#111;-webkit-print-color-adjust:exact;print-color-adjust:exact}img,svg{max-width:100%}${options.styles || ""}</style></head><body>${options.bodyHtml}</body></html>`;
  document.body.appendChild(frame);

  try {
    await new Promise<void>((resolve, reject) => {
      const timer = window.setTimeout(
        () => reject(new Error("print-frame-timeout")),
        20_000,
      );
      frame.addEventListener(
        "load",
        () => {
          window.clearTimeout(timer);
          resolve();
        },
        { once: true },
      );
    });
    const printDocument = frame.contentDocument;
    const printWindow = frame.contentWindow;
    if (!printDocument || !printWindow) throw new Error("print-frame-missing");
    await printDocument.fonts?.ready;
    await Promise.all(
      [...printDocument.images].map((image) => waitForImage(image)),
    );
    printWindow.focus();
    printWindow.print();
    window.setTimeout(() => frame.remove(), 60_000);
  } catch (error) {
    frame.remove();
    throw error;
  }
}

/** Converts rendered charts/canvases to portable images before serializing DOM. */
export function replaceCanvasesWithImages(root: HTMLElement) {
  root.querySelectorAll("canvas").forEach((canvas) => {
    const image = document.createElement("img");
    image.src = canvas.toDataURL("image/png");
    image.alt = canvas.getAttribute("aria-label") || "";
    image.width = canvas.width;
    image.height = canvas.height;
    image.style.cssText = canvas.style.cssText;
    canvas.replaceWith(image);
  });
}

/** Removes active content while retaining authored CSS and printable markup. */
export function parsePrintableHtml(source: string) {
  const parsed = new DOMParser().parseFromString(source, "text/html");
  parsed
    .querySelectorAll("script, iframe, frame, object, embed, form")
    .forEach((node) => node.remove());
  parsed
    .querySelectorAll<HTMLElement>("[onload],[onclick],[onerror],[onmouseover]")
    .forEach((node) => {
      for (const attribute of [...node.attributes])
        if (attribute.name.toLowerCase().startsWith("on"))
          node.removeAttribute(attribute.name);
    });
  return {
    headHtml: parsed.head.innerHTML,
    bodyHtml: parsed.body.innerHTML,
    direction:
      parsed.documentElement.dir === "rtl"
        ? ("rtl" as const)
        : parsed.documentElement.dir === "ltr"
          ? ("ltr" as const)
          : ("auto" as const),
  };
}
