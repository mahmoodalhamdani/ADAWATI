const DAY_MS = 86_400_000;

type DateParts = { year: number; month: number; day: number };

function parseDate(value: string): DateParts | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(Date.UTC(year, month - 1, day));
  if (
    date.getUTCFullYear() !== year ||
    date.getUTCMonth() !== month - 1 ||
    date.getUTCDate() !== day
  )
    return null;
  return { year, month, day };
}

function stamp(value: DateParts) {
  return Date.UTC(value.year, value.month - 1, value.day);
}

function formatDate(value: DateParts) {
  return `${value.year}-${String(value.month).padStart(2, "0")}-${String(value.day).padStart(2, "0")}`;
}

function daysInMonth(year: number, month: number) {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

function addMonthsClamped(value: DateParts, amount: number): DateParts {
  const monthIndex = value.month - 1 + amount;
  const year = value.year + Math.floor(monthIndex / 12);
  const month = (((monthIndex % 12) + 12) % 12) + 1;
  return { year, month, day: Math.min(value.day, daysInMonth(year, month)) };
}

function addYearsClamped(value: DateParts, amount: number): DateParts {
  const year = value.year + amount;
  return {
    year,
    month: value.month,
    day: Math.min(value.day, daysInMonth(year, value.month)),
  };
}

export function calendarDaysBetween(start: string, end: string) {
  const a = parseDate(start);
  const b = parseDate(end);
  if (!a || !b) return null;
  return Math.round((stamp(b) - stamp(a)) / DAY_MS);
}

export function countdownToStartOfDay(target: string, now = new Date()) {
  const value = parseDate(target);
  if (!value || Number.isNaN(now.getTime())) return null;
  const due = new Date(value.year, value.month - 1, value.day, 0, 0, 0, 0);
  const totalMinutes = Math.max(
    0,
    Math.ceil((due.getTime() - now.getTime()) / 60_000),
  );
  return {
    days: Math.floor(totalMinutes / 1440),
    hours: Math.floor((totalMinutes % 1440) / 60),
    minutes: totalMinutes % 60,
    reached: due.getTime() <= now.getTime(),
  };
}

export function dateDifference(start: string, end: string) {
  const a = parseDate(start);
  const b = parseDate(end);
  if (!a || !b || stamp(a) > stamp(b)) return null;
  let cursor = a;
  let years = b.year - a.year;
  let next = addYearsClamped(a, years);
  if (stamp(next) > stamp(b)) {
    years -= 1;
    next = addYearsClamped(a, years);
  }
  cursor = next;
  let months = 0;
  while (months < 11) {
    const candidate = addMonthsClamped(cursor, 1);
    if (stamp(candidate) > stamp(b)) break;
    cursor = candidate;
    months += 1;
  }
  const days = Math.round((stamp(b) - stamp(cursor)) / DAY_MS);
  const totalDays = Math.round((stamp(b) - stamp(a)) / DAY_MS);
  return { years, months, days, totalDays };
}

export function preciseAge(birthDate: string, calculationDate: string) {
  const difference = dateDifference(birthDate, calculationDate);
  const birth = parseDate(birthDate);
  const current = parseDate(calculationDate);
  if (!difference || !birth || !current) return null;
  let nextBirthday = {
    year: current.year,
    month: birth.month,
    day: Math.min(birth.day, daysInMonth(current.year, birth.month)),
  };
  if (stamp(nextBirthday) < stamp(current)) {
    nextBirthday = {
      year: current.year + 1,
      month: birth.month,
      day: Math.min(birth.day, daysInMonth(current.year + 1, birth.month)),
    };
  }
  return {
    ...difference,
    daysToBirthday: Math.round((stamp(nextBirthday) - stamp(current)) / DAY_MS),
  };
}

export function workDaysInclusive(
  start: string,
  end: string,
  excludedDays: number[],
) {
  const a = parseDate(start);
  const b = parseDate(end);
  if (!a || !b || stamp(a) > stamp(b)) return null;
  const excluded = new Set(excludedDays.filter((day) => day >= 0 && day <= 6));
  let workDays = 0;
  for (let current = stamp(a); current <= stamp(b); current += DAY_MS) {
    if (!excluded.has(new Date(current).getUTCDay())) workDays += 1;
  }
  return {
    workDays,
    calendarDays: Math.round((stamp(b) - stamp(a)) / DAY_MS) + 1,
  };
}

export function addWorkDays(
  start: string,
  duration: number,
  excludedDays: number[],
) {
  const value = parseDate(start);
  if (!value || !Number.isInteger(duration) || duration < 0) return null;
  const excluded = new Set(excludedDays.filter((day) => day >= 0 && day <= 6));
  if (excluded.size === 7) return null;
  let current = stamp(value);
  let added = 0;
  while (added < duration) {
    current += DAY_MS;
    if (!excluded.has(new Date(current).getUTCDay())) added += 1;
  }
  const result = new Date(current);
  return formatDate({
    year: result.getUTCFullYear(),
    month: result.getUTCMonth() + 1,
    day: result.getUTCDate(),
  });
}

export function shiftDate(date: string, days: number) {
  const value = parseDate(date);
  if (!value || !Number.isFinite(days)) return null;
  const shifted = new Date(stamp(value) + Math.trunc(days) * DAY_MS);
  return formatDate({
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth() + 1,
    day: shifted.getUTCDate(),
  });
}

export function parseNumberList(value: string) {
  const tokens = value
    .split(/[,،\s]+/)
    .map((item) => item.trim())
    .filter(Boolean);
  if (!tokens.length) return null;
  const numbers = tokens.map(Number);
  return numbers.every(Number.isFinite) ? numbers : null;
}

export function average(values: string) {
  const numbers = parseNumberList(values);
  return numbers
    ? numbers.reduce((sum, value) => sum + value, 0) / numbers.length
    : null;
}

export function weightedAverage(gradesValue: string, hoursValue: string) {
  const grades = parseNumberList(gradesValue);
  const hours = parseNumberList(hoursValue);
  if (
    !grades ||
    !hours ||
    grades.length !== hours.length ||
    hours.some((value) => value <= 0)
  )
    return null;
  const totalHours = hours.reduce((sum, value) => sum + value, 0);
  return (
    grades.reduce((sum, grade, index) => sum + grade * hours[index], 0) /
    totalHours
  );
}

export function percentageOf(value: number, percentage: number) {
  return (value * percentage) / 100;
}

export function percentageChange(start: number, end: number) {
  if (!Number.isFinite(start) || !Number.isFinite(end) || start === 0)
    return null;
  return ((end - start) / Math.abs(start)) * 100;
}

export function targetSalePriceFromMargin(cost: number, targetMargin: number) {
  if (
    !Number.isFinite(cost) ||
    !Number.isFinite(targetMargin) ||
    cost < 0 ||
    targetMargin < 0 ||
    targetMargin >= 100
  )
    return null;
  return cost / (1 - targetMargin / 100);
}

export function fuelStopPlan(
  distance: number,
  consumption: number,
  tankCapacity: number,
  startingFuel: number,
  reserveFuel: number,
  roundTrip = false,
) {
  const kilometers = distance * (roundTrip ? 2 : 1);
  if (
    ![kilometers, consumption, tankCapacity, startingFuel, reserveFuel].every(
      Number.isFinite,
    ) ||
    kilometers < 0 ||
    consumption <= 0 ||
    tankCapacity <= 0 ||
    startingFuel < 0 ||
    startingFuel > tankCapacity ||
    reserveFuel < 0 ||
    reserveFuel >= tankCapacity
  )
    return null;

  const kilometersPerLiter = 100 / consumption;
  const firstLeg = Math.max(0, startingFuel - reserveFuel) * kilometersPerLiter;
  const fullLeg = (tankCapacity - reserveFuel) * kilometersPerLiter;
  const stops =
    kilometers <= firstLeg ? 0 : Math.ceil((kilometers - firstLeg) / fullLeg);
  const stopKilometers = Array.from({ length: stops }, (_, index) =>
    Math.min(kilometers, firstLeg + index * fullLeg),
  );

  return {
    kilometers,
    firstLeg,
    fullLeg,
    stops,
    stopKilometers,
  };
}

export function discountTotal(price: number, discount: number, tax = 0) {
  const afterDiscount = price * (1 - discount / 100);
  const final = afterDiscount * (1 + tax / 100);
  return { afterDiscount, taxAmount: final - afterDiscount, final };
}

export function discountFromFinalPrice(originalPrice: number, finalPrice: number) {
  if (
    !Number.isFinite(originalPrice) ||
    !Number.isFinite(finalPrice) ||
    originalPrice <= 0 ||
    finalPrice < 0 ||
    finalPrice > originalPrice
  )
    return null;
  const saved = originalPrice - finalPrice;
  return { saved, discountRate: (saved / originalPrice) * 100 };
}

export type FuelEconomyUnit = "L/100 km" | "km/L" | "mpg (US)" | "mpg (UK)";

const fuelEconomyConstants = {
  "mpg (US)": 235.214583,
  "mpg (UK)": 282.480936,
} as const;

export function convertFuelEconomy(
  value: number,
  from: FuelEconomyUnit,
  to: FuelEconomyUnit,
) {
  if (!Number.isFinite(value) || value <= 0) return null;

  const litersPer100Km =
    from === "L/100 km"
      ? value
      : from === "km/L"
        ? 100 / value
        : fuelEconomyConstants[from] / value;

  if (to === "L/100 km") return litersPer100Km;
  if (to === "km/L") return 100 / litersPer100Km;
  return fuelEconomyConstants[to] / litersPer100Km;
}

export function savingsPlan(goal: number, months: number, current = 0) {
  if (goal < 0 || current < 0 || months <= 0) return null;
  const remaining = Math.max(0, goal - current);
  return {
    remaining,
    monthly: remaining / months,
    weekly: remaining / (months * 4.345),
  };
}

export function billShare(amount: number, people: number, tip = 0) {
  return amount >= 0 && Number.isInteger(people) && people > 0 && tip >= 0
    ? (amount * (1 + tip / 100)) / people
    : null;
}

export function studyPlan(
  pages: number,
  days: number,
  reviewDays: number,
  restDays: number,
) {
  if (
    !Number.isInteger(pages) ||
    !Number.isInteger(days) ||
    !Number.isInteger(reviewDays) ||
    !Number.isInteger(restDays) ||
    pages <= 0 ||
    days <= 0 ||
    reviewDays < 0 ||
    restDays < 0 ||
    reviewDays + restDays >= days
  )
    return null;
  const activeDays = days - reviewDays - restDays;
  return { activeDays, pagesPerDay: Math.ceil(pages / activeDays) };
}

export function workMinutes(start: string, end: string, breakMinutes: number) {
  const timePattern = /^(\d{2}):(\d{2})$/;
  const a = timePattern.exec(start);
  const b = timePattern.exec(end);
  if (!a || !b || breakMinutes < 0) return null;
  const startMinutes = Number(a[1]) * 60 + Number(a[2]);
  const endMinutes = Number(b[1]) * 60 + Number(b[2]);
  if (
    startMinutes >= 1_440 ||
    endMinutes >= 1_440 ||
    Number(a[2]) >= 60 ||
    Number(b[2]) >= 60
  )
    return null;
  let duration = endMinutes - startMinutes;
  if (duration < 0) duration += 1_440;
  return Math.max(0, duration - breakMinutes);
}

function localStartOfDay(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(year, month - 1, day, 0, 0, 0, 0);
  return date.getFullYear() === year &&
    date.getMonth() === month - 1 &&
    date.getDate() === day
    ? date
    : null;
}

export function zonedDateTimeToUtc(date: string, time: string, zone: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time))
    return null;
  const [year, month, day] = date.split("-").map(Number);
  const [hour, minute] = time.split(":").map(Number);
  if (
    !localStartOfDay(date) ||
    hour < 0 ||
    hour > 23 ||
    minute < 0 ||
    minute > 59
  )
    return null;
  let stamp = Date.UTC(year, month - 1, day, hour, minute);
  try {
    for (let index = 0; index < 2; index += 1) {
      const parts = new Intl.DateTimeFormat("en-CA", {
        timeZone: zone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hourCycle: "h23",
      }).formatToParts(new Date(stamp));
      const map = Object.fromEntries(
        parts.map((part) => [part.type, part.value]),
      );
      const seen = Date.UTC(
        Number(map.year),
        Number(map.month) - 1,
        Number(map.day),
        Number(map.hour),
        Number(map.minute),
      );
      stamp += Date.UTC(year, month - 1, day, hour, minute) - seen;
    }
  } catch {
    return null;
  }
  return new Date(stamp);
}

export function deviceAgeCost(
  price: number,
  purchaseDate: string,
  now = new Date(),
) {
  const purchase = localStartOfDay(purchaseDate);
  const current = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (!purchase || !Number.isFinite(price) || price < 0 || purchase > current)
    return null;
  const days = Math.max(
    1,
    Math.round((current.getTime() - purchase.getTime()) / 86_400_000),
  );
  return { days, months: days / 30.4375, costPerDay: price / days };
}

export function maintenanceScheduleProjection({
  lastDate,
  currentKm,
  lastKm,
  months,
  kilometers,
  dailyKm,
  now = new Date(),
}: {
  lastDate: string;
  currentKm: number;
  lastKm: number;
  months: number;
  kilometers: number;
  dailyKm: number;
  now?: Date;
}) {
  const base = localStartOfDay(lastDate);
  if (
    !base ||
    currentKm < 0 ||
    lastKm < 0 ||
    currentKm < lastKm ||
    months < 0 ||
    kilometers <= 0 ||
    dailyKm < 0
  )
    return null;
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const nextDate = new Date(
    base.getFullYear(),
    base.getMonth() + Math.max(0, Math.floor(months)),
    base.getDate(),
  );
  const nextKm = lastKm + kilometers;
  const kmRemaining = Math.max(0, nextKm - currentKm);
  const daysByKm =
    dailyKm > 0 ? Math.ceil(kmRemaining / dailyKm) : Number.POSITIVE_INFINITY;
  const expectedByKm = Number.isFinite(daysByKm)
    ? new Date(
        today.getFullYear(),
        today.getMonth(),
        today.getDate() + daysByKm,
      )
    : null;
  const effectiveDate =
    expectedByKm && expectedByKm < nextDate ? expectedByKm : nextDate;
  return {
    nextDate,
    nextKm,
    kmRemaining,
    effectiveDate,
    daysByDate: Math.ceil((nextDate.getTime() - today.getTime()) / 86_400_000),
  };
}

export function installmentPayment(
  price: number,
  downPayment: number,
  months: number,
  annualInterest = 0,
) {
  if (
    price < 0 ||
    downPayment < 0 ||
    downPayment > price ||
    !Number.isInteger(months) ||
    months <= 0 ||
    annualInterest < 0
  )
    return null;
  const principal = Math.max(0, price - downPayment);
  const monthlyRate = annualInterest / 1_200;
  const payment =
    monthlyRate > 0
      ? (principal * monthlyRate * (1 + monthlyRate) ** months) /
        ((1 + monthlyRate) ** months - 1)
      : principal / months;
  return {
    payment,
    total: payment * months + downPayment,
    financingCost: Math.max(0, payment * months + downPayment - price),
  };
}

export function requiredFinalGrade(
  current: number,
  completedWeight: number,
  target: number,
) {
  if (completedWeight < 0 || completedWeight >= 100) return null;
  const finalWeight = 100 - completedWeight;
  return (target - (current * completedWeight) / 100) / (finalWeight / 100);
}

export function randomIntegerInclusive(
  first: number,
  second: number,
  random = Math.random,
) {
  if (!Number.isFinite(first) || !Number.isFinite(second)) return null;
  const min = Math.ceil(Math.min(first, second));
  const max = Math.floor(Math.max(first, second));
  if (min > max) return null;
  const sample = Math.min(1 - Number.EPSILON, Math.max(0, random()));
  return Math.floor(sample * (max - min + 1)) + min;
}

export function expensePlan(
  income: number,
  fixedCost: number,
  variableCost: number,
  days: number,
) {
  if (
    [income, fixedCost, variableCost, days].some(
      (value) => !Number.isFinite(value),
    ) ||
    income < 0 ||
    fixedCost < 0 ||
    variableCost < 0 ||
    days < 1
  )
    return null;
  const remaining = income - fixedCost - variableCost;
  return {
    remaining,
    daily: remaining / days,
    expenseRatio:
      income > 0 ? ((fixedCost + variableCost) / income) * 100 : null,
  };
}

export function fuelTripCost(
  distance: number,
  litersPer100Km: number,
  pricePerLiter: number,
  roundTrip = false,
) {
  if (
    [distance, litersPer100Km, pricePerLiter].some(
      (value) => !Number.isFinite(value) || value < 0,
    )
  )
    return null;
  const kilometers = distance * (roundTrip ? 2 : 1);
  const liters = (kilometers * litersPer100Km) / 100;
  return { kilometers, liters, cost: liters * pricePerLiter };
}

export function wageBreakdown(
  mode: "monthly" | "daily" | "hourly",
  amount: number,
  days: number,
  hoursPerDay: number,
) {
  if (
    !Number.isFinite(amount) ||
    amount < 0 ||
    !Number.isFinite(days) ||
    days <= 0 ||
    !Number.isFinite(hoursPerDay) ||
    hoursPerDay <= 0
  )
    return null;
  const totalHours = days * hoursPerDay;
  const monthly =
    mode === "monthly"
      ? amount
      : mode === "daily"
        ? amount * days
        : amount * totalHours;
  return { monthly, daily: monthly / days, hourly: monthly / totalHours };
}

export function electricityUsage(
  watts: number,
  hoursPerDay: number,
  days: number,
  pricePerKwh: number,
) {
  if (
    [watts, hoursPerDay, days, pricePerKwh].some(
      (value) => !Number.isFinite(value) || value < 0,
    )
  )
    return null;
  const kwh = (watts / 1000) * hoursPerDay * days;
  return { kwh, cost: kwh * pricePerKwh };
}

export function internetUsage(
  rateGbPerHour: number,
  hoursPerDay: number,
  days: number,
) {
  if (
    [rateGbPerHour, hoursPerDay, days].some(
      (value) => !Number.isFinite(value) || value < 0,
    )
  )
    return null;
  const gigabytes = rateGbPerHour * hoursPerDay * days;
  return { gigabytes, suggestedPlan: gigabytes * 1.15 };
}

export function compareUnitPrices(
  quantityOne: number,
  priceOne: number,
  quantityTwo: number,
  priceTwo: number,
) {
  if (
    [quantityOne, priceOne, quantityTwo, priceTwo].some(
      (value) => !Number.isFinite(value),
    ) ||
    quantityOne <= 0 ||
    quantityTwo <= 0 ||
    priceOne < 0 ||
    priceTwo < 0
  )
    return null;
  const first = priceOne / quantityOne;
  const second = priceTwo / quantityTwo;
  return {
    first,
    second,
    better: first === second ? "equal" : first < second ? "first" : "second",
  } as const;
}

export function taskDivision(tasks: number, days: number, restDays: number) {
  if (
    ![tasks, days, restDays].every(Number.isInteger) ||
    tasks <= 0 ||
    days <= 0 ||
    restDays < 0 ||
    restDays >= days
  )
    return null;
  const activeDays = days - restDays;
  const tasksPerDay = Math.ceil(tasks / activeDays);
  return {
    activeDays,
    tasksPerDay,
    spareCapacity: activeDays * tasksPerDay - tasks,
  };
}

export function convertDigitShapes(value: string, target: "ar" | "en") {
  const arabic = "٠١٢٣٤٥٦٧٨٩";
  const english = "0123456789";
  return value.replace(/[0-9٠-٩]/g, (character) =>
    target === "ar"
      ? arabic[
          english.includes(character)
            ? english.indexOf(character)
            : arabic.indexOf(character)
        ]
      : english[
          arabic.includes(character)
            ? arabic.indexOf(character)
            : english.indexOf(character)
        ],
  );
}

export function cleanList(value: string, sort = true) {
  const items = value
    .split(/\n|،|,/)
    .map((item) => item.trim())
    .filter(Boolean);
  const unique = [
    ...new Map(items.map((item) => [item.toLocaleLowerCase(), item])).values(),
  ];
  if (sort) unique.sort((a, b) => a.localeCompare(b));
  return { items, unique, duplicateCount: items.length - unique.length };
}
