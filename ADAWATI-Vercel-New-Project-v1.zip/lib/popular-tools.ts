export type ToolUsageRow = { selected_tool: string };

export function rankPopularToolSlugs(
  rows: ToolUsageRow[],
  validSlugs: string[],
  fallbackSlugs: string[],
  limit = 4,
) {
  const safeLimit = Math.max(1, Math.min(4, Math.floor(limit) || 4));
  const valid = new Set(validSlugs);
  const counts = new Map<string, number>();
  for (const row of rows) {
    const slug = String(row.selected_tool || "");
    if (valid.has(slug)) counts.set(slug, (counts.get(slug) || 0) + 1);
  }
  const ranked = [...counts.entries()]
    .sort(([slugA, countA], [slugB, countB]) =>
      countB === countA ? slugA.localeCompare(slugB) : countB - countA,
    )
    .map(([slug]) => slug);
  for (const slug of [...fallbackSlugs, ...validSlugs]) {
    if (valid.has(slug) && !ranked.includes(slug)) ranked.push(slug);
    if (ranked.length >= safeLimit) break;
  }
  return ranked.slice(0, safeLimit);
}
