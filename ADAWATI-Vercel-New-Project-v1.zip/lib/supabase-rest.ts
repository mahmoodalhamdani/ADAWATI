const required = (name: "SUPABASE_URL" | "SUPABASE_PUBLISHABLE_KEY" | "MINJAZ_DB_TOKEN") => {
  const value = process.env[name];
  if (!value) throw new Error(`Missing server environment variable: ${name}`);
  return value;
};

export async function supabaseRequest(path: string, init: RequestInit = {}) {
  const url = required("SUPABASE_URL").replace(/\/$/, "");
  const key = required("SUPABASE_PUBLISHABLE_KEY");
  const headers = new Headers(init.headers);
  headers.set("apikey", key);
  headers.set("authorization", `Bearer ${key}`);
  headers.set("x-minjaz-token", required("MINJAZ_DB_TOKEN"));
  if (init.body && !headers.has("content-type")) headers.set("content-type", "application/json");
  const response = await fetch(`${url}/rest/v1/${path}`, {
    ...init,
    headers,
    cache: "no-store",
  });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`Supabase ${response.status}: ${detail.slice(0, 500)}`);
  }
  return response;
}

export async function supabaseJson<T>(path: string, init: RequestInit = {}) {
  const response = await supabaseRequest(path, init);
  return (await response.json()) as T;
}

export async function supabaseAll<T>(path: string, pageSize = 1000) {
  const rows: T[] = [];
  for (let offset = 0; ; offset += pageSize) {
    const response = await supabaseRequest(path, {
      headers: { Range: `${offset}-${offset + pageSize - 1}`, Prefer: "count=exact" },
    });
    const batch = (await response.json()) as T[];
    rows.push(...batch);
    const total = Number(response.headers.get("content-range")?.split("/")[1] || batch.length);
    if (rows.length >= total || batch.length < pageSize) return rows;
  }
}

export function exactCount(response: Response) {
  const value = response.headers.get("content-range")?.split("/")[1];
  return value && value !== "*" ? Number(value) : 0;
}
