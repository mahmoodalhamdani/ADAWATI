export async function pagesToDocx(pages: string[], pageLabel = "Page") {
  const { Document, HeadingLevel, Packer, Paragraph } = await import("docx");
  const document = new Document({
    sections: [
      {
        children: pages.flatMap((page, index) => [
          new Paragraph({
            text: `${pageLabel} ${index + 1}`,
            heading: HeadingLevel.HEADING_1,
          }),
          ...page
            .split(/\n+/)
            .filter(Boolean)
            .map(
              (line) =>
                new Paragraph({
                  text: line,
                  bidirectional: /[\u0600-\u06ff]/.test(line),
                }),
            ),
        ]),
      },
    ],
  });
  return Packer.toBlob(document);
}

export async function pagesToXlsx(
  pages: string[],
  pageLabel = "Page",
  contentLabel = "Content",
) {
  const XLSX = await import("xlsx");
  const rows = [
    [pageLabel, contentLabel],
    ...pages.flatMap((page, index) =>
      page
        .split(/\n|\s{2,}/)
        .filter(Boolean)
        .map((line) => [index + 1, line]),
    ),
  ];
  const sheet = XLSX.utils.aoa_to_sheet(rows);
  sheet["!cols"] = [{ wch: 12 }, { wch: 90 }];
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(
    workbook,
    sheet,
    contentLabel.slice(0, 31) || "Content",
  );
  return XLSX.write(workbook, { type: "array", bookType: "xlsx" }) as ArrayBuffer;
}

export async function tableRowsToXlsx(
  pages: string[][][],
  pageLabel = "Page",
) {
  const XLSX = await import("xlsx");
  const workbook = XLSX.utils.book_new();
  pages.forEach((rows, index) => {
    const safeRows = rows.length ? rows : [[""]];
    const sheet = XLSX.utils.aoa_to_sheet(safeRows);
    const columnCount = Math.max(...safeRows.map((row) => row.length), 1);
    sheet["!cols"] = Array.from({ length: columnCount }, (_, column) => ({
      wch: Math.min(
        60,
        Math.max(
          10,
          ...safeRows.map((row) => String(row[column] || "").length + 2),
        ),
      ),
    }));
    XLSX.utils.book_append_sheet(
      workbook,
      sheet,
      `${pageLabel} ${index + 1}`.slice(0, 31),
    );
  });
  return XLSX.write(workbook, {
    type: "array",
    bookType: "xlsx",
    cellStyles: true,
  }) as ArrayBuffer;
}
