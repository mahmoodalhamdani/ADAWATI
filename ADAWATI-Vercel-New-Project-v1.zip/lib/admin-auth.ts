import { supabaseJson } from "@/lib/supabase-rest";

export async function hashSecret(value: string) {
  const bytes = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(value),
  );
  return Array.from(new Uint8Array(bytes))
    .map((item) => item.toString(16).padStart(2, "0"))
    .join("");
}

export function cookieValue(request: Request, name: string) {
  const cookie = request.headers.get("cookie") || "";
  const item = cookie
    .split(";")
    .map((value) => value.trim())
    .find((value) => value.startsWith(`${name}=`));
  return item ? decodeURIComponent(item.slice(name.length + 1)) : "";
}

export async function getAdminAuth() {
  const rows = await supabaseJson<Array<{ pin_hash: string }>>(
    "minjaz_admin_auth?select=pin_hash&id=eq.1&limit=1",
  );
  return rows[0] ? { pinHash: rows[0].pin_hash } : null;
}

export async function isAdmin(request: Request) {
  const auth = await getAdminAuth();
  return Boolean(auth && cookieValue(request, "minjaz_admin") === auth.pinHash);
}

export function adminCookie(pinHash: string) {
  return `minjaz_admin=${encodeURIComponent(pinHash)}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=43200`;
}
