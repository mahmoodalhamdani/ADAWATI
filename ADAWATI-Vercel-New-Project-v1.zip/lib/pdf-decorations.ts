import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { parsePdfPageSelection } from "./pdf-tools.ts";

export type PageNumberPosition =
  "bottom-center" | "bottom-right" | "bottom-left" | "top-center";

export async function addPdfPageNumbers(
  bytes: ArrayBuffer | Uint8Array,
  position: PageNumberPosition = "bottom-center",
) {
  const document = await PDFDocument.load(bytes);
  const font = await document.embedFont(StandardFonts.Helvetica);
  document.getPages().forEach((page, index) => {
    const label = String(index + 1);
    const size = 12;
    const labelWidth = font.widthOfTextAtSize(label, size);
    const x = position.includes("left")
      ? 28
      : position.includes("right")
        ? page.getWidth() - labelWidth - 28
        : (page.getWidth() - labelWidth) / 2;
    const y = position.startsWith("top") ? page.getHeight() - 28 : 22;
    page.drawText(label, {
      x,
      y,
      size,
      font,
      color: rgb(0.18, 0.25, 0.42),
    });
  });
  return document.save({ useObjectStreams: true });
}

export async function cropPdfMargins(
  bytes: ArrayBuffer | Uint8Array,
  pages: string,
  percentage: number,
) {
  const document = await PDFDocument.load(bytes);
  const allPages = document.getPages();
  const targets = new Set(parsePdfPageSelection(pages, allPages.length));
  const amount = Math.max(0, Math.min(25, percentage)) / 100;
  targets.forEach((index) => {
    const page = allPages[index];
    const marginX = page.getWidth() * amount;
    const marginY = page.getHeight() * amount;
    page.setCropBox(
      marginX,
      marginY,
      page.getWidth() - marginX * 2,
      page.getHeight() - marginY * 2,
    );
  });
  return document.save({ useObjectStreams: true });
}
