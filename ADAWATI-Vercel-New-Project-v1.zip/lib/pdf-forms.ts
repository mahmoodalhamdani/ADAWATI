import {
  PDFCheckBox,
  PDFDocument,
  PDFDropdown,
  PDFOptionList,
  PDFRadioGroup,
  PDFTextField,
} from "pdf-lib";

export type PdfFormField = {
  name: string;
  type: "text" | "checkbox" | "choice" | "unsupported";
  value: string;
  options: string[];
};

export async function inspectPdfForm(bytes: ArrayBuffer | Uint8Array) {
  const document = await PDFDocument.load(bytes);
  return document
    .getForm()
    .getFields()
    .map<PdfFormField>((field) => {
      if (field instanceof PDFTextField)
        return {
          name: field.getName(),
          type: "text",
          value: field.getText() || "",
          options: [],
        };
      if (field instanceof PDFCheckBox)
        return {
          name: field.getName(),
          type: "checkbox",
          value: field.isChecked() ? "true" : "false",
          options: [],
        };
      if (field instanceof PDFDropdown || field instanceof PDFOptionList)
        return {
          name: field.getName(),
          type: "choice",
          value: field.getSelected()[0] || "",
          options: field.getOptions(),
        };
      if (field instanceof PDFRadioGroup)
        return {
          name: field.getName(),
          type: "choice",
          value: field.getSelected() || "",
          options: field.getOptions(),
        };
      return {
        name: field.getName(),
        type: "unsupported",
        value: "",
        options: [],
      };
    });
}

export async function fillPdfForm(
  bytes: ArrayBuffer | Uint8Array,
  values: Record<string, string>,
  flatten = false,
) {
  const document = await PDFDocument.load(bytes);
  const form = document.getForm();
  for (const field of form.getFields()) {
    const value = values[field.getName()];
    if (value === undefined) continue;
    if (field instanceof PDFTextField) field.setText(value);
    else if (field instanceof PDFCheckBox) {
      if (value === "true") field.check();
      else field.uncheck();
    } else if (field instanceof PDFDropdown) {
      if (value) field.select(value);
      else field.clear();
    } else if (field instanceof PDFOptionList) {
      if (value) field.select(value);
      else field.clear();
    } else if (field instanceof PDFRadioGroup && value) field.select(value);
  }
  if (flatten) form.flatten();
  return document.save({ useObjectStreams: false });
}
