export function circularCropPlacement(
  naturalWidth: number,
  naturalHeight: number,
  zoom: number,
  offsetX: number,
  offsetY: number,
  outputSize: number,
  frameSize = 360,
  cropDiameter = 328,
) {
  if (
    [
      naturalWidth,
      naturalHeight,
      zoom,
      outputSize,
      frameSize,
      cropDiameter,
    ].some((value) => !Number.isFinite(value) || value <= 0)
  )
    throw new Error("Invalid crop geometry");
  const baseScale = Math.max(
    cropDiameter / naturalWidth,
    cropDiameter / naturalHeight,
  );
  const imageWidth = naturalWidth * baseScale * zoom;
  const imageHeight = naturalHeight * baseScale * zoom;
  const maxX = Math.max(0, (imageWidth - cropDiameter) / 2);
  const maxY = Math.max(0, (imageHeight - cropDiameter) / 2);
  const safeX = Math.max(-maxX, Math.min(maxX, offsetX));
  const safeY = Math.max(-maxY, Math.min(maxY, offsetY));
  const ratio = outputSize / cropDiameter;
  const cropStart = (frameSize - cropDiameter) / 2;
  return {
    x: (frameSize / 2 - imageWidth / 2 + safeX - cropStart) * ratio,
    y: (frameSize / 2 - imageHeight / 2 + safeY - cropStart) * ratio,
    width: imageWidth * ratio,
    height: imageHeight * ratio,
    offsetX: safeX,
    offsetY: safeY,
  };
}

export function canvasPointFromClient(
  clientX: number,
  clientY: number,
  rect: { left: number; top: number; width: number; height: number },
  pixelWidth: number,
  pixelHeight: number,
) {
  if (
    [
      clientX,
      clientY,
      rect.left,
      rect.top,
      rect.width,
      rect.height,
      pixelWidth,
      pixelHeight,
    ].some((value) => !Number.isFinite(value)) ||
    rect.width <= 0 ||
    rect.height <= 0 ||
    pixelWidth <= 0 ||
    pixelHeight <= 0
  )
    throw new Error("Invalid canvas geometry");
  return {
    x: Math.max(
      0,
      Math.min(pixelWidth, ((clientX - rect.left) * pixelWidth) / rect.width),
    ),
    y: Math.max(
      0,
      Math.min(pixelHeight, ((clientY - rect.top) * pixelHeight) / rect.height),
    ),
  };
}

export function smartFillMaskedPixels(
  source: Uint8ClampedArray,
  mask: Uint8ClampedArray,
  width: number,
  height: number,
) {
  const count = width * height;
  if (
    width < 1 ||
    height < 1 ||
    source.length !== count * 4 ||
    mask.length !== count * 4
  )
    throw new Error("Invalid image data");
  const work = new Uint8ClampedArray(source);
  const state = new Uint8Array(count);
  const queue = new Int32Array(count);
  let head = 0,
    tail = 0,
    selected = 0;
  for (let index = 0; index < count; index += 1) {
    if (mask[index * 4 + 3] < 12) state[index] = 1;
    else selected += 1;
  }
  if (!selected || selected === count)
    throw new Error("A bounded selection is required");
  for (let y = 0; y < height; y += 1)
    for (let x = 0; x < width; x += 1) {
      const index = y * width + x;
      if (state[index]) continue;
      const boundary =
        (x > 0 && state[index - 1] === 1) ||
        (x < width - 1 && state[index + 1] === 1) ||
        (y > 0 && state[index - width] === 1) ||
        (y < height - 1 && state[index + width] === 1);
      if (boundary) {
        state[index] = 2;
        queue[tail++] = index;
      }
    }
  const surrounding = [
    -1,
    1,
    -width,
    width,
    -width - 1,
    -width + 1,
    width - 1,
    width + 1,
  ];
  while (head < tail) {
    const index = queue[head++],
      x = index % width,
      y = Math.floor(index / width);
    let red = 0,
      green = 0,
      blue = 0,
      alpha = 0,
      samples = 0;
    for (const offset of surrounding) {
      const candidate = index + offset,
        cx = candidate % width,
        cy = Math.floor(candidate / width);
      if (
        candidate < 0 ||
        candidate >= count ||
        Math.abs(cx - x) > 1 ||
        Math.abs(cy - y) > 1 ||
        state[candidate] !== 1
      )
        continue;
      const p = candidate * 4;
      red += work[p];
      green += work[p + 1];
      blue += work[p + 2];
      alpha += work[p + 3];
      samples += 1;
    }
    if (!samples) throw new Error("Selection could not be filled");
    const p = index * 4,
      strength = mask[p + 3] / 255;
    work[p] = source[p] * (1 - strength) + (red / samples) * strength;
    work[p + 1] = source[p + 1] * (1 - strength) + (green / samples) * strength;
    work[p + 2] = source[p + 2] * (1 - strength) + (blue / samples) * strength;
    work[p + 3] = source[p + 3] * (1 - strength) + (alpha / samples) * strength;
    state[index] = 1;
    for (const offset of [-1, 1, -width, width]) {
      const candidate = index + offset,
        cx = candidate % width,
        cy = Math.floor(candidate / width);
      if (
        candidate >= 0 &&
        candidate < count &&
        Math.abs(cx - x) <= 1 &&
        Math.abs(cy - y) <= 1 &&
        state[candidate] === 0
      ) {
        state[candidate] = 2;
        queue[tail++] = candidate;
      }
    }
  }
  return work;
}
