import type { Cell, Color, Fill, Worksheet } from "exceljs";

export type PrintableWorkbook = {
  bodyHtml: string;
  styles: string;
  direction: "rtl" | "ltr" | "auto";
  sheetCount: number;
  recalculatedFormulaCount: number;
};

export const EXCEL_FORMULA_RESULT_MISSING = "excel-formula-result-missing";

type FormulaContext = {
  cache: Map<string, number>;
  visiting: Set<string>;
  recalculated: Set<string>;
};

type FormulaToken = {
  kind: "number" | "reference" | "identifier" | "operator";
  value: string;
};

function formulaError(cell: Cell, reason = "unsupported") {
  return new Error(
    `${EXCEL_FORMULA_RESULT_MISSING}:${cell.fullAddress.sheetName}!${cell.address}:${reason}`,
  );
}

function formulaTokens(formula: string, cell: Cell): FormulaToken[] {
  const source = formula.replace(/^=/, "").trim();
  const pattern = /\s*(?:(\d+(?:\.\d+)?(?:e[+-]?\d+)?)|((?:'[^']+'|[A-Za-z_][A-Za-z0-9_.]*)!\$?[A-Z]{1,3}\$?\d+)|(\$?[A-Z]{1,3}\$?\d+)|([A-Z_][A-Z0-9_.]*)|([()+\-*/^%,:;]))/giy;
  const tokens: FormulaToken[] = [];
  let index = 0;
  while (index < source.length) {
    pattern.lastIndex = index;
    const match = pattern.exec(source);
    if (!match || match.index !== index) throw formulaError(cell, "token");
    index = pattern.lastIndex;
    if (match[1]) tokens.push({ kind: "number", value: match[1] });
    else if (match[2] || match[3])
      tokens.push({ kind: "reference", value: match[2] || match[3] });
    else if (match[4]) tokens.push({ kind: "identifier", value: match[4] });
    else if (match[5]) tokens.push({ kind: "operator", value: match[5] });
  }
  return tokens;
}

function referencedCell(baseCell: Cell, reference: string) {
  const separator = reference.lastIndexOf("!");
  const sheetName =
    separator >= 0
      ? reference
          .slice(0, separator)
          .replace(/^'/, "")
          .replace(/'$/, "")
          .replaceAll("''", "'")
      : baseCell.fullAddress.sheetName;
  const address = reference.slice(separator + 1).replaceAll("$", "");
  const worksheet = baseCell.workbook.getWorksheet(sheetName);
  if (!worksheet || !/^[A-Z]{1,3}\d+$/i.test(address))
    throw formulaError(baseCell, "reference");
  return worksheet.getCell(address);
}

function numericCellValue(cell: Cell, context: FormulaContext): number {
  const key = `${cell.fullAddress.sheetName}!${cell.address}`;
  const cached = context.cache.get(key);
  if (cached !== undefined) return cached;
  if (context.visiting.has(key)) throw formulaError(cell, "circular");
  context.visiting.add(key);
  try {
    const raw = cell.value;
    let value: unknown = raw;
    if (cell.formula) {
      const storedResult =
        raw && typeof raw === "object" && "result" in raw ? raw.result : undefined;
      if (storedResult !== undefined && storedResult !== null) value = storedResult;
      else {
        value = new CommonFormulaParser(
          formulaTokens(cell.formula, cell),
          cell,
          context,
        ).evaluate();
        context.recalculated.add(key);
      }
    }
    const numericValue =
      value === null || value === undefined || value === ""
        ? 0
        : typeof value === "boolean"
          ? value
            ? 1
            : 0
          : typeof value === "number"
            ? value
            : typeof value === "string" && value.trim() && Number.isFinite(Number(value))
              ? Number(value)
              : Number.NaN;
    if (!Number.isFinite(numericValue)) throw formulaError(cell, "non-numeric");
    context.cache.set(key, numericValue);
    return numericValue;
  } finally {
    context.visiting.delete(key);
  }
}

class CommonFormulaParser {
  private position = 0;

  constructor(
    private readonly tokens: FormulaToken[],
    private readonly baseCell: Cell,
    private readonly context: FormulaContext,
  ) {}

  evaluate() {
    const value = this.expression();
    if (this.position !== this.tokens.length || !Number.isFinite(value))
      throw formulaError(this.baseCell, "expression");
    return value;
  }

  private current() {
    return this.tokens[this.position];
  }

  private take(value?: string) {
    const token = this.current();
    if (!token || (value && token.value !== value))
      throw formulaError(this.baseCell, "syntax");
    this.position += 1;
    return token;
  }

  private expression(): number {
    let value = this.term();
    while (["+", "-"].includes(this.current()?.value)) {
      const operator = this.take().value;
      const right = this.term();
      value = operator === "+" ? value + right : value - right;
    }
    return value;
  }

  private term(): number {
    let value = this.power();
    while (["*", "/"].includes(this.current()?.value)) {
      const operator = this.take().value;
      const right = this.power();
      value = operator === "*" ? value * right : value / right;
    }
    return value;
  }

  private power(): number {
    let value = this.unary();
    if (this.current()?.value === "^") {
      this.take("^");
      value **= this.power();
    }
    return value;
  }

  private unary(): number {
    if (this.current()?.value === "+") {
      this.take("+");
      return this.unary();
    }
    if (this.current()?.value === "-") {
      this.take("-");
      return -this.unary();
    }
    let value = this.primary();
    while (this.current()?.value === "%") {
      this.take("%");
      value /= 100;
    }
    return value;
  }

  private primary(): number {
    const token = this.current();
    if (!token) throw formulaError(this.baseCell, "primary");
    if (token.kind === "number") {
      this.take();
      return Number(token.value);
    }
    if (token.kind === "reference") {
      this.take();
      return numericCellValue(referencedCell(this.baseCell, token.value), this.context);
    }
    if (token.kind === "identifier") return this.functionCall();
    if (token.value === "(") {
      this.take("(");
      const value = this.expression();
      this.take(")");
      return value;
    }
    throw formulaError(this.baseCell, "primary");
  }

  private functionCall(): number {
    const name = this.take().value.toUpperCase();
    if (!["SUM", "AVERAGE", "MIN", "MAX"].includes(name))
      throw formulaError(this.baseCell, `function-${name}`);
    this.take("(");
    const values: number[] = [];
    if (this.current()?.value !== ")") {
      while (true) {
        if (
          this.current()?.kind === "reference" &&
          this.tokens[this.position + 1]?.value === ":" &&
          this.tokens[this.position + 2]?.kind === "reference"
        ) {
          const start = this.take().value;
          this.take(":");
          const end = this.take().value;
          values.push(...this.range(start, end));
        } else values.push(this.expression());
        if (![",", ";"].includes(this.current()?.value)) break;
        this.take();
      }
    }
    this.take(")");
    if (name === "SUM") return values.reduce((total, value) => total + value, 0);
    if (!values.length) throw formulaError(this.baseCell, `function-${name}-empty`);
    if (name === "AVERAGE")
      return values.reduce((total, value) => total + value, 0) / values.length;
    return name === "MIN" ? Math.min(...values) : Math.max(...values);
  }

  private range(startReference: string, endReference: string) {
    const start = referencedCell(this.baseCell, startReference);
    const end = referencedCell(this.baseCell, endReference);
    if (start.worksheet !== end.worksheet)
      throw formulaError(this.baseCell, "cross-sheet-range");
    const values: number[] = [];
    for (
      let row = Math.min(Number(start.row), Number(end.row));
      row <= Math.max(Number(start.row), Number(end.row));
      row += 1
    )
      for (
        let column = Math.min(Number(start.col), Number(end.col));
        column <= Math.max(Number(start.col), Number(end.col));
        column += 1
      )
        values.push(numericCellValue(start.worksheet.getCell(row, column), this.context));
    return values;
  }
}

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function cssColor(color?: Partial<Color>) {
  if (!color) return undefined;
  if (color.argb) {
    const argb = color.argb.replace(/^#/, "");
    if (/^[0-9a-f]{8}$/i.test(argb)) return `#${argb.slice(2)}`;
    if (/^[0-9a-f]{6}$/i.test(argb)) return `#${argb}`;
  }
  return undefined;
}

function fillCss(fill?: Fill) {
  if (!fill) return undefined;
  if (fill.type === "pattern")
    return cssColor(fill.fgColor) || cssColor(fill.bgColor);
  if (fill.type === "gradient") {
    const stops = fill.stops
      .map((stop) => {
        const color = cssColor(stop.color);
        return color ? `${color} ${Math.round(stop.position * 100)}%` : "";
      })
      .filter(Boolean)
      .join(",");
    if (stops)
      return fill.gradient === "angle"
        ? `linear-gradient(${fill.degree || 0}deg,${stops})`
        : `radial-gradient(${stops})`;
  }
  return undefined;
}

function borderWidth(style?: string) {
  if (!style) return "0";
  if (style.includes("medium")) return "2px";
  if (style.includes("thick") || style.includes("double")) return "3px";
  return "1px";
}

function borderStyle(style?: string) {
  if (!style) return "solid";
  if (style.includes("dash")) return "dashed";
  if (style.includes("dot")) return "dotted";
  return style === "double" ? "double" : "solid";
}

function cellStyle(cell: Cell, showGridLines: boolean) {
  const styles: string[] = [];
  const font = cell.font || {};
  if (font.name) styles.push(`font-family:${JSON.stringify(font.name)}`);
  if (font.size) styles.push(`font-size:${font.size}pt`);
  if (font.bold) styles.push("font-weight:700");
  if (font.italic) styles.push("font-style:italic");
  if (font.underline) styles.push("text-decoration:underline");
  const fontColor = cssColor(font.color);
  if (fontColor) styles.push(`color:${fontColor}`);
  const background = fillCss(cell.fill);
  if (background)
    styles.push(
      background.includes("gradient")
        ? `background:${background}`
        : `background-color:${background}`,
    );

  const borders = cell.border || {};
  for (const side of ["top", "right", "bottom", "left"] as const) {
    const border = borders[side];
    if (border?.style) {
      styles.push(
        `border-${side}:${borderWidth(border.style)} ${borderStyle(border.style)} ${cssColor(border.color) || "#111827"}`,
      );
    } else if (showGridLines) styles.push(`border-${side}:1px solid #d1d5db`);
  }

  const alignment = cell.alignment || {};
  if (alignment.horizontal)
    styles.push(
      `text-align:${alignment.horizontal === "distributed" ? "justify" : alignment.horizontal}`,
    );
  if (alignment.vertical)
    styles.push(
      `vertical-align:${alignment.vertical === "distributed" ? "middle" : alignment.vertical}`,
    );
  if (alignment.wrapText) styles.push("white-space:pre-wrap");
  if (alignment.shrinkToFit) styles.push("font-size:min(1em,12pt)");
  if (alignment.indent)
    styles.push(`padding-inline-start:${Math.max(0, alignment.indent) * 0.75}em`);
  if (alignment.readingOrder === "rtl") styles.push("direction:rtl");
  if (alignment.readingOrder === "ltr") styles.push("direction:ltr");
  if (typeof alignment.textRotation === "number" && alignment.textRotation)
    styles.push(`transform:rotate(${alignment.textRotation}deg)`);
  return styles.join(";");
}

function cellText(cell: Cell, context: FormulaContext) {
  const value = cell.value;
  if (value === null || value === undefined) return "";
  if (cell.formula) {
    const storedResult =
      value && typeof value === "object" && "result" in value
        ? value.result
        : undefined;
    if (storedResult !== undefined && storedResult !== null)
      return storedResult instanceof Date
        ? storedResult.toISOString()
        : typeof storedResult === "object"
          ? JSON.stringify(storedResult)
          : String(storedResult);
    return String(numericCellValue(cell, context));
  }
  if (cell.text) return cell.text;
  if (value instanceof Date) return value.toISOString();
  if (typeof value !== "object") return String(value);
  if ("richText" in value)
    return value.richText.map((part) => part.text).join("");
  if ("text" in value) return String(value.text);
  if ("error" in value) return String(value.error);
  return String(value);
}

function mergeMap(worksheet: Worksheet) {
  const master = new Map<string, { rowSpan: number; colSpan: number }>();
  const covered = new Set<string>();
  const merges = (worksheet.model as typeof worksheet.model & { merges?: string[] })
    .merges || [];
  for (const range of merges) {
    const [startAddress, endAddress] = range.split(":");
    if (!startAddress || !endAddress) continue;
    const start = worksheet.getCell(startAddress);
    const end = worksheet.getCell(endAddress);
    const startRow = Number(start.row);
    const startCol = Number(start.col);
    const endRow = Number(end.row);
    const endCol = Number(end.col);
    master.set(`${startRow}:${startCol}`, {
      rowSpan: endRow - startRow + 1,
      colSpan: endCol - startCol + 1,
    });
    for (let row = startRow; row <= endRow; row += 1)
      for (let col = startCol; col <= endCol; col += 1)
        if (row !== startRow || col !== startCol) covered.add(`${row}:${col}`);
  }
  return { master, covered };
}

function worksheetHtml(worksheet: Worksheet, index: number, context: FormulaContext) {
  const rows = Math.max(worksheet.actualRowCount, worksheet.rowCount);
  const columns = Math.max(worksheet.actualColumnCount, worksheet.columnCount);
  if (rows * columns > 250_000)
    throw new Error("worksheet-too-large-to-print-safely");
  const rightToLeft = Boolean(worksheet.views?.some((view) => view.rightToLeft));
  const orientation = worksheet.pageSetup.orientation || "portrait";
  const showGridLines = worksheet.properties.showGridLines !== false;
  const { master, covered } = mergeMap(worksheet);
  const widths = Array.from({ length: columns }, (_, offset) => {
    const width = worksheet.getColumn(offset + 1).width || 12;
    return Math.max(36, Math.min(420, width * 7 + 8));
  });
  const totalWidth = widths.reduce((sum, width) => sum + width, 0);
  const printableWidth = orientation === "landscape" ? 1040 : 750;
  const scale = Math.max(0.35, Math.min(1, printableWidth / Math.max(totalWidth, 1)));
  const colgroup = `<colgroup>${widths.map((width) => `<col style="width:${width}px">`).join("")}</colgroup>`;
  const body: string[] = [];
  for (let rowIndex = 1; rowIndex <= rows; rowIndex += 1) {
    const row = worksheet.getRow(rowIndex);
    if (row.hidden) continue;
    const cells: string[] = [];
    for (let colIndex = 1; colIndex <= columns; colIndex += 1) {
      const key = `${rowIndex}:${colIndex}`;
      if (covered.has(key)) continue;
      const cell = row.getCell(colIndex);
      const merge = master.get(key);
      const attributes = [
        merge?.rowSpan && merge.rowSpan > 1 ? `rowspan="${merge.rowSpan}"` : "",
        merge?.colSpan && merge.colSpan > 1 ? `colspan="${merge.colSpan}"` : "",
        `style="${cellStyle(cell, showGridLines)}"`,
      ]
        .filter(Boolean)
        .join(" ");
      cells.push(`<td ${attributes}>${escapeHtml(cellText(cell, context)).replaceAll("\n", "<br>")}</td>`);
    }
    const height = row.height ? ` style="height:${row.height}pt"` : "";
    if (cells.length) body.push(`<tr${height}>${cells.join("")}</tr>`);
  }
  return `<section class="excel-sheet excel-sheet-${orientation}${index ? " excel-new-page" : ""}" dir="${rightToLeft ? "rtl" : "ltr"}"><h1>${escapeHtml(worksheet.name)}</h1><div class="excel-scale" style="--excel-scale:${scale}"><table>${colgroup}<tbody>${body.join("")}</tbody></table></div></section>`;
}

async function legacyWorkbookHtml(file: File): Promise<PrintableWorkbook> {
  const XLSX = await import("xlsx");
  const workbook = XLSX.read(await file.arrayBuffer(), {
    cellText: true,
    cellStyles: true,
    cellFormula: true,
  });
  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    for (const [address, cell] of Object.entries(sheet)) {
      if (address.startsWith("!")) continue;
      if (cell.f && (cell.v === undefined || cell.v === null))
        throw new Error(`${EXCEL_FORMULA_RESULT_MISSING}:${sheetName}!${address}:legacy`);
    }
  }
  const sheets = workbook.SheetNames.map((name, index) => {
    const rows = XLSX.utils.sheet_to_json<string[]>(workbook.Sheets[name], {
      header: 1,
      raw: false,
      defval: "",
    });
    const table = rows
      .map(
        (row) =>
          `<tr>${row.map((value) => `<td>${escapeHtml(String(value))}</td>`).join("")}</tr>`,
      )
      .join("");
    return `<section class="excel-sheet excel-sheet-landscape${index ? " excel-new-page" : ""}"><h1>${escapeHtml(name)}</h1><table><tbody>${table}</tbody></table></section>`;
  });
  return {
    bodyHtml: sheets.join(""),
    styles: excelPrintStyles,
    direction: "auto",
    sheetCount: sheets.length,
    recalculatedFormulaCount: 0,
  };
}

export const excelPrintStyles = `
  @page excel-portrait{size:A4 portrait;margin:10mm}
  @page excel-landscape{size:A4 landscape;margin:10mm}
  .excel-sheet{page:excel-portrait;break-inside:auto;color:#111;background:#fff;font-family:Arial,Tahoma,sans-serif}
  .excel-sheet-landscape{page:excel-landscape}
  .excel-new-page{break-before:page}
  .excel-sheet h1{font-size:15pt;margin:0 0 8mm;font-weight:700}
  .excel-scale{zoom:var(--excel-scale,1);transform-origin:top left}
  .excel-sheet table{border-collapse:collapse;table-layout:fixed;width:max-content}
  .excel-sheet td{box-sizing:border-box;min-height:20px;padding:3px 5px;white-space:pre-line;overflow-wrap:anywhere}
  .excel-sheet tr{break-inside:avoid}
`;

export async function renderExcelForPrint(file: File): Promise<PrintableWorkbook> {
  if (!file.name.toLowerCase().endsWith(".xlsx")) return legacyWorkbookHtml(file);
  const ExcelJSModule = await import("exceljs");
  const ExcelJS =
    (ExcelJSModule as unknown as { default?: typeof ExcelJSModule }).default ?? ExcelJSModule;
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(await file.arrayBuffer());
  if (!workbook.worksheets.length) throw new Error("workbook-empty");
  const formulaContext: FormulaContext = {
    cache: new Map(),
    visiting: new Set(),
    recalculated: new Set(),
  };
  const bodyHtml = workbook.worksheets
    .map((worksheet, index) => worksheetHtml(worksheet, index, formulaContext))
    .join("");
  const rightToLeft = workbook.worksheets.some((worksheet) =>
    worksheet.views?.some((view) => view.rightToLeft),
  );
  return {
    bodyHtml,
    styles: excelPrintStyles,
    direction: rightToLeft ? "rtl" : "auto",
    sheetCount: workbook.worksheets.length,
    recalculatedFormulaCount: formulaContext.recalculated.size,
  };
}
