export type QrPurposeId =
  | "platform"
  | "website"
  | "text"
  | "sms"
  | "email"
  | "phone"
  | "wifi"
  | "contact"
  | "location"
  | "event";

export type QrPlatformCategoryId =
  | "social"
  | "messaging"
  | "video"
  | "audio"
  | "professional"
  | "commerce"
  | "productivity"
  | "developer"
  | "gaming"
  | "travel"
  | "education"
  | "finance"
  | "custom";

export type QrPlatform = {
  id: string;
  name: string;
  category: QrPlatformCategoryId;
  icon: string;
  color: string;
  prefix: string;
  input: "handle" | "url" | "phone" | "place";
};

export type QrStudioFields = {
  profile: string;
  url: string;
  text: string;
  phone: string;
  message: string;
  email: string;
  subject: string;
  body: string;
  ssid: string;
  password: string;
  encryption: string;
  hidden: boolean;
  name: string;
  organization: string;
  website: string;
  address: string;
  latitude: string;
  longitude: string;
  label: string;
  eventTitle: string;
  eventDate: string;
  eventEndDate: string;
  eventLocation: string;
  cardTitle: string;
  cardSubtitle: string;
};

export const qrPurposes = [
  { id: "platform", ar: "منصة أو حساب", en: "Platform or profile", icon: "users" },
  { id: "website", ar: "موقع أو رابط", en: "Website or URL", icon: "globe" },
  { id: "text", ar: "نص", en: "Text", icon: "text" },
  { id: "sms", ar: "رسالة SMS", en: "SMS message", icon: "message" },
  { id: "email", ar: "بريد إلكتروني", en: "Email", icon: "message" },
  { id: "phone", ar: "رقم هاتف", en: "Phone", icon: "smartphone" },
  { id: "wifi", ar: "شبكة Wi-Fi", en: "Wi-Fi", icon: "network" },
  { id: "contact", ar: "بطاقة عمل", en: "Business card", icon: "user" },
  { id: "location", ar: "موقع جغرافي", en: "Location", icon: "globe" },
  { id: "event", ar: "موعد أو فعالية", en: "Event", icon: "calendar" },
] as const satisfies ReadonlyArray<{
  id: QrPurposeId;
  ar: string;
  en: string;
  icon: string;
}>;

export const qrPlatformCategories = [
  { id: "social", ar: "اجتماعي", en: "Social" },
  { id: "messaging", ar: "مراسلة", en: "Messaging" },
  { id: "video", ar: "فيديو وبث", en: "Video & live" },
  { id: "audio", ar: "صوت وموسيقى", en: "Audio & music" },
  { id: "professional", ar: "مهني وإبداعي", en: "Professional" },
  { id: "commerce", ar: "متاجر وخدمات", en: "Commerce" },
  { id: "productivity", ar: "عمل وإنتاجية", en: "Productivity" },
  { id: "developer", ar: "تطوير وتقنية", en: "Developer" },
  { id: "gaming", ar: "ألعاب", en: "Gaming" },
  { id: "travel", ar: "خرائط وسفر", en: "Maps & travel" },
  { id: "education", ar: "تعليم ومعرفة", en: "Education" },
  { id: "finance", ar: "دفع ومال", en: "Payments" },
  { id: "custom", ar: "أي موقع آخر", en: "Any other site" },
] as const satisfies ReadonlyArray<{
  id: QrPlatformCategoryId;
  ar: string;
  en: string;
}>;

function platform(
  id: string,
  name: string,
  category: QrPlatformCategoryId,
  icon: string,
  color: string,
  prefix: string,
  input: QrPlatform["input"] = "handle",
): QrPlatform {
  return { id, name, category, icon, color, prefix, input };
}

export const qrPlatforms: QrPlatform[] = [
  platform("instagram", "Instagram", "social", "IG", "#E4405F", "https://instagram.com/"),
  platform("facebook", "Facebook", "social", "f", "#1877F2", "https://facebook.com/"),
  platform("x", "X", "social", "X", "#111111", "https://x.com/"),
  platform("threads", "Threads", "social", "@", "#111111", "https://threads.net/@"),
  platform("bluesky", "Bluesky", "social", "BS", "#1185FE", "https://bsky.app/profile/"),
  platform("mastodon", "Mastodon", "social", "M", "#6364FF", "", "url"),
  platform("tiktok", "TikTok", "social", "TT", "#111111", "https://tiktok.com/@"),
  platform("snapchat", "Snapchat", "social", "SC", "#F2C300", "https://snapchat.com/add/"),
  platform("pinterest", "Pinterest", "social", "P", "#BD081C", "https://pinterest.com/"),
  platform("reddit", "Reddit", "social", "R", "#FF4500", "https://reddit.com/u/"),
  platform("tumblr", "Tumblr", "social", "t", "#36465D", "https://tumblr.com/"),
  platform("vk", "VK", "social", "VK", "#0077FF", "https://vk.com/"),
  platform("ok", "OK.ru", "social", "OK", "#EE8208", "https://ok.ru/"),
  platform("weibo", "Weibo", "social", "WB", "#E6162D", "https://weibo.com/", "url"),
  platform("xiaohongshu", "RED", "social", "RED", "#FF2442", "https://xiaohongshu.com/user/profile/"),
  platform("mewe", "MeWe", "social", "MW", "#0476D9", "https://mewe.com/i/"),
  platform("nextdoor", "Nextdoor", "social", "N", "#8ED500", "https://nextdoor.com/profile/", "url"),
  platform("bereal", "BeReal", "social", "BR", "#111111", "https://bere.al/"),
  platform("clubhouse", "Clubhouse", "social", "CH", "#F1EEE5", "https://clubhouse.com/@"),

  platform("whatsapp", "WhatsApp", "messaging", "WA", "#25D366", "https://wa.me/", "phone"),
  platform("telegram", "Telegram", "messaging", "TG", "#229ED9", "https://t.me/"),
  platform("messenger", "Messenger", "messaging", "MS", "#0084FF", "https://m.me/"),
  platform("signal", "Signal", "messaging", "SG", "#3A76F0", "https://signal.me/#p/", "phone"),
  platform("viber", "Viber", "messaging", "VB", "#7360F2", "viber://chat?number=", "phone"),
  platform("line", "LINE", "messaging", "LN", "#06C755", "https://line.me/R/ti/p/@"),
  platform("wechat", "WeChat", "messaging", "WC", "#07C160", "", "url"),
  platform("discord", "Discord", "messaging", "DC", "#5865F2", "https://discord.gg/"),
  platform("slack", "Slack", "messaging", "SL", "#611F69", "", "url"),
  platform("teams", "Microsoft Teams", "messaging", "TM", "#6264A7", "", "url"),
  platform("skype", "Skype", "messaging", "SK", "#00AFF0", "skype:"),
  platform("kakaotalk", "KakaoTalk", "messaging", "KT", "#3C1E1E", "https://open.kakao.com/o/"),
  platform("qq", "QQ", "messaging", "QQ", "#12B7F5", "", "url"),
  platform("zalo", "Zalo", "messaging", "Z", "#0068FF", "https://zalo.me/"),
  platform("groupme", "GroupMe", "messaging", "GM", "#00AFF0", "https://groupme.com/join_group/", "url"),
  platform("matrix", "Element / Matrix", "messaging", "MX", "#0DBD8B", "https://matrix.to/#/"),
  platform("threema", "Threema", "messaging", "3", "#3FE669", "https://threema.id/"),

  platform("youtube", "YouTube", "video", "YT", "#FF0000", "https://youtube.com/@"),
  platform("vimeo", "Vimeo", "video", "V", "#1AB7EA", "https://vimeo.com/"),
  platform("twitch", "Twitch", "video", "TW", "#9146FF", "https://twitch.tv/"),
  platform("kick", "Kick", "video", "K", "#53FC18", "https://kick.com/"),
  platform("dailymotion", "Dailymotion", "video", "DM", "#0A0A0A", "https://dailymotion.com/"),
  platform("rumble", "Rumble", "video", "RU", "#85C742", "https://rumble.com/c/"),
  platform("bilibili", "Bilibili", "video", "BL", "#00A1D6", "https://space.bilibili.com/"),
  platform("loom", "Loom", "video", "LM", "#625DF5", "https://loom.com/share/", "url"),

  platform("spotify", "Spotify", "audio", "SP", "#1DB954", "https://open.spotify.com/", "url"),
  platform("apple-music", "Apple Music", "audio", "AM", "#FA243C", "https://music.apple.com/", "url"),
  platform("soundcloud", "SoundCloud", "audio", "SC", "#FF5500", "https://soundcloud.com/"),
  platform("deezer", "Deezer", "audio", "DZ", "#A238FF", "https://deezer.com/", "url"),
  platform("tidal", "TIDAL", "audio", "TD", "#111111", "https://tidal.com/", "url"),
  platform("amazon-music", "Amazon Music", "audio", "AZ", "#25D1DA", "https://music.amazon.com/", "url"),
  platform("youtube-music", "YouTube Music", "audio", "YM", "#FF0000", "https://music.youtube.com/", "url"),
  platform("bandcamp", "Bandcamp", "audio", "BC", "#629AA9", ".bandcamp.com", "handle"),
  platform("audiomack", "Audiomack", "audio", "AK", "#FFA200", "https://audiomack.com/"),
  platform("mixcloud", "Mixcloud", "audio", "MC", "#5000FF", "https://mixcloud.com/"),
  platform("shazam", "Shazam", "audio", "SZ", "#0088FF", "https://www.shazam.com/", "url"),
  platform("pandora", "Pandora", "audio", "PD", "#224099", "https://pandora.com/", "url"),
  platform("iheart", "iHeartRadio", "audio", "IH", "#C6002B", "https://iheart.com/", "url"),
  platform("pocket-casts", "Pocket Casts", "audio", "PC", "#F43E37", "https://pca.st/", "url"),
  platform("castbox", "Castbox", "audio", "CB", "#F55B23", "https://castbox.fm/", "url"),

  platform("linkedin", "LinkedIn", "professional", "in", "#0A66C2", "https://linkedin.com/in/"),
  platform("behance", "Behance", "professional", "Be", "#1769FF", "https://behance.net/"),
  platform("dribbble", "Dribbble", "professional", "Dr", "#EA4C89", "https://dribbble.com/"),
  platform("medium", "Medium", "professional", "M", "#111111", "https://medium.com/@"),
  platform("substack", "Substack", "professional", "SS", "#FF6719", ".substack.com", "handle"),
  platform("devto", "DEV Community", "professional", "DEV", "#111111", "https://dev.to/"),
  platform("producthunt", "Product Hunt", "professional", "PH", "#DA552F", "https://producthunt.com/@"),
  platform("wellfound", "Wellfound", "professional", "WF", "#111111", "https://wellfound.com/u/"),
  platform("researchgate", "ResearchGate", "professional", "RG", "#00CCBB", "https://researchgate.net/profile/"),
  platform("orcid", "ORCID", "professional", "iD", "#A6CE39", "https://orcid.org/"),
  platform("google-scholar", "Google Scholar", "professional", "GS", "#4285F4", "https://scholar.google.com/citations?user="),
  platform("academia", "Academia.edu", "professional", "A", "#41454A", "https://independent.academia.edu/"),
  platform("linktree", "Linktree", "professional", "LT", "#43E55E", "https://linktr.ee/"),
  platform("aboutme", "about.me", "professional", "me", "#00A98F", "https://about.me/"),

  platform("amazon", "Amazon", "commerce", "a", "#FF9900", "https://amazon.com/", "url"),
  platform("ebay", "eBay", "commerce", "eB", "#E53238", "https://ebay.com/", "url"),
  platform("etsy", "Etsy", "commerce", "E", "#F1641E", "https://etsy.com/shop/"),
  platform("shopify", "Shopify", "commerce", "S", "#7AB55C", "", "url"),
  platform("aliexpress", "AliExpress", "commerce", "AE", "#FF4747", "https://aliexpress.com/", "url"),
  platform("target", "Target", "commerce", "T", "#CC0000", "https://target.com/", "url"),
  platform("gumroad", "Gumroad", "commerce", "G", "#FF90E8", "https://gumroad.com/"),
  platform("patreon", "Patreon", "commerce", "P", "#FF424D", "https://patreon.com/"),
  platform("kofi", "Ko-fi", "commerce", "K", "#13C3FF", "https://ko-fi.com/"),
  platform("buymeacoffee", "Buy Me a Coffee", "commerce", "BMC", "#FFDD00", "https://buymeacoffee.com/"),
  platform("fiverr", "Fiverr", "commerce", "fi", "#1DBF73", "https://fiverr.com/"),
  platform("upwork", "Upwork", "commerce", "up", "#14A800", "https://upwork.com/freelancers/"),

  platform("notion", "Notion", "productivity", "N", "#111111", "", "url"),
  platform("trello", "Trello", "productivity", "T", "#0052CC", "", "url"),
  platform("asana", "Asana", "productivity", "AS", "#F06A6A", "", "url"),
  platform("figma", "Figma", "productivity", "F", "#A259FF", "", "url"),
  platform("calendly", "Calendly", "productivity", "CA", "#006BFF", "https://calendly.com/"),
  platform("zoom", "Zoom", "productivity", "Z", "#2D8CFF", "", "url"),
  platform("google-meet", "Google Meet", "productivity", "GM", "#00897B", "", "url"),
  platform("google-drive", "Google Drive", "productivity", "GD", "#4285F4", "", "url"),
  platform("google-docs", "Google Docs", "productivity", "GDoc", "#4285F4", "", "url"),
  platform("google-sheets", "Google Sheets", "productivity", "GSh", "#0F9D58", "", "url"),
  platform("google-slides", "Google Slides", "productivity", "GSl", "#F4B400", "", "url"),
  platform("dropbox", "Dropbox", "productivity", "DB", "#0061FF", "", "url"),
  platform("onedrive", "OneDrive", "productivity", "OD", "#0078D4", "", "url"),

  platform("github", "GitHub", "developer", "GH", "#181717", "https://github.com/"),
  platform("gitlab", "GitLab", "developer", "GL", "#FC6D26", "https://gitlab.com/"),
  platform("bitbucket", "Bitbucket", "developer", "BB", "#0052CC", "https://bitbucket.org/"),
  platform("stackoverflow", "Stack Overflow", "developer", "SO", "#F48024", "https://stackoverflow.com/users/", "url"),
  platform("codepen", "CodePen", "developer", "CP", "#111111", "https://codepen.io/"),
  platform("codesandbox", "CodeSandbox", "developer", "CS", "#151515", "https://codesandbox.io/u/"),
  platform("replit", "Replit", "developer", "R", "#F26207", "https://replit.com/@"),
  platform("npm", "npm", "developer", "npm", "#CB3837", "https://npmjs.com/~"),
  platform("dockerhub", "Docker Hub", "developer", "DH", "#2496ED", "https://hub.docker.com/u/"),
  platform("vercel", "Vercel", "developer", "V", "#111111", "https://vercel.com/", "url"),
  platform("cloudflare", "Cloudflare", "developer", "CF", "#F38020", "https://cloudflare.com/", "url"),

  platform("steam", "Steam", "gaming", "ST", "#171A21", "https://steamcommunity.com/id/"),
  platform("epic", "Epic Games", "gaming", "EP", "#313131", "https://store.epicgames.com/", "url"),
  platform("xbox", "Xbox", "gaming", "XB", "#107C10", "https://account.xbox.com/en-us/profile?gamertag="),
  platform("playstation", "PlayStation", "gaming", "PS", "#003791", "https://psnprofiles.com/"),
  platform("nintendo", "Nintendo", "gaming", "N", "#E60012", "https://nintendo.com/", "url"),
  platform("roblox", "Roblox", "gaming", "RB", "#111111", "https://roblox.com/users/", "url"),
  platform("minecraft", "Minecraft", "gaming", "MC", "#62B47A", "https://minecraft.net/", "url"),
  platform("battlenet", "Battle.net", "gaming", "BN", "#148EFF", "https://battle.net/", "url"),
  platform("ea", "EA", "gaming", "EA", "#FF4747", "https://ea.com/", "url"),
  platform("ubisoft", "Ubisoft Connect", "gaming", "U", "#0070FF", "https://ubisoftconnect.com/", "url"),
  platform("riot", "Riot Games", "gaming", "RG", "#D32936", "https://riotgames.com/", "url"),

  platform("google-maps", "Google Maps", "travel", "GM", "#4285F4", "https://www.google.com/maps/search/?api=1&query=", "place"),
  platform("apple-maps", "Apple Maps", "travel", "AM", "#111111", "https://maps.apple.com/?q=", "place"),
  platform("waze", "Waze", "travel", "W", "#33CCFF", "https://waze.com/ul?q=", "place"),
  platform("tripadvisor", "Tripadvisor", "travel", "TA", "#00AA6C", "https://tripadvisor.com/", "url"),
  platform("booking", "Booking.com", "travel", "B", "#003580", "https://booking.com/", "url"),
  platform("airbnb", "Airbnb", "travel", "A", "#FF5A5F", "https://airbnb.com/", "url"),
  platform("uber", "Uber", "travel", "U", "#111111", "https://m.uber.com/ul/", "url"),
  platform("lyft", "Lyft", "travel", "L", "#FF00BF", "https://lyft.com/", "url"),

  platform("coursera", "Coursera", "education", "C", "#0056D2", "https://coursera.org/", "url"),
  platform("udemy", "Udemy", "education", "U", "#A435F0", "https://udemy.com/", "url"),
  platform("edx", "edX", "education", "edX", "#02262B", "https://edx.org/", "url"),
  platform("khanacademy", "Khan Academy", "education", "KA", "#14BF96", "https://khanacademy.org/", "url"),
  platform("quizlet", "Quizlet", "education", "Q", "#4255FF", "https://quizlet.com/", "url"),
  platform("goodreads", "Goodreads", "education", "GR", "#553B08", "https://goodreads.com/"),
  platform("wikipedia", "Wikipedia", "education", "W", "#111111", "https://wikipedia.org/", "url"),
  platform("archiveorg", "Internet Archive", "education", "IA", "#555555", "https://archive.org/details/", "url"),

  platform("paypal", "PayPal.Me", "finance", "PP", "#003087", "https://paypal.me/"),
  platform("cashapp", "Cash App", "finance", "$", "#00D64F", "https://cash.app/$"),
  platform("venmo", "Venmo", "finance", "V", "#008CFF", "https://venmo.com/"),
  platform("revolut", "Revolut", "finance", "R", "#111111", "https://revolut.me/"),
  platform("wise", "Wise", "finance", "W", "#9FE870", "https://wise.com/pay/me/", "url"),
  platform("stripe", "Stripe Payment Link", "finance", "S", "#635BFF", "", "url"),
  // A broad extension of well-known services whose official vector marks are
  // available in the bundled brand library. URL mode is intentional for
  // services that do not expose one stable public-profile URL pattern.
  platform("quora", "Quora", "social", "Q", "#B92B27", "https://quora.com/profile/"),
  platform("flickr", "Flickr", "social", "F", "#0063DC", "https://flickr.com/people/"),
  platform("500px", "500px", "social", "500", "#111111", "https://500px.com/p/"),
  platform("diaspora", "Diaspora", "social", "D", "#111111", "", "url"),
  platform("xing", "XING", "social", "X", "#006567", "https://xing.com/profile/"),

  platform("gmail", "Gmail", "messaging", "G", "#EA4335", "", "url"),
  platform("protonmail", "Proton Mail", "messaging", "P", "#6D4AFF", "", "url"),
  platform("zulip", "Zulip", "messaging", "Z", "#6492FE", "", "url"),
  platform("wire", "Wire", "messaging", "W", "#000000", "", "url"),
  platform("mattermost", "Mattermost", "messaging", "M", "#0058CC", "", "url"),
  platform("rocketdotchat", "Rocket.Chat", "messaging", "R", "#F5455C", "", "url"),

  platform("netflix", "Netflix", "video", "N", "#E50914", "", "url"),
  platform("plex", "Plex", "video", "P", "#E5A00D", "", "url"),
  platform("youtubeshorts", "YouTube Shorts", "video", "YS", "#FF0000", "", "url"),
  platform("obsstudio", "OBS Studio", "video", "OBS", "#302E31", "", "url"),

  platform("audible", "Audible", "audio", "A", "#F8991C", "", "url"),
  platform("lastdotfm", "Last.fm", "audio", "L", "#D51007", "", "url"),
  platform("applepodcasts", "Apple Podcasts", "audio", "AP", "#9933CC", "", "url"),
  platform("podcastaddict", "Podcast Addict", "audio", "PA", "#F4842D", "", "url"),

  platform("hashnode", "Hashnode", "professional", "H", "#2962FF", "https://hashnode.com/@"),
  platform("wordpress", "WordPress", "professional", "W", "#21759B", "", "url"),
  platform("blogger", "Blogger", "professional", "B", "#FF5722", "", "url"),
  platform("gravatar", "Gravatar", "professional", "G", "#1E8CBE", "", "url"),
  platform("unsplash", "Unsplash", "professional", "U", "#111111", "https://unsplash.com/@"),
  platform("freelancer", "Freelancer", "professional", "F", "#29B2FE", "", "url"),

  platform("woocommerce", "WooCommerce", "commerce", "W", "#96588A", "", "url"),
  platform("bigcommerce", "BigCommerce", "commerce", "B", "#121118", "", "url"),
  platform("squarespace", "Squarespace", "commerce", "S", "#111111", "", "url"),
  platform("wix", "Wix", "commerce", "W", "#0C0C0C", "", "url"),
  platform("doordash", "DoorDash", "commerce", "D", "#FF3008", "", "url"),
  platform("ubereats", "Uber Eats", "commerce", "UE", "#06C167", "", "url"),

  platform("todoist", "Todoist", "productivity", "T", "#E44332", "", "url"),
  platform("airtable", "Airtable", "productivity", "A", "#18BFFF", "", "url"),
  platform("clickup", "ClickUp", "productivity", "C", "#7B68EE", "", "url"),
  platform("basecamp", "Basecamp", "productivity", "B", "#1D2D35", "", "url"),
  platform("evernote", "Evernote", "productivity", "E", "#00A82D", "", "url"),
  platform("miro", "Miro", "productivity", "M", "#050038", "", "url"),
  platform("jira", "Jira", "productivity", "J", "#0052CC", "", "url"),
  platform("confluence", "Confluence", "productivity", "C", "#172B4D", "", "url"),
  platform("googlecalendar", "Google Calendar", "productivity", "GC", "#4285F4", "", "url"),

  platform("android", "Android", "developer", "A", "#3DDC84", "", "url"),
  platform("apple", "Apple", "developer", "A", "#111111", "", "url"),
  platform("stackblitz", "StackBlitz", "developer", "S", "#1389FD", "", "url"),
  platform("netlify", "Netlify", "developer", "N", "#00C7B7", "", "url"),
  platform("digitalocean", "DigitalOcean", "developer", "D", "#0080FF", "", "url"),
  platform("firebase", "Firebase", "developer", "F", "#FFCA28", "", "url"),
  platform("supabase", "Supabase", "developer", "S", "#3FCF8E", "", "url"),
  platform("postgresql", "PostgreSQL", "developer", "P", "#4169E1", "", "url"),
  platform("mongodb", "MongoDB", "developer", "M", "#47A248", "", "url"),

  platform("gogdotcom", "GOG.com", "gaming", "G", "#86328A", "", "url"),
  platform("itchdotio", "Itch.io", "gaming", "I", "#FA5C5C", "", "url"),
  platform("valorant", "VALORANT", "gaming", "V", "#FA4454", "", "url"),
  platform("leagueoflegends", "League of Legends", "gaming", "L", "#C28F2C", "", "url"),

  platform("expedia", "Expedia", "travel", "E", "#191E3B", "", "url"),
  platform("googleearth", "Google Earth", "travel", "GE", "#4285F4", "", "url"),
  platform("here", "HERE WeGo", "travel", "H", "#00AFAA", "", "url"),
  platform("grab", "Grab", "travel", "G", "#00B14F", "", "url"),

  platform("duolingo", "Duolingo", "education", "D", "#58CC02", "", "url"),
  platform("moodle", "Moodle", "education", "M", "#F98012", "", "url"),
  platform("zotero", "Zotero", "education", "Z", "#CC2936", "", "url"),
  platform("codecademy", "Codecademy", "education", "C", "#1F4056", "", "url"),
  platform("freecodecamp", "freeCodeCamp", "education", "F", "#0A0A23", "", "url"),

  platform("binance", "Binance", "finance", "B", "#F0B90B", "", "url"),
  platform("coinbase", "Coinbase", "finance", "C", "#0052FF", "", "url"),
  platform("bitcoin", "Bitcoin", "finance", "B", "#F7931A", "", "url"),
  platform("ethereum", "Ethereum", "finance", "E", "#3C3C3D", "", "url"),
  platform("applepay", "Apple Pay", "finance", "AP", "#111111", "", "url"),
  platform("googlepay", "Google Pay", "finance", "GP", "#4285F4", "", "url"),
  platform("zelle", "Zelle", "finance", "Z", "#6D1ED4", "", "url"),
  platform("visa", "Visa", "finance", "V", "#1A1F71", "", "url"),
  platform("mastercard", "Mastercard", "finance", "MC", "#EB001B", "", "url"),

  platform("custom", "أي موقع أو منصة", "custom", "WWW", "#0754E8", "", "url"),
];

export const qrCardTemplates = [
  { id: "minjaz", ar: "أدواتي", en: "ADAWATI", dark: "#07184f", light: "#ffffff", accent: "#08cbd5", frame: "#edfaff", variant: "spotlight" },
  { id: "classic", ar: "كلاسيكي", en: "Classic", dark: "#071b63", light: "#ffffff", accent: "#0754e8", frame: "#eef4ff", variant: "clean" },
  { id: "midnight", ar: "منتصف الليل", en: "Midnight", dark: "#f7f9ff", light: "#07101f", accent: "#4b8dff", frame: "#0d192b", variant: "glass" },
  { id: "emerald", ar: "زمردي", en: "Emerald", dark: "#073b2a", light: "#ffffff", accent: "#18a66a", frame: "#eaf9f2", variant: "clean" },
  { id: "violet", ar: "بنفسجي", en: "Violet", dark: "#39136b", light: "#ffffff", accent: "#8b5cf6", frame: "#f3efff", variant: "spotlight" },
  { id: "sunset", ar: "غروب", en: "Sunset", dark: "#6a1a27", light: "#fffdf8", accent: "#f97316", frame: "#fff2df", variant: "wave" },
  { id: "ocean", ar: "محيطي", en: "Ocean", dark: "#063c52", light: "#ffffff", accent: "#0891b2", frame: "#e8faff", variant: "glass" },
  { id: "rose", ar: "وردي", en: "Rose", dark: "#6b1738", light: "#ffffff", accent: "#ec4899", frame: "#fff0f7", variant: "ticket" },
  { id: "gold", ar: "ذهبي", en: "Gold", dark: "#2f2406", light: "#fffdf6", accent: "#c89b19", frame: "#fff7dc", variant: "outline" },
  { id: "slate", ar: "رصاصي", en: "Slate", dark: "#1f2937", light: "#ffffff", accent: "#64748b", frame: "#f1f5f9", variant: "clean" },
  { id: "coral", ar: "مرجاني", en: "Coral", dark: "#5f1d18", light: "#ffffff", accent: "#ef6a5b", frame: "#fff0ed", variant: "wave" },
  { id: "forest", ar: "غابة", en: "Forest", dark: "#17351d", light: "#ffffff", accent: "#4d9b58", frame: "#edf8ef", variant: "spotlight" },
  { id: "royal", ar: "ملكي", en: "Royal", dark: "#20125d", light: "#ffffff", accent: "#5b4ce3", frame: "#efefff", variant: "outline" },
  { id: "ice", ar: "جليدي", en: "Ice", dark: "#0d3b50", light: "#ffffff", accent: "#38bdf8", frame: "#eefbff", variant: "glass" },
  { id: "coffee", ar: "قهوة", en: "Coffee", dark: "#3b251b", light: "#fffdf9", accent: "#9a6a4a", frame: "#f8efe8", variant: "ticket" },
  { id: "berry", ar: "توتي", en: "Berry", dark: "#4a174f", light: "#ffffff", accent: "#b64bc0", frame: "#faeffb", variant: "wave" },
  { id: "lime", ar: "ليموني", en: "Lime", dark: "#24320b", light: "#ffffff", accent: "#84b729", frame: "#f5fae9", variant: "clean" },
  { id: "mono", ar: "أحادي", en: "Mono", dark: "#111111", light: "#ffffff", accent: "#444444", frame: "#f3f3f3", variant: "outline" },
  { id: "sky", ar: "سماوي", en: "Sky", dark: "#163d66", light: "#ffffff", accent: "#4b9cf5", frame: "#edf6ff", variant: "spotlight" },
  { id: "brick", ar: "قرميدي", en: "Brick", dark: "#542019", light: "#fffdfb", accent: "#b75141", frame: "#fff0ec", variant: "ticket" },
] as const;

export const qrShapes = [
  { id: "square", ar: "مربعات", en: "Square" },
  { id: "soft-square", ar: "مربع ناعم", en: "Soft square" },
  { id: "rounded", ar: "ناعم", en: "Rounded" },
  { id: "extra-rounded", ar: "دائري الحواف", en: "Extra rounded" },
  { id: "dots", ar: "نقاط", en: "Dots" },
  { id: "dense-dots", ar: "نقاط ممتلئة", en: "Dense dots" },
  { id: "circle", ar: "دوائر", en: "Circles" },
  { id: "diamond", ar: "ماسي", en: "Diamond" },
  { id: "classy", ar: "أنيق", en: "Classy" },
  { id: "pixel", ar: "بكسل", en: "Pixel" },
  { id: "horizontal", ar: "أفقي", en: "Horizontal" },
  { id: "vertical", ar: "عمودي", en: "Vertical" },
  { id: "hexagon", ar: "سداسي", en: "Hexagon" },
  { id: "cross", ar: "متقاطع", en: "Cross" },
] as const;

export const qrCardFormats = [
  { id: "square", ar: "مربع", en: "Square", width: 1080, height: 1080 },
  { id: "portrait", ar: "بطاقة عمودية", en: "Portrait", width: 1080, height: 1350 },
  { id: "story", ar: "ستوري", en: "Story", width: 1080, height: 1920 },
  { id: "compact", ar: "بطاقة مدمجة", en: "Compact", width: 1200, height: 800 },
] as const;

export type QrCardLayout = {
  margin: number;
  qrX: number;
  qrY: number;
  qrSize: number;
  headerX: number;
  badgeY: number;
  badgeRadius: number;
  titleY: number;
  subtitleY: number;
  footerY: number;
  textMaxWidth: number;
  titleSize: number;
  subtitleSize: number;
};

/**
 * Each export format has its own balanced layout. Keeping these coordinates in
 * one pure function makes it possible to verify that the title, subtitle, QR,
 * and footer never overlap or leave the card bounds.
 */
export function getQrCardLayout(
  formatId: (typeof qrCardFormats)[number]["id"],
  width: number,
  height: number,
  templateVariant = "clean",
): QrCardLayout {
  const margin = templateVariant === "ticket" ? 74 : 58;
  if (formatId === "compact") {
    const qrSize = 560;
    return {
      margin,
      qrX: width - margin - qrSize - 25,
      qrY: (height - qrSize) / 2,
      qrSize,
      headerX: 282,
      badgeY: 164,
      badgeRadius: 38,
      titleY: 246,
      subtitleY: 304,
      footerY: 650,
      textMaxWidth: 390,
      titleSize: 42,
      subtitleSize: 24,
    };
  }
  if (formatId === "story") {
    return {
      margin,
      qrX: (width - 760) / 2,
      qrY: 570,
      qrSize: 760,
      headerX: width / 2,
      badgeY: 350,
      badgeRadius: 42,
      titleY: 426,
      subtitleY: 478,
      footerY: 1510,
      textMaxWidth: width - margin * 2 - 110,
      titleSize: 50,
      subtitleSize: 29,
    };
  }
  if (formatId === "portrait") {
    return {
      margin,
      qrX: (width - 700) / 2,
      qrY: 330,
      qrSize: 700,
      headerX: width / 2,
      badgeY: 128,
      badgeRadius: 39,
      titleY: 194,
      subtitleY: 242,
      footerY: 1160,
      textMaxWidth: width - margin * 2 - 100,
      titleSize: 47,
      subtitleSize: 27,
    };
  }
  return {
    margin,
    qrX: (width - 610) / 2,
    qrY: 270,
    qrSize: 610,
    headerX: width / 2,
    badgeY: 108,
    badgeRadius: 34,
    titleY: 176,
    subtitleY: 220,
    footerY: 960,
    textMaxWidth: width - margin * 2 - 100,
    titleSize: 44,
    subtitleSize: 25,
  };
}

export const qrPresetIcons = [
  ["link", "رابط", "Link", "↗"], ["web", "موقع", "Web", "WWW"],
  ["message", "رسالة", "Message", "✉"], ["email", "بريد", "Email", "@"],
  ["phone", "هاتف", "Phone", "☎"], ["wifi", "Wi-Fi", "Wi-Fi", "WiFi"],
  ["contact", "بطاقة", "Contact", "VC"], ["location", "موقع", "Location", "⌖"],
  ["calendar", "تقويم", "Calendar", "31"], ["document", "ملف", "Document", "DOC"],
  ["shop", "متجر", "Shop", "SHOP"], ["menu", "قائمة", "Menu", "MENU"],
  ["ticket", "تذكرة", "Ticket", "TKT"], ["music", "موسيقى", "Music", "♫"],
  ["video", "فيديو", "Video", "▶"], ["game", "ألعاب", "Gaming", "GP"],
  ["map", "خريطة", "Map", "MAP"], ["pay", "دفع", "Payment", "$"],
  ["star", "مميز", "Featured", "★"], ["minjaz", "أدواتي", "ADAWATI", "M"],
] as const;

export type QrColorFamily = {
  id: string;
  ar: string;
  en: string;
  shades: Record<"50" | "100" | "200" | "300" | "400" | "500" | "600" | "700" | "800" | "900" | "950", string>;
};

function colorFamily(
  id: string,
  ar: string,
  en: string,
  shades: QrColorFamily["shades"],
): QrColorFamily {
  return { id, ar, en, shades };
}

export const qrColorFamilies: QrColorFamily[] = [
  colorFamily("slate", "رصاصي مزرق", "Slate", { "50": "#f8fafc", "100": "#f1f5f9", "200": "#e2e8f0", "300": "#cbd5e1", "400": "#94a3b8", "500": "#64748b", "600": "#475569", "700": "#334155", "800": "#1e293b", "900": "#0f172a", "950": "#020617" }),
  colorFamily("gray", "رمادي", "Gray", { "50": "#f9fafb", "100": "#f3f4f6", "200": "#e5e7eb", "300": "#d1d5db", "400": "#9ca3af", "500": "#6b7280", "600": "#4b5563", "700": "#374151", "800": "#1f2937", "900": "#111827", "950": "#030712" }),
  colorFamily("red", "أحمر", "Red", { "50": "#fef2f2", "100": "#fee2e2", "200": "#fecaca", "300": "#fca5a5", "400": "#f87171", "500": "#ef4444", "600": "#dc2626", "700": "#b91c1c", "800": "#991b1b", "900": "#7f1d1d", "950": "#450a0a" }),
  colorFamily("orange", "برتقالي", "Orange", { "50": "#fff7ed", "100": "#ffedd5", "200": "#fed7aa", "300": "#fdba74", "400": "#fb923c", "500": "#f97316", "600": "#ea580c", "700": "#c2410c", "800": "#9a3412", "900": "#7c2d12", "950": "#431407" }),
  colorFamily("amber", "كهرماني", "Amber", { "50": "#fffbeb", "100": "#fef3c7", "200": "#fde68a", "300": "#fcd34d", "400": "#fbbf24", "500": "#f59e0b", "600": "#d97706", "700": "#b45309", "800": "#92400e", "900": "#78350f", "950": "#451a03" }),
  colorFamily("yellow", "أصفر", "Yellow", { "50": "#fefce8", "100": "#fef9c3", "200": "#fef08a", "300": "#fde047", "400": "#facc15", "500": "#eab308", "600": "#ca8a04", "700": "#a16207", "800": "#854d0e", "900": "#713f12", "950": "#422006" }),
  colorFamily("lime", "ليموني", "Lime", { "50": "#f7fee7", "100": "#ecfccb", "200": "#d9f99d", "300": "#bef264", "400": "#a3e635", "500": "#84cc16", "600": "#65a30d", "700": "#4d7c0f", "800": "#3f6212", "900": "#365314", "950": "#1a2e05" }),
  colorFamily("green", "أخضر", "Green", { "50": "#f0fdf4", "100": "#dcfce7", "200": "#bbf7d0", "300": "#86efac", "400": "#4ade80", "500": "#22c55e", "600": "#16a34a", "700": "#15803d", "800": "#166534", "900": "#14532d", "950": "#052e16" }),
  colorFamily("emerald", "زمردي", "Emerald", { "50": "#ecfdf5", "100": "#d1fae5", "200": "#a7f3d0", "300": "#6ee7b7", "400": "#34d399", "500": "#10b981", "600": "#059669", "700": "#047857", "800": "#065f46", "900": "#064e3b", "950": "#022c22" }),
  colorFamily("teal", "أخضر مزرق", "Teal", { "50": "#f0fdfa", "100": "#ccfbf1", "200": "#99f6e4", "300": "#5eead4", "400": "#2dd4bf", "500": "#14b8a6", "600": "#0d9488", "700": "#0f766e", "800": "#115e59", "900": "#134e4a", "950": "#042f2e" }),
  colorFamily("cyan", "سماوي", "Cyan", { "50": "#ecfeff", "100": "#cffafe", "200": "#a5f3fc", "300": "#67e8f9", "400": "#22d3ee", "500": "#06b6d4", "600": "#0891b2", "700": "#0e7490", "800": "#155e75", "900": "#164e63", "950": "#083344" }),
  colorFamily("sky", "أزرق سماوي", "Sky", { "50": "#f0f9ff", "100": "#e0f2fe", "200": "#bae6fd", "300": "#7dd3fc", "400": "#38bdf8", "500": "#0ea5e9", "600": "#0284c7", "700": "#0369a1", "800": "#075985", "900": "#0c4a6e", "950": "#082f49" }),
  colorFamily("blue", "أزرق", "Blue", { "50": "#eff6ff", "100": "#dbeafe", "200": "#bfdbfe", "300": "#93c5fd", "400": "#60a5fa", "500": "#3b82f6", "600": "#2563eb", "700": "#1d4ed8", "800": "#1e40af", "900": "#1e3a8a", "950": "#172554" }),
  colorFamily("indigo", "نيلي", "Indigo", { "50": "#eef2ff", "100": "#e0e7ff", "200": "#c7d2fe", "300": "#a5b4fc", "400": "#818cf8", "500": "#6366f1", "600": "#4f46e5", "700": "#4338ca", "800": "#3730a3", "900": "#312e81", "950": "#1e1b4b" }),
  colorFamily("violet", "بنفسجي مزرق", "Violet", { "50": "#f5f3ff", "100": "#ede9fe", "200": "#ddd6fe", "300": "#c4b5fd", "400": "#a78bfa", "500": "#8b5cf6", "600": "#7c3aed", "700": "#6d28d9", "800": "#5b21b6", "900": "#4c1d95", "950": "#2e1065" }),
  colorFamily("purple", "بنفسجي", "Purple", { "50": "#faf5ff", "100": "#f3e8ff", "200": "#e9d5ff", "300": "#d8b4fe", "400": "#c084fc", "500": "#a855f7", "600": "#9333ea", "700": "#7e22ce", "800": "#6b21a8", "900": "#581c87", "950": "#3b0764" }),
  colorFamily("fuchsia", "فوشيا", "Fuchsia", { "50": "#fdf4ff", "100": "#fae8ff", "200": "#f5d0fe", "300": "#f0abfc", "400": "#e879f9", "500": "#d946ef", "600": "#c026d3", "700": "#a21caf", "800": "#86198f", "900": "#701a75", "950": "#4a044e" }),
  colorFamily("pink", "وردي", "Pink", { "50": "#fdf2f8", "100": "#fce7f3", "200": "#fbcfe8", "300": "#f9a8d4", "400": "#f472b6", "500": "#ec4899", "600": "#db2777", "700": "#be185d", "800": "#9d174d", "900": "#831843", "950": "#500724" }),
  colorFamily("rose", "وردي داكن", "Rose", { "50": "#fff1f2", "100": "#ffe4e6", "200": "#fecdd3", "300": "#fda4af", "400": "#fb7185", "500": "#f43f5e", "600": "#e11d48", "700": "#be123c", "800": "#9f1239", "900": "#881337", "950": "#4c0519" }),
  colorFamily("neutral", "محايد", "Neutral", { "50": "#fafafa", "100": "#f5f5f5", "200": "#e5e5e5", "300": "#d4d4d4", "400": "#a3a3a3", "500": "#737373", "600": "#525252", "700": "#404040", "800": "#262626", "900": "#171717", "950": "#0a0a0a" }),
  colorFamily("zinc", "زنك", "Zinc", { "50": "#fafafa", "100": "#f4f4f5", "200": "#e4e4e7", "300": "#d4d4d8", "400": "#a1a1aa", "500": "#71717a", "600": "#52525b", "700": "#3f3f46", "800": "#27272a", "900": "#18181b", "950": "#09090b" }),
  colorFamily("stone", "حجري", "Stone", { "50": "#fafaf9", "100": "#f5f5f4", "200": "#e7e5e4", "300": "#d6d3d1", "400": "#a8a29e", "500": "#78716c", "600": "#57534e", "700": "#44403c", "800": "#292524", "900": "#1c1917", "950": "#0c0a09" }),
  colorFamily("brown", "بني", "Brown", { "50": "#fbf8f6", "100": "#f5ede8", "200": "#ead9cf", "300": "#d9bca9", "400": "#c09175", "500": "#a66b4f", "600": "#8b503a", "700": "#713d2f", "800": "#5e342b", "900": "#4f2e27", "950": "#2a1512" }),
  colorFamily("gold", "ذهبي", "Gold", { "50": "#fffbea", "100": "#fff3c4", "200": "#ffe586", "300": "#ffd24a", "400": "#fabe20", "500": "#dca20d", "600": "#b77c08", "700": "#925a0b", "800": "#784710", "900": "#653b13", "950": "#3a1f07" }),
];

export const qrGradientPresets = [
  ["minjaz", "أدواتي", "ADAWATI", "#0754e8", "#08cbd5"],
  ["ocean", "محيط", "Ocean", "#0f172a", "#0891b2"],
  ["aurora", "شفق", "Aurora", "#4f46e5", "#22c55e"],
  ["sunset", "غروب", "Sunset", "#7c2d12", "#fb7185"],
  ["royal", "ملكي", "Royal", "#312e81", "#a855f7"],
  ["emerald", "زمرد", "Emerald", "#064e3b", "#34d399"],
  ["fire", "ناري", "Fire", "#991b1b", "#f59e0b"],
  ["berry", "توت", "Berry", "#701a75", "#ec4899"],
  ["ice", "جليدي", "Ice", "#0369a1", "#a5f3fc"],
  ["forest", "غابة", "Forest", "#14532d", "#84cc16"],
  ["night", "ليل", "Night", "#020617", "#3730a3"],
  ["coffee", "قهوة", "Coffee", "#431407", "#d97706"],
  ["coral", "مرجان", "Coral", "#9f1239", "#fb923c"],
  ["lavender", "لافندر", "Lavender", "#6d28d9", "#f0abfc"],
  ["mint", "نعناع", "Mint", "#0f766e", "#6ee7b7"],
  ["sky", "سماء", "Sky", "#1d4ed8", "#38bdf8"],
  ["mono", "أحادي", "Mono", "#030712", "#6b7280"],
  ["gold", "ذهبي", "Gold", "#451a03", "#fbbf24"],
  ["candy", "حلوى", "Candy", "#be185d", "#8b5cf6"],
  ["lagoon", "بحيرة", "Lagoon", "#164e63", "#2dd4bf"],
  ["grape", "عنب", "Grape", "#3b0764", "#c084fc"],
  ["lime", "ليموني", "Lime", "#365314", "#a3e635"],
  ["steel", "فولاذ", "Steel", "#0f172a", "#94a3b8"],
  ["peach", "خوخي", "Peach", "#c2410c", "#fda4af"],
  ["midnight", "منتصف الليل", "Midnight", "#020617", "#0ea5e9"],
  ["desert", "صحراء", "Desert", "#78350f", "#fdba74"],
  ["rose-gold", "ذهب وردي", "Rose Gold", "#9f1239", "#fbbf24"],
  ["jade", "يشم", "Jade", "#064e3b", "#2dd4bf"],
  ["electric", "كهربائي", "Electric", "#312e81", "#22d3ee"],
  ["ruby", "ياقوت", "Ruby", "#450a0a", "#fb7185"],
  ["sand", "رملي", "Sand", "#5e342b", "#fcd34d"],
  ["arctic", "قطبي", "Arctic", "#0c4a6e", "#e0f2fe"],
  ["nebula", "سديم", "Nebula", "#3b0764", "#f472b6"],
  ["meadow", "مرج", "Meadow", "#14532d", "#bef264"],
  ["graphite", "جرافيت", "Graphite", "#09090b", "#a1a1aa"],
  ["bronze", "برونزي", "Bronze", "#4f2e27", "#dca20d"],
] as const;

export function colorContrast(foreground: string, background: string) {
  function luminance(color: string) {
    const hex = color.replace("#", "");
    if (!/^[0-9a-f]{6}$/i.test(hex)) return Number.NaN;
    const channels = [0, 2, 4].map((index) => {
      const value = Number.parseInt(hex.slice(index, index + 2), 16) / 255;
      return value <= 0.03928 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
    });
    return channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
  }
  const first = luminance(foreground);
  const second = luminance(background);
  if (!Number.isFinite(first) || !Number.isFinite(second)) return 0;
  return (Math.max(first, second) + 0.05) / (Math.min(first, second) + 0.05);
}

export const emptyQrFields: QrStudioFields = {
  profile: "",
  url: "https://adawati.adawati.workers.dev",
  text: "",
  phone: "",
  message: "",
  email: "",
  subject: "",
  body: "",
  ssid: "",
  password: "",
  encryption: "WPA",
  hidden: false,
  name: "",
  organization: "",
  website: "",
  address: "",
  latitude: "",
  longitude: "",
  label: "",
  eventTitle: "",
  eventDate: "",
  eventEndDate: "",
  eventLocation: "",
  cardTitle: "",
  cardSubtitle: "",
};

export function normalizeWebUrl(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed.replace(/^\/+/, "")}`;
}

function cleanPhone(value: string) {
  return value.replace(/[^\d+]/g, "").replace(/(?!^)\+/g, "");
}

function escapeStructuredValue(value: string) {
  return value.replace(/\\/g, "\\\\").replace(/\r?\n/g, "\\n").replace(/([;,:"])/g, "\\$1");
}

function compactDate(value: string) {
  return value.replace(/-/g, "");
}

export function buildPlatformPayload(platformValue: QrPlatform, rawValue: string, message = "") {
  const raw = rawValue.trim();
  if (!raw) return "";
  if (/^https?:\/\//i.test(raw)) return raw;
  if (platformValue.input === "url") return normalizeWebUrl(raw);
  if (platformValue.input === "place") return `${platformValue.prefix}${encodeURIComponent(raw)}`;
  if (platformValue.input === "phone") {
    const phone = cleanPhone(raw).replace(/^\+/, "");
    if (!phone) return "";
    if (platformValue.id === "whatsapp") {
      return `${platformValue.prefix}${phone}${message.trim() ? `?text=${encodeURIComponent(message.trim())}` : ""}`;
    }
    return `${platformValue.prefix}${encodeURIComponent(phone)}`;
  }
  if (/^[^\s/]+\.[a-z]{2,}(?:\/|$)/i.test(raw)) return normalizeWebUrl(raw);
  const handle = raw.replace(/^@/, "").replace(/^\/+|\/+$/g, "");
  if (!handle) return "";
  if (platformValue.id === "bandcamp" || platformValue.id === "substack") {
    return `https://${encodeURIComponent(handle)}${platformValue.prefix}`;
  }
  return `${platformValue.prefix}${encodeURIComponent(handle)}`;
}

export function buildQrPayload(
  purpose: QrPurposeId,
  fields: QrStudioFields,
  platformValue?: QrPlatform,
) {
  const phone = cleanPhone(fields.phone);
  if (purpose === "platform") {
    return platformValue ? buildPlatformPayload(platformValue, fields.profile, fields.message) : "";
  }
  if (purpose === "website") return normalizeWebUrl(fields.url);
  if (purpose === "text") return fields.text.trim();
  if (purpose === "sms") {
    return phone && fields.message.trim() ? `SMSTO:${phone}:${fields.message.trim()}` : "";
  }
  if (purpose === "email") {
    if (!fields.email.trim()) return "";
    const query = new URLSearchParams();
    if (fields.subject.trim()) query.set("subject", fields.subject.trim());
    if (fields.body.trim()) query.set("body", fields.body.trim());
    return `mailto:${fields.email.trim()}${query.size ? `?${query.toString()}` : ""}`;
  }
  if (purpose === "phone") return phone ? `tel:${phone}` : "";
  if (purpose === "wifi") {
    return fields.ssid.trim()
      ? `WIFI:T:${fields.encryption};S:${escapeStructuredValue(fields.ssid.trim())};P:${escapeStructuredValue(fields.password)};H:${fields.hidden ? "true" : "false"};;`
      : "";
  }
  if (purpose === "contact") {
    return fields.name.trim()
      ? [
          "BEGIN:VCARD",
          "VERSION:3.0",
          `FN:${escapeStructuredValue(fields.name.trim())}`,
          `ORG:${escapeStructuredValue(fields.organization.trim())}`,
          `TEL:${phone}`,
          `EMAIL:${fields.email.trim()}`,
          `URL:${normalizeWebUrl(fields.website)}`,
          `ADR:;;${escapeStructuredValue(fields.address.trim())};;;;`,
          "END:VCARD",
        ].join("\n")
      : "";
  }
  if (purpose === "location") {
    const latitude = Number(fields.latitude);
    const longitude = Number(fields.longitude);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) return "";
    return `geo:${latitude},${longitude}?q=${latitude},${longitude}(${encodeURIComponent(fields.label.trim())})`;
  }
  if (purpose === "event") {
    const start = fields.eventDate;
    const end = fields.eventEndDate || start;
    if (!fields.eventTitle.trim() || !start || end < start) return "";
    return [
      "BEGIN:VEVENT",
      `SUMMARY:${escapeStructuredValue(fields.eventTitle.trim())}`,
      `DTSTART:${compactDate(start)}T000000`,
      `DTEND:${compactDate(end)}T000000`,
      `LOCATION:${escapeStructuredValue(fields.eventLocation.trim())}`,
      "END:VEVENT",
    ].join("\n");
  }
  return "";
}
