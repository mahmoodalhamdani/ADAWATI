/* eslint-disable @next/next/no-img-element */
"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import dynamic from "next/dynamic";
import QRCode from "qrcode";
import { Icon } from "./Icon";
import { CustomSelect } from "./CustomSelect";
import { ModernDatePicker } from "./ModernDatePicker";
import {
  additionalToolSlugs,
  formulaToolSlugs,
  pdfToolSlugs,
  printDesignToolSlugs,
  priorityToolSlugs,
} from "@/lib/workspace-routing";
import { FileUploadZone } from "./FileUploadZone";
import { useLocale } from "./LocaleProvider";
import { copyWithFeedback } from "@/lib/copy-feedback";
import { cleanText } from "@/lib/text-cleaner";
import { buildLocalDraft } from "@/lib/local-writer";
import { jsonErrorDetails } from "@/lib/json-tools";
import {
  addWorkDays,
  average,
  billShare,
  dateDifference,
  discountFromFinalPrice,
  discountTotal,
  percentageOf,
  percentageChange,
  parseNumberList,
  preciseAge,
  randomIntegerInclusive,
  savingsPlan,
  studyPlan,
  weightedAverage,
  workDaysInclusive,
} from "@/lib/tool-calculations";

const AdditionalToolWorkspace = dynamic(() =>
  import("./AdditionalToolWorkspaces").then(
    (module) => module.AdditionalToolWorkspace,
  ),
);
const PriorityToolWorkspace = dynamic(() =>
  import("./PriorityToolWorkspaces").then(
    (module) => module.PriorityToolWorkspace,
  ),
);
const FormulaToolWorkspace = dynamic(() =>
  import("./FormulaToolWorkspaces").then(
    (module) => module.FormulaToolWorkspace,
  ),
);
const PdfToolWorkspace = dynamic(() =>
  import("./PdfToolWorkspaces").then((module) => module.PdfToolWorkspace),
);
const PrintDesignWorkspace = dynamic(() =>
  import("./PrintDesignWorkspaces").then(
    (module) => module.PrintDesignWorkspace,
  ),
);
const AdvancedQrStudio = dynamic(() =>
  import("./QrStudio").then((module) => module.QrStudio),
);
const TaskPlannerWorkspace = dynamic(() =>
  import("./TaskPlannerWorkspace").then(
    (module) => module.TaskPlannerWorkspace,
  ),
);

function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  window.dispatchEvent(new CustomEvent("minjaz-download-feedback"));
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function Result({ children }: { children: React.ReactNode }) {
  return <div className="result-box">{children}</div>;
}

function ImageWorkspace({ slug }: { slug: string }) {
  const { t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [quality, setQuality] = useState(78);
  const [width, setWidth] = useState(1200);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{
    url: string;
    blob: Blob;
    before: number;
  } | null>(null);
  const [error, setError] = useState("");
  useEffect(
    () => () => {
      if (preview) URL.revokeObjectURL(preview);
      if (result) URL.revokeObjectURL(result.url);
    },
    [preview, result],
  );
  function choose(next: File | null) {
    setError("");
    if (!next) return;
    if (!next.type.startsWith("image/")) {
      setError(t("اختر ملف صورة صالحاً", "Choose a valid image file"));
      return;
    }
    if (preview) URL.revokeObjectURL(preview);
    setFile(next);
    setPreview(URL.createObjectURL(next));
    setResult(null);
  }
  async function process() {
    if (!file) return;
    setBusy(true);
    try {
      setError("");
      const bitmap = await createImageBitmap(file);
      const ratio =
        slug !== "jpg-to-png" ? Math.min(1, width / bitmap.width) : 1;
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(bitmap.width * ratio));
      canvas.height = Math.max(1, Math.round(bitmap.height * ratio));
      canvas
        .getContext("2d")!
        .drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      const type =
        slug === "jpg-to-png"
          ? "image/png"
          : file.type === "image/png" && slug === "image-compressor"
            ? "image/webp"
            : file.type;
      const blob = await new Promise<Blob>((resolve, reject) =>
        canvas.toBlob(
          (value) =>
            value
              ? resolve(value)
              : reject(
                  new Error(
                    t("تعذر إنشاء الصورة", "Could not create the image"),
                  ),
                ),
          type,
          quality / 100,
        ),
      );
      setResult({ url: URL.createObjectURL(blob), blob, before: file.size });
      bitmap.close();
    } catch {
      setError(
        t(
          "تعذر قراءة الصورة أو معالجتها تحقق من أن الملف سليم",
          "The image could not be read or processed Make sure the file is valid",
        ),
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="workspace-stack">
      <FileUploadZone
        files={file ? [file] : []}
        onFiles={(next) => choose(next[0] || null)}
        accept="image/jpeg,image/png,image/webp"
        icon="image"
        title={t("اختر صورة أو اسحبها هنا", "Choose an image or drag it here")}
        helper={t(
          "JPG أو PNG أو WebP — الحد المقترح 20MB",
          "JPG, PNG, or WebP — recommended limit 20MB",
        )}
      />
      {file && (
        <div className="workspace-controls">
          {slug === "image-compressor" && (
            <label className="range-field">
              <span>{t(`الجودة: ${quality}%`, `Quality: ${quality}%`)}</span>
              <input
                type="range"
                min="20"
                max="100"
                value={quality}
                onChange={(e) => setQuality(+e.target.value)}
              />
            </label>
          )}
          {["image-compressor", "image-resizer"].includes(slug) && (
            <label className="range-field">
              <span>
                {t(`العرض الأقصى: ${width}px`, `Maximum width: ${width}px`)}
              </span>
              <input
                type="range"
                min="160"
                max="3000"
                value={width}
                onChange={(e) => setWidth(+e.target.value)}
              />
            </label>
          )}
          <button className="primary-button" onClick={process} disabled={busy}>
            {busy
              ? t("جاري المعالجة...", "Processing...")
              : slug === "jpg-to-png"
                ? t("تحويل إلى PNG", "Convert to PNG")
                : slug === "image-resizer"
                  ? t("تغيير المقاس", "Resize image")
                  : t("تنظيف وضغط الصورة", "Clean and compress image")}
          </button>
        </div>
      )}
      {error && <div className="error-notice">{error}</div>}
      {preview && (
        <div className="image-preview">
          <img
            src={result?.url || preview}
            alt={t("معاينة الصورة", "Image preview")}
          />
        </div>
      )}
      {result && (
        <Result>
          <div>
            <strong>{t("اكتملت المعالجة", "Processing complete")}</strong>
            <span>
              {(result.before / 1024).toFixed(0)} KB ←{" "}
              {(result.blob.size / 1024).toFixed(0)} KB
            </span>
          </div>
          <button
            className="primary-button"
            onClick={() =>
              downloadBlob(
                result.blob,
                `adawati-${file?.name.replace(/\.[^.]+$/, "")}.${result.blob.type.split("/")[1] || "png"}`,
              )
            }
          >
            <Icon name="download" size={18} />{" "}
            {t("تنزيل الصورة", "Download image")}
          </button>
        </Result>
      )}
      {slug === "image-compressor" && (
        <p className="workspace-tip">
          <Icon name="shield" size={18} />
          {t(
            "إعادة إنشاء الصورة داخل المتصفح تزيل بيانات Metadata المرفقة مع تطبيق الضغط وتغيير المقاس",
            "Recreating the image in your browser removes attached metadata while applying compression and resizing",
          )}
        </p>
      )}
    </div>
  );
}

function PdfWorkspace({ slug }: { slug: string }) {
  const { t } = useLocale();
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [output, setOutput] = useState<{ blob: Blob; name: string } | null>(
    null,
  );
  async function process() {
    if (!files.length) return;
    setBusy(true);
    setMessage("");
    setOutput(null);
    try {
      const { imagesToPdfDocuments, mergePdfDocuments } =
        await import("@/lib/pdf-tools");
      const bytes =
        slug === "pdf-merge"
          ? await mergePdfDocuments(
              await Promise.all(files.map((file) => file.arrayBuffer())),
            )
          : await imagesToPdfDocuments(
              await Promise.all(
                files.map(async (file) => ({
                  bytes: await file.arrayBuffer(),
                  type: file.type,
                })),
              ),
            );
      const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
      const name =
        slug === "pdf-merge" ? "adawati-merged.pdf" : "adawati-images.pdf";
      setOutput({ blob, name });
      downloadBlob(blob, name);
      setMessage(
        t(
          "تم إنشاء الملف وتنزيله بنجاح.",
          "The file was created and downloaded successfully.",
        ),
      );
    } catch {
      setMessage(
        t(
          "تعذر معالجة أحد الملفات. تأكد من أن الملفات سليمة وغير محمية بكلمة مرور.",
          "A file could not be processed. Make sure the files are valid and not password protected.",
        ),
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="workspace-stack">
      <FileUploadZone
        files={files}
        onFiles={(next) => {
          setFiles(next);
          setOutput(null);
          setMessage("");
        }}
        multiple
        accept={
          slug === "pdf-merge" ? "application/pdf" : "image/jpeg,image/png"
        }
        icon={slug === "pdf-merge" ? "file" : "image"}
        title={
          slug === "pdf-merge"
            ? t("اختر ملفات PDF", "Choose PDF files")
            : t("اختر الصور", "Choose images")
        }
        helper={t(
          "تتم المعالجة داخل متصفحك ولا تُرسل الملفات إلى الخادم.",
          "Files are processed in your browser and are not uploaded to the server.",
        )}
      />
      {files.length > 0 && (
        <div className="selected-files">
          {files.map((file, index) => (
            <div key={`${file.name}-${index}`}>
              <Icon name={slug === "pdf-merge" ? "file" : "image"} size={18} />
              <span>{file.name}</span>
              <small>{(file.size / 1024 / 1024).toFixed(2)} MB</small>
            </div>
          ))}
        </div>
      )}
      <button
        className="primary-button"
        onClick={process}
        disabled={busy || !files.length}
      >
        {busy
          ? t("جاري تجهيز الملف...", "Preparing file...")
          : slug === "pdf-merge"
            ? t("دمج وتنزيل PDF", "Merge and download PDF")
            : t("تحويل الصور إلى PDF", "Convert images to PDF")}
      </button>
      {message && <div className="notice">{message}</div>}
      {output && (
        <div className="ready-download" role="status">
          <span>
            <Icon name="check" size={18} />
            {t("ملف PDF جاهز", "PDF file ready")}
          </span>
          <button
            type="button"
            className="primary-button"
            onClick={() => downloadBlob(output.blob, output.name)}
          >
            <Icon name="download" size={18} />
            {t("تحميل الملف", "Download file")}
          </button>
        </div>
      )}
    </div>
  );
}

function TextWorkspace({ slug }: { slug: string }) {
  const { t } = useLocale();
  const [value, setValue] = useState("");
  const [result, setResult] = useState("");
  const [limit, setLimit] = useState(280);
  const counts = useMemo(
    () => ({
      words: value.trim() ? value.trim().split(/\s+/).length : 0,
      chars: value.length,
      sentences: value.trim()
        ? value.split(/[.!؟]+/).filter((item) => item.trim()).length
        : 0,
      paragraphs: value.trim()
        ? value.split(/\n\s*\n/).filter(Boolean).length
        : 0,
    }),
    [value],
  );
  function run(mode = "clean") {
    let next = value;
    if (slug === "text-cleaner") next = cleanText(value);
    if (slug === "case-converter")
      next =
        mode === "upper"
          ? value.toUpperCase()
          : mode === "lower"
            ? value.toLowerCase()
            : value
                .toLowerCase()
                .replace(/\b\w/g, (char) => char.toUpperCase());
    setResult(next);
  }
  const removedCharacters = Math.max(0, value.length - result.length),
    removedLines = Math.max(
      0,
      value.split(/\r?\n/).length - result.split(/\r?\n/).length,
    );
  return (
    <div className="workspace-stack">
      <div className="field">
        <label htmlFor="text-input">{t("أدخل النص", "Enter text")}</label>
        <textarea
          id="text-input"
          value={value}
          onChange={(e) => {
            setValue(e.target.value);
            setResult("");
          }}
          placeholder={t("اكتب أو الصق النص هنا", "Type or paste text here")}
        />
      </div>
      {slug === "word-counter" ? (
        <>
          <div className="metric-grid">
            <div>
              <strong>{counts.words}</strong>
              <span>{t("كلمة", "Words")}</span>
            </div>
            <div>
              <strong>{counts.chars}</strong>
              <span>{t("حرف", "Characters")}</span>
            </div>
            <div>
              <strong>{counts.sentences}</strong>
              <span>{t("جملة", "Sentences")}</span>
            </div>
            <div>
              <strong>{counts.paragraphs}</strong>
              <span>{t("فقرة", "Paragraphs")}</span>
            </div>
          </div>
          <div className="field">
            <label>{t("حد المنصة", "Platform limit")}</label>
            <CustomSelect
              value={String(limit)}
              onChange={(next) => setLimit(Number(next))}
              label={t("اختر الحد", "Choose limit")}
              options={[
                { value: "280", label: "X / Twitter — 280" },
                { value: "2200", label: "Instagram — 2200" },
                {
                  value: "5000",
                  label: t("نص طويل — 5000", "Long text — 5000"),
                },
              ]}
            />
          </div>
          <div className="platform-limit">
            <i
              style={{
                width: `${Math.min(100, (counts.chars / limit) * 100)}%`,
              }}
            />
            <span>
              {counts.chars <= limit
                ? t(
                    `متبقٍ ${limit - counts.chars} حرف`,
                    ` ${limit - counts.chars} characters left`,
                  )
                : t(
                    `تجاوزت الحد بـ ${counts.chars - limit}`,
                    `Over limit by ${counts.chars - limit}`,
                  )}
            </span>
          </div>
        </>
      ) : (
        <div className="button-row">
          {slug === "case-converter" ? (
            <>
              <button className="secondary-button" onClick={() => run("upper")}>
                UPPERCASE
              </button>
              <button className="secondary-button" onClick={() => run("lower")}>
                lowercase
              </button>
              <button
                className="primary-button"
                onClick={() => run("capitalize")}
              >
                Capitalize
              </button>
            </>
          ) : (
            <button className="primary-button" onClick={() => run()}>
              {t("تنظيف النص", "Clean text")}
            </button>
          )}
        </div>
      )}
      {result && (
        <>
          {slug === "text-cleaner" && (
            <div className="cleaning-summary">
              <Icon name="check" size={19} />
              <span>
                {t(
                  `نُظف النص فقط من الفراغات والتنسيق الزائد دون تغيير كلماته أزيل ${removedCharacters} محرفاً زائداً و${removedLines} سطراً فارغاً`,
                  `Only extra spacing and formatting were removed without changing the words ${removedCharacters} extra characters and ${removedLines} blank lines removed`,
                )}
              </span>
            </div>
          )}
          <div className="field">
            <label>{t("النتيجة", "Result")}</label>
            <textarea readOnly value={result} />
            <button
              className="secondary-button"
              onClick={(event) => copyWithFeedback(result, event.currentTarget)}
            >
              <Icon name="copy" size={18} /> {t("نسخ النتيجة", "Copy result")}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function LocalTextWorkspace() {
  const { locale, t } = useLocale();
  const [idea, setIdea] = useState("");
  const [wordCount, setWordCount] = useState(50);
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  function generate() {
    if (idea.trim().length < 3)
      return setError(t("اكتب فكرة واضحة أولاً.", "Enter a clear idea first."));
    setBusy(true);
    setError("");
    setResult("");
    setResult(buildLocalDraft(idea, wordCount, locale));
    setBusy(false);
  }

  return (
    <div className="workspace-stack ai-writer">
      <div className="ai-badge">
        <Icon name="sparkles" size={18} />
        <span>{t("إنشاء محلي بالكامل", "Fully local creation")}</span>
      </div>
      <div className="field">
        <label htmlFor="ai-idea">
          {t("ماذا تريد أن أكتب؟", "What would you like me to write?")}
        </label>
        <textarea
          id="ai-idea"
          value={idea}
          onChange={(event) => setIdea(event.target.value)}
          maxLength={300}
          placeholder={t(
            "مثال: اكتب لي رسالة صباحية رومانسية، أو مقالاً عن الصداقة",
            "Example: Write a warm morning message, or an article about friendship",
          )}
        />
      </div>
      <label className="range-field word-count-range">
        <span>
          {t("عدد الكلمات", "Word count")}: <strong>{wordCount}</strong>
        </span>
        <input
          type="range"
          min="10"
          max="100"
          step="5"
          value={wordCount}
          onChange={(event) => setWordCount(Number(event.target.value))}
        />
        <small>
          {t("من 10 إلى 100 كلمة", "Choose between 10 and 100 words")}
        </small>
      </label>
      <button className="primary-button" onClick={generate} disabled={busy}>
        {busy
          ? t("جاري كتابة النص...", "Writing...")
          : t("توليد النص", "Generate text")}{" "}
        <Icon name="sparkles" size={18} />
      </button>
      {error && <div className="error-notice">{error}</div>}
      {result && (
        <div className="generated-text-card">
          <div>
            <strong>{t("النص الناتج", "Generated text")}</strong>
            <span>
              {result.trim().split(/\s+/).filter(Boolean).length}{" "}
              {t("كلمة", "words")}
            </span>
          </div>
          <p>{result}</p>
          <button
            className="secondary-button"
            onClick={(event) => copyWithFeedback(result, event.currentTarget)}
          >
            <Icon name="copy" size={18} />
            {t("نسخ النص", "Copy text")}
          </button>
        </div>
      )}
    </div>
  );
}

function DateWorkspace({ slug }: { slug: string }) {
  const { locale, t } = useLocale();
  const [start, setStart] = useState("");
  const [end, setEnd] = useState(new Date().toISOString().slice(0, 10));
  const [result, setResult] = useState<{ value: string; label: string }[]>([]);
  const [error, setError] = useState("");
  const [weekendDays, setWeekendDays] = useState<number[]>([5, 6]);
  const [workMode, setWorkMode] = useState("range");
  const [durationDays, setDurationDays] = useState("10");
  const isAge = slug === "age-calculator";
  const startCopy = isAge
    ? {
        title: t("تاريخ الميلاد", "Date of birth"),
        description: t(
          "اختر يوم وشهر وسنة ميلادك ولن تُحسب أو تظهر أي نتيجة قبل تحديد هذا التاريخ",
          "Choose your birth day, month, and year No result is calculated or shown until you select it",
        ),
      }
    : {
        title: t("تاريخ البداية", "Start date"),
        description:
          slug === "work-days"
            ? t(
                "اختر أول يوم في الفترة التي تريد حساب أيام العمل خلالها",
                "Choose the first day of the period whose workdays you want to count",
              )
            : t(
                "اختر اليوم الذي تبدأ منه الفترة الزمنية",
                "Choose the day where the time period begins",
              ),
      };
  const endCopy = isAge
    ? {
        title: t("تاريخ حساب العمر", "Age calculation date"),
        description: t(
          "يُضبط على اليوم تلقائياً لمعرفة عمرك الحالي، ويمكنك تغييره لمعرفة عمرك في تاريخ سابق أو قادم",
          "This defaults to today for your current age, or you can change it to find your age on another date",
        ),
      }
    : {
        title: t("تاريخ النهاية", "End date"),
        description:
          slug === "work-days"
            ? t(
                "اختر آخر يوم في الفترة، وسنستبعد يومي الجمعة والسبت من أيام العمل",
                "Choose the last day; Friday and Saturday will be excluded from workdays",
              )
            : t(
                "اختر اليوم الذي تنتهي عنده الفترة لعرض الفرق الكامل بين التاريخين",
                "Choose the final day to see the complete difference between both dates",
              ),
      };

  function updateStart(value: string) {
    setStart(value);
    setResult([]);
    setError("");
  }
  function updateEnd(value: string) {
    setEnd(value);
    setResult([]);
    setError("");
  }
  function calculate() {
    setError("");
    if (!start)
      return setError(
        isAge
          ? t("اختر تاريخ الميلاد أولاً.", "Choose your date of birth first.")
          : t("اختر تاريخ البداية أولاً.", "Choose the start date first."),
      );
    if (!end && !(slug === "work-days" && workMode === "duration"))
      return setError(
        t("اختر تاريخ النهاية أولاً.", "Choose the end date first."),
      );
    if (isAge) {
      const age = preciseAge(start, end);
      if (!age)
        return setError(
          t(
            "تاريخ الميلاد يجب أن يسبق تاريخ حساب العمر.",
            "The date of birth must be before the calculation date.",
          ),
        );
      setResult([
        { value: String(age.years), label: t("سنة", "Years") },
        { value: String(age.months), label: t("شهر", "Months") },
        { value: String(age.days), label: t("يوم", "Days") },
        {
          value: age.totalDays.toLocaleString("en-US"),
          label: t("يوم إجمالاً", "Total days"),
        },
        {
          value: (age.totalDays * 24).toLocaleString("en-US"),
          label: t("ساعة إجمالاً", "Total hours"),
        },
        {
          value: (age.totalDays * 24 * 60).toLocaleString("en-US"),
          label: t("دقيقة إجمالاً", "Total minutes"),
        },
        {
          value: (age.totalDays * 24 * 60 * 60).toLocaleString("en-US"),
          label: t("ثانية إجمالاً", "Total seconds"),
        },
        {
          value: String(age.daysToBirthday),
          label: t("يوم لعيد الميلاد القادم", "Days to next birthday"),
        },
      ]);
    } else if (slug === "work-days") {
      if (workMode === "duration") {
        const duration = Number(durationDays);
        const dueDate = addWorkDays(start, duration, weekendDays);
        if (!dueDate)
          return setError(
            t(
              "أدخل عدداً صحيحاً من أيام العمل واترك يوماً واحداً على الأقل غير مستبعد.",
              "Enter a whole number of workdays and leave at least one weekday available.",
            ),
          );
        setResult([
          { value: dueDate, label: t("تاريخ الاستحقاق", "Due date") },
          {
            value: String(duration),
            label: t("أيام عمل مضافة", "Workdays added"),
          },
        ]);
        return;
      }
      const work = workDaysInclusive(start, end, weekendDays);
      if (!work)
        return setError(
          t(
            "تاريخ البداية يجب أن يسبق تاريخ النهاية.",
            "The start date must be before the end date.",
          ),
        );
      setResult([
        { value: String(work.workDays), label: t("يوم عمل", "Work days") },
        {
          value: String(work.calendarDays),
          label: t("يوم تقويمي", "Calendar days"),
        },
      ]);
    } else {
      const difference = dateDifference(start, end);
      if (!difference)
        return setError(
          t(
            "تاريخ البداية يجب أن يسبق تاريخ النهاية.",
            "The start date must be before the end date.",
          ),
        );
      setResult([
        {
          value: difference.totalDays.toLocaleString(
            locale === "en" ? "en-US" : "ar-IQ",
          ),
          label: t("يوم إجمالاً", "Total days"),
        },
        {
          value: `${Math.floor(difference.totalDays / 7)} + ${difference.totalDays % 7}`,
          label: t("أسابيع + أيام", "Weeks + days"),
        },
        {
          value: `${difference.years} / ${difference.months} / ${difference.days}`,
          label: t("سنوات / أشهر / أيام", "Years / months / days"),
        },
      ]);
    }
  }
  const dayNames =
    locale === "en"
      ? ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
      : [
          "الأحد",
          "الاثنين",
          "الثلاثاء",
          "الأربعاء",
          "الخميس",
          "الجمعة",
          "السبت",
        ];
  return (
    <div className="workspace-stack">
      {slug === "work-days" && (
        <div className="field">
          <label>
            {t("طريقة حساب أيام العمل", "Workday calculation mode")}
          </label>
          <CustomSelect
            value={workMode}
            onChange={(value) => {
              setWorkMode(value);
              setResult([]);
              setError("");
            }}
            label={t("طريقة الحساب", "Calculation mode")}
            options={[
              {
                value: "range",
                label: t("حساب نطاق تاريخ", "Count a date range"),
              },
              { value: "duration", label: t("إضافة أيام عمل", "Add workdays") },
            ]}
          />
        </div>
      )}
      <div className="date-card-grid">
        <section className="date-input-card">
          <div className="date-card-copy">
            <span>1</span>
            <div>
              <h3>{startCopy.title}</h3>
              <p>{startCopy.description}</p>
            </div>
          </div>
          <ModernDatePicker
            label={startCopy.title}
            value={start}
            onChange={updateStart}
            allowFuture={!isAge}
          />
        </section>
        {slug === "work-days" && workMode === "duration" ? (
          <section className="date-input-card">
            <div className="date-card-copy">
              <span>2</span>
              <div>
                <h3>{t("عدد أيام العمل", "Number of workdays")}</h3>
                <p>
                  {t(
                    "أدخل المدة المطلوبة وسنحسب تاريخ الاستحقاق مع استبعاد أيام العطلة المحددة.",
                    "Enter the duration to calculate a due date while skipping the selected weekend days.",
                  )}
                </p>
              </div>
            </div>
            <div className="field">
              <label>{t("أيام العمل المراد إضافتها", "Workdays to add")}</label>
              <input
                type="number"
                min="0"
                step="1"
                value={durationDays}
                onChange={(event) => {
                  setDurationDays(event.target.value);
                  setResult([]);
                  setError("");
                }}
              />
            </div>
          </section>
        ) : (
          <section className="date-input-card">
            <div className="date-card-copy">
              <span>2</span>
              <div>
                <h3>{endCopy.title}</h3>
                <p>{endCopy.description}</p>
              </div>
            </div>
            <ModernDatePicker
              label={endCopy.title}
              value={end}
              onChange={updateEnd}
            />
          </section>
        )}
      </div>
      {slug === "work-days" && (
        <div className="weekend-picker">
          <strong>{t("أيام العطلة المستبعدة", "Excluded weekend days")}</strong>
          <div>
            {dayNames.map((name, index) => (
              <button
                type="button"
                key={name}
                className={weekendDays.includes(index) ? "active" : ""}
                onClick={() => {
                  setWeekendDays((current) =>
                    current.includes(index)
                      ? current.filter((day) => day !== index)
                      : [...current, index],
                  );
                  setResult([]);
                }}
              >
                {name}
              </button>
            ))}
          </div>
        </div>
      )}
      <button className="primary-button" onClick={calculate}>
        {t("احسب الآن", "Calculate now")}
      </button>
      {error && <div className="error-notice">{error}</div>}
      {result.length > 0 && (
        <div className="metric-grid">
          {result.map((item, index) => (
            <div key={index}>
              <strong>{item.value}</strong>
              <span>{item.label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

type BillReminder = {
  id: string;
  name: string;
  dueDate: string;
  frequency: "once" | "daily" | "weekly" | "monthly";
  createdAt: number;
};

function BillReminderManager() {
  const { t } = useLocale();
  const storageKey = "minjaz-bill-reminders";
  const [name, setName] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [frequency, setFrequency] = useState<BillReminder["frequency"]>("once");
  const [reminders, setReminders] = useState<BillReminder[]>([]);
  const [ready, setReady] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    let storedReminders: BillReminder[] = [];
    try {
      const stored = JSON.parse(localStorage.getItem(storageKey) || "[]");
      if (Array.isArray(stored)) {
        storedReminders = stored.filter((item): item is BillReminder =>
          Boolean(
            item &&
            typeof item.id === "string" &&
            typeof item.name === "string" &&
            typeof item.dueDate === "string" &&
            ["once", "daily", "weekly", "monthly"].includes(item.frequency),
          ),
        );
      }
    } catch {
      localStorage.removeItem(storageKey);
    }
    queueMicrotask(() => {
      if (cancelled) return;
      setReminders(storedReminders);
      setReady(true);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem(storageKey, JSON.stringify(reminders));
  }, [ready, reminders]);

  const frequencyLabel = (value: BillReminder["frequency"]) =>
    ({
      once: t("مرة واحدة", "Once"),
      daily: t("يومياً", "Daily"),
      weekly: t("أسبوعياً", "Weekly"),
      monthly: t("شهرياً", "Monthly"),
    })[value];

  function saveReminder() {
    const cleanName = name.trim();
    setError("");
    setNotice("");
    if (!cleanName || !dueDate) {
      setError(
        t(
          "اكتب اسم الفاتورة واختر تاريخ الاستحقاق.",
          "Enter the bill name and choose its due date.",
        ),
      );
      return;
    }
    setReminders((current) => [
      ...current,
      {
        id:
          typeof crypto !== "undefined" && crypto.randomUUID
            ? crypto.randomUUID()
            : `${Date.now()}`,
        name: cleanName,
        dueDate,
        frequency,
        createdAt: Date.now(),
      },
    ]);
    setName("");
    setDueDate("");
    setFrequency("once");
    setNotice(
      t(
        "تم حفظ تذكير موعد الفاتورة على هذا الجهاز.",
        "Bill deadline reminder saved on this device.",
      ),
    );
  }

  return (
    <section
      className="panel bill-reminder-workspace"
      aria-labelledby="bill-reminder-title"
    >
      <header>
        <div>
          <h3 id="bill-reminder-title">
            {t("تذكير موعد دفع الفاتورة", "Bill payment deadline reminder")}
          </h3>
          <p>
            {t(
              "أنشئ موعداً محفوظاً محلياً حتى لا تنسى الفاتورة.",
              "Create a locally saved deadline so you do not miss a bill.",
            )}
          </p>
        </div>
      </header>
      <div className="form-grid">
        <div className="field">
          <label htmlFor="bill-reminder-name">
            {t("اسم الفاتورة", "Bill name")}
          </label>
          <input
            id="bill-reminder-name"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder={t(
              "مثال: فاتورة الكهرباء",
              "Example: Electricity bill",
            )}
          />
        </div>
        <div className="field">
          <label htmlFor="bill-reminder-due-date">
            {t("تاريخ الاستحقاق", "Due date")}
          </label>
          <input
            id="bill-reminder-due-date"
            type="date"
            value={dueDate}
            onInput={(event) => setDueDate(event.currentTarget.value)}
            onChange={(event) => setDueDate(event.target.value)}
          />
        </div>
        <div className="field full">
          <label>{t("تكرار التذكير", "Reminder frequency")}</label>
          <CustomSelect
            value={frequency}
            onChange={(value) =>
              setFrequency(value as BillReminder["frequency"])
            }
            label={t("اختر تكرار التذكير", "Choose reminder frequency")}
            options={(
              [
                ["once", t("مرة واحدة", "Once")],
                ["daily", t("يومياً", "Daily")],
                ["weekly", t("أسبوعياً", "Weekly")],
                ["monthly", t("شهرياً", "Monthly")],
              ] as const
            ).map(([value, label]) => ({ value, label }))}
          />
        </div>
      </div>
      <button className="primary-button" type="button" onClick={saveReminder}>
        <Icon name="plus" size={18} />
        {t("حفظ تذكير الفاتورة", "Save bill reminder")}
      </button>
      {notice && (
        <div className="notice" role="status">
          {notice}
        </div>
      )}
      {error && (
        <div className="error-notice" role="alert">
          {error}
        </div>
      )}
      {reminders.length > 0 && (
        <div
          className="task-list-items"
          aria-label={t("تذكيرات الفواتير المحفوظة", "Saved bill reminders")}
        >
          {reminders.map((reminder) => (
            <article key={reminder.id}>
              <div>
                <strong>{reminder.name}</strong>
                <small>
                  {t("الاستحقاق", "Due")}: <bdi>{reminder.dueDate}</bdi> ·{" "}
                  {frequencyLabel(reminder.frequency)}
                </small>
              </div>
              <button
                type="button"
                onClick={() =>
                  setReminders((current) =>
                    current.filter((item) => item.id !== reminder.id),
                  )
                }
                aria-label={t(
                  `حذف تذكير ${reminder.name}`,
                  `Delete reminder ${reminder.name}`,
                )}
              >
                <Icon name="trash" size={18} />
              </button>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

function NumberWorkspace({ slug }: { slug: string }) {
  const { t } = useLocale();
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  const [c, setC] = useState("");
  const [result, setResult] = useState("");
  const [metrics, setMetrics] = useState<{ value: string; label: string }[]>(
    [],
  );
  const [percentageMode, setPercentageMode] = useState("of");
  const [discountMode, setDiscountMode] = useState<"apply" | "price-after">(
    "apply",
  );
  const [currency, setCurrency] = useState("IQD");
  const labels: Record<string, [string, string, string?]> = {
    "percentage-calculator": [
      percentageMode === "change"
        ? t("قيمة البداية", "Starting value")
        : percentageMode === "discount" || percentageMode === "increase"
          ? t("القيمة الأصلية", "Original value")
          : t("القيمة", "Value"),
      percentageMode === "change"
        ? t("قيمة النهاية", "Ending value")
        : t("النسبة %", "Percentage %"),
    ],
    "discount-calculator":
      discountMode === "price-after"
        ? [
            t("السعر الأصلي", "Original price"),
            t("السعر بعد الخصم", "Price after discount"),
            "",
          ]
        : [
            t("السعر الأصلي", "Original price"),
            t("الخصم %", "Discount %"),
            t("الضريبة % اختياري", "Tax % optional"),
          ],
    "average-calculator": [
      t("الأرقام مفصولة بفواصل", "Numbers separated by commas"),
      "",
      "",
    ],
    "value-comparison": [
      t("القيمة الأولى", "First value"),
      t("القيمة الثانية", "Second value"),
    ],
    "gpa-calculator": [
      t("الدرجات مفصولة بفواصل", "Grades separated by commas"),
      t("الساعات مفصولة بفواصل", "Credit hours separated by commas"),
    ],
    "salary-calculator": [
      t("الراتب الصافي", "Net salary"),
      t("نسبة الادخار %", "Savings %"),
    ],
    "savings-calculator": [
      t("الهدف الادخاري", "Savings goal"),
      t("عدد الأشهر", "Number of months"),
      t("المبلغ الحالي", "Current amount"),
    ],
    "bill-splitter": [
      t("قيمة الفاتورة", "Bill amount"),
      t("عدد الأشخاص", "Number of people"),
      t("الإكرامية %", "Tip %"),
    ],
  };
  function calculate() {
    setMetrics([]);
    const x = Number(a),
      y = Number(b),
      z = Number(c || 0);
    if (slug === "percentage-calculator") {
      const valid =
        a.trim() && b.trim() && Number.isFinite(x) && Number.isFinite(y);
      if (!valid)
        return setResult(t("أدخل قيمتين صحيحتين.", "Enter two valid values."));
      if (percentageMode === "change") {
        const change = percentageChange(x, y);
        return setResult(
          change === null
            ? t(
                "يجب ألا تكون قيمة البداية صفراً.",
                "Starting value cannot be zero.",
              )
            : t(
                `نسبة التغيّر: ${change.toFixed(2)}% من ${x} إلى ${y}`,
                `Percentage change: ${change.toFixed(2)}% from ${x} to ${y}`,
              ),
        );
      }
      if (percentageMode === "discount" || percentageMode === "increase") {
        if (y < 0 || y > 100) {
          return setResult(
            t("أدخل نسبة بين 0 و100.", "Enter a percentage between 0 and 100."),
          );
        }
        const adjustment = percentageOf(x, y);
        const adjusted =
          percentageMode === "discount" ? x - adjustment : x + adjustment;
        return setResult(
          percentageMode === "discount"
            ? t(
                `قيمة الخصم: ${adjustment.toFixed(2)} | السعر بعد الخصم: ${adjusted.toFixed(2)}`,
                `Discount amount: ${adjustment.toFixed(2)} | Total after discount: ${adjusted.toFixed(2)}`,
              )
            : t(
                `قيمة الزيادة: ${adjustment.toFixed(2)} | المجموع بعد الزيادة: ${adjusted.toFixed(2)}`,
                `Increase amount: ${adjustment.toFixed(2)} | Total after increase: ${adjusted.toFixed(2)}`,
              ),
        );
      }
      return setResult(
        t(
          `${percentageOf(x, y).toFixed(2)} — وهي ${y}% من ${x}`,
          `${percentageOf(x, y).toFixed(2)} — ${y}% of ${x}`,
        ),
      );
    }
    if (slug === "discount-calculator") {
      if (discountMode === "price-after") {
        const reverseDiscount =
          a.trim() && b.trim() ? discountFromFinalPrice(x, y) : null;
        if (!reverseDiscount) {
          return setResult(
            t(
              "أدخل سعراً أصلياً أكبر من صفر وسعراً بعد الخصم بين صفر والسعر الأصلي.",
              "Enter an original price greater than zero and a price after discount between zero and the original price.",
            ),
          );
        }
        const { saved, discountRate } = reverseDiscount;
        setMetrics([
          {
            value: `${discountRate.toFixed(2)}%`,
            label: t("نسبة الخصم", "Discount rate"),
          },
          {
            value: saved.toFixed(2),
            label: t("المبلغ الموفر", "Amount saved"),
          },
          {
            value: y.toFixed(2),
            label: t("السعر بعد الخصم", "Price after discount"),
          },
        ]);
        return setResult(
          t(
            `نسبة الخصم ${discountRate.toFixed(2)}% | المبلغ الموفر ${saved.toFixed(2)}`,
            `Discount rate ${discountRate.toFixed(2)}% | Amount saved ${saved.toFixed(2)}`,
          ),
        );
      }
      if (
        !a.trim() ||
        !b.trim() ||
        ![x, y, z].every(Number.isFinite) ||
        x < 0 ||
        y < 0 ||
        y > 100 ||
        z < 0
      )
        return setResult(
          t(
            "تحقق من السعر ونسب الخصم والضريبة.",
            "Check the price, discount, and tax values.",
          ),
        );
      const totals = discountTotal(x, y, z);
      setResult(
        t(
          `بعد الخصم ${totals.afterDiscount.toFixed(2)} | الضريبة ${totals.taxAmount.toFixed(2)} | السعر النهائي ${totals.final.toFixed(2)}`,
          `After discount ${totals.afterDiscount.toFixed(2)} | Tax ${totals.taxAmount.toFixed(2)} | Final price ${totals.final.toFixed(2)}`,
        ),
      );
    }
    if (slug === "average-calculator") {
      const numbers = parseNumberList(a);
      const value = average(a);
      if (!numbers || value === null) {
        setResult(t("أدخل أرقاماً صحيحة.", "Enter valid numbers."));
        return;
      }
      const sum = numbers.reduce((total, item) => total + item, 0);
      setResult("");
      setMetrics([
        { value: String(numbers.length), label: t("عدد القيم", "Count") },
        { value: value.toFixed(2), label: t("المتوسط", "Average") },
        { value: sum.toFixed(2), label: t("المجموع", "Sum") },
        {
          value: Math.min(...numbers).toString(),
          label: t("أصغر قيمة", "Minimum"),
        },
        {
          value: Math.max(...numbers).toString(),
          label: t("أكبر قيمة", "Maximum"),
        },
      ]);
      return;
    }
    if (slug === "value-comparison") {
      if (
        !a.trim() ||
        !b.trim() ||
        !Number.isFinite(x) ||
        !Number.isFinite(y)
      ) {
        setResult(t("أدخل قيمتين صحيحتين.", "Enter two valid values."));
        return;
      }
      const difference = x - y;
      const percentageDifference =
        x === 0 && y === 0
          ? 0
          : (Math.abs(difference) / ((Math.abs(x) + Math.abs(y)) / 2)) * 100;
      setResult(
        x === y
          ? t("القيمتان متساويتان.", "Both values are equal.")
          : x > y
            ? t(
                "القيمة الأولى أكبر من القيمة الثانية.",
                "The first value is greater than the second.",
              )
            : t(
                "القيمة الثانية أكبر من القيمة الأولى.",
                "The second value is greater than the first.",
              ),
      );
      setMetrics([
        {
          value: Math.abs(difference).toFixed(2),
          label: t("الفرق المطلق", "Absolute difference"),
        },
        {
          value: `${percentageDifference.toFixed(2)}%`,
          label: t("فرق النسبة", "Percentage difference"),
        },
        {
          value: Math.max(x, y).toString(),
          label: t("القيمة الأكبر", "Greater value"),
        },
        {
          value: Math.min(x, y).toString(),
          label: t("القيمة الأصغر", "Smaller value"),
        },
      ]);
      return;
    }
    if (slug === "gpa-calculator") {
      const value = weightedAverage(a, b);
      setResult(
        value === null
          ? t(
              "أدخل عدداً متساوياً من الدرجات وساعات موجبة.",
              "Enter an equal number of grades and positive credit hours.",
            )
          : t(`المعدل: ${value.toFixed(2)}`, `GPA: ${value.toFixed(2)}`),
      );
    }
    if (slug === "salary-calculator") {
      if (
        !a.trim() ||
        !b.trim() ||
        !Number.isFinite(x) ||
        !Number.isFinite(y) ||
        x < 0 ||
        y < 0 ||
        y > 50
      )
        return setResult(
          t(
            "أدخل راتباً صحيحاً ونسبة ادخار بين 0 و50%.",
            "Enter a valid salary and a savings rate between 0 and 50%.",
          ),
        );
      setResult(
        t(
          `أساسيات 50%: ${(x * 0.5).toFixed(2)} | مرونة ${(x * (0.5 - y / 100)).toFixed(2)} | ادخار ${((x * y) / 100).toFixed(2)}`,
          `Essentials 50%: ${(x * 0.5).toFixed(2)} | Flexible ${(x * (0.5 - y / 100)).toFixed(2)} | Savings ${((x * y) / 100).toFixed(2)}`,
        ),
      );
    }
    if (slug === "savings-calculator") {
      const plan = a.trim() && b.trim() ? savingsPlan(x, y, z) : null;
      setResult(
        plan
          ? t(
              `شهرياً ${plan.monthly.toFixed(2)} | أسبوعياً ${plan.weekly.toFixed(2)} | المتبقي ${plan.remaining.toFixed(2)}`,
              `Monthly ${plan.monthly.toFixed(2)} | Weekly ${plan.weekly.toFixed(2)} | Remaining ${plan.remaining.toFixed(2)}`,
            )
          : t(
              "أدخل هدفاً ومدة صحيحة بالأشهر",
              "Enter a valid goal and number of months",
            ),
      );
    }
    if (slug === "bill-splitter") {
      const share = a.trim() && b.trim() ? billShare(x, y, z) : null;
      setResult(
        share === null
          ? t(
              "أدخل عدداً صحيحاً من الأشخاص.",
              "Enter a valid number of people.",
            )
          : t(
              `حصة كل شخص: ${share.toFixed(2)} ${currency}`,
              `Each person pays: ${share.toFixed(2)} ${currency}`,
            ),
      );
    }
  }
  const current = labels[slug] || [
    t("القيمة الأولى", "First value"),
    t("القيمة الثانية", "Second value"),
  ];
  function reset() {
    setA("");
    setB("");
    setC("");
    setResult("");
    setMetrics([]);
  }
  function updateValue(setter: (value: string) => void, value: string) {
    setter(value);
    setResult("");
    setMetrics([]);
  }
  return (
    <div className="workspace-stack">
      {slug === "percentage-calculator" && (
        <div className="field">
          <label>{t("وضع الحاسبة", "Calculator mode")}</label>
          <CustomSelect
            value={percentageMode}
            onChange={(value) => {
              setPercentageMode(value);
              setA("");
              setB("");
              setResult("");
              setMetrics([]);
            }}
            label={t("اختر طريقة حساب النسبة", "Choose percentage mode")}
            options={[
              {
                value: "of",
                label: t("نسبة من قيمة", "Percentage of a value"),
              },
              { value: "discount", label: t("تطبيق خصم", "Apply a discount") },
              {
                value: "increase",
                label: t("تطبيق زيادة", "Apply an increase"),
              },
              {
                value: "change",
                label: t("نسبة التغيّر", "Percentage change"),
              },
            ]}
          />
        </div>
      )}
      {slug === "discount-calculator" && (
        <div className="field full">
          <label>{t("وضع حاسبة الخصم", "Discount calculator mode")}</label>
          <div
            className="button-row"
            role="group"
            aria-label={t("وضع حاسبة الخصم", "Discount calculator mode")}
          >
            <button
              type="button"
              className={
                discountMode === "apply" ? "primary-button" : "secondary-button"
              }
              aria-pressed={discountMode === "apply"}
              onClick={() => {
                setDiscountMode("apply");
                setA("");
                setB("");
                setC("");
                setResult("");
                setMetrics([]);
              }}
            >
              {t("احسب السعر بعد الخصم", "Calculate price after discount")}
            </button>
            <button
              type="button"
              className={
                discountMode === "price-after"
                  ? "primary-button"
                  : "secondary-button"
              }
              aria-pressed={discountMode === "price-after"}
              onClick={() => {
                setDiscountMode("price-after");
                setA("");
                setB("");
                setC("");
                setResult("");
                setMetrics([]);
              }}
            >
              {t("لديّ السعر بعد الخصم", "I have the price after discount")}
            </button>
          </div>
        </div>
      )}
      {slug === "bill-splitter" && (
        <div className="field">
          <label>{t("العملة", "Currency")}</label>
          <CustomSelect
            value={currency}
            onChange={setCurrency}
            label={t("اختر عملة الفاتورة", "Choose bill currency")}
            options={[
              {
                value: "IQD",
                label: t("دينار عراقي (IQD)", "Iraqi dinar (IQD)"),
              },
              {
                value: "USD",
                label: t("دولار أمريكي (USD)", "US dollar (USD)"),
              },
              { value: "EUR", label: t("يورو (EUR)", "Euro (EUR)") },
              {
                value: "GBP",
                label: t("جنيه إسترليني (GBP)", "British pound (GBP)"),
              },
            ]}
          />
        </div>
      )}
      <div className="form-grid">
        <div className={`field ${slug === "average-calculator" ? "full" : ""}`}>
          <label>{current[0]}</label>
          <input
            value={a}
            onChange={(e) => updateValue(setA, e.target.value)}
            inputMode={
              slug === "average-calculator" || slug === "gpa-calculator"
                ? "text"
                : "decimal"
            }
            placeholder={slug === "average-calculator" ? "10, 15, 20" : "0"}
          />
        </div>
        {current[1] && (
          <div className="field">
            <label>{current[1]}</label>
            <input
              value={b}
              onChange={(e) => updateValue(setB, e.target.value)}
              inputMode={slug === "gpa-calculator" ? "text" : "decimal"}
              placeholder="0"
            />
          </div>
        )}
        {current[2] && (
          <div className="field full">
            <label>{current[2]}</label>
            <input
              value={c}
              onChange={(e) => updateValue(setC, e.target.value)}
              inputMode="decimal"
              placeholder="0"
            />
          </div>
        )}
      </div>
      <div className="button-row">
        <button className="primary-button" onClick={calculate}>
          {t("احسب النتيجة", "Calculate")}
        </button>
        <button className="secondary-button" type="button" onClick={reset}>
          <Icon name="reset" size={18} />
          {t("مسح وإعادة تعيين", "Clear and reset")}
        </button>
      </div>
      {metrics.length > 0 && (
        <div className="metric-grid" role="status" aria-live="polite">
          {metrics.map((item) => (
            <div key={item.label}>
              <strong>{item.value}</strong>
              <span>{item.label}</span>
            </div>
          ))}
        </div>
      )}
      {result && (
        <Result>
          <strong>{result}</strong>
        </Result>
      )}
      {["salary-calculator", "savings-calculator", "bill-splitter"].includes(
        slug,
      ) && (
        <p className="workspace-disclaimer">
          {t(
            "هذه الأداة لأغراض حسابية وتعليمية عامة ولا تمثل استشارة مالية.",
            "This tool is for general calculation and educational purposes and is not financial advice.",
          )}
        </p>
      )}
      {slug === "bill-splitter" && <BillReminderManager />}
    </div>
  );
}

function StudyWorkspace() {
  const { t } = useLocale();
  const [pages, setPages] = useState("");
  const [days, setDays] = useState("");
  const [review, setReview] = useState("");
  const [rest, setRest] = useState("");
  const pagesValue = Number(pages),
    daysValue = Number(days),
    reviewValue = Number(review || 0),
    restValue = Number(rest || 0);
  const plan = studyPlan(pagesValue, daysValue, reviewValue, restValue);
  const ready = plan !== null;
  const studyDays = plan?.activeDays || 0;
  const perDay = plan?.pagesPerDay || 0;
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field">
          <label>{t("عدد الصفحات", "Pages")}</label>
          <input
            type="number"
            inputMode="numeric"
            min="1"
            value={pages}
            placeholder="400"
            onChange={(e) => setPages(e.target.value)}
          />
        </div>
        <div className="field">
          <label>{t("عدد الأيام", "Days")}</label>
          <input
            type="number"
            inputMode="numeric"
            min="1"
            value={days}
            placeholder="10"
            onChange={(e) => setDays(e.target.value)}
          />
        </div>
        <div className="field">
          <label>{t("أيام المراجعة", "Review days")}</label>
          <input
            type="number"
            inputMode="numeric"
            min="0"
            max={Math.max(0, daysValue - 1)}
            value={review}
            placeholder="1"
            onChange={(e) => setReview(e.target.value)}
          />
        </div>
        <div className="field">
          <label>{t("أيام الراحة", "Rest days")}</label>
          <input
            type="number"
            inputMode="numeric"
            min="0"
            max={Math.max(0, daysValue - reviewValue - 1)}
            value={rest}
            placeholder="1"
            onChange={(e) => setRest(e.target.value)}
          />
        </div>
      </div>
      {ready ? (
        <>
          <Result>
            <div>
              <strong>
                {perDay} {t("صفحة يومياً", "pages per day")}
              </strong>
              <span>
                {studyDays} {t("يوم دراسة", "study days")} + {reviewValue}{" "}
                {t("يوم مراجعة", "review days")} + {restValue}{" "}
                {t("راحة", "rest")}
              </span>
            </div>
          </Result>
          <div className="study-plan">
            {Array.from({ length: studyDays }, (_, i) => (
              <div key={i}>
                <span>
                  {t("يوم الدراسة", "Study day")} {i + 1}
                </span>
                <strong>
                  {t(
                    `من صفحة ${i * perDay + 1} إلى ${Math.min(pagesValue, (i + 1) * perDay)}`,
                    `Pages ${i * perDay + 1} to ${Math.min(pagesValue, (i + 1) * perDay)}`,
                  )}
                </strong>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className="empty-result-hint">
          <Icon name="book" size={20} />
          <span>
            {t(
              "اضغط داخل كل مربع واكتب أرقامك لتظهر الخطة مباشرة",
              "Tap each field and type your numbers to build the plan instantly",
            )}
          </span>
        </div>
      )}
      <p className="workspace-tip">
        <Icon name="book" size={18} />
        {t(
          "الأرقام الظاهرة داخل المربعات أمثلة فقط وتُستبدل مباشرة عند الكتابة",
          "Numbers shown inside the fields are examples and are replaced as soon as you type",
        )}
      </p>
      <section className="embedded-task-planner">
        <header>
          <div>
            <h2>{t("مهام خطة الدراسة", "Study plan tasks")}</h2>
            <p>
              {t(
                "أضف مهمة وموعدها ثم علّمها كمكتملة أثناء تنفيذ الخطة.",
                "Add a task and due date, then mark it complete as you follow the plan.",
              )}
            </p>
          </div>
          <Icon name="check" size={24} />
        </header>
        <TaskPlannerWorkspace storageKey="minjaz-study-plan-tasks" />
      </section>
    </div>
  );
}

function PomodoroWorkspace() {
  const { t } = useLocale();
  const [hours, setHours] = useState(0);
  const [minutes, setMinutes] = useState(25);
  const [inputSeconds, setInputSeconds] = useState(0);
  const [seconds, setSeconds] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [error, setError] = useState("");
  const deadline = useRef(0);
  const configured = hours * 3600 + minutes * 60 + inputSeconds;
  useEffect(() => {
    if (!running) return;
    const update = () => {
      const remaining = Math.max(
        0,
        Math.ceil((deadline.current - Date.now()) / 1000),
      );
      setSeconds(remaining);
      if (remaining === 0) {
        setRunning(false);
        setCompleted(true);
        deadline.current = 0;
        try {
          const context = new AudioContext();
          const oscillator = context.createOscillator(),
            gain = context.createGain();
          oscillator.connect(gain);
          gain.connect(context.destination);
          oscillator.frequency.setValueAtTime(880, context.currentTime);
          gain.gain.setValueAtTime(0.08, context.currentTime);
          gain.gain.exponentialRampToValueAtTime(
            0.001,
            context.currentTime + 0.7,
          );
          oscillator.start();
          oscillator.stop(context.currentTime + 0.7);
        } catch {
          /* Audio is an optional enhancement. */
        }
      }
    };
    update();
    const timer = setInterval(update, 250);
    return () => clearInterval(timer);
  }, [running]);
  const value = `${String(Math.floor(seconds / 3600)).padStart(2, "0")}:${String(Math.floor((seconds % 3600) / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  const progress =
    configured > 0 ? Math.max(0, Math.min(1, seconds / configured)) : 0;
  function setDuration(h: number, m: number, s: number) {
    const safeH = Math.min(99, Math.max(0, h)),
      safeM = Math.min(59, Math.max(0, m)),
      safeS = Math.min(59, Math.max(0, s));
    setHours(safeH);
    setMinutes(safeM);
    setInputSeconds(safeS);
    setSeconds(safeH * 3600 + safeM * 60 + safeS);
    setRunning(false);
    setCompleted(false);
    setError("");
    deadline.current = 0;
  }
  function toggle() {
    if (running) {
      setRunning(false);
      deadline.current = 0;
      return;
    }
    const next = seconds > 0 ? seconds : configured;
    if (next <= 0) {
      setError(
        t(
          "حدد ساعة أو دقيقة أو ثانية واحدة على الأقل.",
          "Set at least one hour, minute, or second.",
        ),
      );
      return;
    }
    setCompleted(false);
    setError("");
    setSeconds(next);
    deadline.current = Date.now() + next * 1000;
    setRunning(true);
  }
  function reset() {
    setRunning(false);
    deadline.current = 0;
    setSeconds(configured);
    setCompleted(false);
    setError("");
  }
  return (
    <div className="timer-workspace">
      <div className="timer-presets">
        <button onClick={() => setDuration(0, 25, 0)}>
          25 {t("دقيقة", "min")}
        </button>
        <button onClick={() => setDuration(0, 5, 0)}>
          5 {t("دقائق", "min")}
        </button>
        <button onClick={() => setDuration(0, 15, 0)}>
          15 {t("دقيقة", "min")}
        </button>
      </div>
      <div className="timer-duration-fields">
        <div className="field">
          <label>{t("الساعات", "Hours")}</label>
          <input
            type="number"
            min="0"
            max="99"
            value={hours}
            disabled={running}
            onChange={(event) =>
              setDuration(Number(event.target.value), minutes, inputSeconds)
            }
          />
        </div>
        <span>:</span>
        <div className="field">
          <label>{t("الدقائق", "Minutes")}</label>
          <input
            type="number"
            min="0"
            max="59"
            value={minutes}
            disabled={running}
            onChange={(event) =>
              setDuration(hours, Number(event.target.value), inputSeconds)
            }
          />
        </div>
        <span>:</span>
        <div className="field">
          <label>{t("الثواني", "Seconds")}</label>
          <input
            type="number"
            min="0"
            max="59"
            value={inputSeconds}
            disabled={running}
            onChange={(event) =>
              setDuration(hours, minutes, Number(event.target.value))
            }
          />
        </div>
      </div>
      <div
        className="timer-circle"
        style={{
          background: `conic-gradient(var(--primary) ${progress * 360}deg, #e9effc 0)`,
        }}
      >
        <div className="timer-circle__inner">
          <Icon name={completed ? "check" : "timer"} size={34} />
          <strong>{value}</strong>
          <span>
            {completed
              ? t("انتهى الوقت", "Time is up")
              : running
                ? t("المؤقت يعمل", "Timer running")
                : t("جاهز للبدء", "Ready to start")}
          </span>
        </div>
      </div>
      <div className="button-row">
        <button className="primary-button" onClick={toggle}>
          {running
            ? t("إيقاف مؤقت", "Pause")
            : seconds !== configured && seconds > 0
              ? t("استئناف", "Resume")
              : t("بدء المؤقت", "Start timer")}
        </button>
        <button className="secondary-button" onClick={reset}>
          <Icon name="reset" size={18} /> {t("إعادة ضبط", "Reset")}
        </button>
      </div>
      {completed && (
        <div className="notice success-notice">
          <Icon name="check" size={19} />
          {t(
            "اكتمل المؤقت وتوقف تلقائياً.",
            "The timer finished and stopped automatically.",
          )}
        </div>
      )}
      {error && <div className="error-notice">{error}</div>}
    </div>
  );
}

const qrTypes = [
  { id: "website", ar: "موقع أو رابط", en: "Website", icon: "globe" },
  { id: "text", ar: "نص", en: "Text", icon: "text" },
  { id: "sms", ar: "رسالة SMS", en: "SMS message", icon: "message" },
  { id: "email", ar: "بريد إلكتروني", en: "Email", icon: "message" },
  { id: "phone", ar: "رقم هاتف", en: "Phone", icon: "smartphone" },
  { id: "wifi", ar: "شبكة Wi-Fi", en: "Wi-Fi", icon: "network" },
  { id: "contact", ar: "بطاقة عمل", en: "Business card", icon: "user" },
  { id: "whatsapp", ar: "WhatsApp", en: "WhatsApp", icon: "message" },
  { id: "telegram", ar: "Telegram", en: "Telegram", icon: "message" },
  { id: "social", ar: "حساب اجتماعي", en: "Social profile", icon: "users" },
  { id: "location", ar: "موقع جغرافي", en: "Location", icon: "globe" },
  { id: "event", ar: "موعد أو فعالية", en: "Event", icon: "calendar" },
] as const;

const qrTemplates = [
  ["classic", "كلاسيكي", "Classic", "#071b63", "#ffffff", "#0754e8", "#eef4ff"],
  [
    "midnight",
    "منتصف الليل",
    "Midnight",
    "#f7f9ff",
    "#07101f",
    "#4b8dff",
    "#0d192b",
  ],
  ["emerald", "زمردي", "Emerald", "#073b2a", "#ffffff", "#18a66a", "#eaf9f2"],
  ["violet", "بنفسجي", "Violet", "#39136b", "#ffffff", "#8b5cf6", "#f3efff"],
  ["sunset", "غروب", "Sunset", "#6a1a27", "#fffdf8", "#f97316", "#fff2df"],
  ["ocean", "محيطي", "Ocean", "#063c52", "#ffffff", "#0891b2", "#e8faff"],
  ["rose", "وردي", "Rose", "#6b1738", "#ffffff", "#ec4899", "#fff0f7"],
  ["gold", "ذهبي", "Gold", "#2f2406", "#fffdf6", "#c89b19", "#fff7dc"],
  ["slate", "رصاصي", "Slate", "#1f2937", "#ffffff", "#64748b", "#f1f5f9"],
  ["coral", "مرجاني", "Coral", "#5f1d18", "#ffffff", "#ef6a5b", "#fff0ed"],
  ["forest", "غابة", "Forest", "#17351d", "#ffffff", "#4d9b58", "#edf8ef"],
  ["royal", "ملكي", "Royal", "#20125d", "#ffffff", "#5b4ce3", "#efefff"],
  ["ice", "جليدي", "Ice", "#0d3b50", "#ffffff", "#38bdf8", "#eefbff"],
  ["coffee", "قهوة", "Coffee", "#3b251b", "#fffdf9", "#9a6a4a", "#f8efe8"],
  ["berry", "توتي", "Berry", "#4a174f", "#ffffff", "#b64bc0", "#faeffb"],
  ["lime", "ليموني", "Lime", "#24320b", "#ffffff", "#84b729", "#f5fae9"],
  ["mono", "أحادي", "Mono", "#111111", "#ffffff", "#444444", "#f3f3f3"],
  ["sky", "سماوي", "Sky", "#163d66", "#ffffff", "#4b9cf5", "#edf6ff"],
  ["brick", "قرميدي", "Brick", "#542019", "#fffdfb", "#b75141", "#fff0ec"],
  ["minjaz", "أدواتي", "ADAWATI", "#07184f", "#ffffff", "#08cbd5", "#edfaff"],
] as const;

const qrIcons = [
  ["none", "بدون", "None", ""],
  ["web", "موقع", "Web", "WWW"],
  ["message", "رسالة", "Message", "✉"],
  ["email", "بريد", "Email", "@"],
  ["phone", "هاتف", "Phone", "☎"],
  ["wifi", "Wi-Fi", "Wi-Fi", "WiFi"],
  ["contact", "بطاقة", "Contact", "VC"],
  ["whatsapp", "واتساب", "WhatsApp", "WA"],
  ["telegram", "تلغرام", "Telegram", "TG"],
  ["instagram", "إنستغرام", "Instagram", "IG"],
  ["facebook", "فيسبوك", "Facebook", "f"],
  ["x", "X", "X", "X"],
  ["linkedin", "LinkedIn", "LinkedIn", "in"],
  ["youtube", "YouTube", "YouTube", "▶"],
  ["tiktok", "TikTok", "TikTok", "TT"],
  ["snapchat", "Snapchat", "Snapchat", "SC"],
  ["location", "موقع", "Location", "⌖"],
  ["calendar", "تقويم", "Calendar", "31"],
  ["document", "ملف", "Document", "DOC"],
  ["shop", "متجر", "Shop", "SHOP"],
] as const;

type QrFields = {
  url: string;
  text: string;
  phone: string;
  message: string;
  email: string;
  subject: string;
  body: string;
  ssid: string;
  password: string;
  encryption: string;
  hidden: boolean;
  name: string;
  organization: string;
  website: string;
  address: string;
  username: string;
  platform: string;
  latitude: string;
  longitude: string;
  label: string;
  eventTitle: string;
  eventDate: string;
  eventEndDate: string;
  eventLocation: string;
};

function escapeQrValue(value: string) {
  return value.replace(/([\\;,:\"])/g, "\\$1");
}

function compactDate(value: string) {
  return value.replace(/-/g, "");
}

function roundedRect(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
) {
  const safe = Math.min(radius, width / 2, height / 2);
  context.beginPath();
  context.moveTo(x + safe, y);
  context.arcTo(x + width, y, x + width, y + height, safe);
  context.arcTo(x + width, y + height, x, y + height, safe);
  context.arcTo(x, y + height, x, y, safe);
  context.arcTo(x, y, x + width, y, safe);
  context.closePath();
}

// Kept temporarily as an internal compatibility reference while the routed studio
// is loaded from the dedicated component above.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function QrStudio() {
  const { t, locale } = useLocale();
  const [type, setType] = useState<(typeof qrTypes)[number]["id"]>("website");
  const [templateId, setTemplateId] = useState("minjaz");
  const [iconId, setIconId] = useState("web");
  const [result, setResult] = useState("");
  const [payload, setPayload] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [fields, setFields] = useState<QrFields>({
    url: "https://adawati.adawati.workers.dev",
    text: "",
    phone: "",
    message: "",
    email: "",
    subject: "",
    body: "",
    ssid: "",
    password: "",
    encryption: "WPA",
    hidden: false,
    name: "",
    organization: "",
    website: "",
    address: "",
    username: "",
    platform: "instagram",
    latitude: "",
    longitude: "",
    label: "",
    eventTitle: "",
    eventDate: "",
    eventEndDate: "",
    eventLocation: "",
  });

  function update(key: keyof QrFields, value: string | boolean) {
    setFields((current) => ({ ...current, [key]: value }));
    setResult("");
  }

  function buildPayload() {
    const phone = fields.phone.replace(/[^\d+]/g, "");
    if (type === "website") return fields.url.trim();
    if (type === "text") return fields.text.trim();
    if (type === "sms")
      return phone && fields.message.trim()
        ? `SMSTO:${phone}:${fields.message.trim()}`
        : "";
    if (type === "email")
      return fields.email.trim()
        ? `mailto:${fields.email.trim()}?subject=${encodeURIComponent(fields.subject)}&body=${encodeURIComponent(fields.body)}`
        : "";
    if (type === "phone") return phone ? `tel:${phone}` : "";
    if (type === "wifi")
      return fields.ssid.trim()
        ? `WIFI:T:${fields.encryption};S:${escapeQrValue(fields.ssid.trim())};P:${escapeQrValue(fields.password)};H:${fields.hidden ? "true" : "false"};;`
        : "";
    if (type === "contact")
      return fields.name.trim()
        ? `BEGIN:VCARD\nVERSION:3.0\nFN:${fields.name.trim()}\nORG:${fields.organization.trim()}\nTEL:${phone}\nEMAIL:${fields.email.trim()}\nURL:${fields.website.trim()}\nADR:;;${fields.address.trim()};;;;\nEND:VCARD`
        : "";
    if (type === "whatsapp")
      return phone
        ? `https://wa.me/${phone.replace(/\D/g, "")}${fields.message ? `?text=${encodeURIComponent(fields.message)}` : ""}`
        : "";
    if (type === "telegram")
      return fields.username.trim()
        ? `https://t.me/${fields.username.trim().replace(/^@/, "")}`
        : "";
    if (type === "social") {
      const username = fields.username.trim().replace(/^@/, "");
      const roots: Record<string, string> = {
        instagram: "https://instagram.com/",
        facebook: "https://facebook.com/",
        x: "https://x.com/",
        linkedin: "https://linkedin.com/in/",
        youtube: "https://youtube.com/@",
        tiktok: "https://tiktok.com/@",
        snapchat: "https://snapchat.com/add/",
      };
      return username ? `${roots[fields.platform] || ""}${username}` : "";
    }
    if (type === "location")
      return fields.latitude && fields.longitude
        ? `geo:${fields.latitude},${fields.longitude}?q=${fields.latitude},${fields.longitude}(${encodeURIComponent(fields.label)})`
        : "";
    if (type === "event")
      return fields.eventTitle.trim() && fields.eventDate
        ? `BEGIN:VEVENT\nSUMMARY:${fields.eventTitle.trim()}\nDTSTART:${compactDate(fields.eventDate)}T000000\nDTEND:${compactDate(fields.eventEndDate || fields.eventDate)}T000000\nLOCATION:${fields.eventLocation.trim()}\nEND:VEVENT`
        : "";
    return "";
  }

  async function generate() {
    const nextPayload = buildPayload();
    if (!nextPayload) {
      setError(
        t(
          "أكمل الحقول الأساسية لهذا النوع قبل الإنشاء",
          "Complete the required fields for this type",
        ),
      );
      return;
    }
    setBusy(true);
    setError("");
    setResult("");
    try {
      const template =
        qrTemplates.find((item) => item[0] === templateId) || qrTemplates[0];
      const icon = qrIcons.find((item) => item[0] === iconId) || qrIcons[0];
      const qr = document.createElement("canvas");
      await QRCode.toCanvas(qr, nextPayload, {
        width: 640,
        margin: 2,
        errorCorrectionLevel: "H",
        color: { dark: template[3], light: template[4] },
      });
      const canvas = document.createElement("canvas");
      canvas.width = 900;
      canvas.height = 900;
      const context = canvas.getContext("2d");
      if (!context) throw new Error("canvas");
      const gradient = context.createLinearGradient(0, 0, 900, 900);
      gradient.addColorStop(0, template[6]);
      gradient.addColorStop(1, template[5]);
      context.fillStyle = gradient;
      context.fillRect(0, 0, 900, 900);
      context.shadowColor = "rgba(8, 28, 70, .18)";
      context.shadowBlur = 34;
      context.shadowOffsetY = 16;
      roundedRect(context, 72, 72, 756, 756, 46);
      context.fillStyle = template[4];
      context.fill();
      context.shadowColor = "transparent";
      context.drawImage(qr, 130, 130, 640, 640);
      if (icon[3]) {
        context.beginPath();
        context.arc(450, 450, 58, 0, Math.PI * 2);
        context.fillStyle = template[4];
        context.fill();
        context.lineWidth = 8;
        context.strokeStyle = template[5];
        context.stroke();
        context.fillStyle = template[3];
        context.textAlign = "center";
        context.textBaseline = "middle";
        context.font = `800 ${String(icon[3]).length > 3 ? 24 : 34}px Arial`;
        context.fillText(icon[3], 450, 453);
      }
      context.fillStyle = template[3];
      context.textAlign = "center";
      context.font = "700 18px Arial";
      context.fillText("ADAWATI QR", 450, 854);
      setPayload(nextPayload);
      setResult(canvas.toDataURL("image/png"));
    } catch {
      setError(
        t(
          "تعذر إنشاء QR من البيانات المدخلة",
          "QR could not be generated from the entered data",
        ),
      );
    } finally {
      setBusy(false);
    }
  }

  function input(
    key: keyof QrFields,
    ar: string,
    en: string,
    kind: "text" | "email" | "url" | "date" = "text",
  ) {
    return (
      <div className="field">
        <label>{t(ar, en)}</label>
        <input
          type={kind}
          value={String(fields[key])}
          onChange={(event) => update(key, event.target.value)}
        />
      </div>
    );
  }

  return (
    <div className="workspace-stack qr-studio">
      <section className="qr-stage-section">
        <header>
          <span>1</span>
          <div>
            <h2>{t("اختر وظيفة QR", "Choose QR purpose")}</h2>
            <p>
              {t(
                "كل نوع يعرض حقوله المناسبة فقط",
                "Each type shows only its relevant fields",
              )}
            </p>
          </div>
        </header>
        <div className="qr-type-grid">
          {qrTypes.map((item) => (
            <button
              key={item.id}
              type="button"
              className={type === item.id ? "active" : ""}
              onClick={() => {
                setType(item.id);
                setResult("");
              }}
            >
              <Icon name={item.icon} size={22} />
              <span>{locale === "en" ? item.en : item.ar}</span>
            </button>
          ))}
        </div>
      </section>
      <section className="qr-stage-section">
        <header>
          <span>2</span>
          <div>
            <h2>{t("أدخل البيانات", "Enter details")}</h2>
            <p>
              {t("تبقى البيانات داخل جهازك", "Details stay on your device")}
            </p>
          </div>
        </header>
        <div className="form-grid">
          {type === "website" &&
            input("url", "رابط الموقع", "Website URL", "url")}
          {type === "text" && (
            <div className="field full">
              <label>{t("النص", "Text")}</label>
              <textarea
                value={fields.text}
                onChange={(event) => update("text", event.target.value)}
              />
            </div>
          )}
          {type === "sms" && (
            <>
              {input(
                "phone",
                "رقم الهاتف مع رمز الدولة",
                "Phone with country code",
              )}
              <div className="field full">
                <label>{t("نص الرسالة", "Message")}</label>
                <textarea
                  value={fields.message}
                  onChange={(event) => update("message", event.target.value)}
                />
              </div>
            </>
          )}
          {type === "email" && (
            <>
              {input("email", "البريد الإلكتروني", "Email", "email")}
              {input("subject", "موضوع الرسالة", "Subject")}
              <div className="field full">
                <label>{t("نص البريد", "Email body")}</label>
                <textarea
                  value={fields.body}
                  onChange={(event) => update("body", event.target.value)}
                />
              </div>
            </>
          )}
          {type === "phone" &&
            input(
              "phone",
              "رقم الهاتف مع رمز الدولة",
              "Phone with country code",
            )}
          {type === "wifi" && (
            <>
              {input("ssid", "اسم الشبكة", "Network name")}
              {input("password", "كلمة المرور", "Password")}
              <div className="field">
                <label>{t("نوع الحماية", "Security")}</label>
                <CustomSelect
                  value={fields.encryption}
                  onChange={(value) => update("encryption", value)}
                  label={t("نوع الحماية", "Security")}
                  options={["WPA", "WEP", "nopass"].map((value) => ({
                    value,
                    label: value,
                  }))}
                />
              </div>
              <label className="modern-check">
                <input
                  type="checkbox"
                  checked={fields.hidden}
                  onChange={(event) => update("hidden", event.target.checked)}
                />
                <span>{t("الشبكة مخفية", "Hidden network")}</span>
              </label>
            </>
          )}
          {type === "contact" && (
            <>
              {input("name", "الاسم الكامل", "Full name")}
              {input("organization", "الشركة أو المنصب", "Company or title")}
              {input("phone", "رقم الهاتف", "Phone")}
              {input("email", "البريد", "Email", "email")}
              {input("website", "الموقع", "Website", "url")}
              {input("address", "العنوان", "Address")}
            </>
          )}
          {type === "whatsapp" && (
            <>
              {input("phone", "رقم WhatsApp مع رمز الدولة", "WhatsApp number")}
              <div className="field full">
                <label>
                  {t("رسالة جاهزة اختيارية", "Optional prepared message")}
                </label>
                <textarea
                  value={fields.message}
                  onChange={(event) => update("message", event.target.value)}
                />
              </div>
            </>
          )}
          {type === "telegram" &&
            input("username", "معرف Telegram", "Telegram username")}
          {type === "social" && (
            <>
              <div className="field">
                <label>{t("المنصة", "Platform")}</label>
                <CustomSelect
                  value={fields.platform}
                  onChange={(value) => update("platform", value)}
                  label={t("المنصة", "Platform")}
                  options={[
                    "instagram",
                    "facebook",
                    "x",
                    "linkedin",
                    "youtube",
                    "tiktok",
                    "snapchat",
                  ].map((value) => ({ value, label: value }))}
                />
              </div>
              {input("username", "المعرف أو اسم الحساب", "Username")}
            </>
          )}
          {type === "location" && (
            <>
              {input("latitude", "خط العرض", "Latitude")}
              {input("longitude", "خط الطول", "Longitude")}
              {input("label", "اسم المكان", "Place label")}
            </>
          )}
          {type === "event" && (
            <>
              {input("eventTitle", "اسم الموعد", "Event title")}
              {input("eventLocation", "المكان", "Location")}
              {input(
                "eventDate",
                "تاريخ البداية — 00:00",
                "Start date — 00:00",
                "date",
              )}
              {input(
                "eventEndDate",
                "تاريخ النهاية — 00:00",
                "End date — 00:00",
                "date",
              )}
            </>
          )}
        </div>
      </section>
      <section className="qr-stage-section">
        <header>
          <span>3</span>
          <div>
            <h2>{t("اختر الهوية البصرية", "Choose visual identity")}</h2>
            <p>
              {t(
                "20 تصميماً و20 أيقونة جاهزة",
                "20 designs and 20 ready icons",
              )}
            </p>
          </div>
        </header>
        <div className="qr-template-grid">
          {qrTemplates.map((item) => (
            <button
              key={item[0]}
              type="button"
              className={templateId === item[0] ? "active" : ""}
              onClick={() => {
                setTemplateId(item[0]);
                setResult("");
              }}
              style={
                {
                  "--qr-dark": item[3],
                  "--qr-light": item[4],
                  "--qr-accent": item[5],
                  "--qr-frame": item[6],
                } as React.CSSProperties
              }
            >
              <i />
              <span>{locale === "en" ? item[2] : item[1]}</span>
            </button>
          ))}
        </div>
        <div className="qr-icon-grid">
          {qrIcons.map((item) => (
            <button
              key={item[0]}
              type="button"
              className={iconId === item[0] ? "active" : ""}
              onClick={() => {
                setIconId(item[0]);
                setResult("");
              }}
            >
              <b>{item[3] || "×"}</b>
              <span>{locale === "en" ? item[2] : item[1]}</span>
            </button>
          ))}
        </div>
      </section>
      <button
        className="primary-button qr-generate-button"
        type="button"
        disabled={busy}
        onClick={generate}
      >
        {busy
          ? t("جاري الإنشاء...", "Generating...")
          : t("إنشاء QR بالتصميم المختار", "Generate styled QR")}
      </button>
      {error && <div className="error-notice">{error}</div>}
      {result && (
        <div className="qr-studio-result">
          <img src={result} alt={t("QR المصمم", "Styled QR")} />
          <div>
            <button
              className="primary-button"
              type="button"
              onClick={() => {
                const anchor = document.createElement("a");
                anchor.href = result;
                anchor.download = `adawati-qr-${templateId}.png`;
                anchor.click();
                window.dispatchEvent(
                  new CustomEvent("minjaz-download-feedback"),
                );
              }}
            >
              <Icon name="download" size={18} />{" "}
              {t("تحميل PNG", "Download PNG")}
            </button>
            <button
              className="secondary-button"
              type="button"
              onClick={(event) =>
                copyWithFeedback(payload, event.currentTarget)
              }
            >
              <Icon name="copy" size={18} />{" "}
              {t("نسخ محتوى QR", "Copy QR content")}
            </button>
          </div>
        </div>
      )}
      <p className="workspace-tip">
        <Icon name="shield" size={18} />
        {t(
          "يتم إنشاء الرمز والتصميم داخل جهازك، ولا تُرسل البيانات إلى الخادم",
          "The code and design are generated on your device and no data is sent to a server",
        )}
      </p>
    </div>
  );
}

function InternetWorkspace({ slug }: { slug: string }) {
  const { t } = useLocale();
  const [value, setValue] = useState("");
  const [second, setSecond] = useState("");
  const [result, setResult] = useState("");
  const [error, setError] = useState("");
  async function run(mode = "encode") {
    setError("");
    setResult("");
    try {
      if (slug === "whatsapp-link") {
        const phone = value.replace(/\D/g, "");
        if (!phone) throw new Error("phone");
        setResult(
          `https://wa.me/${phone}${second ? `?text=${encodeURIComponent(second)}` : ""}`,
        );
      }
      if (slug === "url-encoder") {
        if (!value) throw new Error("empty");
        setResult(
          mode === "decode"
            ? decodeURIComponent(value)
            : encodeURIComponent(value),
        );
      }
      if (slug === "base64") {
        if (!value) throw new Error("empty");
        setResult(
          mode === "decode"
            ? decodeURIComponent(escape(atob(value)))
            : btoa(unescape(encodeURIComponent(value))),
        );
      }
      if (slug === "json-formatter") {
        if (!value.trim()) throw new Error("empty");
        setResult(JSON.stringify(JSON.parse(value), null, 2));
      }
      if (slug === "uuid-generator") setResult(crypto.randomUUID());
    } catch (caught) {
      if (slug === "json-formatter" && caught instanceof SyntaxError) {
        const details = jsonErrorDetails(value, caught);
        setError(
          t(
            `JSON غير صالح — السطر ${details.line}، العمود ${details.column}. السبب: ${details.reason}`,
            `Invalid JSON — line ${details.line}, column ${details.column}. Reason: ${details.reason}`,
          ),
        );
        return;
      }
      setError(
        t(
          "تعذر تنفيذ العملية تحقق من البيانات المدخلة",
          "The operation failed Check your input",
        ),
      );
    }
  }
  const isUuid = slug === "uuid-generator";
  return (
    <div className="workspace-stack">
      {!isUuid && (
        <div className="field">
          <label>
            {slug === "whatsapp-link"
              ? t("رقم الهاتف مع رمز الدولة", "Phone number with country code")
              : t("أدخل المحتوى", "Enter content")}
          </label>
          <textarea
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={
              slug === "whatsapp-link"
                ? t("مثال: 9647700000000", "Example: 12025550123")
                : t("اكتب هنا", "Type here")
            }
          />
        </div>
      )}
      {slug === "whatsapp-link" && (
        <div className="field">
          <label>{t("رسالة جاهزة اختياري", "Prepared message optional")}</label>
          <textarea
            value={second}
            onChange={(e) => setSecond(e.target.value)}
            placeholder={t("اكتب هنا", "Type here")}
          />
        </div>
      )}
      <div className="button-row">
        {["url-encoder", "base64"].includes(slug) ? (
          <>
            <button className="primary-button" onClick={() => run("encode")}>
              {t("ترميز", "Encode")}
            </button>
            <button className="secondary-button" onClick={() => run("decode")}>
              {t("فك الترميز", "Decode")}
            </button>
          </>
        ) : (
          <button className="primary-button" onClick={() => run()}>
            {isUuid
              ? t("توليد UUID جديد", "Generate new UUID")
              : slug === "json-formatter"
                ? t("تنسيق وفحص", "Format and validate")
                : t("إنشاء الرابط", "Create link")}
          </button>
        )}
      </div>
      {error && <div className="error-notice">{error}</div>}
      {result && (
        <Result>
          <code>{result}</code>
          <button
            className="secondary-button"
            onClick={(event) => copyWithFeedback(result, event.currentTarget)}
          >
            <Icon name="copy" size={18} /> {t("نسخ", "Copy")}
          </button>
        </Result>
      )}
    </div>
  );
}

function PasswordWorkspace({ slug }: { slug: string }) {
  const { t } = useLocale();
  const [length, setLength] = useState(18);
  const [value, setValue] = useState("");
  function generate() {
    const pools = [
      "ABCDEFGHJKLMNPQRSTUVWXYZ",
      "abcdefghijkmnopqrstuvwxyz",
      "23456789",
      "!@#$%&*",
    ];
    const chars = pools.join("");
    const pick = (pool: string) =>
      pool[crypto.getRandomValues(new Uint32Array(1))[0] % pool.length];
    const output = [
      ...pools.map(pick),
      ...Array.from({ length: Math.max(0, length - pools.length) }, () =>
        pick(chars),
      ),
    ];
    for (let index = output.length - 1; index > 0; index -= 1) {
      const target =
        crypto.getRandomValues(new Uint32Array(1))[0] % (index + 1);
      [output[index], output[target]] = [output[target], output[index]];
    }
    setValue(output.join(""));
  }
  const score = Math.min(
    4,
    [
      value.length >= 12,
      /[A-Z]/.test(value),
      /[0-9]/.test(value),
      /[^\w]/.test(value),
    ].filter(Boolean).length,
  );
  const strength = [
    t("ضعيفة جداً", "Very weak"),
    t("ضعيفة", "Weak"),
    t("متوسطة", "Medium"),
    t("قوية", "Strong"),
    t("قوية جداً", "Very strong"),
  ][score];
  return (
    <div className="workspace-stack">
      {slug === "password-generator" ? (
        <>
          <label className="range-field">
            <span>
              {t("الطول", "Length")}: {length} {t("حرفاً", "characters")}
            </span>
            <input
              type="range"
              min="8"
              max="64"
              value={length}
              onChange={(e) => setLength(+e.target.value)}
            />
          </label>
          <button className="primary-button" onClick={generate}>
            {t("توليد كلمة مرور قوية", "Generate a strong password")}
          </button>
        </>
      ) : (
        <div className="field">
          <label>{t("كلمة المرور", "Password")}</label>
          <input
            type="password"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={t(
              "اكتب كلمة المرور لفحصها محلياً",
              "Enter a password to check it locally",
            )}
          />
        </div>
      )}
      {value && (
        <Result>
          <code>
            {slug === "password-generator"
              ? value
              : t(
                  `قوة كلمة المرور: ${strength}`,
                  `Password strength: ${strength}`,
                )}
          </code>
          <div className="strength-bar">
            <i style={{ width: `${score * 25}%` }} />
          </div>
          {slug === "password-generator" && (
            <button
              className="secondary-button"
              onClick={(event) => copyWithFeedback(value, event.currentTarget)}
            >
              <Icon name="copy" size={18} /> {t("نسخ", "Copy")}
            </button>
          )}
        </Result>
      )}
      <p className="privacy-note">
        <Icon name="shield" size={18} />{" "}
        {t(
          "لا تغادر كلمة المرور جهازك ولا يتم حفظها.",
          "Your password never leaves your device and is not stored.",
        )}
      </p>
    </div>
  );
}

function RandomWorkspace({ slug }: { slug: string }) {
  const { t } = useLocale();
  const [value, setValue] = useState("");
  const [amount, setAmount] = useState(2);
  const [result, setResult] = useState("");
  function secureIndex(max: number) {
    if (max <= 1) return 0;
    const range = 0x1_0000_0000 - (0x1_0000_0000 % max);
    let value = 0;
    do {
      value = crypto.getRandomValues(new Uint32Array(1))[0];
    } while (value >= range);
    return value % max;
  }
  function run() {
    if (slug === "random-number") {
      const parts = value
        .split(/[,،\s]+/)
        .map((item) => item.trim())
        .filter(Boolean)
        .map(Number);
      const generated =
        parts.length >= 2
          ? randomIntegerInclusive(
              parts[0],
              parts[1],
              () =>
                crypto.getRandomValues(new Uint32Array(1))[0] / 0x1_0000_0000,
            )
          : null;
      setResult(
        generated === null
          ? t(
              "أدخل حدين صحيحين مثل 0, 100",
              "Enter two valid limits such as 0, 100",
            )
          : String(generated),
      );
      return;
    }
    if (slug === "random-string") {
      const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
      const safeAmount = Math.min(128, Math.max(1, Math.trunc(amount) || 1));
      const bytes = crypto.getRandomValues(new Uint32Array(safeAmount));
      setResult(Array.from(bytes, (n) => chars[n % chars.length]).join(""));
      return;
    }
    const items = value
      .split(/\n|،|,/)
      .map((s) => s.trim())
      .filter(Boolean);
    if (slug === "random-picker")
      setResult(
        items.length
          ? items[secureIndex(items.length)]
          : t("أدخل عنصراً واحداً على الأقل", "Enter at least one item"),
      );
    else {
      const shuffled = [...items];
      for (let index = shuffled.length - 1; index > 0; index--) {
        const target = secureIndex(index + 1);
        [shuffled[index], shuffled[target]] = [
          shuffled[target],
          shuffled[index],
        ];
      }
      const teamCount = Math.min(20, Math.max(2, Math.trunc(amount) || 2));
      const teams = Array.from({ length: teamCount }, () => [] as string[]);
      shuffled.forEach((x, i) => teams[i % teamCount].push(x));
      setResult(
        items.length >= 2
          ? teams
              .map(
                (team, i) =>
                  `${t("الفريق", "Team")} ${i + 1}: ${team.join(t("، ", ", ")) || t("—", "—")}`,
              )
              .join("\n")
          : t("أدخل اسمين على الأقل", "Enter at least two names"),
      );
    }
  }
  return (
    <div className="workspace-stack">
      <div className="field">
        <label>
          {slug === "random-number"
            ? t("الحد الأدنى والحد الأعلى", "Minimum and maximum")
            : slug === "random-string"
              ? t("طول النص", "String length")
              : t("الأسماء أو العناصر", "Names or items")}
        </label>
        {slug === "random-string" ? (
          <input
            type="number"
            min="1"
            max="128"
            value={amount}
            onChange={(e) => setAmount(+e.target.value)}
          />
        ) : (
          <textarea
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={
              slug === "random-number"
                ? "1, 100"
                : t("كل اسم في سطر", "One name per line")
            }
          />
        )}
      </div>
      {slug === "team-divider" && (
        <div className="field">
          <label>{t("عدد الفرق", "Number of teams")}</label>
          <input
            type="number"
            min="2"
            max="20"
            value={amount}
            onChange={(e) => setAmount(+e.target.value)}
          />
        </div>
      )}
      <button className="primary-button" onClick={run}>
        {slug === "team-divider"
          ? t("قسّم الفرق", "Divide teams")
          : slug === "random-string"
            ? t("أنشئ النص", "Create string")
            : t("اختيار عشوائي", "Pick randomly")}
      </button>
      {result && (
        <Result>
          <strong className="multiline">{result}</strong>
        </Result>
      )}
    </div>
  );
}

function UsernameGeneratorWorkspace() {
  const { t } = useLocale();
  const [platform, setPlatform] = useState("instagram");
  const [kind, setKind] = useState("mixed");
  const [length, setLength] = useState(12);
  const [seed, setSeed] = useState("");
  const [results, setResults] = useState<string[]>([]);
  const limits: Record<string, { min: number; max: number }> = {
    instagram: { min: 1, max: 30 },
    facebook: { min: 5, max: 50 },
    x: { min: 4, max: 15 },
    telegram: { min: 5, max: 32 },
    other: { min: 3, max: 40 },
  };
  const current = limits[platform];
  const effectiveMin =
    kind === "mixed" ? Math.max(2, current.min) : current.min;
  const safeLength = Math.min(current.max, Math.max(effectiveMin, length));
  const platformOptions = [
    {
      value: "instagram",
      label: "Instagram",
      hint: t("حتى 30 حرفاً", "Up to 30 characters"),
    },
    {
      value: "facebook",
      label: "Facebook",
      hint: t("5 أحرف أو أكثر", "5 characters or more"),
    },
    {
      value: "x",
      label: "X / Twitter",
      hint: t("حتى 15 حرفاً", "Up to 15 characters"),
    },
    {
      value: "telegram",
      label: "Telegram",
      hint: t("من 5 إلى 32 حرفاً", "5 to 32 characters"),
    },
    {
      value: "other",
      label: t("منصة أخرى", "Other platform"),
      hint: t("إعداد مرن", "Flexible settings"),
    },
  ];
  const kindOptions = [
    { value: "mixed", label: t("أحرف وأرقام", "Letters and numbers") },
    { value: "letters", label: t("أحرف فقط", "Letters only") },
    { value: "numbers", label: t("أرقام فقط", "Numbers only") },
  ];

  function generate() {
    const letters = "abcdefghijkmnopqrstuvwxyz";
    const numbers = "0123456789";
    const chars =
      kind === "letters"
        ? letters
        : kind === "numbers"
          ? numbers
          : `${letters}${numbers}`;
    const seedPattern = kind === "letters" ? /[^a-z]/g : /[^a-z0-9]/g;
    const cleanSeed = seed
      .toLowerCase()
      .replace(seedPattern, "")
      .slice(0, safeLength);
    const next = new Set<string>();
    for (let attempt = 0; attempt < 60 && next.size < 6; attempt += 1) {
      let output = kind === "numbers" ? "" : cleanSeed;
      const bytes = crypto.getRandomValues(
        new Uint32Array(Math.max(1, safeLength - output.length)),
      );
      output += Array.from(bytes, (value) => chars[value % chars.length]).join(
        "",
      );
      if (kind === "mixed" && !/\d/.test(output))
        output = `${output.slice(0, -1)}${numbers[bytes[0] % numbers.length]}`;
      if (kind === "mixed" && !/[a-z]/.test(output))
        output = `${letters[bytes[0] % letters.length]}${output.slice(1)}`;
      next.add(`@${output.slice(0, safeLength)}`);
    }
    setResults([...next]);
  }

  return (
    <div className="workspace-stack username-generator">
      <div className="form-grid">
        <div className="field">
          <label>{t("المنصة", "Platform")}</label>
          <CustomSelect
            value={platform}
            options={platformOptions}
            onChange={(value) => {
              setPlatform(value);
              const range = limits[value];
              setLength((currentLength) =>
                Math.min(range.max, Math.max(range.min, currentLength)),
              );
            }}
            label={t("اختر المنصة", "Choose platform")}
          />
        </div>
        <div className="field">
          <label>{t("نوع المعرف", "Username type")}</label>
          <CustomSelect
            value={kind}
            options={kindOptions}
            onChange={setKind}
            label={t("نوع المعرف", "Username type")}
          />
        </div>
        <div className="field full">
          <label>
            {t("كلمة مفضلة (اختياري)", "Preferred word (optional)")}
          </label>
          <input
            value={seed}
            onChange={(event) => setSeed(event.target.value)}
            maxLength={20}
            placeholder={t("مثال: omar أو elpha", "Example: omar or elpha")}
          />
        </div>
      </div>
      <label className="range-field">
        <span>
          {t("عدد الأحرف", "Length")}: <strong>{safeLength}</strong>
        </span>
        <input
          type="range"
          min={effectiveMin}
          max={current.max}
          value={safeLength}
          onChange={(event) => setLength(Number(event.target.value))}
        />
        <small>
          {t(
            `المسموح لهذا الاختيار: من ${effectiveMin} إلى ${current.max}`,
            `Allowed for this selection: ${effectiveMin} to ${current.max}`,
          )}
        </small>
      </label>
      <button className="primary-button" onClick={generate}>
        <Icon name="sparkles" size={18} />
        {t("توليد المعرفات", "Generate usernames")}
      </button>
      {results.length > 0 && (
        <div className="username-results">
          {results.map((result) => (
            <button
              type="button"
              key={result}
              onClick={(event) => copyWithFeedback(result, event.currentTarget)}
            >
              <strong>{result}</strong>
              <span>{t("اضغط للنسخ", "Click to copy")}</span>
              <Icon name="copy" size={17} />
            </button>
          ))}
        </div>
      )}
      <p className="workspace-disclaimer">
        {t(
          "الأداة تقترح معرفات فقط؛ تحقق من توفر المعرف داخل المنصة المختارة.",
          "This tool suggests usernames only. Check availability on the selected platform.",
        )}
      </p>
    </div>
  );
}

function FileSizeWorkspace() {
  const { t } = useLocale();
  const [value, setValue] = useState(1);
  const [unit, setUnit] = useState("MB");
  const bytes = value * ({ KB: 1024, MB: 1048576, GB: 1073741824 }[unit] || 1);
  return (
    <div className="workspace-stack">
      <div className="form-grid">
        <div className="field">
          <label>{t("القيمة", "Value")}</label>
          <input
            type="number"
            min="0"
            value={value}
            onChange={(e) => setValue(+e.target.value)}
          />
        </div>
        <div className="field">
          <label>{t("الوحدة", "Unit")}</label>
          <CustomSelect
            value={unit}
            onChange={setUnit}
            label={t("الوحدة", "Unit")}
            options={["KB", "MB", "GB"].map((item) => ({
              value: item,
              label: item,
            }))}
          />
        </div>
      </div>
      <div className="metric-grid">
        <div>
          <strong>{(bytes / 1024).toLocaleString()}</strong>
          <span>KB</span>
        </div>
        <div>
          <strong>{(bytes / 1048576).toLocaleString()}</strong>
          <span>MB</span>
        </div>
        <div>
          <strong>{(bytes / 1073741824).toLocaleString()}</strong>
          <span>GB</span>
        </div>
      </div>
    </div>
  );
}

export function ToolWorkspace({ slug }: { slug: string }) {
  useEffect(() => {
    const current = JSON.parse(
      localStorage.getItem("minjaz-recent-tools") || "[]",
    ) as string[];
    localStorage.setItem(
      "minjaz-recent-tools",
      JSON.stringify(
        [slug, ...current.filter((item) => item !== slug)].slice(0, 10),
      ),
    );
  }, [slug]);
  if (priorityToolSlugs.includes(slug))
    return <PriorityToolWorkspace slug={slug} />;
  if (formulaToolSlugs.includes(slug))
    return <FormulaToolWorkspace slug={slug} />;
  if (pdfToolSlugs.includes(slug)) return <PdfToolWorkspace slug={slug} />;
  if (printDesignToolSlugs.includes(slug))
    return <PrintDesignWorkspace slug={slug} />;
  if (additionalToolSlugs.includes(slug))
    return <AdditionalToolWorkspace slug={slug} />;
  if (["image-compressor", "image-resizer", "jpg-to-png"].includes(slug))
    return <ImageWorkspace slug={slug} />;
  if (["pdf-merge", "images-to-pdf"].includes(slug))
    return <PdfWorkspace slug={slug} />;
  if (slug === "file-size-converter") return <FileSizeWorkspace />;
  if (["word-counter", "text-cleaner", "case-converter"].includes(slug))
    return <TextWorkspace slug={slug} />;
  if (slug === "local-text-generator") return <LocalTextWorkspace />;
  if (["age-calculator", "date-difference", "work-days"].includes(slug))
    return <DateWorkspace slug={slug} />;
  if (
    [
      "percentage-calculator",
      "discount-calculator",
      "average-calculator",
      "value-comparison",
      "gpa-calculator",
      "salary-calculator",
      "savings-calculator",
      "bill-splitter",
    ].includes(slug)
  )
    return <NumberWorkspace slug={slug} />;
  if (slug === "study-planner") return <StudyWorkspace />;
  if (slug === "task-planner") return <TaskPlannerWorkspace />;
  if (slug === "pomodoro") return <PomodoroWorkspace />;
  if (
    [
      "whatsapp-link",
      "url-encoder",
      "base64",
      "json-formatter",
      "uuid-generator",
    ].includes(slug)
  )
    return <InternetWorkspace slug={slug} />;
  if (slug === "qr-generator") return <AdvancedQrStudio />;
  if (slug === "username-generator") return <UsernameGeneratorWorkspace />;
  if (["password-generator", "password-strength"].includes(slug))
    return <PasswordWorkspace slug={slug} />;
  return <RandomWorkspace slug={slug} />;
}
