import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const canonicalUrl =
  /<link(?=[^>]*\brel=["']canonical["'])(?=[^>]*\bhref=["']https:\/\/adawati\.adawati\.workers\.dev\/?["'])[^>]*>/i;

test("renders the production brand and Cloudflare canonical URL", async () => {
  const html = await readFile(
    new URL("../.next/server/app/index.html", import.meta.url),
    "utf8",
  );

  assert.match(html, /<title>أدواتي \| أدوات رقمية سريعة ومجانية<\/title>/);
  assert.match(html, canonicalUrl);
  assert.match(html, /أدواتي لتجعل حياتك أسهل/);
});
