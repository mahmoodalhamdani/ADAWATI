import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import path from "node:path";
import test from "node:test";

const projectRoot = path.resolve(new URL("..", import.meta.url).pathname);
const read = (relativePath) => readFile(path.join(projectRoot, relativePath), "utf8");

test("public and internal surfaces use the correct ADAWATI logo variants", async () => {
  const [logo, admin, login] = await Promise.all([
    read("app/components/Logo.tsx"),
    read("app/components/AdminDashboard.tsx"),
    read("app/components/AdminLogin.tsx"),
  ]);
  assert.match(logo, /\/brand\/adawati-logo\.webp/);
  assert.match(admin, /\/brand\/adawati-symbol\.png/);
  assert.match(login, /\/brand\/adawati-symbol\.png/);
});

test("metadata, indexing and install surfaces identify ADAWATI", async () => {
  const [layout, manifest, toolPage, seo, registry] = await Promise.all([
    read("app/layout.tsx"),
    read("app/manifest.ts"),
    read("app/tools/[slug]/page.tsx"),
    read("lib/seo-registry.ts"),
    read("lib/registry.ts"),
  ]);
  const source = [layout, manifest, toolPage, seo, registry].join("\n");
  assert.match(source, /أدواتي/);
  assert.match(source, /ADAWATI/);
  assert.match(source, /\/og\.png/);
  assert.match(source, /baseUrl:\s*"https:\/\/adawati\.adawati\.workers\.dev"/);
  assert.match(source, /domain:\s*"adawati\.adawati\.workers\.dev"/);
  assert.doesNotMatch(source, /مِنجاز|MINJAZ/);
});

test("tab and PWA icon files plus the social preview are present", async () => {
  await Promise.all(
    [
      "public/favicon.png",
      "public/favicon-32.png",
      "public/favicon-16.png",
      "public/apple-touch-icon.png",
      "public/icon-192.png",
      "public/icon-512.png",
      "public/brand/adawati-app-icon.png",
      "public/brand/adawati-logo.png",
      "public/brand/adawati-symbol.png",
      "public/brand/adawati-domain-qr.png",
      "public/og.png",
    ].map((relativePath) => access(path.join(projectRoot, relativePath))),
  );
});

test("downloaded artifacts carry the ADAWATI name while legacy storage keys stay compatible", async () => {
  const [pdf, tools, qr, favorites] = await Promise.all([
    read("app/components/PdfToolWorkspaces.tsx"),
    read("app/components/ToolWorkspace.tsx"),
    read("app/components/QrStudio.tsx"),
    read("app/components/FavoriteButton.tsx"),
  ]);
  assert.match(pdf, /adawati-repaired\.pdf/);
  assert.match(tools, /adawati-merged\.pdf/);
  assert.match(qr, /adawati-qr-/);
  assert.match(favorites, /minjaz-favorites/);
});

test("the hero wordmark and tagline stay visually centered in Arabic and English", async () => {
  const css = await read("app/globals.css");
  const [page, chrome] = await Promise.all([
    read("app/page.tsx"),
    read("app/components/SiteChrome.tsx"),
  ]);
  assert.match(css, /\.brand-logo--hero\s*\{[\s\S]*?justify-content:\s*center;/);
  assert.match(css, /\.brand-logo--hero \.brand-logo__crest\s*\{[\s\S]*?width:\s*156px;/);
  assert.match(css, /\.tagline\s*\{[\s\S]*?width:\s*100%;[\s\S]*?text-align:\s*center;/);
  assert.match(page, /t\("أدواتي لتجعل حياتك أسهل",\s*"ADAWATI makes your life easier"\)/);
  assert.doesNotMatch(page, /popular-grid|trust-strip/);
  assert.doesNotMatch(chrome, /site-footer|footer-grid|footer-bottom/);
});
